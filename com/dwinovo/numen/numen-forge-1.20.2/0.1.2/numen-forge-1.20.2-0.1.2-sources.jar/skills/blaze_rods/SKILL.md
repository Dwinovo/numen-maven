---
name: blaze_rods
description: Locate a Nether fortress, fight blazes at their spawner, and collect ≥7 blaze rods (each grinds into 2 blaze powder; 12 eyes of ender need 12 powder = 6 rods, +1 margin).
---

# Skill: blaze_rods

Phase 3 of the dragon route. Eyes of ender need blaze powder; `locate_structure` means you waste zero eyes on throwing, so **7 rods (14 powder) is enough** with margin.

## Done when

- `get_self_status` shows **≥7 blaze_rod**
- You're back at the Nether portal (or another safe spot), ready for phase 4

## Finding a fortress

1. **`locate_structure("minecraft:fortress")`** — exact coordinates, direction and distance in one call (must be called while IN the Nether). Don't wander looking for it.
2. `goto` the returned x/z (the returned y is approximate — travel around y≈70), then `scan_blocks(nether_bricks, radius=128)` to find the actual corridors; the structure spans many y-levels.
3. Beware the lookalike: blackstone with gold = **bastion** (`minecraft:bastion_remnant`) — different structure, avoid; its piglin brutes attack on sight.
4. Track your portal's coordinates so you can navigate home.

## Blazes

- 20 HP, fly/hover, volley of 3 fireballs (~5 dmg each + sets you on fire) every ~3s at line of sight, fire-immune.
- They spawn from **blaze spawners**: small fortress rooms with a caged spawner block, plus naturally on fortress bridges.
- **Carry a bow and ~6 arrows per blaze.** Blazes hover, so `attack` shoots the ones it cannot reach and closes on the ones it can — you do not pick. A diamond sword alone still works when arrows run out (3 hits kill) as long as you carry plenty of cooked food for the fireball damage; what you control is what is in the inventory, not the range.

## Farming loop

1. Find the spawner room (`scan_blocks(spawner)` inside the fortress helps).
2. `scan_nearby_entities` → `attack({"entity_ids":[id]})` in small batches.
3. `collect_items` — rods drop on the floor; grab them before they burn in nearby lava... rods are fire-immune items, but lava destroys them. Don't let drops land in lava.
4. `get_self_status` between batches: HP ≤ 8 → `goto` out of spawner range, eat, return.
5. Repeat until `get_self_status` shows ≥7 rods. Drop rate is 0–1 per kill (avg 0.5) → expect **~14 kills**, more if unlucky.

**Do not mine the spawner** — you need it spawning blazes until the count is met. (You *may* `build` a block or two to wall off excess sight-lines if too many blazes volley at once.)

## Hazards

- **Wither skeletons** roam fortress corridors; their hits apply Wither (damage over time). scan them and pass one runtime ID at a time to `attack`, or stay out of reach.
- Fortress bridges have no railings; knockback over the edge usually lands in lava. Fight away from edges (`combat_basics` positioning rules).

## What to load next

≥7 rods banked → mark phase 3 `completed`, then `load_skill(name="ender_pearls")`. Warped forests (teal trees, dense endermen) are worth noting on your way out — phase 4 can use them.
