package com.dwinovo.numen.pathing.drive;

import com.dwinovo.numen.pathing.plan.WorldView;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_4076;

/**
 * 活世界:执行复核读的视图,前提函数在它上面判与在搜索快照上判是同一份。只读已经加载的区块,不触发加载或生成;没加载的
 * 列由 {@link #isLoaded} 答否,执行碰到它们就停在边上,不往里走。
 *
 * <p>只在世界所在的线程上用。
 */
public final class LiveWorld implements WorldView {

    private static final class_2680 VOID = class_2246.field_10243.method_9564();

    private final class_3218 level;

    public LiveWorld(class_3218 level) {
        this.level = level;
    }

    public class_3218 level() {
        return level;
    }

    /** {@code (x, z)} 这一列所在的区块已经加载。 */
    public boolean isLoaded(int x, int z) {
        return chunk(x, z) != null;
    }

    private class_2818 chunk(int x, int z) {
        return level.method_14178().method_21730(class_4076.method_18675(x), class_4076.method_18675(z));
    }

    @Override
    public class_2680 method_8320(class_2338 pos) {
        class_2818 chunk = chunk(pos.method_10263(), pos.method_10260());
        return chunk == null ? VOID : chunk.method_8320(pos);
    }

    /** 没加载的区块读出来是虚空空气,建筑高度之外是空气;其余看区段自己数的非空气方块数。 */
    @Override
    public boolean airSection(int x, int y, int z) {
        class_2818 chunk = chunk(x, z);
        if (chunk == null) {
            return true;
        }
        int index = chunk.method_31602(y);
        return index < 0 || index >= chunk.method_32890() || chunk.method_38259(index).method_38292();
    }

    @Override
    public class_3610 method_8316(class_2338 pos) {
        return method_8320(pos).method_26227();
    }

    @Override
    public class_2586 method_8321(class_2338 pos) {
        class_2818 chunk = chunk(pos.method_10263(), pos.method_10260());
        return chunk == null ? null : chunk.method_8321(pos);
    }

    @Override
    public int method_31605() {
        return level.method_31605();
    }

    @Override
    public int method_31607() {
        return level.method_31607();
    }

    @Override
    public class_2784 border() {
        return level.method_8621();
    }

    @Override
    public boolean waterEvaporates(class_2338 pos) {
        return level.method_75598().method_75697(net.minecraft.class_12206.field_63755, pos);
    }
}
