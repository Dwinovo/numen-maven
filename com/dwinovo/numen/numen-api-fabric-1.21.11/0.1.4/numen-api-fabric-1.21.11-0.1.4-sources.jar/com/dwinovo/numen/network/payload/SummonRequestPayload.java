package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.network.Wire;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client → Server: the owner asked to summon a companion by name from the panel's
 * "+" button. Mirrors the {@code /numen player summon} command — summon is
 * idempotent per (owner, name), so re-summoning an existing name just wakes it.
 *
 * <p>名字限定 Minecraft 官方命名规则(3~16 位英文/数字/下划线)。皮肤来源二选一:
 * {@code skinValue} 非空 = 客户端皮肤库里 MineSkin 代签好的 Mojang 签名数据,直接
 * 采用(签名自验证,客户端伪造不了);为空 = <b>名字就是皮肤来源</b>,服务端异步查
 * 同名正版玩家,查到穿其皮肤,查不到静默回落默认皮肤(日志可查,不打扰玩家)。
 */
public record SummonRequestPayload(String name, String skinValue, String skinSig, boolean creative)
        implements class_8710 {

    public static final int MAX_NAME = 16;

    public static final class_9154<SummonRequestPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "summon_request"));

    public static final class_9139<ByteBuf, SummonRequestPayload> STREAM_CODEC =
            class_9139.method_56905(
                    class_9135.method_56364(MAX_NAME), SummonRequestPayload::name,
                    // Mojang 签名的 textures(带皮肤/披风 URL 的 base64 JSON,实测 1KB 上下;签名约 700B):长度是 Mojang 的,
                    // 不是这个包的,整包的大小由 Wire 量
                    Wire.TO_SERVER.text(), SummonRequestPayload::skinValue,
                    Wire.TO_SERVER.text(), SummonRequestPayload::skinSig,
                    class_9135.field_48547, SummonRequestPayload::creative,
                    SummonRequestPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** 正在异步召唤中的 owner/name 键——皮肤查询窗口内吃掉重复请求,防双击造重。 */
    private static final java.util.Set<String> SPAWNING =
            java.util.concurrent.ConcurrentHashMap.newKeySet();

    /** Server main thread. */
    public static void handle(SummonRequestPayload p, class_3222 owner) {
        String name = p.name() == null ? "" : p.name().trim();
        if (!com.dwinovo.numen.entity.MojangSkins.validName(name)) return;   // 服务端权威校验
        var server = owner.method_51469().method_8503();
        // 重名闸:同名玩家已在线(真人/别的主人的同伴)一律拒绝——
        // 例外是自己的同名同伴(那是幂等唤醒/换肤,summon 内部处理)。
        var online = server.method_3760().method_14566(name);
        boolean ownSameName = online instanceof com.dwinovo.numen.entity.NumenPlayer np
                && np.isOwnedByPlayer(owner.method_5667());
        if (online != null && !ownSameName) {
            owner.method_64398(net.minecraft.class_2561.method_43469(
                    com.dwinovo.numen.data.ModLanguageData.Keys.NOTICE_NAME_TAKEN, name));
            return;
        }
        // 登录中闸:异步皮肤查询窗口内(几秒)重复点击不许再召。
        String spawnKey = owner.method_5667() + "/" + name;
        if (!SPAWNING.add(spawnKey)) return;
        // 皮肤一律由客户端备好(自定义库条目或它在本机查到的正版档案),服务端
        // 不再查询:那条路吃 JVM 默认网络、绕开玩家的代理,国内经常静默超时。
        // 签名数据是 Mojang 自验证的,伪造不了,所以照单收下是安全的。
        String value = p.skinValue() == null ? "" : p.skinValue();
        var skin = value.isBlank() ? null
                : new com.dwinovo.numen.entity.MojangSkins.Skin(value,
                        p.skinSig() == null ? "" : p.skinSig());
        try {
            class_3218 level = (class_3218) owner.method_51469();
            var body = Companions.summon(server, owner.method_5667(), name, level, owner.method_73189(), skin);
            Companions.applyGameMode(owner, body, p.creative());
            Companions.syncRosterToOwner(server, owner);   // push the new roster to the owner
        } finally {
            SPAWNING.remove(spawnKey);
        }
    }
}
