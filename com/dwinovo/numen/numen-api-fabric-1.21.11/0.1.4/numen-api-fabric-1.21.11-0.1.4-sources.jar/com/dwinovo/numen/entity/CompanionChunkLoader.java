package com.dwinovo.numen.entity;

import net.minecraft.class_1923;
import net.minecraft.class_3218;
import net.minecraft.class_3230;

/**
 * Keeps a small, self-expiring pad of chunks loaded and ticking around a companion,
 * so a {@link NumenPlayer} can path / mine / fight away from any real player WITHOUT
 * being a full client viewer.
 *
 * <h2>Why this exists</h2>
 * A vanilla {@link net.minecraft.class_3222} loads chunks through
 * {@code DistanceManager.addPlayer}, which {@code ChunkMap.updatePlayerStatus} gates on
 * {@code !skipPlayer(player)}. {@link com.dwinovo.numen.mixin.ChunkMapCompanionMixin} forces
 * {@code skipPlayer == true} for companions — that strips the wasted client chunk-tracking /
 * packet machinery (a fake player has no client), but as a side effect also strips the player
 * loading ticket. This class adds the loading back, but <b>bounded</b>: a {@value #RADIUS}-chunk
 * region ticket (3×3 {@code ENTITY_TICKING} around her, a 7×7 loaded pad) instead of a real player's
 * whole simulation-distance sphere. Remote autonomy is preserved; the per-companion footprint is
 * a fixed, small pad rather than full-player weight.
 *
 * <h2>Self-cleaning — no explicit release</h2>
 * The ticket carries a {@value #TIMEOUT_TICKS}-tick timeout and is re-stamped on every
 * {@link #refresh}. {@code DistanceManager.addTicket} resets a re-added ticket's created-tick, so
 * while the companion ticks the pad stays alive; the instant it stops ticking — dormancy, death,
 * despawn, chunk unload, even a crash — the ticket simply times out. Nothing is leaked and nothing
 * has to be remembered and removed. Companions sharing a chunk share one ticket, kept alive by
 * whoever is still refreshing it, so a departing companion never yanks the pad out from under one
 * that stayed.
 */
public final class CompanionChunkLoader {

    /**
     * Region-ticket radius. i = 3 → centre chunk level 30, its ring level 31: the companion's chunk AND the eight
     * around it are ENTITY_TICKING (3×3), a 7×7 pad is loaded. Whatever she can touch or fights over (reach ≤ 5
     * blocks, the combat field 12) can lie across a chunk border; an entity in a chunk that is loaded but not
     * entity-ticking is frozen — a mob she hits there keeps its hurt time forever, so she never gets a second
     * swing in and it never dies.
     */
    private static final int RADIUS = 3;

    /**
     * Ticket timeout in ticks. The refresh re-adds the ticket at half this interval (or immediately
     * on a chunk crossing), so a live companion always renews with a full margin; 40 ticks also
     * bounds how long a departed companion's pad lingers before it unloads (~2 s).
     */
    private static final int TIMEOUT_TICKS = 40;

    /**
     * 1.21.5 起 {@code TicketType} 是不带泛型的 record,1.21.9 又把「是否入档 + 用途」
     * 合并成一个 {@code flags} 位图。这里直接构造:超时同为 {@value #TIMEOUT_TICKS}
     * tick,标志取 {@code FLAG_LOADING | FLAG_SIMULATION}(旧代
     * {@code TicketUse.LOADING_AND_SIMULATION},即「加载 + 实体 tick」),不置
     * {@code FLAG_PERSIST} —— {@code TicketStorage.packTickets} 只序列化 persist 的票据,
     * 所以这张票不入档,也就不需要进 {@code BuiltInRegistries.TICKET_TYPE}(未注册时
     * {@code Util.getRegisteredName} 回落 "[unregistered]",只影响 toString)。
     */
    private static final class_3230 TICKET = new class_3230(
            TIMEOUT_TICKS, class_3230.field_61097 | class_3230.field_61098);

    private CompanionChunkLoader() {}

    /** 运行期总开关(诊断 A/B 用):关掉后 {@link #refresh} 变空操作,已有票据 40 tick 内自然过期。
     *  服务端主线程读写;volatile 仅为命令线程可见性兜底。 */
    public static volatile boolean enabled = true;

    /** 距超时刷新的间隔:取 {@link #TIMEOUT_TICKS} 的一半,对到期留一整倍裕量。 */
    private static final int REFRESH_TICKS = TIMEOUT_TICKS / 2;

    /** 每同伴的 pad 状态:上一次的中心 chunk + 距下一次超时续票的倒计时。服务端线程独占;
     *  条目数 ≤ 本次运行出现过的同伴数,不清理。 */
    private static final class PadState {
        long chunk = Long.MIN_VALUE;
        int countdown;
    }

    private static final java.util.Map<java.util.UUID, PadState> states = new java.util.HashMap<>();

    /**
     * Maintain the loader pad. Called every server tick, but the actual ticket op is amortised:
     * a ticket is (re-)added only when the companion CROSSED into a new chunk (re-centre the pad
     * immediately) or the {@link #REFRESH_TICKS} countdown elapsed (keep the timeout alive with a
     * full margin). In the steady state this is one countdown decrement per tick and one ticket op
     * per {@value #REFRESH_TICKS} ticks — the ticket's own timeout still guarantees cleanup if the
     * companion stops ticking for any reason.
     */
    public static void refresh(NumenPlayer companion) {
        if (!enabled) {
            return;
        }
        if (companion.method_51469() instanceof class_3218 level) {
            class_1923 pos = companion.method_31476();
            long packed = pos.method_8324();
            PadState st = states.computeIfAbsent(companion.method_5667(), k -> new PadState());
            boolean crossed = st.chunk != packed;
            if (!crossed && --st.countdown > 0) {
                return;   // 票据仍在裕量期内,无事可做
            }
            if (crossed) {
                // pad 中心迁移打点(debug 级:诊断用,走路的同伴几秒跨一个 chunk,不该刷正式日志;
                // 需要时开 debug.log 或调日志级别即可看到)。
                com.dwinovo.numen.Constants.LOG.debug("[numen-pad] {} pad center -> chunk {},{}",
                        companion.method_5477().getString(), pos.field_9181, pos.field_9180);
            }
            st.chunk = packed;
            st.countdown = REFRESH_TICKS;
            // 1.21.5:addRegionTicket(type,pos,radius,value) → addTicketWithRadius(type,pos,radius)。
            // 票级算法两代一致(ChunkLevel.byStatus(FULL) - 半径),重复添加同型同级票照旧 resetTicksLeft()。
            level.method_14178().method_66009(TICKET, pos, RADIUS);
        }
    }
}
