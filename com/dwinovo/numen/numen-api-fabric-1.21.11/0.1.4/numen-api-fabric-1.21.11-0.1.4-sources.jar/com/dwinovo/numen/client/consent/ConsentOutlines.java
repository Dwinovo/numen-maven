package com.dwinovo.numen.client.consent;

import com.dwinovo.numen.client.debug.LineBox;
import com.dwinovo.numen.network.payload.ConsentRequestPayload;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

/**
 * 世界里给挂着的征询涉及的方块与实体描轮廓——主人抬头就知道她问的是哪几块、哪一只。
 * 只照 {@link ConsentCards} 画,请求撤回轮廓就没了。与寻路调试覆盖层同一条世界渲染管线。
 */
public final class ConsentOutlines {

    private static final float R = 1.0f;
    private static final float G = 0.72f;
    private static final float B = 0.1f;

    private ConsentOutlines() {}

    /** 世界渲染钩子入口(半透明方块阶段之后;poseStack 为世界空间)。 */
    public static void render(class_4587 poseStack, class_4184 camera) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || ConsentCards.all().isEmpty()) {
            return;
        }
        class_243 cam = camera.method_71156();
        class_4597.class_4598 buffers = mc.method_22940().method_23000();
        class_4588 vc = buffers.method_73477(class_12249.method_76015());
        poseStack.method_22903();
        poseStack.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);
        for (ConsentCards.Card card : ConsentCards.all()) {
            ConsentRequestPayload request = card.request();
            for (long packed : request.blocks()) {
                class_2338 pos = class_2338.method_10092(packed);
                LineBox.draw(vc, poseStack.method_23760(),
                        pos.method_10263() - 0.01, pos.method_10264() - 0.01, pos.method_10260() - 0.01,
                        pos.method_10263() + 1.01, pos.method_10264() + 1.01, pos.method_10260() + 1.01, R, G, B, 1.0f);
            }
            for (int id : request.entities()) {
                class_1297 entity = mc.field_1687.method_8469(id);
                if (entity != null) {
                    class_238 box = entity.method_5829().method_1014(0.05);
                    LineBox.draw(vc, poseStack.method_23760(), box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324,
                            R, G, B, 1.0f);
                }
            }
        }
        poseStack.method_22909();
        buffers.method_22994(class_12249.method_76015());
    }
}
