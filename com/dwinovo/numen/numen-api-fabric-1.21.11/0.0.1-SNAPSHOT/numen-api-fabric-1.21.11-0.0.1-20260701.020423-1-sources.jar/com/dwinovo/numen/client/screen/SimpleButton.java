package com.dwinovo.numen.client.screen;

import com.dwinovo.numen.Constants;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/**
 * The Numen button: a vanilla GUI sprite (nine-slice, so it stretches to any width
 * with a crisp border), drawn with {@code blitSprite} like vanilla widgets — idle /
 * highlighted / disabled states from three sprites under
 * {@code textures/gui/sprites/button*.png}. Label is flat (shadowless) + coloured.
 */
public final class SimpleButton extends class_4185 {

    private static final class_2960 IDLE = sprite("button");
    private static final class_2960 HOVER = sprite("button_highlighted");
    private static final class_2960 DISABLED = sprite("button_disabled");

    private static class_2960 sprite(String name) {
        return class_2960.method_60655(Constants.MOD_ID, name);
    }

    /** Optional centered icon sprite; when set it replaces the text label (e.g. the eye toggle). */
    private class_2960 icon;

    public SimpleButton(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 onPress) {
        super(x, y, width, height, message, onPress,
                defaultNarrationSupplier -> defaultNarrationSupplier.get());
    }

    /** Draw a centered icon sprite instead of a text label. Returns {@code this} for chaining. */
    public SimpleButton icon(class_2960 icon) {
        this.icon = icon;
        return this;
    }

    @Override
    protected void method_75752(class_332 g, int mouseX, int mouseY, float partialTick) {
        int x = method_46426(), y = method_46427(), w = method_25368(), h = method_25364();
        boolean hovered = field_22763 && method_25367();
        class_2960 sprite = !field_22763 ? DISABLED : (hovered ? HOVER : IDLE);
        g.method_52706(net.minecraft.class_10799.field_56883, sprite, x, y, w, h);

        if (icon != null) {   // icon button: a centered square sprite, no text label
            int s = Math.min(w - 4, h - 2);
            g.method_52706(net.minecraft.class_10799.field_56883, icon, x + (w - s) / 2, y + (h - s) / 2, s, s);
            return;
        }

        class_327 font = class_310.method_1551().field_1772;
        int color = field_22763 ? UiTheme.current().text() : 0xFF6E5E48;
        int tw = font.method_27525(method_25369());
        Nb.text(g, font, method_25369(), x + (w - tw) / 2, y + (h - 8) / 2, color);   // flat, coloured
    }
}
