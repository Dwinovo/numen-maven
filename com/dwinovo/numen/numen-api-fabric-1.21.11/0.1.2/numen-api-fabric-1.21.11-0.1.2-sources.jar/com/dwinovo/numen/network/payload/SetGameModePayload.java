package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * Client → Server:编辑卡把一只<b>已创建</b>同伴的游戏模式切到生存/创造。
 * 权限门与召唤同一道({@link Companions#applyGameMode}):创造要主人有
 * gamemode 权限或本人在创造。改完立刻重推名册,编辑卡的模式格按新真相显示。
 */
public record SetGameModePayload(UUID uuid, boolean creative) implements class_8710 {

    public static final class_9154<SetGameModePayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "set_game_mode"));

    public static final class_9139<class_9129, SetGameModePayload> STREAM_CODEC =
            class_9139.method_56435(
                    class_4844.field_48453, SetGameModePayload::uuid,
                    class_9135.field_48547, SetGameModePayload::creative,
                    SetGameModePayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static void handle(SetGameModePayload p, class_3222 owner) {
        MinecraftServer server = ((class_3218) owner.method_51469()).method_8503();
        if (server == null || p.uuid() == null) return;
        NumenPlayer body = NumenPlayer.findByUuid(server, p.uuid());
        if (body == null || !body.isOwnedByPlayer(owner.method_5667())) {
            return;   // 不在场(休眠/死亡)或不是他的:模式住在活体上,没有活体没有可改的
        }
        Companions.applyGameMode(owner, body, p.creative());
        Companions.syncRosterToOwner(server, owner);
    }
}
