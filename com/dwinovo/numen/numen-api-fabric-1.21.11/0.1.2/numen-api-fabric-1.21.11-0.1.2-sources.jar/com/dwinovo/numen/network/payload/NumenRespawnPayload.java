package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: a companion has respawned at the owner's side after dying — both the same-session
 * timed recovery and the at-login recovery for a companion that died while the owner was away. Carries
 * the {@code cause} so the brain always learns WHY it died, even when a logout wiped the client's
 * in-memory death state. The owner's {@link com.dwinovo.numen.client.agent.EntityAgentLoop} is created
 * if needed and reawakened with a death {@code <event>}.
 */
public record NumenRespawnPayload(UUID entityUuid, String cause) implements class_8710 {

    public static final class_9154<NumenRespawnPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "numen_respawn"));

    public static final class_9139<class_9129, NumenRespawnPayload> STREAM_CODEC =
            class_9139.method_56435(
                    class_4844.field_48453, NumenRespawnPayload::entityUuid,
                    class_9135.field_48554, NumenRespawnPayload::cause,
                    NumenRespawnPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that).
     *  getOrCreate (not get): after a logout the loop may not exist yet — make it so the death event lands. */
    public static void handle(NumenRespawnPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.respawn.accept(p);
    }
}
