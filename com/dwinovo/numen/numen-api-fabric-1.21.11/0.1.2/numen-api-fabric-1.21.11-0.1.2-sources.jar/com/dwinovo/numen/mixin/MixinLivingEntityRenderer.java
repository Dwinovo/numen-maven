package com.dwinovo.numen.mixin;

import com.dwinovo.numen.client.hud.SpeechBubbleRenderer;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 头顶气泡的渲染入口:生物实体提交尾部,与名牌同一条管线——这是光影
 * /着色器正确处理的路径(世界渲染阶段的裸几何在着色器下会被吃掉)。
 * 没有气泡的实体(包括所有真人玩家)一次 map 查询即返回,零开销。
 *
 * <p>1.21.2+ 的渲染状态化改造:{@code PlayerRenderer} 不再自己实现
 * 绘制,统一落在 {@code LivingEntityRenderer} 上,入参从实体换成了渲染
 * 状态。1.21.9+ 又把即时绘制换成提交式管线:挂载点随之从
 * {@code render(状态, PoseStack, MultiBufferSource, int)} 移到
 * {@code submit(状态, PoseStack, SubmitNodeCollector, CameraRenderState)},
 * 玩家状态类也改名 {@code PlayerRenderState} → {@code AvatarRenderState}。
 * 仍靠状态类型筛出玩家、再用状态里的实体网络 id 取回本体——
 * 位姿时机与旧代完全一致(TAIL 处 poseStack 已 pop 回实体原点)。
 */
@Mixin(class_922.class)
public abstract class MixinLivingEntityRenderer {

    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;"
                    + "Lcom/mojang/blaze3d/vertex/PoseStack;"
                    + "Lnet/minecraft/client/renderer/SubmitNodeCollector;"
                    + "Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At("TAIL"))
    private void numen$speechBubble(class_10042 state, class_4587 poseStack,
                                    class_11659 collector, class_12075 camera,
                                    CallbackInfo ci) {
        if (!(state instanceof class_10055 player)) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        class_1297 body = mc.field_1687.method_8469(player.field_53528);
        if (body instanceof class_742 p) {
            SpeechBubbleRenderer.render(p, poseStack, collector, camera);
        }
    }
}
