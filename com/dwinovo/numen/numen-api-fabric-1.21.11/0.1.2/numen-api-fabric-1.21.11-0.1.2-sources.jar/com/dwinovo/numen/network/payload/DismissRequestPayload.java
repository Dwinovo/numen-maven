package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.CompanionRegistry;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * Client → Server: the owner asked to permanently delete a companion from the panel (rail ✕ → confirm).
 * Like a death — the live body drops its whole inventory at its feet — then it's dismissed for good
 * (registry entry removed, won't return on login). A dormant (unloaded) companion has no body to drop
 * from, so it's just forgotten (its orphaned {@code .dat} keeps the items but nothing respawns it).
 */
public record DismissRequestPayload(UUID uuid) implements class_8710 {

    public static final class_9154<DismissRequestPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "dismiss_request"));

    public static final class_9139<class_9129, DismissRequestPayload> STREAM_CODEC =
            class_9139.method_56434(class_4844.field_48453, DismissRequestPayload::uuid, DismissRequestPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Server main thread. */
    public static void handle(DismissRequestPayload p, class_3222 owner) {
        MinecraftServer server = ((class_3218) owner.method_51469()).method_8503();
        if (server == null || p.uuid() == null) return;

        NumenPlayer body = NumenPlayer.findByUuid(server, p.uuid());
        if (body != null) {
            if (!body.isOwnedByPlayer(owner.method_5667())) return;   // not the caller's companion
            body.method_31548().method_7388();                        // death-style: drop everything at its feet
            Companions.dismiss(server, body);                     // despawn + forget (no respawn)
        } else {
            // 休眠 / 没加载——先按注册表验归属,再除名。走 Companions.forget 而不是直接
            // reg.remove:除名和通知客户端是同一件事的两半,分开写迟早漏一半。
            CompanionRegistry.Entry e = CompanionRegistry.get(server).find(p.uuid());
            if (e == null || !e.owner().equals(owner.method_5667())) return;
            Companions.forget(server, owner.method_5667(), java.util.List.of(p.uuid()));
        }
    }
}
