package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: answer to {@link LocateNumenPayload}. One snapshot per
 * requested UUID — position, dimension and HP for owned + loaded companions,
 * {@code found=false} otherwise. The client drops them into
 * {@link ClientNumenLocations} for the roster panel / vitals strip to read.
 */
public record NumenLocationsPayload(List<Snapshot> snapshots) implements class_8710 {

    /**
     * Wire shape of one located (or not) companion. {@code loaded=false} with
     * {@code found=true} means "asleep in unloaded chunks at its last known
     * position" — position/dimension are valid, vitals are not.
     */
    public record Snapshot(UUID uuid, boolean found, boolean loaded,
                           double x, double y, double z,
                           String dimension, float hp, float maxHp) {

        public static Snapshot notFound(UUID uuid) {
            return new Snapshot(uuid, false, false, 0, 0, 0, "", 0, 0);
        }

        /** A live, ticking companion. */
        public static Snapshot live(UUID uuid, double x, double y, double z,
                                    String dimension, float hp, float maxHp) {
            return new Snapshot(uuid, true, true, x, y, z, dimension, hp, maxHp);
        }

        /** Unloaded — last known position from the persistent index. */
        public static Snapshot lastSeen(UUID uuid, double x, double y, double z, String dimension) {
            return new Snapshot(uuid, true, false, x, y, z, dimension, 0, 0);
        }

        // StreamCodec.composite 上限 12 字段(1.21.11),装下本 record 的 9 个;线格式与
        // 逐字段手写完全一致(同序同码,writeUtf(256) ≡ stringUtf8(256))。
        static final class_9139<class_9129, Snapshot> CODEC =
                class_9139.method_67079(
                        class_4844.field_48453, Snapshot::uuid,
                        class_9135.field_48547, Snapshot::found,
                        class_9135.field_48547, Snapshot::loaded,
                        class_9135.field_48553, Snapshot::x,
                        class_9135.field_48553, Snapshot::y,
                        class_9135.field_48553, Snapshot::z,
                        class_9135.method_56364(256), Snapshot::dimension,
                        class_9135.field_48552, Snapshot::hp,
                        class_9135.field_48552, Snapshot::maxHp,
                        Snapshot::new);
    }

    public static final class_9154<NumenLocationsPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "numen_locations"));

    public static final class_9139<class_9129, NumenLocationsPayload> STREAM_CODEC =
            class_9139.method_56434(
                    Snapshot.CODEC.method_56433(class_9135.method_58000(LocateNumenPayload.MAX_UUIDS)),
                    NumenLocationsPayload::snapshots,
                    NumenLocationsPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenLocationsPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.locations.accept(p);
    }
}
