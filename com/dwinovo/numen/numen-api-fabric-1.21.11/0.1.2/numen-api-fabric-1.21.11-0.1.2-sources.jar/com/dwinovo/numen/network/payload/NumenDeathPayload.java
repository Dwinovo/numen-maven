package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: an Numen body died for good. The owner's client-side
 * {@link com.dwinovo.numen.client.agent.EntityAgentLoop} must stop — a dead
 * companion has no body to act through, so it must never call the LLM again.
 *
 * <h2>Why a dedicated signal</h2>
 * Without it, a loop whose body just died keeps dispatching tools and gets back
 * misleading {@code entity not found} / {@code not loaded on client} errors,
 * which the LLM misreads as a transient sync glitch and retries until the loop
 * guard trips. This payload makes death explicit: the loop is hard-stopped and
 * disposed, so no further LLM turns happen.
 *
 * <h2>Death is recoverable (not disposed)</h2>
 * The companion respawns at its owner after a delay (see {@link NumenRespawnPayload}), so the loop
 * is SUSPENDED, not disposed: {@code onEntityDied} resolves any in-flight tool calls with the death
 * cause (so the conversation stays valid and the brain learns WHY it stopped) and latches it idle.
 * {@code cause} is the vanilla death message ("X was slain by a zombie") for that tool result.
 */
public record NumenDeathPayload(UUID entityUuid, String cause)
        implements class_8710 {

    public static final class_9154<NumenDeathPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "numen_death"));

    public static final class_9139<class_9129, NumenDeathPayload> STREAM_CODEC =
            class_9139.method_56435(
                    class_4844.field_48453, NumenDeathPayload::entityUuid,
                    class_9135.field_48554, NumenDeathPayload::cause,
                    NumenDeathPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenDeathPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.death.accept(p);
    }
}
