package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: 一条进同伴输入队列的条目。
 *
 * <p>它就是 {@code EventQueue.Entry} 的线上形状——四个字段一个不少:
 *
 * <ul>
 *   <li>{@code entryType} —— 查类型表(拼给模型的样子、进不进聊天流、打断时清不清)。
 *       第三方内容包注册了新类型,这条通道不用改;</li>
 *   <li>{@code ts} —— <b>事发的真实时刻</b>,不是收到的时刻。主人离线期间攒下的事
 *       补发时,少了它她会把三小时前的事当成刚发生的;</li>
 *   <li>{@code urgent} —— 她不知道就会做错事。到了队列会立刻带走攒的一切开一轮
 *       (除非队列锁着)。</li>
 * </ul>
 *
 * <p>消费时机<b>不由发送方决定</b>:队列按自己的规则(急件 / 攒够条数 / 攒够时长)
 * 说了算。
 */
public record NumenEventPayload(UUID entityUuid, String entryType, String text, long ts, boolean urgent)
        implements class_8710 {

    public static final class_9154<NumenEventPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "numen_event"));

    public static final class_9139<class_9129, NumenEventPayload> STREAM_CODEC =
            class_9139.method_56906(
                    class_4844.field_48453, NumenEventPayload::entityUuid,
                    class_9135.method_56364(64), NumenEventPayload::entryType,
                    class_9135.field_48554, NumenEventPayload::text,
                    class_9135.field_48551, NumenEventPayload::ts,
                    class_9135.field_48547, NumenEventPayload::urgent,
                    NumenEventPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenEventPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.event.accept(p);
    }
}
