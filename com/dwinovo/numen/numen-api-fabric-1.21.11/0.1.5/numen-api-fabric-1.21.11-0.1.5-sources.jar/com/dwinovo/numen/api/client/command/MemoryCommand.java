package com.dwinovo.numen.api.client.command;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import net.minecraft.class_1074;

/** {@code /memory} —— 打开她资料页的记忆一节:看全部札记,新增、修改、删除。 */
final class MemoryCommand implements PageCommand {

    @Override
    public String name() {
        return "memory";
    }

    @Override
    public String description() {
        return class_1074.method_4662(Keys.CMD_MEMORY);
    }

    @Override
    public boolean touchesContext() {
        return true;
    }

    @Override
    public Page page() {
        return Page.MEMORY;
    }
}
