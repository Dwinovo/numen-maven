package com.dwinovo.numen.api.client.command;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import net.minecraft.class_1074;
import com.dwinovo.numen.api.client.agent.RemoteCompanion;

/**
 * {@code /compact [关注点]} —— 整理记忆;带了关注点,摘要就特别留意它。
 *
 * <p>可用性问 {@link RemoteCompanion#compactProblem()},那是唯一的判据。补全行会把
 * 理由原样显示出来——从前那颗按钮只会灰着,不说为什么。
 */
final class CompactCommand implements ChatCommand {

    @Override
    public String name() {
        return "compact";
    }

    @Override
    public String description() {
        return class_1074.method_4662(Keys.LOOP_COMPACT);
    }

    @Override
    public String argHint() {
        return class_1074.method_4662(Keys.CMD_COMPACT_ARGS);
    }

    @Override
    public boolean touchesContext() {
        return true;
    }

    @Override
    public String unavailable(RemoteCompanion loop) {
        return loop == null || loop.compactProblem() == null ? null : class_1074.method_4662(loop.compactProblem());
    }

    @Override
    public String run(RemoteCompanion loop, String args) {
        String refused = loop.requestCompact(args);
        if (refused != null) {
            return class_1074.method_4662(refused);
        }
        // 空闲时进队列就当场走掉了,忙的时候才真排着——照实说哪一种。
        return loop.status().phase() == com.dwinovo.numen.api.agent.loop.Phase.COMPACT
                ? class_1074.method_4662(Keys.CMD_COMPACT_STARTED) : class_1074.method_4662(Keys.CMD_COMPACT_QUEUED);
    }
}
