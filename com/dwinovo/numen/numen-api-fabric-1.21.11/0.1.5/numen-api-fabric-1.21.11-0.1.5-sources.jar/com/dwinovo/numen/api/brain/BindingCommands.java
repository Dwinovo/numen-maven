package com.dwinovo.numen.api.brain;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.entity.CompanionRegistry;
import com.dwinovo.numen.api.library.Library;
import com.dwinovo.numen.api.library.LibraryHub;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * {@code /numen companion <她> profile|persona|voice [<条目>]}:给她换一项绑定,面板编辑卡的另一种按法,给没装客户端的
 * 主人用(装了的也能用)。条目写 {@code 命名空间:名字},补全列他看得到的"服务器提供 + 我的"里没被他关掉的;不写条目是不绑
 * (档案不能不绑)。办的是 {@link CompanionBinding},和面板同一个入口。皮肤不是库条目,同一个同伴参数下另有 {@code skin} 一支({@link SkinCommand})。
 *
 * <p>命令召唤只要一个名字,档案、人设、声线、皮肤之后用这条命令(或编辑卡)绑;面板的召唤卡可以召唤时一并选。没绑档案的她停在
 * {@code BLOCKED},主人跟她说话时她回"还没配模型档案"。
 */
public final class BindingCommands {

    private static final String COMPANION = "companion";
    private static final String ENTRY = "entry";

    private BindingCommands() {}

    public static LiteralArgumentBuilder<class_2168> node() {
        var her = CompanionArgument.of(COMPANION);
        for (Slot slot : Slot.values()) {
            var literal = class_2170.method_9247(slot.command());
            if (slot != Slot.PROVIDER) {
                literal.executes(ctx -> bind(ctx, slot, null));
            }
            her.then(literal.then(class_2170.method_9244(ENTRY, StringArgumentType.greedyString())
                    .suggests((ctx, builder) -> class_2172.method_9264(entries(ctx.getSource(), slot), builder))
                    .executes(ctx -> bind(ctx, slot, StringArgumentType.getString(ctx, ENTRY).strip()))));
        }
        return class_2170.method_9247(COMPANION).then(her.then(SkinCommand.node(COMPANION)));
    }

    /** 他此刻能绑的:看得到、没被他关掉的条目的名字。 */
    private static java.util.stream.Stream<String> entries(class_2168 source, Slot slot) {
        if (!(source.method_9228() instanceof class_3222 player)) {
            return java.util.stream.Stream.empty();
        }
        return LibraryHub.of(player.method_51469().method_8503()).library(slot.kind(), player.method_5667()).active().stream()
                .map(Library.Entry::id).map(Object::toString);
    }

    private static int bind(CommandContext<class_2168> ctx, Slot slot, String entry)
            throws CommandSyntaxException {
        class_3222 owner = ctx.getSource().method_9207();
        Map.Entry<UUID, CompanionRegistry.Entry> her = CompanionArgument.resolve(ctx, COMPANION, owner);
        if (her == null) {
            return 0;
        }
        OwnerInputs.Applied applied = OwnerInputs.handle(owner.method_51469().method_8503(), owner.method_5667(),
                new OwnerInput.Bind(her.getKey(), slot, entry), Venue.PANEL);
        if (applied.problem() != null) {
            ctx.getSource().method_9213(class_2561.method_43469(Keys.COMMAND_BIND_FAILED, applied.problem()));
            return 0;
        }
        ctx.getSource().method_9226(() -> entry == null
                ? class_2561.method_43469(Keys.COMMAND_UNBOUND, her.getValue().name(), slot.command())
                : class_2561.method_43469(Keys.COMMAND_BOUND, her.getValue().name(), slot.command(), entry), false);
        return 1;
    }
}
