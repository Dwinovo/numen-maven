package com.dwinovo.numen.api.entity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9288;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

/**
 * 一叠东西在模型眼里是什么样:物品 id 一样、组件不一样的几叠(装着钻石的潜影盒与空盒、不同的药水、附魔与没附魔的镐)靠这一句短描述
 * 分开。<b>描述只有这一处</b>:背包清单({@code runtime_state} 与 {@code numen.inv.items})、{@code numen.gui.view} 的槽、
 * 回执里"用了哪一叠"都读它,所以模型在清单里看到的写法与回执里报的是同一个。
 *
 * <p>只说事实,不下结论(该不该喝、值不值钱是她的判断)。已知的组件写成人话(名字、附魔、容器里装着什么、药水效果、旗帜花纹、头颅的
 * 主人、蜂数、耐久损耗);其余组件只写组件名,至少让模型知道这一叠"不是一件白货"。和一件新物品没有任何区别的,描述为空
 * (空着的潜影盒、熔炉都是白货:原版里容器类物品默认带一个空的容器组件,空的不算区别)。
 */
public final class StackLabel {

    /** 容器里最多列几种,其余计数。 */
    private static final int MAX_LISTED = 3;

    private StackLabel() {}

    /** 物品 id,带描述时后接 {@code [描述]}:{@code minecraft:shulker_box[holds diamond x3]}。 */
    public static String of(class_1799 stack) {
        return of(stack, detail(stack));
    }

    /** 同 {@link #of(class_1799)},描述由调用方给({@link #details} 排过重的)。 */
    public static String of(class_1799 stack, String detail) {
        return wrap(class_7923.field_41178.method_10221(stack.method_7909()).toString(), detail);
    }

    /** 不带命名空间的 {@link #of}:回执正文里用,{@code shulker_box[holds diamond x3]}。 */
    public static String brief(class_1799 stack) {
        return wrap(class_7923.field_41178.method_10221(stack.method_7909()).method_12832(), detail(stack));
    }

    private static String wrap(String id, String detail) {
        return detail.isEmpty() ? id : id + "[" + detail + "]";
    }

    /**
     * 一批互不相同的种({@link Stacks#kinds})各自的描述。区别落在描述没写出来的组件值上(两叠 {@code custom_data} 不同)时,
     * 同物品同描述的几种会写得一样,模型分不出;这里给它们依次加上 {@code variant N},清单与回执里每一种都有自己的写法。
     */
    public static List<String> details(List<class_1799> kinds) {
        List<String> out = new ArrayList<>();
        for (class_1799 kind : kinds) {
            out.add(detail(kind));
        }
        for (int i = 0; i < kinds.size(); i++) {
            int n = 0;
            for (int j = 0; j < kinds.size(); j++) {
                if (kinds.get(j).method_31574(kinds.get(i).method_7909()) && detail(kinds.get(j)).equals(detail(kinds.get(i)))) {
                    n++;
                }
            }
            if (n > 1) {
                int nth = 1;
                for (int j = 0; j < i; j++) {
                    if (kinds.get(j).method_31574(kinds.get(i).method_7909()) && detail(kinds.get(j)).equals(detail(kinds.get(i)))) {
                        nth++;
                    }
                }
                String base = detail(kinds.get(i));
                out.set(i, (base.isEmpty() ? "" : base + "; ") + "variant " + nth);
            }
        }
        return out;
    }

    /** 区分这一叠的描述,几条用分号连;和新物品没有区别为空。 */
    public static String detail(class_1799 stack) {
        List<String> parts = new ArrayList<>();
        var name = stack.method_58694(class_9334.field_49631);
        if (name != null) {
            parts.add("named “" + name.getString() + "”");
        }
        var enchants = stack.method_58694(class_9334.field_49633);
        if (enchants != null && !enchants.method_57543()) {
            parts.add("enchanted " + enchantments(enchants.method_57539()));
        }
        var stored = stack.method_58694(class_9334.field_49643);
        if (stored != null && !stored.method_57543()) {
            parts.add("stores " + enchantments(stored.method_57539()));
        }
        class_9288 container = stack.method_58694(class_9334.field_49622);
        if (container != null && container.method_59712().findAny().isPresent()) {
            parts.add("holds " + contents(container.method_59714()));
        }
        var bundle = stack.method_58694(class_9334.field_49650);
        if (bundle != null && !bundle.method_57429()) {
            parts.add("holds " + contents(bundle.method_57421()));
        }
        String brew = brew(stack);
        if (!brew.isEmpty()) {
            parts.add(brew);
        }
        var banner = stack.method_58694(class_9334.field_49619);
        if (banner != null && !banner.comp_2428().isEmpty()) {
            List<String> layers = new ArrayList<>();
            banner.comp_2428().forEach(l -> layers.add(path(l.comp_2429()) + " " + l.comp_2430().method_7792()));
            parts.add("patterns " + String.join(", ", layers));
        }
        var profile = stack.method_58694(class_9334.field_49617);
        if (profile != null) {
            parts.add("head of " + profile.method_73317().orElse("unknown"));
        }
        var bees = stack.method_58694(class_9334.field_49624);
        if (bees != null && !bees.comp_3585().isEmpty()) {
            parts.add(bees.comp_3585().size() + " bee" + (bees.comp_3585().size() == 1 ? "" : "s"));
        }
        if (stack.method_7919() > 0) {
            parts.add("damage " + stack.method_7919() + "/" + stack.method_7936());
        }
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore != null && !lore.comp_2400().isEmpty()) {
            parts.add("lore");
        }
        List<String> others = new ArrayList<>();
        stack.method_57380().method_57846().forEach(e -> {
            if (e.getValue().isPresent() && !known(e.getKey())) {
                others.add(class_7923.field_49658.method_10221(e.getKey()).method_12832());
            }
        });
        if (!others.isEmpty()) {
            parts.add("with " + String.join(", ", others));
        }
        return String.join("; ", parts);
    }

    /** 上面单独写成人话的那些组件;其余的才进"with …"。 */
    private static boolean known(class_9331<?> type) {
        return type == class_9334.field_49631 || type == class_9334.field_49633
                || type == class_9334.field_49643 || type == class_9334.field_49622
                || type == class_9334.field_49650 || type == class_9334.field_49651
                || type == class_9334.field_49619 || type == class_9334.field_49617
                || type == class_9334.field_49624 || type == class_9334.field_49629 || type == class_9334.field_49632;
    }

    private static String enchantments(Iterable<? extends Map.Entry<? extends class_6880<?>, Integer>> entries) {
        List<String> out = new ArrayList<>();
        entries.forEach(e -> out.add(path(e.getKey()) + " " + e.getValue()));
        return String.join(", ", out);
    }

    private static String path(class_6880<?> holder) {
        return holder.method_40230().map(key -> key.method_29177().method_12832()).orElse("unknown");
    }

    /** 装着什么:按物品种类合计,先见先列,最多 {@link #MAX_LISTED} 种,其余计数。 */
    private static String contents(Iterable<class_1799> stacks) {
        Map<String, Integer> totals = new LinkedHashMap<>();
        for (class_1799 s : stacks) {
            totals.merge(class_7923.field_41178.method_10221(s.method_7909()).method_12832(), s.method_7947(), Integer::sum);
        }
        List<String> listed = new ArrayList<>();
        totals.forEach((id, n) -> {
            if (listed.size() < MAX_LISTED) {
                listed.add(id + " x" + n);
            }
        });
        String more = totals.size() > MAX_LISTED ? ", +" + (totals.size() - MAX_LISTED) + " more kinds" : "";
        return String.join(", ", listed) + more;
    }

    /**
     * 瓶子里装的是什么。<b>治疗、剧毒、夜视的 item id 全都是 {@code minecraft:potion}</b>,内容在 {@code POTION_CONTENTS}
     * 组件里。印的是原版药水的<b>注册名</b>({@code strong_healing}、{@code long_poison}),不是"安全/危险"那种结论;
     * 酿造出来的、模组的药水没有预设名,效果只在自定义列表里,两处都读,不用维护白名单。
     */
    private static String brew(class_1799 stack) {
        var contents = stack.method_58694(class_9334.field_49651);
        if (contents == null) {
            return "";
        }
        StringBuilder label = new StringBuilder();
        contents.comp_2378().ifPresent(held -> label.append(path(held)));
        for (var effect : contents.comp_2380()) {
            if (label.length() > 0) {
                label.append('+');
            }
            label.append(path(effect.method_5579()));
        }
        return label.toString();
    }
}
