/**
 * 各后端家族的线格式适配器。{@link com.dwinovo.numen.api.agent.provider.IToolSpec}
 * 是工具在 LLM 侧的描述面契约——Numen API 侧的 NumenTool 继承它。
 */
package com.dwinovo.numen.api.agent.provider;
