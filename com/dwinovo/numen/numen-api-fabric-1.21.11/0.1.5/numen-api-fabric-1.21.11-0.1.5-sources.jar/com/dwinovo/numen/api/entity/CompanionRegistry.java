package com.dwinovo.numen.api.entity;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Persistent index of every companion that exists, keyed by companion UUID.
 * The companion BODY (inventory, position, owner) persists for free as a vanilla
 * player {@code .dat}, but vanilla never enumerates the {@code playerdata/}
 * folder for players that aren't logging in — so without this index we couldn't
 * know which companions to recreate, or who owns them, while they sit dormant.
 *
 * <p>World-saved on the overworld data storage (one file, all owners' companions).
 * The {@code dimension}/{@code pos} are a respawn hint (which level to construct
 * the body in); the {@code .dat} carries the authoritative restored state.
 */
@com.dwinovo.numen.api.Internal
public final class CompanionRegistry extends class_18 {

    /** One companion's catalog entry.
     *  {@code skinValue}/{@code skinSig} = 借来的正版皮肤(Mojang 签名的 textures 属性),
     *  空串 = 无皮肤,客户端回落原版默认皮肤(按 UUID 哈希抽取)。
     *  {@code removedFor} 非空 = 她的身体被外面的人或插件请出了服务器(值是当时说的理由),在主人再召唤她之前不重建。
     *  死亡不进名册:她死了就由原版重生流程当场重生,没有"死着等复活"的状态;老存档里的 {@code diedAt}、{@code deathCause}
     *  读档时被忽略,下一次存盘就不再写。 */
    public record Entry(String name, UUID owner, class_5321<class_1937> dimension, class_2338 pos,
                        String skinValue, String skinSig,
                        String taskName, String taskLua, String taskOld, String removedFor) {
        /** A companion with no borrowed skin, idle. */
        public Entry(String name, UUID owner, class_5321<class_1937> dimension, class_2338 pos) {
            this(name, owner, dimension, pos, "", "", "", "", "", "");
        }

        /**
         * 她现在在做什么:这件活给模型看的名字(派它的函数的全名)与重启后再跑的那一行 Lua({@code taskLua});空串 = 闲着,只有名字 =
         * 在做、但接不回来。见 {@code TaskPersistence}。{@code taskOld} 只是读进来的:旧版本按一行命令记下的活,这一版不再跑它。
         */
        public Entry doing(String task, String lua) {
            return new Entry(name, owner, dimension, pos, skinValue, skinSig,
                    task == null ? "" : task, lua == null ? "" : lua, "", removedFor);
        }

        /** 刷新落点(休眠/移动时的 respawn 提示),皮肤原样保留。 */
        public Entry movedTo(class_5321<class_1937> dimension, class_2338 pos) {
            return new Entry(name, owner, dimension, pos, skinValue, skinSig,
                    taskName, taskLua, taskOld, removedFor);
        }

        /** 换上 Mojang 签名的皮肤数据(value+signature)。 */
        public Entry withSkin(String value, String sig) {
            return new Entry(name, owner, dimension, pos,
                    value == null ? "" : value, sig == null ? "" : sig, taskName, taskLua, taskOld, removedFor);
        }

        /** 身体被外面请出了服务器({@code reason} 是当时说的理由);主人再召唤之前不重建。 */
        Entry removed(String reason) {
            return new Entry(name, owner, dimension, pos, skinValue, skinSig,
                    taskName, taskLua, taskOld, reason);
        }

        /** 身体被外面请出了服务器、还没被再召唤。 */
        public boolean removed() {
            return !removedFor.isEmpty();
        }

        static final Codec<Entry> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("name").forGetter(Entry::name),
                class_4844.field_41525.fieldOf("owner").forGetter(Entry::owner),
                class_5321.method_39154(class_7924.field_41223).fieldOf("dimension").forGetter(Entry::dimension),
                class_2338.field_25064.fieldOf("pos").forGetter(Entry::pos),
                Codec.STRING.optionalFieldOf("skinValue", "").forGetter(Entry::skinValue),
                Codec.STRING.optionalFieldOf("skinSig", "").forGetter(Entry::skinSig),
                Codec.STRING.optionalFieldOf("taskName", "").forGetter(Entry::taskName),
                Codec.STRING.optionalFieldOf("taskLua", "").forGetter(Entry::taskLua),
                // 旧版本记的那一行命令:读进来只为如实说它接不回来,写回去它已经清掉了
                Codec.STRING.optionalFieldOf("taskArgs", "").forGetter(Entry::taskOld),
                Codec.STRING.optionalFieldOf("removedFor", "").forGetter(Entry::removedFor)
        ).apply(i, Entry::new));
    }

    // 包内可见:持久化是这个类最要命的部分(解析失败 = 全世界同伴静默消失),
    // 得让单测够得着。
    static final Codec<CompanionRegistry> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.unboundedMap(class_4844.field_41525, Entry.CODEC)
                    .fieldOf("companions").forGetter(d -> d.entries),
            Codec.STRING.optionalFieldOf("worldId", "").forGetter(d -> d.worldId)
    ).apply(i, CompanionRegistry::new));

    // 1.21.5 codec 化的 SavedDataType:名字 + 构造器 + CODEC + datafix 类型,存储层自己驱动
    // (反)序列化,save()/load() 重写不复存在。解析失败由存储层兜底:readSavedData 记日志
    // 返 null,computeIfAbsent 落回构造器 —— "垃圾降级为空注册表"的语义与旧代一致。
    private static final class_10741<CompanionRegistry> TYPE = new class_10741<>(
            "numen_companions", CompanionRegistry::new, CODEC,
            net.minecraft.class_4284.field_45082);

    private final Map<UUID, Entry> entries;
    private String worldId;

    CompanionRegistry() {
        this.entries = new HashMap<>();
        this.worldId = "";
    }

    private CompanionRegistry(Map<UUID, Entry> entries, String worldId) {
        this.entries = new HashMap<>(entries);
        this.worldId = worldId == null ? "" : worldId;
    }

    public static CompanionRegistry get(MinecraftServer server) {
        return server.method_30002().method_17983().method_17924(TYPE);
    }

    /**
     * 这个世界的身份证——首次访问时随机生成并持久化。
     *
     * <p>客户端的同伴数据({@code config/numen/companions/}) 是一个跨存档共用的目录,
     * 所以"这只同伴不在名册上"必须先问清楚"名册是哪个世界的"。没有这个 id,换一个
     * 存档进去就会把上一个存档的同伴全判成已遣散——那是会毁数据的。
     *
     * <p>随机 UUID 而不是存档名:存档名会重名、会改名,服务器地址会变。
     */
    public String worldId() {
        if (worldId == null || worldId.isBlank()) {
            worldId = UUID.randomUUID().toString();
            method_80();
        }
        return worldId;
    }

    /** Add or update a companion's catalog entry. */
    public void put(UUID companionUuid, Entry entry) {
        entries.put(companionUuid, entry);
        method_80();
    }

    public Entry find(UUID companionUuid) {
        return entries.get(companionUuid);
    }

    public void remove(UUID companionUuid) {
        if (entries.remove(companionUuid) != null) method_80();
    }

    /** Every companion that exists, whoever owns it. */
    public List<UUID> all() {
        return new ArrayList<>(entries.keySet());
    }

    /** Every companion owned by {@code ownerUuid} (UUID + entry). */
    public List<Map.Entry<UUID, Entry>> ownedBy(UUID ownerUuid) {
        List<Map.Entry<UUID, Entry>> out = new ArrayList<>();
        for (Map.Entry<UUID, Entry> e : entries.entrySet()) {
            if (e.getValue().owner().equals(ownerUuid)) out.add(e);
        }
        return out;
    }

    /** 记下她的身体被外面请出了服务器(理由 {@code reason} 随名册落盘,主人下次上线还说得出)。 */
    public void markRemoved(UUID uuid, String reason) {
        Entry e = entries.get(uuid);
        if (e == null) return;
        entries.put(uuid, e.removed(reason));
        method_80();
    }

    /** 主人再召唤了她:不再是被请出去的状态。 */
    public void markReturned(UUID uuid) {
        Entry e = entries.get(uuid);
        if (e == null || !e.removed()) return;
        entries.put(uuid, e.removed(""));
        method_80();
    }
}
