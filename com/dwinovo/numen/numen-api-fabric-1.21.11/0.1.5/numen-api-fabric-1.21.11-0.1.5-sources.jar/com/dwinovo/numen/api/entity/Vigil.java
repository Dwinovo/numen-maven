package com.dwinovo.numen.api.entity;

import com.dwinovo.numen.api.event.NumenEvents;
import com.dwinovo.numen.api.sdk.NearbyEntities;
import com.dwinovo.numen.api.task.CompanionTickDispatcher;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

/**
 * 她四周两件值得说的事的看护,每服务端 tick 问一次({@code CompanionTickDispatcher}):
 * <ul>
 *   <li><b>被锁定</b>:半径({@link NearbyEntities#RADIUS})里某只怪的攻击目标变成她,发一次 {@code targeted}。盯着期间不再发,
 *       抖动去抖,见 {@link TargetingWatch};</li>
 *   <li><b>没了</b>:她留意的对象被移出世界,发一次 {@code gone},附原版的移除原因。走出半径不发——它还在,只是不在身边。</li>
 * </ul>
 *
 * <h2>她留意谁</h2>
 * 最近在她的事件里出现过的对象(打她的、盯上她的,{@link #follow})和她正在打、在用、骑着的({@code CompanionTickDispatcher#engagedBy})。
 * 发过 {@code gone} 就不再留意;留意的最多 {@value #FOCUS_CAP} 个,多了先放下最久没提起的。玩家不在其内:他们下线、被打倒都不是
 * 被移出世界。
 */
public final class Vigil {

    /** 留意的对象至多这么多:远处还活着的永远等不到被移出世界,不设上限就只增不减。 */
    static final int FOCUS_CAP = 16;

    private final TargetingWatch<UUID> targeting = new TargetingWatch<>();
    /** 留意的对象,按最近一次提起排;持有实体本身,因为移除原因只在被移出的那个对象上。 */
    private final Map<UUID, class_1297> focus = new LinkedHashMap<>(16, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<UUID, class_1297> eldest) {
            return size() > FOCUS_CAP;
        }
    };

    /** 这个对象从此留意:它被移出世界时说一声。 */
    public void follow(class_1297 entity) {
        if (!(entity instanceof class_1657)) {
            focus.put(entity.method_5667(), entity);
        }
    }

    /** 每服务端 tick 一次。 */
    public void poll(NumenPlayer her, long now) {
        CompanionTickDispatcher.engagedBy(her).forEach(this::follow);

        List<class_1308> hunters = NearbyEntities.within(her, NearbyEntities.RADIUS, class_1308.class,
                mob -> mob.method_5805() && mob.method_5968() == her);
        Map<UUID, class_1308> byId = new LinkedHashMap<>();
        hunters.forEach(mob -> byId.put(mob.method_5667(), mob));
        for (UUID id : targeting.poll(byId.keySet(), now)) {
            class_1308 mob = byId.get(id);
            NumenEvents.targeted(her, mob);
            follow(mob);
        }

        List<class_1297> gone = new ArrayList<>();
        for (Iterator<class_1297> it = focus.values().iterator(); it.hasNext(); ) {
            class_1297 entity = it.next();
            if (entity.method_31481()) {
                gone.add(entity);
                it.remove();
            }
        }
        gone.forEach(entity -> NumenEvents.gone(her, entity, killerOf(entity)));
    }

    /** 倒下的是谁打倒的(原版的击杀归属);不是被打倒的、查不到的是 null。 */
    private static class_1309 killerOf(class_1297 entity) {
        return entity instanceof class_1309 living ? living.method_6124() : null;
    }
}
