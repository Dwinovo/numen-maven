package com.dwinovo.numen.api.client.chat;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.agent.conversation.Conversation;
import com.dwinovo.numen.api.Delivery;
import com.dwinovo.numen.api.NumenGateway;
import com.dwinovo.numen.api.client.agent.RemoteCompanions;
import com.dwinovo.numen.api.client.agent.Conversations;
import com.dwinovo.numen.api.client.agent.RemoteCompanion;
import com.dwinovo.numen.api.client.agent.NumenRoster;
import com.dwinovo.numen.api.client.consent.ConsentCards;
import com.dwinovo.numen.api.client.consent.ConsentMessage;
import com.dwinovo.numen.api.client.screen.Nb;
import com.dwinovo.numen.api.client.screen.UiTheme;
import com.dwinovo.numen.api.client.screen.chat.ChatInputBar;
import com.dwinovo.numen.api.client.screen.settings.HostThemeColors;
import com.dwinovo.numen.api.client.skin.ConversationFaces;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.class_1074;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_742;

/**
 * 快捷对话:按对话键(默认 Y,入口在 {@code NumenKeys})对「当前交互
 * 对象」弹出这一条极简输入行——就一行,回车说出去立刻关屏,回复会浮
 * 在它头顶的气泡里。收件人是一个会话,由 {@code SelectedCompanion} 解析:准星指着
 * 谁就是跟她一个人说,否则是转盘选中的那个(可能是多人会话)。屏只是输入法,不是对话窗口;
 * 历史与长文在 G 面板。准星提示见 {@code TalkHint}。
 *
 * <p>输入行与 G 面板是<b>同一条</b>({@link ChatInputBar}):斜杠补全弹层、
 * {@code /skills} 这类面板、回车先补后发,两处一模一样,不另写一套。不带麦克风键
 * ——快捷语音有自己的按住说话键。命令跑完的回话走准星提示层闪一下,屏照关。
 *
 * <p>与 {@code @名字} 路由是同一条管线({@link NumenGateway#emit}),
 * 对应两种社交距离:@ 是远程喊话,这里是走到跟前说话。
 *
 * <p>样子照 Telegram 的输入区:窗口底色的一条、浮起的细描边;左端是说给谁——会话头像(群是群头像)加名字,
 * 一道分隔线隔开输入框。开屏时整条自下浮起 {@link #OPEN_MS},不硬切。
 *
 * <p>有征询挂着时按对话键先答征询(对象是最早在等的那位,见 {@code NumenKeys}):她问的那条(问话 + 内联按钮,
 * 见 {@link ConsentMessage})浮在输入卡上面,点按钮、"说一句再拒绝"后打字回车都和 G 面板一样;答完
 * 还有别的同伴在等就换到她,都答完且输入框是空的就关屏——和说完一句一样。
 */
public class CompanionChatScreen extends class_437 {

    private static final int INPUT_W = 300;
    /** 与 G 面板输入行同高。 */
    private static final int INPUT_H = 18;
    /** 名字牌里的会话头像:输入行里上下各留 2。 */
    private static final int FACE = INPUT_H - 4;
    /** 开屏浮起:Telegram 的快动效时长,浮起的高度。 */
    private static final long OPEN_MS = 150;
    private static final int OPEN_RISE = 8;

    private final Conversation conv;
    private final String companionName;
    private ChatInputBar inputBar;
    private final long openedAtMs = net.minecraft.class_156.method_658();
    /** 这一帧征询那排按钮画在哪(点的时候照它认);没画是 0 宽。 */
    private int keysX, keysY, keysW;

    public CompanionChatScreen(Conversation conv) {
        super(class_2561.method_43471(Keys.CHAT_SCREEN_TITLE));
        this.conv = conv;
        this.companionName = conv.displayName(NumenRoster.instance()::name);
    }

    /**
     * 准星此刻指着的「自己的」同伴,不在指着返回 null。花名册只含本人的
     * 同伴,身份校验是白送的;别人的同伴不响应(它的大脑不在你机器上)。
     */
    public static class_742 crosshairCompanion() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1724.method_7325()) return null;
        if (!(mc.field_1765 instanceof class_3966 hit)) return null;
        if (!(hit.method_17782() instanceof class_742 body)) return null;
        for (NumenRoster.Entry entry : NumenRoster.instance().entries()) {
            if (entry.uuid().equals(body.method_5667())) {
                return body;
            }
        }
        return null;
    }

    /** 就他俩那只的大脑(补全、征询);会话没有单一的主时 null。 */
    private RemoteCompanion loop() {
        UUID her = Conversations.instance().soloOf(conv);
        return her == null ? null : RemoteCompanions.getOrCreate(her);
    }

    /** 名字牌(说给谁:头像 + 名字)的宽度:它和输入行同排,占掉输入卡最左边这一截。 */
    private int tagW() {
        return FACE + 4 + this.field_22793.method_1727(companionName) + 4;
    }

    @Override
    protected void method_25426() {
        // 输入框的真控件挂到本屏上:只注册事件、不进 renderables,画面归 NumenUI。
        // 屏幕作用域——关屏时在 removed() 卸掉。
        com.dwinovo.numen.api.client.ui.mc.McTextInput.mountVia(this::method_25429, this::method_25395);
        String kept = inputBar != null ? inputBar.text() : "";
        int x = (this.field_22789 - INPUT_W) / 2;
        int y = this.field_22790 - 44;
        inputBar = new ChatInputBar(new BarHost(), EnumSet.of(ChatInputBar.Key.SEND, ChatInputBar.Key.STOP));
        int lead = tagW() + 6;
        inputBar.build(x, y, INPUT_W, INPUT_H, lead);
        if (!kept.isEmpty()) inputBar.setText(kept);
    }

    /** 输入行的宿主:说话走 Gateway 然后关屏;命令的回话闪在准星提示层,屏也关。 */
    private final class BarHost implements ChatInputBar.Host {
        @Override public void onSend(String text) {
            if (Conversations.instance().say(conv, text).reached()) {
                ChatLines.owner(companionName, text, false);
            } else {
                com.dwinovo.numen.api.client.hud.TalkHint.flash(class_1074.method_4662(Keys.CHAT_NOT_RECEIVED, companionName), 3000);
            }
            method_25419();
        }

        @Override public void onAbort() { Conversations.instance().abort(conv); }   // 停止停全体

        @Override public boolean canAbort() { return Conversations.instance().canAbort(conv); }

        @Override public String hint() {
            return class_1074.method_4662(Keys.CHAT_INPUT_HINT);
        }

        @Override public RemoteCompanion loop() { return CompanionChatScreen.this.loop(); }

        @Override public Conversation conversation() { return conv; }

        @Override public void onConsentSettled() {
            var next = com.dwinovo.numen.api.client.consent.ConsentCards.first();
            if (next != null) {
                field_22787.method_1507(new CompanionChatScreen(Conversations.instance().of(next.companion())));
            } else if (inputBar.text().isEmpty()) {
                method_25419();
            }
        }

        /** 只注册事件,不进 renderables——画面归 NumenUI。见 {@code McTextInput}。 */
        @Override public void onCommandReply(String reply) {
            if (reply == null || reply.isBlank()) {
                return;   // 不吭声的命令,或面板已在输入行原位打开——屏留着
            }
            // 行数越多给的时间越长——一屏技能清单三秒看不完
            long life = 4000L + reply.split("\n").length * 600L;
            com.dwinovo.numen.api.client.hud.TalkHint.flash(reply, life);
            method_25419();
        }
    }

    /**
     * 此刻占着屏幕的那一块:输入卡连同它上面挂着的征询,{@code {左, 顶, 右}}。消息通知卡落在它旁边就得让开,
     * 不能压住输入行。
     */
    public int[] occupied() {
        int x = (this.field_22789 - INPUT_W) / 2;
        int cardTop = this.field_22790 - 44 - 6 - (inputBar.height() - INPUT_H);
        int top = cardTop;
        ConsentCards.Card card = ConsentCards.pending(Conversations.instance().soloOf(conv));
        if (card != null) top = consentTop(card, cardTop);
        return new int[]{x - 8, top, x + INPUT_W + 8};
    }

    /** 征询那张卡的顶边:贴着输入卡上沿往上摞。 */
    private int consentTop(ConsentCards.Card card, int cardTop) {
        int innerW = INPUT_W + 16 - 8;
        int h = 4 + ConsentMessage.listHeight(card) + ConsentMessage.GAP + ConsentMessage.keyboardHeight(this.field_22793, innerW) + 4;
        return cardTop - 4 - h;
    }

    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float partialTicks) {
        // 刻意留空:super.render 默认会画菜单模糊+压暗遮罩,面对面说话
        // 不该把世界糊掉——她就站在你面前
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partialTicks) {
        UiTheme th = UiTheme.current();
        int x = (this.field_22789 - INPUT_W) / 2;
        int y = this.field_22790 - 44;
        long now = net.minecraft.class_156.method_658();

        // 开屏浮起:只挪画面,点击区不跟着挪——150ms 里差几个像素,点不偏
        float rise = 1f - com.dwinovo.numen.api.client.ui.Anim.easeOutCubic((now - openedAtMs) / (float) OPEN_MS);
        g.method_51448().pushMatrix();
        g.method_51448().translate(0, Math.round(OPEN_RISE * rise));
        var surface = new com.dwinovo.numen.api.client.ui.mc.McDrawSurface(g, this.field_22793);
        // 输入卡:Telegram 输入区是窗口底色,浮在世界上用浮起的描边;输入行(含弹层/面板)画在它上面。
        // 输入行往上长(多行、引用栏、"说一句再拒绝"的提示栏)时卡片跟着长,底边不动
        int grown = inputBar.height() - INPUT_H;
        com.dwinovo.numen.api.client.ui.NumenStyle.box(surface, x - 8, y - 6 - grown, INPUT_W + 16, INPUT_H + 10 + grown,
                th.band(), th.aiBorder());
        // 名字牌:与输入行同排、占卡片最左一截,标明这句话说给谁。不放输入框上方——
        // 斜杠补全弹层和 /skills 面板都贴着输入框往上长,上面那块地是它们的
        ConversationFaces.draw(g, conv, x, y + (INPUT_H - FACE) / 2, FACE);
        Nb.text(g, this.field_22793, companionName, x + FACE + 4, y + (INPUT_H - this.field_22793.field_2000) / 2 + 1,
                th.onBand());
        int div = x + tagW() + 2;
        g.method_25294(div, y + 1, div + 1, y + INPUT_H - 1, th.surfaceBorder());
        renderConsent(g, surface, th, x - 8, y - 6 - grown, mouseX, mouseY);
        inputBar.render(g, mouseX, mouseY, now, HostThemeColors.current());
        g.method_51448().popMatrix();

        String tip = inputBar.tooltipAt(mouseX, mouseY);
        if (tip != null) {
            g.method_51438(this.field_22793, class_2561.method_43470(tip), mouseX, mouseY);
        }
        super.method_25394(g, mouseX, mouseY, partialTicks);
    }

    /**
     * 她挂着的征询浮在输入卡上面:同一套框,里面是清单与内联按钮;顶边一道缩短的线是剩下的时间(撤不回时是警示色)。
     */
    private void renderConsent(class_332 g, com.dwinovo.numen.api.client.ui.mc.McDrawSurface surface, UiTheme th,
                               int cardX, int cardTop, int mouseX, int mouseY) {
        ConsentCards.Card card = ConsentCards.pending(Conversations.instance().soloOf(conv));
        keysW = 0;
        if (card == null) return;
        int w = INPUT_W + 16;
        int listH = ConsentMessage.listHeight(card);
        int innerW = w - 8;
        int h = 4 + listH + ConsentMessage.GAP + ConsentMessage.keyboardHeight(this.field_22793, innerW) + 4;
        int top = consentTop(card, cardTop);
        com.dwinovo.numen.api.client.ui.NumenStyle.box(surface, cardX, top, w, h, th.band(), th.aiBorder());
        g.method_25294(cardX + 1, top + 1, cardX + 1 + Math.round((w - 2) * ConsentMessage.timeLeft(card)), top + 2,
                ConsentMessage.tone(card));
        ConsentMessage.drawList(g, this.field_22793, card, cardX + 4, top + 4, innerW);
        keysX = cardX + 4;
        keysY = top + 4 + listH + ConsentMessage.GAP;
        keysW = innerW;
        ConsentMessage.drawKeyboard(g, this.field_22793, card, keysX, keysY, keysW, mouseX, mouseY);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        int keyCode = com.dwinovo.numen.api.client.ui.KeyCodes.canonical(event.comp_4795());   // 小键盘回车并成回车
        // 输入行先拿:弹层的上下/Tab/回车、面板的整个键盘、回车发送。它不要的(比如
        // 没开面板时的 Esc)才落到屏幕——Esc 关屏
        if (inputBar != null && inputBar.keyPressed(keyCode, event.comp_4797())) {
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (inputBar != null && inputBar.charTyped((char) event.comp_4793())) {
            return true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        double mouseX = event.comp_4798();
        double mouseY = event.comp_4799();
        ConsentCards.Card card = ConsentCards.pending(Conversations.instance().soloOf(conv));
        if (card != null && keysW > 0
                && ConsentMessage.click(this.field_22793, card, keysX, keysY, keysW, mouseX, mouseY)) {
            return true;
        }
        boolean handled = inputBar != null && inputBar.mouseClicked(mouseX, mouseY, event.method_74245())
                || super.method_25402(event, doubleClick);
        // 这一屏只是一行输入:点到哪儿输入框都不失焦。失了焦字打不进、回车也没反应,只剩发送键还能点
        if (inputBar != null) inputBar.setFocused(true);
        return handled;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        // 写满五行的输入框在框里翻
        if (inputBar != null && scrollY != 0 && inputBar.mouseScrolled(mouseX, mouseY, scrollY)) {
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void method_25393() {
        if (inputBar != null) {
            inputBar.tick();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25432() {
        com.dwinovo.numen.api.client.ui.mc.McTextInput.mountVia(null, null);
        super.method_25432();
    }
}
