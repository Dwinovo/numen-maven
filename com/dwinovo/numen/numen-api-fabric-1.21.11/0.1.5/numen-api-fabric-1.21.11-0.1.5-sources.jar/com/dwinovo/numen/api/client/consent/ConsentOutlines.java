package com.dwinovo.numen.api.client.consent;

import com.dwinovo.numen.api.network.payload.ConsentRequestPayload;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9848;
import net.minecraft.class_9974;

/**
 * 世界里给挂着的征询涉及的方块与实体描轮廓——主人抬头就知道她问的是哪几块、哪一只。
 * 只照 {@link ConsentCards} 画,请求撤回轮廓就没了。与寻路调试覆盖层同一条世界渲染管线。
 */
public final class ConsentOutlines {

    private static final int COLOR = class_9848.method_61318(1.0f, 1.0f, 0.72f, 0.1f);
    /** 方块轮廓比整格略大一圈。 */
    private static final class_265 BLOCK = class_259.method_1081(-0.01, -0.01, -0.01, 1.01, 1.01, 1.01);

    private ConsentOutlines() {}

    /** 世界渲染钩子入口(半透明方块阶段之后;poseStack 为世界空间)。 */
    public static void render(class_4587 poseStack, class_4184 camera) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || ConsentCards.all().isEmpty()) {
            return;
        }
        class_243 cam = camera.method_71156();
        class_4597.class_4598 buffers = mc.method_22940().method_23000();
        class_4588 vc = buffers.method_73477(class_12249.method_76015());
        poseStack.method_22903();
        poseStack.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);
        float width = mc.method_22683().method_75291();
        for (ConsentCards.Card card : ConsentCards.all()) {
            ConsentRequestPayload request = card.request();
            for (long packed : request.blocks()) {
                class_2338 pos = class_2338.method_10092(packed);
                class_9974.method_62296(poseStack, vc, BLOCK, pos.method_10263(), pos.method_10264(), pos.method_10260(), COLOR, width);
            }
            for (int id : request.entities()) {
                class_1297 entity = mc.field_1687.method_8469(id);
                if (entity != null) {
                    class_238 box = entity.method_5829().method_1014(0.05);
                    class_9974.method_62296(poseStack, vc, class_259.method_1078(box), 0, 0, 0, COLOR, width);
                }
            }
        }
        poseStack.method_22909();
        buffers.method_22994(class_12249.method_76015());
    }
}
