package com.dwinovo.numen.api.client.screen.settings;

import com.dwinovo.numen.api.client.ui.IDrawSurface;
import com.dwinovo.numen.api.client.ui.NumenStyle;
import com.dwinovo.numen.api.client.ui.NumenTheme;
import com.dwinovo.numen.api.client.ui.widget.Dropdown;
import com.dwinovo.numen.api.client.ui.widget.InlineAlert;
import com.dwinovo.numen.api.client.ui.widget.Label;
import com.dwinovo.numen.api.client.ui.widget.ScrollBox;
import com.dwinovo.numen.api.client.ui.widget.Slider;
import com.dwinovo.numen.api.client.ui.widget.TextField;
import com.dwinovo.numen.api.client.ui.widget.UiRoot;
import com.dwinovo.numen.api.client.voice.SpokenVoice;
import com.dwinovo.numen.api.data.ModLanguageData;
import com.dwinovo.numen.api.voice.VoiceProfile;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * 声线的编辑表单——NumenUI 版的瓤:后端下拉切换字段行(MiniMax 最多八行,
 * 躺进模型配置表单同款的滚动底盘)、音量滑条、试听按钮真合成真播放、
 * 结果走页面级 InlineAlert(试听中驻留/成功自动淡出/失败驻留),校验错误
 * 内联在字段上。编辑的是 {@link Draft} 草稿,保存才落库。
 *
 * <p>声线条目(服务端的库)是服务商、音色、参数,不含 key;表单上的 key 是这台电脑钥匙串里那个"服务"的 key,
 * 由宿主存进本机({@code ClientKeys}),试听用的就是这里填的。
 */
public final class VoiceFormPanel {

    /** 表单草稿:与 VoiceProfile 字段一一对应(id 由宿主管理),另有本机钥匙串里的 key;
     *  {@code volume} 用 UI 档位 1~10(5 档 = 原始响度 1.0)。 */
    public static final class Draft {
        public String backend = VoiceProfile.BACKEND_OPENAI;
        public String name = "";
        public String service = "";
        public String url = "";
        public String apiKey = "";
        public String groupId = "";
        public String model = "";
        public String voice = "";
        public String refAudio = "";
        public String promptText = "";
        public String textLang = "";
        public int volume = 5;
    }

    /** 新草稿:官方端点预填,用户只补 key/音色。 */
    public static Draft freshDraft() {
        Draft d = new Draft();
        d.url = defaultUrl(d.backend);
        return d;
    }

    /** 草稿 → 声线(档位换算增益;试听与保存共用同一转换,试出来的就是存进去的)。 */
    public static VoiceProfile profileOf(Draft d) {
        return new VoiceProfile(d.service, d.backend, d.url, d.groupId, d.model, d.voice, d.refAudio, d.promptText,
                d.textLang, Math.clamp(d.volume, 1, 10) / 5.0f);
    }

    public static String defaultUrl(String backend) {
        return switch (backend) {
            case VoiceProfile.BACKEND_SOVITS -> com.dwinovo.numen.api.client.voice.GptSovitsTts.DEFAULT_BASE;
            case VoiceProfile.BACKEND_MINIMAX -> com.dwinovo.numen.api.client.voice.MiniMaxTts.DEFAULT_BASE;
            case VoiceProfile.BACKEND_FISH -> com.dwinovo.numen.api.client.voice.FishAudioTts.DEFAULT_BASE;
            case VoiceProfile.BACKEND_DASHSCOPE -> com.dwinovo.numen.api.client.voice.DashScopeTts.DEFAULT_BASE;
            case VoiceProfile.BACKEND_MIMO -> com.dwinovo.numen.api.client.voice.MimoTts.DEFAULT_BASE;
            case VoiceProfile.BACKEND_DOUBAO -> com.dwinovo.numen.api.client.voice.DoubaoTts.DEFAULT_BASE;
            default -> com.dwinovo.numen.api.client.voice.OpenAiCompatibleTts.DEFAULT_BASE;
        };
    }

    private static final List<String> BACKENDS = List.of(
            VoiceProfile.BACKEND_OPENAI, VoiceProfile.BACKEND_SOVITS,
            VoiceProfile.BACKEND_MINIMAX, VoiceProfile.BACKEND_FISH,
            VoiceProfile.BACKEND_DASHSCOPE, VoiceProfile.BACKEND_MIMO,
            VoiceProfile.BACKEND_DOUBAO);

    /** 滚动根:表单行(进裁剪区,可上下滚);固定根:结果胶囊/按钮行(不动)。 */
    private final UiRoot ui = new UiRoot();
    private final UiRoot fixedUi = new UiRoot();
    private final Consumer<Draft> onSave;
    private final Runnable onCancel;

    /** 表单行装不下卡片时整体上下位移(记账在 {@link ScrollBox})。 */
    private final ScrollBox scroll = new ScrollBox();
    private int formX, formY, formW, formH;
    /** 下拉不得越出的区域,由宿主给(设置窗口与屏幕的交集)。 */
    private UiRoot.Viewport window = UiRoot.Viewport.UNBOUNDED;

    private Draft draft = new Draft();
    private TextField nameField;
    private InlineAlert resultAlert;
    /** 在途试听的作废闸:表单关闭/又点一次都 ++,迟到的回调对不上号就丢弃。 */
    private int testGen;
    private com.dwinovo.numen.api.client.voice.VoicePreviewSound preview;

    public VoiceFormPanel(Consumer<Draft> onSave, Runnable onCancel) {
        this.onSave = onSave;
        this.onCancel = onCancel;
        class_310 mc = class_310.method_1551();
        ui.setClipboard(() -> mc.field_1774.method_1460(),
                s -> mc.field_1774.method_1455(s));
        // 文本编辑交给真 EditBox(只收事件、不自绘),画面仍归 NumenUI。
        // 这是输入法辅助模组能认出这些框的前提——见 McTextInput。
        ui.setInputFactory(com.dwinovo.numen.api.client.ui.mc.McTextInput.factory());
    }

    /** 载入待编辑的草稿(新建=freshDraft;编辑=从条目拷来)。宿主随后 build。 */
    public void open(Draft d) {
        this.draft = d;
    }

    /** 表单关闭/切分区:作废在途试听回调。 */
    public void cancelPendingTest() {
        testGen++;
    }

    public void build(int x, int y, int w, int h, UiRoot.Viewport window) {
        this.formX = x;
        this.formY = y;
        this.formW = w;
        this.formH = h;
        this.window = window;
        ui.clear();
        fixedUi.clear();
        ui.setViewport(window);

        int ry = y;
        Label nameLabel = labelWidget(x, ry, ModLanguageData.Keys.VOICE_FORM_NAME);
        ry += NumenStyle.LABEL_PITCH;
        nameField = ui.add(new TextField(draft.name, v -> draft.name = v).withLabel(nameLabel));
        nameField.setBounds(x, ry, w, NumenStyle.CONTROL_H);
        ry += NumenStyle.ROW_PITCH;

        ry = label(x, ry, ModLanguageData.Keys.PROVIDER_FORM_PROVIDER);
        Dropdown backendPick = ui.add(new Dropdown(List.of(
                t(ModLanguageData.Keys.VOICE_BACKEND_OPENAI),
                t(ModLanguageData.Keys.VOICE_BACKEND_SOVITS),
                t(ModLanguageData.Keys.VOICE_BACKEND_MINIMAX),
                t(ModLanguageData.Keys.VOICE_BACKEND_FISH),
                t(ModLanguageData.Keys.VOICE_BACKEND_DASHSCOPE),
                t(ModLanguageData.Keys.VOICE_BACKEND_MIMO),
                t(ModLanguageData.Keys.VOICE_BACKEND_DOUBAO)),
                Math.max(0, BACKENDS.indexOf(draft.backend)), this::onBackendPicked));
        backendPick.setBounds(x, ry, w, NumenStyle.CONTROL_H);
        ry += NumenStyle.ROW_PITCH;

        ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_SERVICE, draft.backend, false, draft.service,
                v -> draft.service = v);

        ry = label(x, ry, ModLanguageData.Keys.VOICE_FORM_URL);
        TextField urlField = ui.add(new TextField(draft.url, v -> draft.url = v)
                .placeholder(defaultUrl(draft.backend)));
        urlField.setBounds(x, ry, w, NumenStyle.CONTROL_H);
        ry += NumenStyle.ROW_PITCH;

        // 后端专属行(行序与旧表单一致,占位符沿用旧示例)。
        switch (draft.backend) {
            case VoiceProfile.BACKEND_SOVITS -> {
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_REF,
                        "D:/refs/voice.wav", false, draft.refAudio, v -> draft.refAudio = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_PROMPT,
                        "", false, draft.promptText, v -> draft.promptText = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_LANG,
                        "zh", false, draft.textLang, v -> draft.textLang = v);
            }
            case VoiceProfile.BACKEND_MINIMAX -> {
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_KEY_MINIMAX,
                        "eyJ…", true, draft.apiKey, v -> draft.apiKey = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_GROUP,
                        "", false, draft.groupId, v -> draft.groupId = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_MINIMAX_MODEL,
                        "speech-02-turbo", false, draft.model, v -> draft.model = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_MINIMAX_VOICE,
                        "male-qn-qingse", false, draft.voice, v -> draft.voice = v);
            }
            case VoiceProfile.BACKEND_FISH -> {
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_KEY_FISH,
                        "sk-…", true, draft.apiKey, v -> draft.apiKey = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_REFERENCE,
                        class_1074.method_4662(ModLanguageData.Keys.VOICE_FISH_REF_PLACEHOLDER), false, draft.voice,
                        v -> draft.voice = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_FISH_MODEL,
                        "s1 / s2.1-pro-free", false, draft.model, v -> draft.model = v);
            }
            case VoiceProfile.BACKEND_DASHSCOPE -> {
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_KEY_DASHSCOPE,
                        "sk-…", true, draft.apiKey, v -> draft.apiKey = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_DASHSCOPE_MODEL,
                        com.dwinovo.numen.api.client.voice.DashScopeTts.DEFAULT_MODEL,
                        false, draft.model, v -> draft.model = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_DASHSCOPE_VOICE,
                        com.dwinovo.numen.api.client.voice.DashScopeTts.DEFAULT_VOICE,
                        false, draft.voice, v -> draft.voice = v);
            }
            case VoiceProfile.BACKEND_MIMO -> {
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_KEY_MIMO,
                        "sk-…", true, draft.apiKey, v -> draft.apiKey = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_MIMO_MODEL,
                        com.dwinovo.numen.api.client.voice.MimoTts.DEFAULT_MODEL,
                        false, draft.model, v -> draft.model = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_MIMO_VOICE,
                        com.dwinovo.numen.api.client.voice.MimoTts.DEFAULT_VOICE,
                        false, draft.voice, v -> draft.voice = v);
            }
            case VoiceProfile.BACKEND_DOUBAO -> {
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_KEY_DOUBAO,
                        "", true, draft.apiKey, v -> draft.apiKey = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_DOUBAO_RESOURCE,
                        com.dwinovo.numen.api.client.voice.DoubaoTts.DEFAULT_RESOURCE_ID,
                        false, draft.model, v -> draft.model = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_DOUBAO_SPEAKER,
                        "zh_female_…_bigtts", false, draft.voice, v -> draft.voice = v);
            }
            default -> {
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_KEY_OPENAI,
                        "sk-…", true, draft.apiKey, v -> draft.apiKey = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_MODEL,
                        "FunAudioLLM/CosyVoice2-0.5B", false, draft.model, v -> draft.model = v);
                ry = textRow(x, ry, w, ModLanguageData.Keys.VOICE_FORM_VOICE,
                        "FunAudioLLM/CosyVoice2-0.5B:alex", false, draft.voice, v -> draft.voice = v);
            }
        }

        ry = label(x, ry, ModLanguageData.Keys.VOICE_FORM_VOLUME);
        Slider volume = ui.add(new Slider(1, 10, 1, draft.volume,
                v -> draft.volume = (int) Math.round(v),
                v -> String.valueOf(Math.round(v))));
        volume.setBounds(x, ry, w - 24, NumenStyle.CONTROL_H);

        // ---- 滚动记账:视口到收尾行上方为止,内容高按最后一行的底边算 ----
        scroll.measure(ui, x, y, w,
                NumenStyle.footerTop(y, h) - NumenStyle.HEADER_GAP - y,
                (ry + NumenStyle.CONTROL_H) - y);

        // ---- 固定层:结果胶囊/按钮行——不随滚动 ----
        resultAlert = fixedUi.add(new InlineAlert());
        resultAlert.setBounds(x, y + 2, w, 24);
        DialogButtons.left(fixedUi, x, y, h, this::runVoiceTest, t(ModLanguageData.Keys.VOICE_TEST));
        DialogButtons.cancelSave(fixedUi, x, y, w, h, onCancel, this::save);
    }

    // ---- 宿主转发面 ----

    public void render(IDrawSurface s, NumenTheme.Colors c, int mouseX, int mouseY, long nowMs) {
        scroll.beginClip(s);
        ui.renderContent(s, c, mouseX, mouseY, nowMs);
        scroll.endClip(s);
        scroll.renderThumb(s, c);
        fixedUi.render(s, c, mouseX, mouseY, nowMs);
        ui.renderOverlayLayer(s, c, mouseX, mouseY, nowMs);
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (ui.hasOverlay()) return ui.mouseClicked(mx, my, button);   // 弹层优先(可越出视口)
        if (fixedUi.mouseClicked(mx, my, button)) return true;
        return scroll.inside(my) && ui.mouseClicked(mx, my, button);
    }

    public boolean mouseDragged(double mx, double my, double dx, double dy) {
        return ui.mouseDragged(mx, my, dx, dy);   // 音量滑条拖动
    }

    public boolean mouseReleased(double mx, double my, int button) {
        return ui.mouseReleased(mx, my, button);
    }

    public boolean mouseScrolled(double mx, double my, double delta) {
        if (ui.mouseScrolled(mx, my, delta)) return true;
        return scroll.scrolled(my, delta);
    }

    public boolean keyPressed(int keyCode, int modifiers) {
        return ui.keyPressed(keyCode, modifiers) || fixedUi.keyPressed(keyCode, modifiers);
    }

    public boolean charTyped(char ch) {
        return ui.charTyped(ch) || fixedUi.charTyped(ch);
    }

    public boolean hasOverlay() {
        return ui.hasOverlay() || fixedUi.hasOverlay();
    }

    // ---- 内部 ----

    private int label(int lx, int ly, String key) {
        labelWidget(lx, ly, key);
        return ly + NumenStyle.LABEL_PITCH;
    }

    /** 标签控件本体:会报错的字段用 withLabel 认领它(出错时自动让位)。 */
    private Label labelWidget(int lx, int ly, String key) {
        Label l = ui.add(new Label(t(key), Label.Role.SECONDARY));
        l.setBounds(lx, ly, 200, 9);
        return l;
    }

    /** 一行"标签+输入框",返回下一行的 y。 */
    private int textRow(int x, int ry, int w, String labelKey, String placeholder,
                        boolean masked, String initial, Consumer<String> onChange) {
        ry = label(x, ry, labelKey);
        TextField f = ui.add(new TextField(initial, onChange).masked(masked));
        if (!placeholder.isEmpty()) f.placeholder(placeholder);
        f.setBounds(x, ry, w, NumenStyle.CONTROL_H);
        return ry + NumenStyle.ROW_PITCH;
    }

    /** 选型变了:行随之换(草稿字段全保);URL 只覆盖"空或还是旧默认"的值。 */
    private void onBackendPicked(int index) {
        String sel = BACKENDS.get(Math.clamp(index, 0, BACKENDS.size() - 1));
        if (sel.equals(draft.backend)) return;
        if (draft.url.isBlank() || draft.url.equals(defaultUrl(draft.backend))) {
            draft.url = defaultUrl(sel);
        }
        draft.backend = sel;
        scroll.toTop();
        build(formX, formY, formW, formH, window);
    }

    private void save() {
        if (draft.name == null || draft.name.isBlank()) {
            nameField.setError(t(ModLanguageData.Keys.GUI_INLINE_REQUIRED));   // 校验错误内联在错误发生处
            return;
        }
        cancelPendingTest();
        onSave.accept(draft);
    }

    /**
     * 试听:用草稿当前值合成固定测试句,就地 2D 播放(不挂实体,
     * {@link com.dwinovo.numen.api.client.voice.VoicePreviewSound} 走与 3D 语音同一条
     * mixin 取数路径)。结果进页面级胶囊:成功自动淡出,失败驻留到下次操作。
     */
    private void runVoiceTest() {
        var probe = new SpokenVoice(profileOf(draft), draft.apiKey.trim());
        resultAlert.show(InlineAlert.Severity.INFO, t(ModLanguageData.Keys.VOICE_TEST_RUNNING));
        final int gen = ++testGen;
        final float vol = probe.volume();
        // 同步防线:后端构建/合成同步抛(坏 URL 曾直接崩掉渲染线程)也只落到胶囊。
        java.util.concurrent.CompletableFuture<byte[]> synth;
        final com.dwinovo.numen.api.client.voice.TtsBackend backend;
        try {
            backend = probe.createBackend();
            synth = backend.synthesize(class_1074.method_4662(ModLanguageData.Keys.VOICE_TEST_SENTENCE));
        } catch (Exception ex) {
            com.dwinovo.numen.api.Constants.LOG.warn("[numen-voice] 试音失败(同步): {}",
                    com.dwinovo.numen.api.client.voice.VoiceError.fromError(ex).getMessage());
            resultAlert.show(InlineAlert.Severity.ERROR,
                    t2(ModLanguageData.Keys.VOICE_TEST_FAIL,
                            shorten(com.dwinovo.numen.api.client.voice.VoiceWords.text(ex))));
            return;
        }
        synth.whenComplete((wav, err) -> {
            com.dwinovo.numen.api.client.voice.PcmAudio decoded = null;
            Throwable failure = err;
            if (err == null) {
                try {
                    decoded = com.dwinovo.numen.api.client.voice.WavCodec.decode(wav).amplified(vol);
                } catch (Exception ex) {
                    failure = ex;
                }
            }
            final var audio = decoded;
            final Throwable fail = failure;
            class_310.method_1551().execute(() -> {
                if (gen != testGen) return;   // 表单已离开/又点了一次:作废
                if (fail != null) {
                    // 完整原因进日志(胶囊里被截短,排障全靠这行)。
                    com.dwinovo.numen.api.Constants.LOG.warn("[numen-voice] 试音失败({}): {}",
                            backend.describe(), com.dwinovo.numen.api.client.voice.VoiceError.fromError(fail).getMessage());
                    resultAlert.show(InlineAlert.Severity.ERROR,
                            t2(ModLanguageData.Keys.VOICE_TEST_FAIL,
                                    shorten(com.dwinovo.numen.api.client.voice.VoiceWords.text(fail))));
                    return;
                }
                var sm = class_310.method_1551().method_1483();
                if (preview != null) sm.method_4870(preview);   // 重听:停掉上一句
                preview = com.dwinovo.numen.api.client.platform.ClientServices.VOICE.previewVoice(audio, 1.0f);
                sm.method_4873(preview);
                resultAlert.show(InlineAlert.Severity.SUCCESS,
                        t(ModLanguageData.Keys.VOICE_TEST_OK), 2_500);
            });
        });
    }

    /** 胶囊是单行:错误原文截短进胶囊,完整版在日志。 */
    private static String shorten(String why) {
        return why.length() > 64 ? why.substring(0, 64) + "…" : why;
    }

    private static String t(String key) {
        return class_2561.method_43471(key).getString();
    }

    private static String t2(String key, Object arg) {
        return class_2561.method_43469(key, arg).getString();
    }
}
