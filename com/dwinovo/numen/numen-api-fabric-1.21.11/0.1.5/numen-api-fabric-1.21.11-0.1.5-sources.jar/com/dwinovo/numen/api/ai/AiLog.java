package com.dwinovo.numen.api.ai;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * numen-ai 模块自己的日志句柄。本模块是纯 JVM 库(零 Minecraft、零 Numen API
 * 依赖),不能回头引用 api 侧的 Constants——日志名沿用同一个 "Numen",两侧输出
 * 在游戏日志里不可区分,行为与拆分前一致。
 *
 * <p>numen-agent 依赖本模块、同样不能引用 Numen API,它的日志也经这一个句柄打。
 */
public final class AiLog {

    public static final Logger LOG = LoggerFactory.getLogger("Numen");

    private AiLog() {}
}
