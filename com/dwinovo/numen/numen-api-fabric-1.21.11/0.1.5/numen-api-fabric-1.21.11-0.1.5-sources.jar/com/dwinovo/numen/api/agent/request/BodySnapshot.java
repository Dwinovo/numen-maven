package com.dwinovo.numen.api.agent.request;

import com.dwinovo.numen.api.network.payload.NumenStatePayload;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1799;

/**
 * 主人这一侧收到的她的身体状态:服务端经 {@link NumenStatePayload} 推来的一份,记下收到的时刻。背包块、效果块照它渲染
 * ({@link RuntimeState}),物品页照它画。
 *
 * <p>{@code loaded=false} = the body is asleep / not ours (no contents). foodLevel 0-20.
 * {@code craft} is the 2×2 crafting menu: indices 0-3 = grid, index 4 = result (may be empty).
 * {@code selectedSlot} indexes {@code items} for the main hand.
 * {@code vehicle} 是座驾的身份({@code EntityLabel}),空串 = 没骑任何东西。
 * {@code bodyState} 是插件从身体上读的状态片段,服务端拼好的整段;空串 = 没有。
 * {@code nearby} 是她四周此刻的样子({@link Nearby}):只有服务端为这一轮请求现取的那份带着它,
 * 主人客户端收到的状态包里没有这一项({@link Nearby#NONE})。
 */
public record BodySnapshot(boolean loaded, List<class_1799> items, List<class_1799> craft,
                           int foodLevel, float saturation, int selectedSlot, class_1799 offhand,
                           List<class_1293> effects,
                           String vehicle, String bodyState,
                           long receivedAtMs, Nearby nearby) {

    /** 收到的这一包,盖上收到的时刻。 */
    public static BodySnapshot of(NumenStatePayload p, long receivedAtMs) {
        return new BodySnapshot(p.loaded(), p.items(), p.craft(), p.foodLevel(), p.saturation(),
                p.selectedSlot(), p.offhand(), p.effects(), p.vehicle(), p.bodyState(),
                receivedAtMs, Nearby.NONE);
    }

    /** 同一份,带上她四周此刻的样子。 */
    public BodySnapshot withNearby(Nearby nearby) {
        return new BodySnapshot(loaded, items, craft, foodLevel, saturation, selectedSlot, offhand, effects, vehicle,
                bodyState, receivedAtMs, nearby);
    }

    /** 主手那一格;槽位越界(空快照)时给空栈。 */
    public class_1799 mainHand() {
        return selectedSlot >= 0 && selectedSlot < items.size()
                ? items.get(selectedSlot)
                : class_1799.field_8037;
    }

    /**
     * 这一刻还剩几刻。<b>服务端只在"多了/少了/升级了"时才重推</b>,所以包里那个时长是
     * 收到那一刻的值;效果是确定性的每刻自减,按收到至今的时间往下扣就是真值。
     *
     * @return 扣完余量,已经过期的给 0
     */
    public int remainingTicks(class_1293 effect, long nowMs) {
        if (effect.method_48559()) {
            return -1;
        }
        long elapsed = Math.max(0L, nowMs - receivedAtMs) / 50L;
        return (int) Math.max(0L, effect.method_5584() - elapsed);
    }
}
