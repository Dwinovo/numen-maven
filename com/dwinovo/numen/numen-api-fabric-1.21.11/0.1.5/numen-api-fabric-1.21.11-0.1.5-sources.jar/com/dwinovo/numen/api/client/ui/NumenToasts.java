package com.dwinovo.numen.api.client.ui;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.DoubleSupplier;
import java.util.function.ToIntFunction;

/**
 * NumenUI 的横幅通知(toast):右上角滑入 → 停留 → 滑出,一次一条,队列排队。
 *
 * <h2>性能形态</h2>
 * 折行/测宽只在首帧接触画布时做一次并缓存进条目;此后每帧渲染是纯绘制,
 * 零排版零分配。滑动用时间驱动的缓动(不积帧),入队线程安全——LLM 异步
 * 回调线程可以直接 {@link #push},排版推迟到渲染线程首帧。
 *
 * <h2>为什么不用原版 toast</h2>
 * 原版 ToastManager 样式锁死成就风、不吃我们的主题,而且其 API 恰好逐版本
 * 变动——自建后整套行为在纯 JVM 层,十一个分支零移植。
 *
 * <h2>文案纪律</h2>
 * 说人话 + 说下一步("密钥无效——检查 API Key 是否复制完整"),不甩堆栈;
 * 堆栈的去处是游戏日志(错误四去处口径)。
 */
public final class NumenToasts {

    public enum Severity { INFO, WARN, ERROR }

    // ---- 时序参数(毫秒) ----
    static final long SLIDE_MS = 200;
    /** 最短停留:与原版系统 toast、成就 toast 一样长。 */
    static final long VISIBLE_MIN_MS = 5_000;
    static final long VISIBLE_MAX_MS = 10_000;
    /** ERROR 至少停留这么久——报错看不清等于没报。 */
    static final long ERROR_VISIBLE_MIN_MS = 8_000;
    /** 每字符追加的停留时长(阅读速度补偿)。 */
    static final long PER_CHAR_MS = 35;

    // ---- 版式参数(像素,GUI 缩放坐标) ----
    static final int MARGIN = 6;
    static final int PAD = NumenStyle.PAD;
    static final int MAX_TEXT_WIDTH = 200;
    static final int MAX_LINES = 3;

    private enum State { SLIDE_IN, VISIBLE, SLIDE_OUT }

    private static final class Toast {
        final Severity severity;
        final String message;
        // 首帧排版缓存
        java.util.List<String> lines;
        int w, h;
        long visibleMs;

        Toast(Severity severity, String message) {
            this.severity = severity;
            this.message = message == null ? "" : message;
        }
    }

    private final Queue<Toast> queue = new ConcurrentLinkedQueue<>();
    /** 停留时长的倍数:游戏里宿主给原版"通知显示时间"那一项(辅助功能设置),和原版 toast 同一个开关。 */
    private final DoubleSupplier displayTimeScale;
    private Toast current;
    private State state;
    private long stateStartMs;

    /** 停留时长不缩放(表单里自带的一份、测试)。 */
    public NumenToasts() {
        this(() -> 1.0);
    }

    /** @param displayTimeScale 停留时长的倍数,每条排版时读一次 */
    public NumenToasts(DoubleSupplier displayTimeScale) {
        this.displayTimeScale = displayTimeScale;
    }

    /** 线程安全;可从任意线程调用(异步 LLM 回调直接用)。 */
    public void push(Severity severity, String message) {
        queue.add(new Toast(severity, message));
    }

    public boolean isIdle() {
        return current == null && queue.isEmpty();
    }

    /**
     * 顶锚定渲染(HUD 场景:右上角滑入)。时间由调用方注入,本类不读钟。
     *
     * @param screenW GUI 缩放后的屏幕宽
     * @param top     从这一行往下排——右上角已经有别人的通知(原版的成就、配方提示)时,宿主给出它们的下沿
     */
    public void render(IDrawSurface s, int screenW, int top, NumenTheme.Colors c, long nowMs) {
        renderAnchored(s, screenW - MARGIN, top + MARGIN, false, c, nowMs);
    }

    /**
     * 底锚定渲染(表单/面板场景):toast 底边贴 {@code bottomY},右边贴
     * {@code rightX}——结果就落在用户正在操作的按钮上方,不把视线拽去
     * 屏幕角落。不是所有提示都该弹右上角。
     */
    public void renderAboveButtons(IDrawSurface s, int rightX, int bottomY,
                                   NumenTheme.Colors c, long nowMs) {
        renderAnchored(s, rightX, bottomY, true, c, nowMs);
    }

    private void renderAnchored(IDrawSurface s, int rightX, int anchorY, boolean bottomAnchored,
                                NumenTheme.Colors c, long nowMs) {
        if (current == null) {
            current = queue.poll();
            if (current == null) return;
            state = State.SLIDE_IN;
            stateStartMs = nowMs;
        }
        if (current.lines == null) {
            layout(current, s::textWidth, s.lineHeight());
        }

        long elapsed = nowMs - stateStartMs;
        if (state == State.SLIDE_IN && elapsed >= SLIDE_MS) {
            state = State.VISIBLE;
            stateStartMs = nowMs;
            elapsed = 0;
        }
        if (state == State.VISIBLE && elapsed >= current.visibleMs) {
            state = State.SLIDE_OUT;
            stateStartMs = nowMs;
            elapsed = 0;
        }
        if (state == State.SLIDE_OUT && elapsed >= SLIDE_MS) {
            current = null;   // 下一帧从队列取下一条
            return;
        }

        // 动效:入场回弹落位+渐显,退场加速离场+渐隐。顶锚定横滑(HUD 右上),
        // 底锚定纵浮(表单按钮上方,从下方 10px 浮起)——方向服从锚点语义。
        float p = Animation.progress(elapsed, SLIDE_MS);
        float alpha = switch (state) {
            case SLIDE_IN -> Animation.easeOutCubic(p);
            case VISIBLE -> 1f;
            case SLIDE_OUT -> 1f - Animation.easeInCubic(p);
        };
        int hiddenOffset = current.w + MARGIN;
        int slideX = 0;
        int riseY = 0;
        if (bottomAnchored) {
            riseY = switch (state) {
                case SLIDE_IN -> Math.round((1 - Animation.easeOutBack(p)) * 10);
                case VISIBLE -> 0;
                case SLIDE_OUT -> -Math.round(Animation.easeInCubic(p) * 8);
            };
        } else {
            slideX = switch (state) {
                case SLIDE_IN -> Math.round(hiddenOffset * (1 - Animation.easeOutBack(p)));
                case VISIBLE -> 0;
                case SLIDE_OUT -> Math.round(hiddenOffset * Animation.easeInCubic(p));
            };
        }

        int x = rightX - current.w + slideX;
        int y = (bottomAnchored ? anchorY - current.h : anchorY) + riseY;
        // 三色语义:正常绿、警告黄、失败红——边框用强色,底用同系浅调。
        int border = switch (current.severity) {
            case INFO -> c.success();
            case WARN -> c.warning();
            case ERROR -> c.danger();
        };
        int bg = switch (current.severity) {
            case INFO -> c.toastInfoBg();
            case WARN -> c.toastWarnBg();
            case ERROR -> c.toastErrorBg();
        };
        s.fillRect(x, y, current.w, current.h, applyAlpha(border, alpha));
        s.fillRect(x + 1, y + 1, current.w - 2, current.h - 2, applyAlpha(bg, alpha));
        if (alpha > 0.05f) {   // MC 字体渲染对极低 alpha 有怪癖,干脆不画
            int textColor = applyAlpha(c.toastText(), alpha);
            int ty = y + PAD;
            for (String line : current.lines) {
                s.drawText(line, x + PAD, ty, textColor, false);
                ty += s.lineHeight();
            }
        }
    }

    /** 颜色的 alpha 通道乘以 {@code a}(渐显渐隐)。 */
    private static int applyAlpha(int argb, float a) {
        int alpha = Math.round(((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, a)));
        return (alpha << 24) | (argb & 0xFFFFFF);
    }

    /** 首帧排版一次:折行、量宽、按字数定停留时长,全部缓存进条目。 */
    private void layout(Toast t, ToIntFunction<String> widthFn, int lineHeight) {
        t.lines = TextWrap.wrap(t.message, MAX_TEXT_WIDTH, widthFn, MAX_LINES);
        int textW = 0;
        for (String line : t.lines) textW = Math.max(textW, widthFn.applyAsInt(line));
        t.w = textW + PAD * 2;
        t.h = Math.max(1, t.lines.size()) * lineHeight + PAD * 2;
        long dur = VISIBLE_MIN_MS + (long) t.message.length() * PER_CHAR_MS;
        if (t.severity == Severity.ERROR) dur = Math.max(dur, ERROR_VISIBLE_MIN_MS);
        t.visibleMs = Math.round(Math.min(dur, VISIBLE_MAX_MS) * displayTimeScale.getAsDouble());
    }
}
