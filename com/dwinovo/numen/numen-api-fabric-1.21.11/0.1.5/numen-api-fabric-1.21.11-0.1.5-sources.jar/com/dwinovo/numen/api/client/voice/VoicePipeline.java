package com.dwinovo.numen.api.client.voice;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.client.agent.ClientNumenLookup;
import java.util.ArrayDeque;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_742;

/**
 * 每同伴一条的流式语音管线：LLM 的 SSE content delta →
 * {@link SentenceDivider} 分句 → {@link VoiceTextSanitizer} 清洗 →
 * 段队列 → 并发预取合成（{@link TtsBackend}）→ <b>按序</b>从同伴身体位置播放
 * （{@link EntityVoiceSound}）。首句在首个逗号级边界就切出去送合成,
 * 开口延迟 ≈ LLM 首句时延 + 单句 TTS 时延。
 *
 * <h2>代际失效（generation）</h2>
 * 每次 {@link #beginTurn} / {@link #interrupt} 递增 {@link #generation}；
 * 开轮时捕获的 gen 随着增量去处、合成完成回调一路携带,落地时对不上号
 * 即整体丢弃。主人夺话的新 turn、主人打断（Stop）、同伴死亡立即停播清队;
 * 事件触发的新 turn 只清未播段,正在播的句子说完再接(句界衔接)。
 * 同伴不在世（客户端解析不到实体）时只清不播。
 *
 * <h2>线程模型</h2>
 * 所有可变状态只在客户端主线程上碰：
 * <ul>
 *   <li>正文增量随循环内核的事件在主线程到达,直接喂 divider;</li>
 *   <li>合成完成同样蹦回主线程落格;</li>
 *   <li>{@link #tick} / {@link #interrupt} 本来就在主线程。</li>
 * </ul>
 *
 * <h2>预取</h2>
 * 队首 {@value #PREFETCH} 段并发合成——下一段在上一段还在播时就开始请求,
 * 播完即接。更深的窗口对本地 GPT-SoVITS 只会造成排队,对按量计费的云服务
 * 则是白花钱（打断时丢弃）,2 是个经验平衡点。
 */
public final class VoicePipeline {

    /** 同时在途的合成请求上限（含正在播的下一段）。 */
    private static final int PREFETCH = 2;

    /** 一段文本的三态：待合成 → 音频就绪 / 失败。 */
    private static final class Segment {
        final String text;
        boolean synthStarted;
        PcmAudio audio;
        boolean failed;
        Segment(String text) { this.text = text; }
    }

    private final UUID entityUuid;
    private final SentenceDivider divider = new SentenceDivider();
    private final ArrayDeque<Segment> queue = new ArrayDeque<>();

    private TtsBackend backend;
    private float volume = 1.0f;
    private int generation;
    private EntityVoiceSound playing;

    public VoicePipeline(UUID entityUuid) {
        this.entityUuid = entityUuid;
    }

    /**
     * 一次 LLM 分发开始,按触发者分两档(语音 agent 的通行做法):主人夺话
     * ({@code bargeIn})立即硬停上一轮——人开口了还把句子说完,体感是"没理我";
     * 她自己接自己的话(事件/任务触发)则句界衔接——正在播的这句说完,旧轮未播段
     * 丢弃,不拦腰、不叠播、不积压陈话。按当前绑定的声线重建后端,返回本轮代际号。
     * 主线程调用。
     */
    public int beginTurn(SpokenVoice cfg, boolean bargeIn) {
        generation++;
        if (bargeIn) {
            stopAndClear();
        } else {
            queue.clear();
            divider.reset();
        }
        this.backend = cfg.createBackend();
        this.volume = cfg.volume();
        return generation;
    }

    /**
     * 这一轮正文增量的去处——思考、工具调用增量不进语音。主线程调用;轮次已被打断或换掉的增量直接丢。
     */
    public Consumer<String> deltaSink(int gen) {
        return delta -> {
            if (gen != generation || delta.isEmpty()) return;
            enqueue(divider.feed(delta));
        };
    }

    /**
     * 整段开说(外接大脑的 say):整段就地分句、排到播放队尾——不动代际、不清存量、
     * 不碰流式那只 divider,连续调用自然连播。声线按传入配置现取(与 {@link #beginTurn}
     * 同一来源);{@link #interrupt}(主人打断/死亡)照样一刀切停它。主线程调用。
     */
    public void sayAppend(SpokenVoice cfg, String text) {
        if (text == null || text.isBlank()) return;
        this.backend = cfg.createBackend();
        this.volume = cfg.volume();
        SentenceDivider whole = new SentenceDivider();
        List<String> segments = new java.util.ArrayList<>(whole.feed(text));
        segments.addAll(whole.flush());
        enqueue(segments);
    }

    /** 流结束（正常或出错都调）：flush 分句器余量。任意线程可调。 */
    public void endTurn(int gen) {
        class_310.method_1551().execute(() -> {
            if (gen != generation) return;
            enqueue(divider.flush());
        });
    }

    /** 停播 + 清队列 + 作废一切在途回调。主线程调用（abort / 死亡 / 收尾）。 */
    public void interrupt() {
        generation++;
        stopAndClear();
    }

    /** 每客户端 tick 驱动一次：推进播放接续。主线程调用。 */
    public void tick() {
        if (playing == null && queue.isEmpty()) return;
        pumpPlayback();
    }

    /** 有段在播或还有段没播完（调试/状态用）。 */
    public boolean isSpeaking() {
        return playing != null || !queue.isEmpty();
    }

    // ---- internals（全部主线程） ----

    private void enqueue(List<String> rawSegments) {
        for (String raw : rawSegments) {
            String clean = VoiceTextSanitizer.clean(raw);
            if (clean.isEmpty()) continue;   // 纯记号/纯标点段:跳过,不浪费请求
            queue.add(new Segment(clean));
        }
        pumpSynthesis();
        pumpPlayback();
    }

    /** 给队首至多 {@link #PREFETCH} 个未启动的段发起合成。 */
    private void pumpSynthesis() {
        if (backend == null) return;
        final int gen = generation;
        int inWindow = 0;
        for (Segment seg : queue) {
            if (inWindow >= PREFETCH) break;
            if (seg.failed) continue;
            inWindow++;
            if (seg.synthStarted) continue;
            seg.synthStarted = true;
            final Segment target = seg;
            final long t0 = System.nanoTime();
            backend.synthesize(seg.text).whenComplete((wav, err) -> {
                PcmAudio decoded = null;
                Throwable failure = err;
                if (err == null) {
                    try {
                        if (wav == null || wav.length == 0) {
                            throw VoiceError.of(VoiceError.EMPTY_AUDIO);
                        }
                        // 归一化+用户增益烙进采样(MC 实例音量被引擎钳在 1.0,只能在这做响度)。
                        decoded = WavCodec.decode(wav).amplified(volume);
                    } catch (Exception ex) {
                        failure = ex;
                    }
                }
                final PcmAudio audio = decoded;
                final Throwable fail = failure;
                class_310.method_1551().execute(() -> {
                    if (gen != generation) return;   // 本轮已被打断,结果作废
                    if (fail != null) {
                        target.failed = true;
                        Constants.LOG.warn("[numen-voice#{}] 合成失败({}), 跳过该句({} 字): {}",
                                entityUuid, backend.describe(), target.text.length(), unwrap(fail));
                    } else {
                        target.audio = audio;
                        // INFO 而非 debug:每句一行,是"流式分句确实在 LLM 说完前就开始
                        // 合成"的唯一运行时证据,也是合成延迟的常驻观测点。
                        Constants.LOG.info("[numen-voice#{}] 合成完成 {}ms, {}ms 音频, {} 字",
                                entityUuid, (System.nanoTime() - t0) / 1_000_000,
                                audio.durationMs(), target.text.length());
                    }
                    pumpSynthesis();
                    pumpPlayback();
                });
            });
        }
    }

    /** 上一段播完且队首音频就绪 → 从同伴当前位置接着播。 */
    private void pumpPlayback() {
        class_310 mc = class_310.method_1551();
        if (playing != null) {
            if (mc.method_1483().method_4877(playing)) return;   // 还在播
            playing = null;
        }
        while (!queue.isEmpty() && queue.peek().failed) {
            queue.poll();   // 失败段直接跳过,继续后面的
            pumpSynthesis();
        }
        Segment head = queue.peek();
        if (head == null || head.audio == null) return;   // 空了,或还在合成

        class_742 body = ClientNumenLookup.resolve(entityUuid);
        if (body == null) {
            // 同伴不在世:只清不播。
            Constants.LOG.info("[numen-voice#{}] 实体不在场,丢弃 {} 段待播语音",
                    entityUuid, queue.size());
            stopAndClear();
            return;
        }
        queue.poll();
        // 经平台工厂创建:NeoForge 返回覆写官方 getStream 补丁钩子的子类,
        // Fabric 返回原类走 vanilla mixin——取数机制两侧不同(见 IVoiceSoundFactory)。
        // 响度已烙进 PCM(amplified),实例音量恒 1.0——只留 3D 距离衰减。
        playing = com.dwinovo.numen.api.client.platform.ClientServices.VOICE
                .entityVoice(entityUuid, body, head.audio, 1.0f);
        mc.method_1483().method_4873(playing);
        Constants.LOG.info("[numen-voice#{}] 开播 {}ms, {} 字",
                entityUuid, head.audio.durationMs(), head.text.length());
        pumpSynthesis();
    }

    private void stopAndClear() {
        if (playing != null) {
            class_310.method_1551().method_1483().method_4870(playing);
            playing = null;
        }
        queue.clear();
        divider.reset();
    }

    private static String unwrap(Throwable t) {
        Throwable cur = t;
        while (cur.getCause() != null && cur != cur.getCause()) cur = cur.getCause();
        return cur.getClass().getSimpleName() + ": " + cur.getMessage();
    }
}
