package com.dwinovo.numen.api.brain;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.keys.ServerKeyQuota;
import com.dwinovo.numen.api.platform.Services;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.server.MinecraftServer;

import java.util.Map;
import java.util.UUID;

/**
 * {@code /numen usage}:管理员查服主的 key 今天每个人用了多少 token(以及每人每天的限额,{@code server.json} 里设)。
 * 玩家自己的 key 不在这里——那是他自己的账。
 */
public final class UsageCommand {

    private UsageCommand() {}

    /** 挂在 {@code /numen} 下的一格,只有管理员用得了。 */
    public static LiteralArgumentBuilder<class_2168> node() {
        return class_2170.method_9247("usage").requires(source -> Services.permissions().isAdmin(source))
                .executes(UsageCommand::run);
    }

    private static int run(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        MinecraftServer server = source.method_9211();
        ServerKeyQuota quota = ModelServices.of(server).quota();
        Map<UUID, Long> used = quota.usedToday();
        source.method_9226(() -> class_2561.method_43469(Keys.USAGE_HEADER, quota.limit() == 0
                ? class_2561.method_43471(Keys.USAGE_UNLIMITED) : class_2561.method_43470(String.valueOf(quota.limit()))), false);
        if (used.isEmpty()) {
            source.method_9226(() -> class_2561.method_43471(Keys.USAGE_NOBODY), false);
        }
        used.forEach((player, tokens) -> source.method_9226(() -> class_2561.method_43469(Keys.USAGE_LINE,
                server.method_73550().comp_4407().method_14512(player).map(net.minecraft.class_11560::comp_4423).orElse(player.toString()),
                tokens), false));
        return used.size();
    }
}
