package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.path.ClientPathViz;
import net.minecraft.core.BlockPos;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;
import java.util.UUID;

/**
 * Server → Client: the companion's current pathfinding plan, for the in-world
 * path overlay. The path is computed and owned on the server (the client has
 * no planner state of its own to render from), so the body pushes the plan to
 * the owner whenever it
 * (re)plans a segment, and pushes an EMPTY one (all lists empty, no goal) to
 * clear the overlay when the path ends.
 *
 * <ul>
 *   <li>{@code nodes} — the path positions (feet cells); drawn as a red poly-line.</li>
 *   <li>{@code toBreak} — blocks the path will dig; drawn as red boxes.</li>
 *   <li>{@code toPlace} — scaffold blocks the path will place; drawn as green boxes.</li>
 *   <li>{@code goal} — the goal cell; drawn as a green box (absent while clearing).</li>
 * </ul>
 */
public record PathVizPayload(UUID companion,
                             ResourceLocation dimension,
                             List<BlockPos> nodes,
                             List<BlockPos> toBreak,
                             List<BlockPos> toPlace,
                             List<BlockPos> targets) implements CustomPacketPayload {

    /** Cap per list — paths are trimmed well below this; defends against absurd input. */
    public static final int MAX = 512;

    public static final Type<PathVizPayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(Constants.MOD_ID, "path_viz"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PathVizPayload> STREAM_CODEC =
            StreamCodec.composite(
                    UUIDUtil.STREAM_CODEC, PathVizPayload::companion,
                    ResourceLocation.STREAM_CODEC, PathVizPayload::dimension,
                    BlockPos.STREAM_CODEC.apply(ByteBufCodecs.list(MAX)), PathVizPayload::nodes,
                    BlockPos.STREAM_CODEC.apply(ByteBufCodecs.list(MAX)), PathVizPayload::toBreak,
                    BlockPos.STREAM_CODEC.apply(ByteBufCodecs.list(MAX)), PathVizPayload::toPlace,
                    BlockPos.STREAM_CODEC.apply(ByteBufCodecs.list(MAX)), PathVizPayload::targets,
                    PathVizPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(PathVizPayload p) {
        ClientPathViz.accept(p);
    }
}
