package com.dwinovo.numen.client.stt;

import com.dwinovo.numen.platform.services.INumenConfig;

import java.util.List;

/**
 * 语音输入预设 + 后端工厂。预设只预填 baseUrl/model(用户填 key 即可用),`backend`
 * 字段选实现——目前只有 {@code whisper-http}(OpenAI 兼容批量);未来加流式(阿里/腾讯)
 * 只在这里加一个预设 + {@link #fromConfig} 里加一个 case,上层不动。UI 下拉共用本列表。
 */
public final class SttProviders {

    private SttProviders() {}

    public static final String BACKEND_WHISPER_HTTP = "whisper-http";

    public record Option(String id, String displayName, String backend,
                         String defaultBaseUrl, String defaultModel) {}

    private static final List<Option> PRESETS = List.of(
            new Option("siliconflow", "SiliconFlow (硅基流动)", BACKEND_WHISPER_HTTP,
                    "https://api.siliconflow.cn", "FunAudioLLM/SenseVoiceSmall"),
            new Option("openai", "OpenAI Whisper", BACKEND_WHISPER_HTTP,
                    "https://api.openai.com", "whisper-1"),
            new Option("groq", "Groq", BACKEND_WHISPER_HTTP,
                    "https://api.groq.com/openai", "whisper-large-v3-turbo"),
            new Option("custom", "Custom (OpenAI-compatible)", BACKEND_WHISPER_HTTP, "", ""));

    public static List<Option> all() {
        return PRESETS;
    }

    public static Option byId(String id) {
        String norm = id == null ? "" : id.strip().toLowerCase();
        for (Option o : PRESETS) {
            if (o.id().equals(norm)) {
                return o;
            }
        }
        return PRESETS.get(0);
    }

    /**
     * 据全局配置实例化后端。无 API key 时返回 {@code null}(=语音输入未启用)。
     * baseUrl / model 留空时回落到所选预设的默认值。
     */
    public static SttBackend fromConfig(INumenConfig cfg) {
        String key = cfg.getSttApiKey();
        if (key == null || key.isBlank()) {
            return null;
        }
        Option opt = byId(cfg.getSttProvider());
        String base = cfg.getSttBaseUrl();
        if (base == null || base.isBlank()) {
            base = opt.defaultBaseUrl();
        }
        String model = cfg.getSttModel();
        if (model == null || model.isBlank()) {
            model = opt.defaultModel();
        }
        return switch (opt.backend()) {
            case BACKEND_WHISPER_HTTP -> new WhisperHttpStt(base, key, model);
            default -> new WhisperHttpStt(base, key, model);
        };
    }
}
