package com.dwinovo.numen.client.hud;

import com.dwinovo.numen.agent.llm.ConvoState;
import com.dwinovo.numen.agent.provider.AssistantTurn;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import com.dwinovo.numen.client.agent.NumenRoster;
import com.dwinovo.numen.client.agent.ClientNumenLookup;
import com.dwinovo.numen.client.screen.NumenScreen;
import com.dwinovo.numen.client.screen.Nb;
import com.dwinovo.numen.client.screen.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.PlayerSkin;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Left-edge activity HUD with a three-stage lifecycle per companion:
 * <ol>
 *   <li><b>Idle</b> (no recent activity) — the avatar is retracted off-screen, leaving only a thin gold
 *       sliver at the very edge as a "still here" hint.</li>
 *   <li><b>Recently active, toast expired</b> — the avatar lingers, fully out, but no bubble.</li>
 *   <li><b>Active</b> (just spoke) — the avatar AND a toast bubble slide out together.</li>
 * </ol>
 * "Active" = any new assistant turn or the loop being busy; the avatar's lifetime ({@link #AVATAR_LIFE_MS})
 * is longer than a toast line's ({@link #LINE_LIFE_MS}), so stage 2 exists. A fresh message after a long
 * idle pulls the avatar and the bubble out together. Tool-only turns refresh activity but raise no bubble.
 */
public final class NumenToasts {

    private static final int W = 172;            // bubble width
    private static final int AVATAR = 24;        // avatar head size
    private static final int MARGIN = 0;         // avatar flush against the left window edge (no gap)
    private static final int STACK_GAP = 8;
    private static final int BUBBLE_GAP = 5;
    private static final int SLIVER_W = 3;       // collapsed gold edge
    private static final int COLLAPSE_MAX = 5;   // more than this many companions → one shared slot
    private static final int LINE_H = 11;
    private static final int PADV = 5;
    private static final int INNER_W = W - 14;
    private static final int MAX_LINES = 4;
    private static final int MAX_REPLY_LINES = 3;
    private static final long LINE_LIFE_MS = 5000;                  // toast line lifetime
    private static final long AVATAR_LIFE_MS = LINE_LIFE_MS + 8000; // avatar lingers 8 s past the toast
    private static final long SLIDE_MS = 220;

    private static net.minecraft.resources.ResourceLocation spr(String n) {
        return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(com.dwinovo.numen.Constants.MOD_ID, n);
    }
    private static final net.minecraft.resources.ResourceLocation AVATAR_FRAME = spr("avatar_frame");

    private static final Map<UUID, Integer> SEEN = new HashMap<>();
    private static final Map<UUID, Status> STATUS = new HashMap<>();

    private NumenToasts() {}

    private record Line(String text, int color, long bornMs) {}

    private static final class Status {
        long lastActivityMs;      // any assistant turn / busy tick — drives the avatar lifetime
        long activatedMs;         // last idle→active transition — drives the avatar slide-out
        long bubbleBornMs;        // last time a bubble (re)appeared — drives the bubble slide-out
        final Deque<Line> lines = new ArrayDeque<>();
    }

    /** Expire toast lines, then poll loops for new assistant turns / busy state. */
    public static void tick() {
        long now = System.currentTimeMillis();
        STATUS.values().forEach(s -> s.lines.removeIf(l -> now - l.bornMs() > LINE_LIFE_MS));

        for (NumenRoster.Entry entry : NumenRoster.instance().entries()) {
            UUID uuid = entry.uuid();
            AgentLoopRegistry.get(uuid).ifPresent(loop -> {
                // Physical transcript: append-only even across compaction, so the
                // seen-index below can never go backwards (the logical context
                // shrinks when compaction swaps it for a summary).
                List<ConvoState.Msg> snap = loop.display();
                int prev = SEEN.getOrDefault(uuid, -1);
                if (prev >= 0) {
                    for (int i = prev; i < snap.size(); i++) {
                        if (snap.get(i) instanceof ConvoState.Msg.Assistant a) {
                            markActivity(uuid, now);
                            if (a.turn().content() != null && !a.turn().content().isBlank()) {
                                addToastLines(uuid, a.turn(), now);
                            }
                        }
                    }
                }
                SEEN.put(uuid, snap.size());
                if (loop.isBusy()) markActivity(uuid, now);   // keep the avatar out during long task runs
            });
        }
    }

    private static void markActivity(UUID uuid, long now) {
        Status s = STATUS.computeIfAbsent(uuid, k -> new Status());
        if (now - s.lastActivityMs >= AVATAR_LIFE_MS) s.activatedMs = now;   // was collapsed → start slide-out
        s.lastActivityMs = now;
    }

    private static void addToastLines(UUID uuid, AssistantTurn turn, long now) {
        // 气泡与聊天面板同一套显示过滤(剥 [emotion] 语气标签等协议记号)。
        String shown = com.dwinovo.numen.client.chat.ChatDisplayFilters.current()
                .filterAssistantMessage(turn.content());
        if (shown.isBlank()) return;
        UiTheme th = UiTheme.current();
        Status s = STATUS.computeIfAbsent(uuid, k -> new Status());
        boolean wasEmpty = s.lines.isEmpty();
        for (String wrapped : wrapToWidth(shown, INNER_W, MAX_REPLY_LINES)) {
            s.lines.addLast(new Line(wrapped, th.text(), now));   // 深字浅底,与面板气泡同款
        }
        while (s.lines.size() > MAX_LINES) s.lines.removeFirst();
        if (wasEmpty) s.bubbleBornMs = now;                 // fresh bubble → restart the slide
    }

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof NumenScreen) return;
        List<NumenRoster.Entry> entries = new ArrayList<>(NumenRoster.instance().entries());
        if (entries.isEmpty()) return;

        Font font = mc.font;
        UiTheme th = UiTheme.current();
        long now = System.currentTimeMillis();
        int n = entries.size();

        // Past COLLAPSE_MAX companions the stacked rail overflows the screen (and can't scroll), so
        // collapse to a single centred slot that always shows whoever spoke / acted most recently —
        // a new turn from any companion preempts the slot (latest wins).
        if (n > COLLAPSE_MAX) {
            renderOne(g, font, th, mostRecentlyActive(entries), (g.guiHeight() - AVATAR) / 2, now);
            return;
        }

        int startY = (g.guiHeight() - (n * AVATAR + (n - 1) * STACK_GAP)) / 2;
        for (int i = 0; i < n; i++) {
            renderOne(g, font, th, entries.get(i).uuid(), startY + i * (AVATAR + STACK_GAP), now);
        }
    }

    /** Draw one companion's avatar (+ bubble) at row {@code ay}, through its idle→active→retract stages. */
    private static void renderOne(GuiGraphics g, Font font, UiTheme th, UUID uuid, int ay, long now) {
        Status s = STATUS.get(uuid);
        long sinceActive = s == null ? Long.MAX_VALUE : now - s.lastActivityMs;

        if (s != null && sinceActive < AVATAR_LIFE_MS) {                 // stage 2/3 — avatar out
            int ax = MARGIN - slideOut(now - s.activatedMs, MARGIN + AVATAR);
            if (!s.lines.isEmpty()) drawBubble(g, font, ax, ay, s, now); // stage 3 — bubble too
            drawAvatar(g, uuid, ax, ay, th);
        } else {
            long collapseAge = s == null ? Long.MAX_VALUE : sinceActive - AVATAR_LIFE_MS;
            if (collapseAge < SLIDE_MS) {                                // retracting off-screen
                int ax = MARGIN - ((MARGIN + AVATAR) - slideOut(collapseAge, MARGIN + AVATAR));
                drawAvatar(g, uuid, ax, ay, th);
            } else {                                                     // stage 1 — gold sliver only
                g.fill(0, ay + 2, SLIVER_W, ay + AVATAR - 2, th.cta());
            }
        }
    }

    /** The companion that spoke / acted most recently (latest {@code lastActivityMs}); the first entry
     *  if none has any activity yet. Drives the collapsed single-slot HUD. */
    private static UUID mostRecentlyActive(List<NumenRoster.Entry> entries) {
        UUID best = entries.get(0).uuid();
        long bestT = Long.MIN_VALUE;
        for (NumenRoster.Entry e : entries) {
            Status s = STATUS.get(e.uuid());
            long t = s == null ? Long.MIN_VALUE : s.lastActivityMs;
            if (t >= bestT) { bestT = t; best = e.uuid(); }
        }
        return best;
    }

    private static void drawAvatar(GuiGraphics g, UUID uuid, int x, int y, UiTheme th) {
        // textured socket behind the head (same sprite as the panel rail), face on top covering the centre
        g.blitSprite(
                AVATAR_FRAME, x - 2, y - 2, AVATAR + 4, AVATAR + 4);
        PlayerFaceRenderer.draw(g, skinFor(uuid), x, y, AVATAR);
    }


    private static void drawBubble(GuiGraphics g, Font font, int ax, int ay, Status s, long now) {
        int h = s.lines.size() * LINE_H + PADV * 2;
        // 与聊天面板同款的圆角奶油气泡,宽度贴内容(短句不再拖一整条)。
        int need = 0;
        for (Line line : s.lines) need = Math.max(need, font.width(line.text()));
        int bw = Math.min(W, need + 14);
        int targetX = ax + AVATAR + BUBBLE_GAP;
        int bx = targetX - slideOut(now - s.bubbleBornMs, AVATAR + BUBBLE_GAP);
        int by = ay + AVATAR / 2 - h / 2;
        com.dwinovo.numen.client.ui.RoundRect.card(g, bx, by, bx + bw, by + h, 4,
                com.dwinovo.numen.client.ui.ChatColors.AI_FILL,
                com.dwinovo.numen.client.ui.ChatColors.AI_BORDER);
        int ly = by + PADV;
        for (Line line : s.lines) {
            Nb.text(g, font, line.text(), bx + 7, ly, line.color());
            ly += LINE_H;
        }
    }

    private static PlayerSkin skinFor(UUID uuid) {
        AbstractClientPlayer e = ClientNumenLookup.resolve(uuid);
        return e != null ? e.getSkin() : DefaultPlayerSkin.get(uuid);
    }

    /** Eased slide: {@code dist} px → 0 over {@link #SLIDE_MS}. */
    private static int slideOut(long age, int dist) {
        if (age >= SLIDE_MS) return 0;
        return (int) (dist * (1f - com.dwinovo.numen.client.ui.Anim.easeOutCubic(
                (float) age / SLIDE_MS)));
    }

    /** Greedily wrap to a pixel width (CJK-aware), capped at {@code maxLines}; ellipsis if truncated. */
    private static List<String> wrapToWidth(String text, int maxW, int maxLines) {
        Font font = Minecraft.getInstance().font;
        String s = text.replaceAll("\\s+", " ").trim();
        List<String> out = new ArrayList<>();
        while (!s.isEmpty() && out.size() < maxLines) {
            String head = font.plainSubstrByWidth(s, maxW);
            if (head.isEmpty()) head = s.substring(0, 1);
            out.add(head.trim());
            s = s.substring(head.length());
        }
        if (!s.isEmpty() && !out.isEmpty()) {
            String last = out.get(out.size() - 1);
            while (!last.isEmpty() && font.width(last + "…") > maxW) last = last.substring(0, last.length() - 1);
            out.set(out.size() - 1, last + "…");
        }
        return out;
    }

    public static void clear() {
        SEEN.clear();
        STATUS.clear();
    }
}
