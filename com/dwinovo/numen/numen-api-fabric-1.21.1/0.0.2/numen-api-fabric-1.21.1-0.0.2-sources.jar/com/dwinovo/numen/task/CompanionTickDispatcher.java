package com.dwinovo.numen.task;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.payload.TaskResultPayload;
import com.dwinovo.numen.platform.Services;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Server-tick driver of companion tasks — the player-body replacement for the
 * Mob's {@code GoalSelector} + {@code customServerAiStep}. Each tick, for every
 * live {@link NumenPlayer}: pull the head of its task queue, run the matching
 * {@link CompanionTask} to completion (deadline-bounded), and ship finished
 * results back to the owner as {@link TaskResultPayload}. Registered from both
 * loaders' end-of-tick hooks.
 */
public final class CompanionTickDispatcher {

    private record Running(CompanionTask task, TaskRecord record) {}

    private static final Map<UUID, Running> ACTIVE = new HashMap<>();

    private CompanionTickDispatcher() {}

    public static void tick(MinecraftServer server) {
        com.dwinovo.numen.entity.Companions.tickRespawns(server);   // timed death recoveries
        for (class_3222 p : server.method_3760().method_14571()) {
            if (p instanceof NumenPlayer ap) {
                tickOne(ap);
            }
        }
    }

    /**
     * Drop a companion's running task WITHOUT shipping a result — used on death, where the client's
     * {@code NumenDeathPayload} already resolves the in-flight tool call with the death cause (so a
     * second result here would be a duplicate the client ignores). The follow-up {@code despawn} →
     * {@link #onCompanionRemoved} then finds nothing to finalize.
     */
    public static void clearActiveTask(NumenPlayer player) {
        ACTIVE.remove(player.method_5667());
        player.setActiveTask(null);
        player.setDebugTask(null);
    }

    /**
     * Finalize a companion's running task because the BODY is leaving the world
     * (dormancy / dismissal / death) — the tick loop only visits players still in
     * the player list, so without this the running task is orphaned in {@link
     * #ACTIVE} and its {@code buildResult} side-effects never run (e.g. a mining
     * dig's crack overlay would stay painted on every viewer until chunk reload).
     * Cancels the running task through the same terminal path a normal finish
     * takes, then ships the result if the owner is online.
     */
    public static void onCompanionRemoved(NumenPlayer player) {
        Running running = ACTIVE.remove(player.method_5667());
        if (running == null) return;
        TaskState st = running.record().getState();
        if (st == TaskState.RUNNING || st == TaskState.PENDING) {
            st = TaskState.CANCELLED;
            running.record().setState(st);
        }
        running.record().setResult(running.task().buildResult(st));
        player.getTaskQueue().complete(running.record());
        player.setActiveTask(null);
        player.setDebugTask(null);
        drainResults(player);
    }

    private static void tickOne(NumenPlayer player) {
        UUID id = player.method_5667();
        Running running = ACTIVE.get(id);

        if (running == null) {
            TaskRecord rec = player.getTaskQueue().pollHead();
            if (rec != null) {
                rec.setState(TaskState.RUNNING);
                player.setActiveTask(rec);
                player.setDebugTask(rec.describe());
                player.pathTally().reset();
                CompanionTask task = CompanionTaskFactory.create(player, rec);
                running = new Running(task, rec);
                ACTIVE.put(id, running);
                task.start();   // may flip the record terminal immediately
            }
        } else if (running.record().getState() == TaskState.RUNNING) {
            if (player.method_37908().method_8510() >= running.record().getDeadlineGameTime()) {
                running.record().setState(TaskState.TIMEOUT);
            } else {
                running.record().setState(running.task().tick());
            }
        }

        // Finish on any terminal state (set by start(), tick(), deadline, or cancel).
        running = ACTIVE.get(id);
        if (running != null) {
            TaskState st = running.record().getState();
            if (st != TaskState.RUNNING && st != TaskState.PENDING) {
                running.record().setResult(running.task().buildResult(st));
                player.getTaskQueue().complete(running.record());
                player.setActiveTask(null);
                player.setDebugTask(null);
                ACTIVE.remove(id);
            }
        }

        drainResults(player);
    }

    private static void drainResults(NumenPlayer player) {
        List<TaskRecord> completed = player.getTaskQueue().drainCompleted();
        if (completed.isEmpty()) return;
        class_3222 owner = player.resolveOwnerPlayer();
        if (owner == null) return;   // owner offline — drop (the loop will re-ask)
        for (TaskRecord rec : completed) {
            TaskResult result = rec.getResult();
            String json = result == null
                    ? "{\"success\":false,\"message\":\"no result produced\"}"
                    : result.toJson();
            Services.NETWORK.sendToPlayer(owner,
                    new TaskResultPayload(player.method_5667(), rec.getToolCallId(), json));
        }
    }
}
