package com.dwinovo.numen.task;

import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

/**
 * Small adapter giving the companion task layer the {@code SimpleContainer}-style
 * inventory operations it grew up on (count / remove-by-type / add-with-leftover)
 * over the player's native {@link class_1661}. The Mob used a 27-slot
 * SimpleContainer; the player body uses its full Inventory (hotbar + main +
 * armor + offhand), all reachable via {@link class_1661#method_5439()} /
 * {@link class_1661#method_5438(int)}.
 */
public final class PlayerInv {

    private PlayerInv() {}

    /** Total count of {@code item} across the whole inventory. */
    public static int count(class_1661 inv, class_1792 item) {
        int n = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960() && s.method_31574(item)) n += s.method_7947();
        }
        return n;
    }

    /** First slot holding {@code item}, or -1. */
    public static int findSlot(class_1661 inv, class_1792 item) {
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960() && s.method_31574(item)) return i;
        }
        return -1;
    }

    /** Remove up to {@code max} of {@code item}; returns how many were removed. */
    public static int remove(class_1661 inv, class_1792 item, int max) {
        int removed = 0;
        for (int i = 0; i < inv.method_5439() && removed < max; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_7960() || !s.method_31574(item)) continue;
            int take = Math.min(s.method_7947(), max - removed);
            s.method_7934(take);
            removed += take;
        }
        inv.method_5431();
        return removed;
    }

    /**
     * Add {@code stack} to the inventory; returns whatever didn't fit (empty if
     * all fit). Mirrors {@code SimpleContainer.addItem}'s leftover contract over
     * {@link class_1661#method_7394(class_1799)} (which mutates the stack down by what fit).
     */
    public static class_1799 add(class_1661 inv, class_1799 stack) {
        inv.method_7394(stack);
        return stack;   // Inventory.add consumed what fit; remainder stays here
    }
}
