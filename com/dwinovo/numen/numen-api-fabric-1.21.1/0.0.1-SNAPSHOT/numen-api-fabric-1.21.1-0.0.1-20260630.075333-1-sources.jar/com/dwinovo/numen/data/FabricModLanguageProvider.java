package com.dwinovo.numen.data;

import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;

/**
 * Fabric-side translation provider. One instance per locale; both feed the
 * shared {@link ModLanguageData} catalogue so the English and Simplified
 * Chinese JSONs stay in sync key-by-key.
 */
public final class FabricModLanguageProvider extends FabricLanguageProvider {

    private final String locale;

    public FabricModLanguageProvider(FabricDataOutput output, String locale,
                                     CompletableFuture<class_7225.class_7874> registries) {
        super(output, locale, registries);
        this.locale = locale;
    }

    @Override
    public void generateTranslations(class_7225.class_7874 registries, TranslationBuilder builder) {
        ModLanguageData.addTranslations(locale, builder::add);
    }
}
