package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: an asynchronous WORLD EVENT for a companion's brain (dimension change, a hazard,
 * …) — the generic version of Claude Code's "channel notification" (an external event pushed into a
 * running session). The server detects the event (edge-triggered) and ships a ready-made {@code <event>}
 * XML string; the client loop queues it like an owner prompt and splices it in at a protocol-valid
 * boundary. {@code urgent} wakes an idle brain to react now; otherwise it rides along on the next
 * owner-driven turn (no extra LLM call). Death is its own bespoke freeze/thaw pair, not this.
 */
public record NumenEventPayload(UUID entityUuid, String xml, boolean urgent) implements class_8710 {

    public static final class_9154<NumenEventPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "numen_event"));

    public static final class_9139<class_9129, NumenEventPayload> STREAM_CODEC =
            class_9139.method_56436(
                    class_4844.field_48453, NumenEventPayload::entityUuid,
                    class_9135.field_48554, NumenEventPayload::xml,
                    class_9135.field_48547, NumenEventPayload::urgent,
                    NumenEventPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenEventPayload p) {
        AgentLoopRegistry.get(p.entityUuid()).ifPresent(loop -> loop.injectEvent(p.xml(), p.urgent()));
    }
}
