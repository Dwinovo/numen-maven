package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: ask the receiving owner's client to perform a local UI action.
 * The {@code /numen} command tree lives entirely on the server now (so it
 * doesn't collide with the client-side command dispatcher), but a couple of its
 * verbs — opening the settings GUI, clearing the conversation loops — are
 * inherently client-local. The server command just fires this packet at the
 * caller and their client does the rest.
 */
public record ClientUiActionPayload(Action action) implements class_8710 {

    public enum Action { OPEN_SETTINGS, RESET_LOOPS }

    public static final class_9154<ClientUiActionPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "client_ui_action"));

    public static final class_9139<class_9129, ClientUiActionPayload> STREAM_CODEC =
            class_9139.method_56434(
                    class_9135.field_48550.method_56432(i -> Action.values()[i], a -> a.ordinal()),
                    ClientUiActionPayload::action,
                    ClientUiActionPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(ClientUiActionPayload p) {
        switch (p.action()) {
            case OPEN_SETTINGS -> com.dwinovo.numen.client.screen.SettingsScreen.open(null);
            case RESET_LOOPS -> com.dwinovo.numen.client.agent.AgentLoopRegistry.clear();
        }
    }
}
