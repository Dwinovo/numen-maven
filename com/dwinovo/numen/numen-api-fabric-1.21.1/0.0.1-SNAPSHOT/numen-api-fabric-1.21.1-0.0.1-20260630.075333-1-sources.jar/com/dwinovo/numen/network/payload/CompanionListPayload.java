package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.NumenRoster;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: the roster of companions this player owns (UUID + name).
 * The companion body is a fake {@code ServerPlayer}, so the client can't be
 * "enrolled" by right-clicking a Mob any more — the server is the authority on
 * which companions exist. Pushed on owner login (after their dormant companions
 * respawn) and right after a fresh summon, so the client's {@link NumenRoster}
 * panel always reflects the truth without the player having to seek each body
 * out physically.
 */
public record CompanionListPayload(List<Entry> companions) implements class_8710 {

    /** Cap defends against absurd input; nobody owns hundreds of companions. */
    public static final int MAX = 64;

    /** One companion's roster line. */
    public record Entry(UUID uuid, String name) {
        static final class_9139<class_9129, Entry> CODEC =
                class_9139.method_56435(
                        class_4844.field_48453, Entry::uuid,
                        class_9135.method_56364(256), Entry::name,
                        Entry::new);
    }

    public static final class_9154<CompanionListPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "companion_list"));

    public static final class_9139<class_9129, CompanionListPayload> STREAM_CODEC =
            class_9139.method_56434(
                    Entry.CODEC.method_56433(class_9135.method_58000(MAX)),
                    CompanionListPayload::companions,
                    CompanionListPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(CompanionListPayload p) {
        java.util.List<NumenRoster.Entry> snapshot = new java.util.ArrayList<>();
        for (Entry e : p.companions()) {
            snapshot.add(new NumenRoster.Entry(e.uuid(), e.name()));
        }
        NumenRoster.instance().replaceAll(snapshot);
    }
}
