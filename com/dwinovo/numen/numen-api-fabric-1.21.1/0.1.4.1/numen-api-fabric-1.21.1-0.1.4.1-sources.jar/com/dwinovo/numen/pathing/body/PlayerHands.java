package com.dwinovo.numen.pathing.body;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import com.dwinovo.numen.pathing.plan.DigTime;

/**
 * 一具服务端假玩家的两只手,原版机制只此一份:左键挖照原版客户端的挖掘循环({@code MultiPlayerGameMode} 的
 * {@code startDestroyBlock}、{@code continueDestroyBlock}、{@code stopDestroyBlock}),右键照原版客户端的
 * {@code Minecraft.startUseItem}。送到服务端的,是真客户端的包到了服务端之后走的同一个入口——挖掘经
 * {@code handlePlayerAction},右键在 {@code handleUseItemOn} 的同一套检查之后调 {@code useItemOn}、{@code useItem}。
 * 服务端自己的规矩(够不够得着、出生点保护、冒险模式、别的模组取消了事件)都在那些入口里生效。
 *
 * <h2>挖</h2>
 * 第一下送 START:秒破的方块与创造模式当场碎;其余每刻累加原版的 {@code getDestroyProgress},到 1 送 STOP,服务端按它
 * 自己的钟确认后挖掉。碎掉之后手要缓几刻才挖下一格,照原版客户端的 {@code destroyDelay}({@link DigTime#cooldown}:
 * 累着进度挖碎的与创造模式缓 5 刻,秒破的不缓),规划给挖一格定价按的是同一个。手上的东西换了就从头挖;
 * 原地变了的(修补附魔吸经验改了耐久)还是同一件,不重开——原版客户端记的是手上那一叠本身。
 *
 * <p>服务端没挖掉就是没让挖:送 STOP 之后方块没变,再等服务端自己的钟走一阵(它记的进度偶尔比客户端慢,会挂成延迟
 * 破坏,过几刻自己挖掉);还不变就以 {@link Refusal#SERVER} 收场,不空挥到超时。
 *
 * <h2>右键</h2>
 * 两次右键至少隔 4 刻;正在挖时不按;主手先试,方块上用不了、手里又不空就对空用,再不成换副手。按下去之后,点中的那一格
 * 与它面前那一格(各连同上下一格,门的另一半在那里)哪几格变了,就是这一下的结果。
 *
 * <p>缓手按游戏刻计(世界的游戏时间),不随有没有按键、有没有被调用而冻住;调高刻速率也一样。
 */
public final class PlayerHands implements Effector {

    /** 模块自己看出来的拒绝理由。宿主的拒绝用宿主自己的理由。 */
    public enum Refusal {
        /** 服务端没让这一下落地:挖了没碎。 */
        SERVER
    }

    /** 原版客户端两次右键之间的刻数。 */
    private static final int RIGHT_CLICK_DELAY = 4;
    /** 送了 STOP 之后,最多等服务端这么多刻把延迟破坏落地。 */
    private static final int STOP_GRACE = 20;

    private final class_3222 body;
    private int sequence;
    private long destroyReadyAt;
    private long useReadyAt;
    /** 正在挖的那一格;没在挖为 null。 */
    private class_2338 destroying;
    /** 开挖时手上那一叠本身(不是副本)。 */
    private class_1799 destroyingItem = class_1799.field_8037;
    private float progress;
    /** 送过 STOP、等服务端落地的那一格与原来的方块;没在等为 null。 */
    private class_2338 stopped;
    private class_2680 stoppedState;
    private long stopDeadline;

    public PlayerHands(class_3222 body) {
        this.body = body;
    }

    /** 左键正按在某一格上(包括送了 STOP 在等服务端落地)。 */
    public boolean digging() {
        return pressing() != null;
    }

    /** 左键正按在哪一格上(包括送了 STOP 在等服务端落地的那一格);没按为 null。 */
    public class_2338 pressing() {
        return stopped != null ? stopped : destroying;
    }

    private long now() {
        return body.method_37908().method_8510();
    }

    // ==================== 左键 ====================

    @Override
    public Strike dig(class_3965 hit) {
        class_3218 level = body.method_51469();
        if (stopped != null) {
            return awaitStop(level);
        }
        if (now() < destroyReadyAt) {
            return Strike.RECOVERING;
        }
        class_2338 pos = hit.method_17777().method_10062();
        class_2350 face = hit.method_17780();
        class_2680 state = level.method_8320(pos);
        if (body.field_13974.method_14268()) {
            cooldown(true, true);
            body.method_6104(class_1268.field_5808);
            send(class_2846.class_2847.field_12968, pos, face);
            return landed(level, pos, state);
        }
        if (destroying == null || !destroying.equals(pos)
                || !class_1799.method_31577(body.method_6047(), destroyingItem)) {
            return start(level, pos, face, state);
        }
        if (state.method_26215()) {
            destroying = null;
            return Strike.SWINGING;
        }
        progress += state.method_26165(body, level, pos);
        body.method_6104(class_1268.field_5808);
        if (progress < 1.0F) {
            return Strike.SWINGING;
        }
        destroying = null;
        progress = 0;
        cooldown(false, false);
        send(class_2846.class_2847.field_12973, pos, face);
        if (level.method_8320(pos) != state) {
            return new Strike.Broke(pos, state);
        }
        stopped = pos;
        stoppedState = state;
        stopDeadline = now() + STOP_GRACE;
        return Strike.SWINGING;
    }

    /** 碎掉一格之后缓手:缓的那几刻里不挖,下一刻才挖下一格。 */
    private void cooldown(boolean creative, boolean instant) {
        destroyReadyAt = now() + DigTime.cooldown(creative, instant) + 1;
    }

    /** 第一下:原版客户端换了目标就先放下旧的,再送 START;秒破的当场碎,否则开始累加进度。 */
    private Strike start(class_3218 level, class_2338 pos, class_2350 face, class_2680 state) {
        release();
        body.method_6104(class_1268.field_5808);
        boolean instant = !state.method_26215() && state.method_26165(body, level, pos) >= 1.0F;
        send(class_2846.class_2847.field_12968, pos, face);
        if (instant) {
            return landed(level, pos, state);
        }
        destroying = pos;
        destroyingItem = body.method_6047();
        progress = 0;
        return Strike.SWINGING;
    }

    /** 当场该碎的那一下落没落地。 */
    private static Strike landed(class_3218 level, class_2338 pos, class_2680 before) {
        return level.method_8320(pos) != before
                ? new Strike.Broke(pos, before)
                : new Strike.Refused(pos, Refusal.SERVER);
    }

    /** 送过 STOP 还没碎:服务端挂了延迟破坏会在它自己的刻里挖掉,等一阵;一直不变就是没让挖。 */
    private Strike awaitStop(class_3218 level) {
        class_2338 pos = stopped;
        if (level.method_8320(pos) != stoppedState) {
            stopped = null;
            return new Strike.Broke(pos, stoppedState);
        }
        if (now() < stopDeadline) {
            return Strike.SWINGING;
        }
        stopped = null;
        return new Strike.Refused(pos, Refusal.SERVER);
    }

    @Override
    public void release() {
        if (destroying != null) {
            send(class_2846.class_2847.field_12971, destroying, class_2350.field_11033);
            body.method_7350();
        }
        destroying = null;
        progress = 0;
    }

    /** 这一个动作经服务端收包的入口送进去。 */
    private void send(class_2846.class_2847 action, class_2338 pos, class_2350 face) {
        body.field_13987.method_12066(new class_2846(action, pos, face, ++sequence));
    }

    // ==================== 右键 ====================

    @Override
    public Use use(class_3965 hit) {
        if (now() < useReadyAt || digging()) {
            return Use.WAITING;
        }
        useReadyAt = now() + RIGHT_CLICK_DELAY;
        class_3218 level = body.method_51469();
        Map<class_2338, class_2680> before = around(level, hit);
        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = body.method_5998(hand);
            if (!stack.method_45435(level.method_45162())) {
                break;
            }
            class_1269 onBlock = useItemOn(level, stack, hand, hit);
            if (onBlock.method_23665() || onBlock == class_1269.field_5814) {
                break;
            }
            if (!stack.method_7960() && body.field_13974.method_14256(body, level, stack, hand).method_23665()) {
                break;
            }
        }
        List<Change> changes = new ArrayList<>();
        before.forEach((pos, was) -> {
            class_2680 now = level.method_8320(pos);
            if (now != was) {
                changes.add(new Change(pos, was, now));
            }
        });
        return changes.isEmpty() ? Use.NOTHING : new Use.Changed(changes);
    }

    /**
     * 原版 {@code handleUseItemOn} 在调 {@code useItemOn} 之前的检查:够得着(交互距离加 1 格宽限)、点中的位置落在那一格上、
     * 不在建筑高度之上、世界许这具身体动它。
     */
    private class_1269 useItemOn(class_3218 level, class_1799 stack, class_1268 hand, class_3965 hit) {
        class_2338 pos = hit.method_17777();
        class_243 offset = hit.method_17784().method_1020(class_243.method_24953(pos));
        if (!body.method_56093(pos, 1.0) || Math.abs(offset.field_1352) >= 1.0000001
                || Math.abs(offset.field_1351) >= 1.0000001 || Math.abs(offset.field_1350) >= 1.0000001) {
            return class_1269.field_5811;
        }
        body.method_14234();
        if (pos.method_10264() >= level.method_31600() || !level.method_8505(body, pos)) {
            return class_1269.field_5811;
        }
        class_1269 result = body.field_13974.method_14262(body, level, stack, hand, hit);
        if (result.method_23665()) {
            class_174.field_48269.method_56049(body, pos, stack.method_7972());
        }
        if (result.method_23666()) {
            body.method_23667(hand, true);
        }
        return result;
    }

    /** 右键可能改到的几格:点中的那一格、它面前那一格,各连同上下一格。 */
    private static Map<class_2338, class_2680> around(class_3218 level, class_3965 hit) {
        Map<class_2338, class_2680> out = new LinkedHashMap<>();
        for (class_2338 center : new class_2338[] {hit.method_17777(), hit.method_17777().method_10093(hit.method_17780())}) {
            for (int dy = -1; dy <= 1; dy++) {
                class_2338 pos = center.method_10069(0, dy, 0).method_10062();
                out.putIfAbsent(pos, level.method_8320(pos));
            }
        }
        return out;
    }
}
