package com.dwinovo.numen.pathing.body;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import com.dwinovo.numen.pathing.world.Faces;
import com.dwinovo.numen.pathing.world.Reach;
import com.dwinovo.numen.pathing.world.Replaceable;
import com.dwinovo.numen.pathing.world.Sight;

/**
 * 视角:往哪儿看、怎么转过去。瞄点只在这里定——挖一格看它身上哪一点、放一块点哪个面的哪一点;转头照原版鼠标,每移一个
 * 像素转一个固定角度,所以转到的角度落在这个格子上,离算出来的点差不到半个像素。
 *
 * <p>看得见是指从眼睛到那一点的视线(第 0 层 {@link Sight},按轮廓、不看流体)第一下就碰上那一格,而且在交互距离之内——
 * 与准星拾取({@link Crosshair})是同一种射线,所以转过去之后准星就落在那一格上。
 */
public final class Aim {

    /** 鼠标灵敏度 0.5 时移一个像素视角转的角度(原版 {@code (s·0.6+0.2)³·8·0.15})。 */
    static final double PIXEL = Math.pow(0.5 * 0.6 + 0.2, 3) * 8 * 0.15;

    private Aim() {}

    // ==================== 转头 ====================

    /** 转过去看 {@code point}。 */
    public static void look(class_3222 body, class_243 point) {
        rotate(body, toward(body, body.method_33571(), point));
    }

    /** 转到朝 {@code yaw}、俯仰 {@code pitch}(按鼠标像素取整)。 */
    public static void turn(class_3222 body, float yaw, float pitch) {
        rotate(body, turned(body.method_36454(), body.method_36455(), yaw, pitch));
    }

    private static void rotate(class_3222 body, Rotation to) {
        body.method_36456(to.yaw());
        body.method_5847(to.yaw());
        body.method_5636(to.yaw());
        body.method_36457(to.pitch());
    }

    /** 从 {@code eye} 转向 {@code point} 之后身体的朝向(按鼠标像素取整)。 */
    private static Rotation toward(class_3222 body, class_243 eye, class_243 point) {
        double dx = point.field_1352 - eye.field_1352;
        double dy = point.field_1351 - eye.field_1351;
        double dz = point.field_1350 - eye.field_1350;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return turned(body.method_36454(), body.method_36455(), yaw, pitch);
    }

    /**
     * 转向 {@code point} 之后视线真正落在的那一点(与 {@code point} 离眼睛一样远):转头取整到鼠标像素,这条线与到 {@code point}
     * 的直线差不到半个像素。视线擦着挡路方块的棱而过时,碰没碰上就由差的这一点点决定,所以判看不看得见要照这条线。
     */
    private static class_243 landing(class_3222 body, class_243 eye, class_243 point) {
        Rotation to = toward(body, eye, point);
        return eye.method_1019(class_243.method_1030(to.pitch(), to.yaw()).method_1021(point.method_1022(eye)));
    }

    /** 一个朝向:水平朝向 {@code yaw} 与俯仰 {@code pitch},度。 */
    record Rotation(float yaw, float pitch) {}

    /**
     * 从 {@code (fromYaw, fromPitch)} 照鼠标转向 {@code (yaw, pitch)} 之后落在哪:两个方向各转整数个像素({@link #PIXEL}),
     * 取离要的角度最近的那一格,所以差不到半个像素;水平朝向走近的那一边(不超过半圈,转到的值不回绕到 ±180 之内,与原版
     * 鼠标一样累加);俯仰照原版夹在 ±90 之间。
     */
    static Rotation turned(float fromYaw, float fromPitch, float yaw, float pitch) {
        float newYaw = fromYaw + quantize(class_3532.method_15393(yaw - fromYaw));
        float newPitch = class_3532.method_15363(fromPitch + quantize(pitch - fromPitch), -90.0F, 90.0F);
        return new Rotation(newYaw, newPitch);
    }

    /** 走路时朝 {@code (x, z)} 看去,俯仰留在平视。 */
    public static void faceToward(class_3222 body, double x, double z) {
        float yaw = (float) (Math.toDegrees(Math.atan2(z - body.method_23321(), x - body.method_23317())) - 90.0);
        turn(body, yaw, 0);
    }

    private static float quantize(float degrees) {
        return (float) (Math.round(degrees / PIXEL) * PIXEL);
    }

    // ==================== 挖:看这一格身上的哪一点 ====================

    /**
     * 挖 {@code pos} 这一格时看它身上的哪一点:它的轮廓中心,不行就是轮廓各个朝着眼睛的面的中心,再不行是这些面上离眼睛最近的
     * 一点(离棱留一点边),取第一个看得见、够得着的;都看不见为 null。最后那一档与第 0 层 {@link Reach} 量的是同一个距离
     * ——眼睛到方块最近的一点——所以 {@code Reach} 说够得着、那一点又没被挡着,这里就交得出瞄点。有没有被挡着照转过去之后视线
     * 实际落的那条线判({@link #landing})。
     */
    public static class_243 point(class_3222 body, class_2338 pos) {
        class_243 eye = body.method_33571();
        for (class_243 candidate : digPoints(body, pos)) {
            if (hits(body, eye, landing(body, eye, candidate), pos, null)) {
                return candidate;
            }
        }
        return null;
    }

    /**
     * 挖 {@code pos} 时够得着的瞄点,先后照 {@link #point} 说的那三档,不管中间有没有东西挡着。看不见它时从这几点里挑隔着的格都
     * 清得掉的那一条视线({@link Sight#dig}),朝那一点看过去,准星落着的就是先要挖开的那一格。
     */
    public static List<class_243> digPoints(class_3222 body, class_2338 pos) {
        class_243 eye = body.method_33571();
        double range = body.method_55754();
        List<class_243> out = new ArrayList<>();
        for (class_243 candidate : candidates(body, pos)) {
            if (candidate.method_1022(eye) < range) {
                out.add(candidate);
            }
        }
        return out;
    }

    /** 挖 {@code pos} 时的候选瞄点,先后照 {@link #point} 说的那三档。 */
    private static List<class_243> candidates(class_3222 body, class_2338 pos) {
        class_1937 level = body.method_37908();
        class_265 shape = level.method_8320(pos).method_26218(level, pos);
        List<class_238> boxes = shape.method_1110() ? List.of(new class_238(0, 0, 0, 1, 1, 1)) : shape.method_1090();
        class_243 eye = body.method_33571();
        List<class_243> candidates = new ArrayList<>();
        class_238 bounds = shape.method_1110() ? boxes.get(0) : shape.method_1107();
        candidates.add(bounds.method_1005().method_1031(pos.method_10263(), pos.method_10264(), pos.method_10260()));
        List<class_243> nearest = new ArrayList<>();
        for (class_238 local : boxes) {
            class_238 box = local.method_996(pos);
            for (class_2350 side : class_2350.values()) {
                class_243 center = faceCenter(box, side);
                if (Sight.facing(eye, center, side)) {
                    class_243 inward = class_243.method_24954(side.method_10163()).method_1021(Sight.INSET);
                    candidates.add(center.method_1020(inward));
                    nearest.add(nearestOnFace(box, side, eye).method_1020(inward));
                }
            }
        }
        candidates.addAll(nearest);
        return candidates;
    }

    // ==================== 用:点它哪一面 ====================

    /**
     * 从眼睛此刻的位置用 {@code pos} 这一格:它哪一面用得上(第 0 层 {@link Sight#use}——面朝着眼睛、在交互距离内、视线上没有
     * 硬遮挡),交出那一次视线;没隔着软遮挡的面优先。一面都用不上为 null。与导航"用一格方块"的到达是同一个视线函数。
     */
    public static Sight.Trace use(class_3222 body, class_2338 pos) {
        class_1937 level = body.method_37908();
        class_243 eye = body.method_33571();
        double range = body.method_55754();
        Sight.Trace behindSoft = null;
        for (class_2350 side : class_2350.values()) {
            Sight.Trace trace = Sight.use(level, eye, range, pos, side);
            if (trace == null) {
                continue;
            }
            if (trace.soft().isEmpty()) {
                return trace;
            }
            if (behindSoft == null) {
                behindSoft = trace;
            }
        }
        return behindSoft;
    }

    // ==================== 放:点哪个面的哪一点 ====================

    /**
     * 往 {@code target} 放 {@code placing} 时,从眼睛此刻的位置点得中的那个面(第 0 层 {@link Faces#inSight},规划判放不放得下
     * 问的是同一个);看不见任何一个为 null。
     */
    public static Faces.Face face(class_3222 body, class_2338 target, class_2248 placing) {
        return Faces.inSight(body.method_37908(), body.method_33571(), body.method_55754(), target, placing);
    }

    // ==================== 射线 ====================

    /** 从眼睛朝 {@code point} 的视线第一下碰上的是 {@code pos}(给了 {@code side} 时还得是那一面):第 0 层 {@link Sight}。 */
    private static boolean hits(class_3222 body, class_243 eye, class_243 point, class_2338 pos, class_2350 side) {
        return Sight.trace(body.method_37908(), eye, point, pos).clear(side);
    }

    /** {@code box} 的 {@code side} 面上离 {@code eye} 最近的一点,离面的四条棱各留 {@link Reach#EDGE}。 */
    private static class_243 nearestOnFace(class_238 box, class_2350 side, class_243 eye) {
        double x = clampInside(eye.field_1352, box.field_1323, box.field_1320);
        double y = clampInside(eye.field_1351, box.field_1322, box.field_1325);
        double z = clampInside(eye.field_1350, box.field_1321, box.field_1324);
        return switch (side) {
            case field_11033 -> new class_243(x, box.field_1322, z);
            case field_11036 -> new class_243(x, box.field_1325, z);
            case field_11043 -> new class_243(x, y, box.field_1321);
            case field_11035 -> new class_243(x, y, box.field_1324);
            case field_11039 -> new class_243(box.field_1323, y, z);
            case field_11034 -> new class_243(box.field_1320, y, z);
        };
    }

    private static double clampInside(double v, double min, double max) {
        double margin = Math.min(Reach.EDGE, (max - min) / 2);
        return class_3532.method_15350(v, min + margin, max - margin);
    }

    private static class_243 faceCenter(class_238 box, class_2350 side) {
        class_243 c = box.method_1005();
        return switch (side) {
            case field_11033 -> new class_243(c.field_1352, box.field_1322, c.field_1350);
            case field_11036 -> new class_243(c.field_1352, box.field_1325, c.field_1350);
            case field_11043 -> new class_243(c.field_1352, c.field_1351, box.field_1321);
            case field_11035 -> new class_243(c.field_1352, c.field_1351, box.field_1324);
            case field_11039 -> new class_243(box.field_1323, c.field_1351, c.field_1350);
            case field_11034 -> new class_243(box.field_1320, c.field_1351, c.field_1350);
        };
    }
}
