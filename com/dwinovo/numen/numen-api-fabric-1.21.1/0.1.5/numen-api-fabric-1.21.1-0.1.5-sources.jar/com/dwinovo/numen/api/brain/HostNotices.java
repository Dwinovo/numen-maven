package com.dwinovo.numen.api.brain;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.platform.ServerLifecycle;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * 启动时迁移({@link HostMerge})改动了房主的东西,要告诉他:服务器起来的那一刻他还没进游戏,话先攒着,他的客户端报到时({@link Replies#hello})一次说完。
 *
 * <p>线程:服务端主线程。
 */
final class HostNotices {

    private static final Map<UUID, List<class_2561>> PENDING = new ConcurrentHashMap<>();

    static {
        ServerLifecycle.onStopped(PENDING::clear);
    }

    private HostNotices() {}

    /** 并库时改了名的条目、被他的钥匙换掉的服主钥匙,各记一句。 */
    static void merged(UUID host, List<HostMerge.Renamed> renamed, List<String> replacedKeys) {
        for (HostMerge.Renamed each : renamed) {
            say(host, class_2561.method_43469(Keys.MERGE_RENAMED, each.kind().dir(), each.from().name(), each.to().name()));
        }
        for (String service : replacedKeys) {
            say(host, class_2561.method_43469(Keys.MERGE_KEY_REPLACED, service));
        }
    }

    private static void say(UUID player, class_2561 line) {
        PENDING.computeIfAbsent(player, id -> new CopyOnWriteArrayList<>()).add(line);
    }

    /** 他报到了:攒下的话说给他,说过就没了。 */
    static void deliver(class_3222 player) {
        List<class_2561> lines = PENDING.remove(player.method_5667());
        if (lines != null) {
            lines.forEach(player::method_43496);
        }
    }
}
