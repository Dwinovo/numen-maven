package com.dwinovo.numen.api.entity;

import java.util.EnumSet;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1656;
import net.minecraft.class_1770;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/**
 * 一具服务端假玩家的键盘,一具身体一副(同伴的是 {@link NumenPlayer#controls})。键按下就一直按着,直到松开;每刻由 {@link Physics#step}
 * 在身体的物理步进之前落一次,照原版客户端把按键变成身体输入的那一套({@code KeyboardInput.tick} 与
 * {@code LocalPlayer.aiStep})落到身体上——假玩家没有客户端,服务端缺的就是这一段:
 * <ul>
 *   <li>前后左右是数字键:{@code zza}、{@code xxa} 只取 -1、0、1,相对身体此刻的朝向;蹲着或爬着乘潜行速度属性,
 *       用着物品乘 0.2;</li>
 *   <li>跳是按住:原版服务端的 {@code aiStep} 按住跳时自己分地面起跳、水里上浮、攀爬上爬;</li>
 *   <li>潜行交给服务端的姿势与"不走出边沿";在水里按着潜行往下沉(原版客户端的 {@code goDownInWater});</li>
 *   <li>疾跑照原版客户端的条件开始与中止:前冲够大、吃得够饱(或能飞)、没用物品、没失明;撞墙、松开前进、饿了、在水面
 *       上就停。唯一的不同是松开疾跑键就停跑——键盘上要停跑得松一下前进键,这里把两件事合成一个键;</li>
 *   <li>身体卡在方块里时,照原版客户端每刻往最近的空处推一下({@code LocalPlayer.moveTowardsClosestSpace});</li>
 *   <li>创造飞行:许飞的身体(能力 {@code mayfly})在 {@value #DOUBLE_TAP} 刻之内连按两下跳(松开再按)切换飞行,切的方式是客户端发的那个能力包,
 *       许不许由原版服务端照 {@code mayfly} 判;从地面切上去时照原版起跳一次。飞着按跳往上、按潜行往下(每刻 ±3 × 飞行速度),
 *       飞着落了地就停飞({@code LocalPlayer.aiStep} 的末尾);</li>
 *   <li>鞘翅:没在飞行、没骑乘、没攀着、胸甲位是没坏的鞘翅时,按下跳的那一刻发展开鞘翅的玩家指令,在不在空中、水里、有没有漂浮效果由原版服务端判;
 *       {@link #unfurl} 是同一件事,不等按键。</li>
 * </ul>
 * 视角不在这里:朝向由执行层的瞄准直接转。
 */
public final class Controls {

    /** 键。 */
    public enum Key {
        FORWARD, BACK, LEFT, RIGHT, JUMP, SNEAK, SPRINT
    }

    /** 原版客户端判"前冲够大才能开跑"的门槛。 */
    private static final double SPRINT_IMPULSE = 0.8;
    /** 用着物品时的走速({@code LocalPlayer.aiStep})。 */
    private static final float USING_ITEM_SLOWDOWN = 0.2F;
    /** 按着潜行时每刻往下沉多少(原版 {@code LivingEntity.goDownInWater})。 */
    private static final double SINK = -0.04;
    /** 卡在方块里时每刻往外推的速度(原版 {@code LocalPlayer.moveTowardsClosestSpace})。 */
    private static final double PUSH_OUT = 0.1;
    /** 双击跳的窗口(原版 {@code LocalPlayer.aiStep} 的 {@code jumpTriggerTime = 7},{@code Player.aiStep} 每刻减一)。 */
    public static final int DOUBLE_TAP = 7;
    /** 飞着按跳、按潜行每刻加的竖直速度是飞行速度的几倍(原版 {@code LocalPlayer.aiStep} 的 {@code * 3.0F})。 */
    public static final float FLY_LIFT = 3.0F;

    private final EnumSet<Key> held = EnumSet.noneOf(Key.class);
    /** 上一刻跳键按没按着:按下沿(这一刻按着、上一刻没按)才算"按了一下"。 */
    private boolean jumpedBefore;
    /** 第一下跳之后还剩几刻能接第二下;0 是没有在等第二下。 */
    private int doubleTap;

    public void press(Key key) {
        held.add(key);
    }

    public void release(Key key) {
        held.remove(key);
    }

    public void set(Key key, boolean down) {
        if (down) {
            held.add(key);
        } else {
            held.remove(key);
        }
    }

    public boolean held(Key key) {
        return held.contains(key);
    }

    /**
     * 此刻按下跳,会不会被当成双击的第二下而切换飞行:第一下之后的窗口里、跳键松着时是。飞着靠跳升高的控制器按之前问它——
     * 松开又按、隔得不到 {@value #DOUBLE_TAP} 刻,就把飞行关了。
     */
    public boolean jumpWouldToggleFlight() {
        return doubleTap > 0 && !held(Key.JUMP);
    }

    /** 松开所有键。 */
    public void releaseAll() {
        held.clear();
    }

    /** 停下脚步:松开前后左右、跳与疾跑,潜行照旧按着(蹲在边沿上干活时停下不站起来)。 */
    public void stop() {
        held.removeAll(MOVING);
    }

    private static final EnumSet<Key> MOVING = EnumSet.of(Key.FORWARD, Key.BACK, Key.LEFT, Key.RIGHT, Key.JUMP,
            Key.SPRINT);

    /** 把按着的键落到身体上。只由 {@link Physics#step} 调,每刻一次。 */
    void apply(class_3222 body) {
        boolean pressed = held(Key.JUMP) && !jumpedBefore;
        jumpedBefore = held(Key.JUMP);
        pushOutOfBlocks(body);
        float forward = impulse(Key.FORWARD, Key.BACK);
        float left = impulse(Key.LEFT, Key.RIGHT);
        if (body.method_18276() || body.method_20448()) {
            float slow = (float) body.method_45325(class_5134.field_51584);
            forward *= slow;
            left *= slow;
        }
        if (body.method_6115() && !body.method_5765()) {
            forward *= USING_ITEM_SLOWDOWN;
            left *= USING_ITEM_SLOWDOWN;
        }
        body.field_6250 = forward;
        body.field_6212 = left;
        body.method_6100(held(Key.JUMP));
        body.method_5660(held(Key.SNEAK));
        sprint(body, forward);
        boolean toggled = toggleFlight(body, pressed);
        if (pressed && !toggled) {
            unfurl(body);
        }
        if (body.method_5799() && held(Key.SNEAK) && body.method_29920()) {
            body.method_18799(body.method_18798().method_1031(0, SINK, 0));
        }
        if (body.method_31549().field_7479) {
            lift(body);
        }
        if (doubleTap > 0) {
            doubleTap--;
        }
    }

    /**
     * 身体这一刻的物理步进做完之后:飞着落了地就停飞。原版客户端在 {@code aiStep} 末尾做,发的同样是能力包。只由 {@link Physics#step} 调。
     */
    void afterTick(class_3222 body) {
        if (body.method_31549().field_7479 && body.method_24828()) {
            new ClientPackets(body).flying(false);
        }
    }

    /**
     * 许飞的身体按下了一下跳:{@value #DOUBLE_TAP} 刻之内的第二下切换飞行(游着时不切),从地面切上去时起跳一次。
     * 能力包发出去,服务端照 {@code mayfly} 判,切没切成读回来的能力就是。
     *
     * @return 这一刻切换了飞行(同一下跳不再去展开鞘翅)
     */
    private boolean toggleFlight(class_3222 body, boolean pressed) {
        class_1656 abilities = body.method_31549();
        if (!abilities.field_7478 || !pressed) {
            return false;
        }
        if (doubleTap == 0) {
            doubleTap = DOUBLE_TAP;
            return false;
        }
        if (body.method_5681()) {
            return false;
        }
        new ClientPackets(body).flying(!abilities.field_7479);
        if (abilities.field_7479 && body.method_24828()) {
            body.method_6043();
        }
        doubleTap = 0;
        return true;
    }

    /** 飞着按跳往上、按潜行往下:这一刻往竖直速度里加 ±3 × 飞行速度。 */
    private void lift(class_3222 body) {
        int direction = (held(Key.JUMP) ? 1 : 0) - (held(Key.SNEAK) ? 1 : 0);
        if (direction != 0) {
            body.method_18799(body.method_18798().method_1031(0.0,
                    (double) ((float) direction * body.method_31549().method_7252() * FLY_LIFT), 0.0));
        }
    }

    /**
     * 展开鞘翅:发展开的玩家指令(原版客户端在空中按下跳时发的那个),在不在空中、水里、有没有漂浮效果由原版服务端判。
     * 飞着(创造飞行)、骑乘、攀着、没穿没坏的鞘翅时客户端不发。展开的流程只此一处:按键走这里,{@code numen.use.glide} 也走这里。
     *
     * @return 身体此刻在滑翔(展开成了,或本来就在滑翔)
     */
    public boolean unfurl(class_3222 body) {
        if (body.method_6128()) {
            return true;
        }
        var chest = body.method_6118(class_1304.field_6174);
        if (body.method_31549().field_7479 || body.method_5765() || body.method_6101() || !chest.method_31574(class_1802.field_8833)
                || !class_1770.method_7804(chest)) {
            return false;
        }
        new ClientPackets(body).command(class_2848.class_2849.field_12982);
        return body.method_6128();
    }

    private float impulse(Key positive, Key negative) {
        boolean p = held(positive);
        boolean n = held(negative);
        return p == n ? 0 : p ? 1 : -1;
    }

    /** 原版客户端的开跑与停跑。 */
    private void sprint(class_3222 body, float forward) {
        boolean forwardImpulse = forward > 1.0E-5F;
        boolean fed = body.method_7344().method_7586() > 6 || body.method_31549().field_7478;
        if (!body.method_5624()) {
            boolean impulse = body.method_5869() ? forwardImpulse : forward >= SPRINT_IMPULSE;
            boolean surface = body.method_5799() && !body.method_5869();
            if (held(Key.SPRINT) && impulse && fed && !body.method_6115() && !body.method_6059(class_1294.field_5919)
                    && !body.method_5765() && !body.method_6128() && !surface) {
                body.method_5728(true);
            }
            return;
        }
        boolean spent = !forwardImpulse || !fed;
        boolean stop = body.method_5681()
                ? !body.method_24828() && !held(Key.SNEAK) && spent || !body.method_5799()
                : spent || body.field_5976 && !body.field_34927
                        || body.method_5799() && !body.method_5869();
        if (stop || !held(Key.SPRINT)) {
            body.method_5728(false);
        }
    }

    /** 原版客户端:身体脚底的四个角各看一次,陷在会窒息的方块里就朝最近的空处推。 */
    private static void pushOutOfBlocks(class_3222 body) {
        if (body.field_5960) {
            return;
        }
        double reach = body.method_17681() * 0.35;
        pushOut(body, body.method_23317() - reach, body.method_23321() + reach);
        pushOut(body, body.method_23317() - reach, body.method_23321() - reach);
        pushOut(body, body.method_23317() + reach, body.method_23321() - reach);
        pushOut(body, body.method_23317() + reach, body.method_23321() + reach);
    }

    private static final class_2350[] SIDES = {class_2350.field_11039, class_2350.field_11034, class_2350.field_11043, class_2350.field_11035};

    private static void pushOut(class_3222 body, double x, double z) {
        class_2338 cell = class_2338.method_49637(x, body.method_23318(), z);
        if (!suffocatesAt(body, cell)) {
            return;
        }
        double inX = x - cell.method_10263();
        double inZ = z - cell.method_10260();
        class_2350 best = null;
        double bestDistance = Double.MAX_VALUE;
        for (class_2350 side : SIDES) {
            double along = side.method_10166().method_10172(inX, 0.0, inZ);
            double distance = side.method_10171() == class_2350.class_2352.field_11056 ? 1.0 - along : along;
            if (distance < bestDistance && !suffocatesAt(body, cell.method_10093(side))) {
                bestDistance = distance;
                best = side;
            }
        }
        if (best != null) {
            class_243 motion = body.method_18798();
            body.method_18799(best.method_10166() == class_2350.class_2351.field_11048
                    ? new class_243(PUSH_OUT * best.method_10148(), motion.field_1351, motion.field_1350)
                    : new class_243(motion.field_1352, motion.field_1351, PUSH_OUT * best.method_10165()));
        }
    }

    private static boolean suffocatesAt(class_3222 body, class_2338 cell) {
        class_238 box = body.method_5829();
        class_238 column = new class_238(cell.method_10263(), box.field_1322, cell.method_10260(), cell.method_10263() + 1.0, box.field_1325, cell.method_10260() + 1.0)
                .method_1011(1.0E-7);
        return body.method_37908().method_39454(body, column);
    }
}
