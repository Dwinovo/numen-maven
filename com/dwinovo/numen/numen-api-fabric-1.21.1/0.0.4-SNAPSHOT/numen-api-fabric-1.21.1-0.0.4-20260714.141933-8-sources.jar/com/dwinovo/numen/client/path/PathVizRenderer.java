package com.dwinovo.numen.client.path;

import org.joml.Vector3f;

import java.util.List;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

/**
 * Draws every companion's path overlay in the world: a coloured poly-line
 * through the path nodes, red boxes
 * on blocks to break, green boxes on blocks to place, and a green box on the
 * goal. Default-on — the overlay is how the player reads what the body intends.
 *
 * <p>Loader-neutral: each loader's client init calls {@link #render} from its
 * post-translucent world-render hook with that frame's {@link class_4587}; the
 * camera and line buffer are pulled from {@link class_310} here so the body is
 * written once.
 */
public final class PathVizRenderer {

    private static final int PATH_COLOR  = 0xFFFF0000; // red
    private static final int BREAK_COLOR = 0xFFFF0000; // red
    private static final int PLACE_COLOR = 0xFF00FF00; // green
    private static final int GOAL_COLOR  = 0xFF00FF00; // green
    private static final float LINE_WIDTH = 5.0F;   // overlay line width in pixels
    /** The path is drawn as a thin vertical ribbon, the line
     *  plus a parallel edge 0.03 above it, joined at each segment's ends —
     *  reads better at distance than a bare 1-px line. */
    private static final double RIBBON = 0.03;
    /** Box inset so the wireframe hugs faces without z-fighting. */
    private static final double BOX_INSET = 0.002;

    private PathVizRenderer() {}

    public static void render(class_4587 poseStack) {
        var active = ClientPathViz.all();
        if (active.isEmpty()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;
        class_2960 here = mc.field_1687.method_27983().method_29177();
        class_243 cam = mc.field_1773.method_19418().method_19326();
        class_4597.class_4598 buffers = mc.method_22940().method_23000();
        class_4588 vc = buffers.getBuffer(class_1921.method_23594());
        class_4587.class_4665 pose = poseStack.method_23760();

        for (ClientPathViz.Viz v : active) {
            // Skip paths for bodies in another dimension; the nodes are world
            // coords that only make sense in their own dimension.
            if (!here.equals(v.dimension())) continue;
            drawPathLine(vc, pose, v.nodes(), cam, v.companion());
            for (class_2338 b : v.toBreak()) drawBox(vc, pose, b, cam, BREAK_COLOR);
            for (class_2338 p : v.toPlace()) drawBox(vc, pose, p, cam, PLACE_COLOR);
            // Every target the body will work through — for mining, a box on each
            // ore of the whole field; for a move, the
            // single destination. Real cells, never a floating goal-centroid.
            for (class_2338 t : v.targets()) drawBox(vc, pose, t, cam, GOAL_COLOR);
        }
        // Flush only our line batch (not endLastBatch, which could flush a foreign
        // open batch in the shared buffer source at this render stage).
        buffers.method_22994(class_1921.method_23594());
    }

    /**
     * Poly-line through block centres, drawn from the body's
     * CURRENT position onward — redrawn every frame starting at the body's
     * progress along the path, so the walked-over portion vanishes and the line
     * shrinks as the body advances. Progress is approximated as the path node
     * nearest the body's live position; the already-travelled prefix isn't drawn.
     */
    private static void drawPathLine(class_4588 vc, class_4587.class_4665 pose, List<class_2338> nodes,
                                     class_243 cam, java.util.UUID companion) {
        int start = renderBegin(nodes, companion);
        for (int i = start + 1; i < nodes.size(); i++) {
            class_2338 a = nodes.get(i - 1);
            class_2338 b = nodes.get(i);
            double ax = a.method_10263() + 0.5 - cam.field_1352, ay = a.method_10264() + 0.5 - cam.field_1351, az = a.method_10260() + 0.5 - cam.field_1350;
            double bx = b.method_10263() + 0.5 - cam.field_1352, by = b.method_10264() + 0.5 - cam.field_1351, bz = b.method_10260() + 0.5 - cam.field_1350;
            // Each segment is emitted with a 3-sided
            // ribbon — vertical up at the far end, a parallel edge RIBBON above back to
            // the near end, vertical down — so the path reads as a thin standing band.
            line(vc, pose, ax, ay, az, bx, by, bz, PATH_COLOR);
            line(vc, pose, bx, by, bz, bx, by + RIBBON, bz, PATH_COLOR);
            line(vc, pose, bx, by + RIBBON, bz, ax, ay + RIBBON, az, PATH_COLOR);
            line(vc, pose, ax, ay + RIBBON, az, ax, ay, az, PATH_COLOR);
        }
    }

    /** The node nearest the body's live position — the client-side stand-in for
     *  the executor's current path index (which only the server knows). 0 if the
     *  body can't be resolved (just drawn the whole path, as before). */
    private static int renderBegin(List<class_2338> nodes, java.util.UUID companion) {
        var body = com.dwinovo.numen.client.agent.ClientNumenLookup.resolve(companion);
        if (body == null) return 0;
        class_243 p = body.method_19538();
        int best = 0;
        double bestSq = Double.MAX_VALUE;
        for (int i = 0; i < nodes.size(); i++) {
            class_2338 n = nodes.get(i);
            double dx = n.method_10263() + 0.5 - p.field_1352;
            double dy = n.method_10264() + 0.5 - p.field_1351;
            double dz = n.method_10260() + 0.5 - p.field_1350;
            double sq = dx * dx + dy * dy + dz * dz;
            if (sq < bestSq) {
                bestSq = sq;
                best = i;
            }
        }
        return best;
    }

    /** The 12 edges of a unit block at {@code pos}, as a wireframe selection box. */
    private static void drawBox(class_4588 vc, class_4587.class_4665 pose, class_2338 pos, class_243 cam, int color) {
        double x0 = pos.method_10263() - cam.field_1352 + BOX_INSET, y0 = pos.method_10264() - cam.field_1351 + BOX_INSET, z0 = pos.method_10260() - cam.field_1350 + BOX_INSET;
        double x1 = pos.method_10263() - cam.field_1352 + 1 - BOX_INSET, y1 = pos.method_10264() - cam.field_1351 + 1 - BOX_INSET, z1 = pos.method_10260() - cam.field_1350 + 1 - BOX_INSET;
        // bottom rectangle
        line(vc, pose, x0, y0, z0, x1, y0, z0, color);
        line(vc, pose, x1, y0, z0, x1, y0, z1, color);
        line(vc, pose, x1, y0, z1, x0, y0, z1, color);
        line(vc, pose, x0, y0, z1, x0, y0, z0, color);
        // top rectangle
        line(vc, pose, x0, y1, z0, x1, y1, z0, color);
        line(vc, pose, x1, y1, z0, x1, y1, z1, color);
        line(vc, pose, x1, y1, z1, x0, y1, z1, color);
        line(vc, pose, x0, y1, z1, x0, y1, z0, color);
        // vertical pillars
        line(vc, pose, x0, y0, z0, x0, y1, z0, color);
        line(vc, pose, x1, y0, z0, x1, y1, z0, color);
        line(vc, pose, x1, y0, z1, x1, y1, z1, color);
        line(vc, pose, x0, y0, z1, x0, y1, z1, color);
    }

    /** One GL line segment, with the per-vertex normal + width the lines render type wants. */
    private static void line(class_4588 vc, class_4587.class_4665 pose,
                             double x1, double y1, double z1, double x2, double y2, double z2, int color) {
        Vector3f n = new Vector3f((float) (x2 - x1), (float) (y2 - y1), (float) (z2 - z1));
        if (n.lengthSquared() > 1.0e-6F) n.normalize();
        else n.set(0.0F, 1.0F, 0.0F);
        vc.method_56824(pose, (float) x1, (float) y1, (float) z1).method_39415(color).method_60831(pose, n.x(), n.y(), n.z());
        vc.method_56824(pose, (float) x2, (float) y2, (float) z2).method_39415(color).method_60831(pose, n.x(), n.y(), n.z());
    }
}
