package com.dwinovo.numen.client.voice;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1102;
import net.minecraft.class_1113;
import net.minecraft.class_3419;
import net.minecraft.class_4234;

/**
 * 设置界面"试听"用的 2D 就地播放:不挂实体、无距离衰减、位置相对监听者
 * (即耳边直出,vanilla UI 音效同款做法)。数据同样是内存 PCM,经
 * {@code MixinSoundEngine} 的取数重定向进声音引擎——和 3D 路径共用一条
 * 管线,不另起播放机制。
 */
public final class VoicePreviewSound extends class_1102 implements VoicePcmSource {

    private final PcmAudio audio;

    public VoicePreviewSound(PcmAudio audio, float volume) {
        super(VoicePcmSource.SOUND_EVENT, class_3419.field_15246, class_1113.method_43221());
        this.audio = audio;
        this.field_5442 = VoiceLibrary.clampVolume(volume);
        this.field_5446 = false;
        this.field_5451 = 0;
        this.field_18936 = true;                                   // 坐标相对监听者
        this.field_5440 = class_1113.class_1114.field_5478;      // 不做距离衰减
        this.field_5439 = 0.0;
        this.field_5450 = 0.0;
        this.field_5449 = 0.0;
    }

    @Override
    public CompletableFuture<class_4234> openStream() {
        return CompletableFuture.completedFuture(new PcmAudioStream(audio));
    }
}
