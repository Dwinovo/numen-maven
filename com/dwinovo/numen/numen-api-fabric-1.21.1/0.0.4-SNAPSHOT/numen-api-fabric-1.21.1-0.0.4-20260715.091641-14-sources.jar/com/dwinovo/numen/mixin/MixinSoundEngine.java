package com.dwinovo.numen.mixin;

import com.dwinovo.numen.client.voice.VoicePcmSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_2960;
import net.minecraft.class_4234;
import net.minecraft.class_4237;

/**
 * 同伴语音的取数重定向。{@code SoundEngine.play} 对流式声音固定调用
 * {@code SoundBufferLibrary.getStream(sound.getPath(), loop)} 去开 ogg——
 * 1.21.1 的 {@link class_1113} 还没有后续版本那个可覆写的
 * {@code getStream} default 钩子,所以在这里把带内存 PCM 的实例
 * （{@link VoicePcmSource}:同伴 3D 语音与设置界面 2D 试听）的取数换成
 * 它自带的流,其余声音原样放行。语义与后续版本官方钩子一致,
 * 升版本时删掉本 mixin 改成覆写即可。
 */
@Mixin(class_1140.class)
public class MixinSoundEngine {

    @Redirect(method = "play",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/sounds/SoundBufferLibrary;getStream(Lnet/minecraft/resources/ResourceLocation;Z)Ljava/util/concurrent/CompletableFuture;"))
    private CompletableFuture<class_4234> numen$voicePcmStream(class_4237 library,
                                                                class_2960 path, boolean looping,
                                                                class_1113 sound) {
        if (sound instanceof VoicePcmSource voice) {
            return voice.openStream();
        }
        return library.method_19744(path, looping);
    }
}
