package com.dwinovo.numen.client.screen;

import com.dwinovo.numen.agent.llm.NumenLlmClient;
import com.dwinovo.numen.agent.model.ModelRegistry;
import com.dwinovo.numen.agent.llm.ConvoLog;
import com.dwinovo.numen.agent.llm.ConvoState;
import com.dwinovo.numen.agent.provider.AssistantTurn;
import com.dwinovo.numen.agent.provider.LlmToolCall;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import com.dwinovo.numen.client.agent.ClientDeaths;
import com.dwinovo.numen.client.agent.ClientNumenLookup;
import com.dwinovo.numen.client.agent.EntityAgentLoop;
import com.dwinovo.numen.client.agent.NumenRoster;
import com.dwinovo.numen.client.data.ClientNumenInventory;
import com.dwinovo.numen.network.payload.RequestInventoryPayload;
import com.dwinovo.numen.persona.PersonaLibrary;
import com.dwinovo.numen.platform.Services;
import com.dwinovo.numen.platform.services.INumenConfig;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1068;
import net.minecraft.class_1074;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_742;
import net.minecraft.class_7532;
import net.minecraft.class_8685;

/**
 * The owner-facing companion panel: one tabbed screen per Numen (Chat / Items /
 * Settings), opened from the roster or hotkey. Resolves the companion lazily by
 * UUID so it works at any distance.
 *
 * <h2>Chat tab</h2>
 * A scrollable transcript on the left + a live PLAN panel on the right. Tool calls
 * show a spinner while running and a green check once their result lands — the raw
 * tool-result JSON is NOT shown (it only flips the call to done), keeping the chat
 * readable. The plan is the companion's latest {@code todowrite}.
 */
public final class NumenScreen extends class_437 {

    private enum Tab { CHAT, ITEMS, SETTINGS }

    // ---- layout ----
    private static final int PANEL_W = 380;
    private static final int PANEL_H = 232;
    // Left companion rail (folded-in roster): one avatar per Numen, click to switch, + to summon.
    private static final int RAIL_W = 46;        // left rail column width (baked into the workspace sprite)
    private static final int RAIL_AV = 26;       // avatar tile size
    private static final int RAIL_SLOT = 32;     // vertical pitch per avatar
    private static final int RAIL_TOP = 12;      // top margin before the first avatar (clears the active crown)
    private static final int RAIL_BOT_GAP = 6;   // gap kept above the pinned "+" tile
    private static final int HEADER_H = 22;
    private static final int INPUT_H = 18;
    /** Text fields are inset inside their parchment frame: the EditBox is shrunk by this much
     *  (so vanilla's top-left unbordered text lands padded + centred) and the FIELD_SPRITE is
     *  inflated back out to the full frame. */
    private static final int FIELD_INSET_X = 5;
    private static final int FIELD_INSET_Y = 4;
    private static final int PAD = 8;
    private static final int LINE_H = 10;
    private static final int PLAN_W = 122;
    private static final int MAX_PROMPT = 1024;
    private static final int TOOL_ARG_CHARS = 44;

    // ---- palette (BlockFrame "Cottage" theme — single theme for now, see UiTheme) ----
    private static final UiTheme TH = UiTheme.WARM;
    private static final int BORDER = TH.border();
    private static final int ACCENT = TH.cta();
    private static final int TXT = TH.text();
    private static final int TXT_MUTED = TH.textDim();
    private static final int TXT_FAINT = 0xFF8C7C62;
    private static final int ON_BAND = TH.onBand();
    /** Faint on-band text (persona name after the companion name): cream blended toward the green band. */
    private static final int ON_BAND_FAINT = 0xFFB2BF9F;
    private static final int CTA = TH.cta();
    private static final int ON_CTA = TH.onCta();
    private static final int FIELD = TH.field();
    private static final int YOU = TH.reply();          // user messages — teal
    private static final int AI = 0xFF35562F;            // assistant replies — deep moss green (the "point")
    private static final int TOOL = TH.textDim();        // folded tool-call rows — muted, secondary
    private static final int OK = TH.ok();
    private static final int RUN = TH.run();
    private static final int FAIL = TH.fail();
    private static net.minecraft.class_2960 railSpr(String n) {
        return net.minecraft.class_2960.method_60655(com.dwinovo.numen.Constants.MOD_ID, n);
    }
    /** rail + panel composited into ONE sprite (continuous header, no gap; panel's left border = divider). */
    private static final net.minecraft.class_2960 WORKSPACE_SPRITE = railSpr("workspace");
    private static final net.minecraft.class_2960 AVATAR_FRAME = railSpr("avatar_frame");
    private static final net.minecraft.class_2960 AVATAR_FRAME_ACTIVE = railSpr("avatar_frame_active");
    private static final net.minecraft.class_2960 SUMMON_SPRITE = railSpr("summon");
    private static final net.minecraft.class_2960 SUMMON_ACTIVE = railSpr("summon_active");
    /** API-key reveal toggle icons: open eye = "click to show", slashed eye = "click to hide". */
    private static final net.minecraft.class_2960 EYE = railSpr("eye");
    private static final net.minecraft.class_2960 EYE_OFF = railSpr("eye_off");
    private static final net.minecraft.class_2960 CHEVRON_UP = railSpr("chevron_up");
    private static final net.minecraft.class_2960 CHEVRON_DOWN = railSpr("chevron_down");

    private static final String[] SPIN = {"|", "/", "-", "\\"};
    /** Armor column on the Items tab (top → bottom); offhand is drawn separately below it. */
    private static final class_1304[] ARMOR = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

    private UUID uuid;       // active companion (mutable — the rail switches it in place)
    private String name;
    private Tab tab = Tab.CHAT;

    /** The Settings tab is a config hub: a left sub-nav picks one of these sections. */
    private enum SettingsSection { PROVIDER, MCP, SKILLS, PERSONA }

    // ---- provider-library section state (mirrors the persona section) ----
    private boolean addingProvider;
    private String providerEditId;
    private String providerDeletePending;
    private String wProvName = "", wProvProvider = "", wProvModel = "", wProvKey = "", wProvBaseUrl = "";
    private net.minecraft.class_342 provNameInput, provProviderInput,
            provModelInput, provKeyInput, provBaseUrlInput;
    private SettingsSection settingsSection = SettingsSection.PROVIDER;

    // Persona library form state (mirrors the MCP add/edit/delete flow).
    private boolean addingPersona;
    private String personaEditId;          // non-null = editing this persona; null = creating
    private String personaDeletePending;   // id awaiting delete confirm
    private String wPersonaName = "", wPersonaText = "";
    private net.minecraft.class_342 personaNameInput;
    private net.minecraft.class_7529 personaTextArea;   // roomy multi-line persona editor
    /** Persona chosen for the companion currently being summoned (null = default / none). */
    private String summonPersonaId;
    private Dropdown summonPersonaDropdown;
    /** Provider entry for the new companion — REQUIRED (no default, no fallback). */
    private Dropdown summonProviderDropdown;
    private String summonProviderId;
    private static final String PERSONA_DEFAULT = "__default__";
    private int settingsScroll;   // first visible row of the MCP / skill list (wheel-scroll when long)

    // MCP "add server" form (mirrors the LLM add-site flow)
    private boolean addingMcp;
    private boolean mcpStdio;                 // form type: false = http, true = stdio
    private String wMcpName = "", wMcpTarget = "", wMcpHeader = "";
    private class_342 mcpNameInput, mcpTargetInput, mcpHeaderInput;
    private String mcpDeletePending;          // non-null = showing the delete-confirm bar for this server
    private String mcpEditOriginal;           // non-null = the add-form is EDITING this server (replace on save)

    private class_342 input;
    private SimpleButton sendButton;
    private SimpleButton stopButton;
    private SimpleButton compactButton;
    private String savedInput = "";

    // "+" summon flow: a transient name field shown over the panel
    private boolean summoning;
    private class_342 summonInput;
    private UUID dismissPending;   // non-null = showing the "delete companion?" confirm bar for this uuid

    // settings tab widgets
    private ProviderDropdown providerDropdown;
    private Dropdown modelDropdown;          // null when in custom-model mode
    private boolean customModel;             // model is a free-text custom id (not a registry preset)
    private static final String CUSTOM_MODEL = "__custom__";
    // unsaved working state — settings widgets are (re)built from these, NOT from config, so a rebuild
    // (provider change / custom toggle) doesn't revert what you just picked or typed.
    private String wProvider = "", wApiKey = "", wModel = "", wBaseUrl = "", wProxy = "", wSiteName = "";
    private String wReasoning = "auto";      // reasoning/thinking effort: auto | low | medium | high
    private boolean addingSite;              // "+ 添加站点" mode: name + base URL + model → writes a site
    private class_342 proxyInput;
    private class_342 siteNameInput;
    private class_342 apiKeyInput;
    private class_342 modelInput;
    private class_342 baseUrlInput;
    private long savedFlashUntil;
    private long warnUntil;        // transient "no API key" hint on the chat tab
    /** The current warn hint's text (endpoint problems vary: unbound provider vs keyless
     *  entry); null falls back to the generic no-key translation. */
    private String warnText;

    // A hovered-row tooltip (MCP / skill list) collected during section render, drawn last so
    // it sits above every later draw. Cleared each frame.
    private List<class_2561> pendingTip;
    private int pendingTipX, pendingTipY;

    // Widgets are registered for EVENTS only (addWidget) and rendered MANUALLY at the end of the
    // frame, so they sit ON TOP of the panel background instead of being painted over by it (the
    // "dim fields" bug — the panel fill ran after the auto-rendered widgets).
    private final List<class_339> overlay = new ArrayList<>();
    /** API key is masked by default; the eye button toggles it. */
    private boolean showKey;

    // geometry resolved in init()
    private int left, top, railX;
    private final int[] tabX = new int[3];   // left x of each tab label, for click hit-testing
    private final int[] tabW = new int[3];

    // chat transcript scroll
    private int scroll;            // px scrolled down from the top of the content
    private boolean pinBottom = true;
    private int lastMaxScroll;
    private int railScroll;        // index of the first visible rail avatar (wheel-scroll when many companions)
    /** Completed tool-call groups the user clicked open (keyed by the group's first call id). */
    private final Set<String> expandedGroups = new HashSet<>();

    /** Re-request the backpack every ~1 s while the Items tab is open. */
    private static final int INV_REFRESH_TICKS = 20;
    private int tickCounter;

    private NumenScreen(UUID uuid, String name) {
        super(class_2561.method_43470(name == null ? "Numen" : "Numen - " + name));
        this.uuid = uuid;
        this.name = name;
    }

    /** Open the panel focused on a specific companion. */
    public static void open(UUID uuid, String name) {
        class_310.method_1551().method_1507(new NumenScreen(uuid, name));
    }

    /** Hotkey entry: open the workspace on the first companion (or an empty panel to summon from). */
    public static void openWorkspace() {
        var entries = NumenRoster.instance().entries();
        if (entries.isEmpty()) { class_310.method_1551().method_1507(new NumenScreen(null, null)); return; }
        NumenRoster.Entry first = entries.get(0);
        class_310.method_1551().method_1507(new NumenScreen(first.uuid(), first.name()));
    }

    /** Switch the panel to another companion in place (left-rail click) — no reopen. */
    private void switchTo(UUID u, String n) {
        if (java.util.Objects.equals(u, uuid)) return;
        input = null; savedInput = "";          // don't carry typed text across companions
        uuid = u; name = n;
        scroll = 0; pinBottom = true; expandedGroups.clear();
        rebuild();
        if (tab == Tab.ITEMS && u != null) requestInventory();
    }

    private EntityAgentLoop loop() {
        return AgentLoopRegistry.getOrCreate(uuid);
    }

    @Override
    protected void method_25426() {
        int composite = RAIL_W + PANEL_W;        // rail flush against the panel — one merged sprite
        this.railX = (this.field_22789 - composite) / 2;
        this.left = railX + RAIL_W;
        this.top = (this.field_22790 - PANEL_H) / 2;
        layoutTabs();
        rebuild();
    }

    private static String[] tabLabels() {
        return new String[]{
                class_1074.method_4662("numen.tab.chat"), class_1074.method_4662("numen.tab.status"), class_1074.method_4662("numen.tab.settings")};
    }

    private void layoutTabs() {
        String[] labels = tabLabels();
        int x = left + PANEL_W - PAD;
        for (int i = labels.length - 1; i >= 0; i--) {
            int w = field_22793.method_1727(labels[i]) + 10;
            x -= w;
            tabX[i] = x;
            tabW[i] = w;
            x -= 4;
        }
    }

    /** Rebuild the widgets for the active tab. */
    private void rebuild() {
        if (input != null) savedInput = input.method_1882();
        method_37067();
        overlay.clear();
        input = null;
        sendButton = stopButton = compactButton = null;
        apiKeyInput = modelInput = baseUrlInput = proxyInput = siteNameInput = null;
        mcpNameInput = mcpTargetInput = mcpHeaderInput = null;
        personaNameInput = null;
        personaTextArea = null;
        provNameInput = provProviderInput = provModelInput = provKeyInput = provBaseUrlInput = null;
        modelDropdown = null;
        summonInput = null;
        summonPersonaDropdown = null;
        summonProviderDropdown = null;
        if (summoning) { buildSummonField(); return; }
        if (dismissPending != null) { buildDismissConfirm(); return; }
        switch (tab) {
            case CHAT -> { if (uuid != null) buildChatWidgets(); }
            case SETTINGS -> buildSettingsWidgets();
            case ITEMS -> { /* no widgets */ }
        }
    }

    private void buildSummonField() {
        int y = top + HEADER_H + 24;
        summonInput = new FlatEditBox(field_22793, left + PAD + FIELD_INSET_X, y + FIELD_INSET_Y,
                PANEL_W - PAD * 2 - FIELD_INSET_X * 2, 18 - FIELD_INSET_Y * 2, class_2561.method_43470(""));
        summonInput.method_1880(com.dwinovo.numen.network.payload.SummonRequestPayload.MAX_NAME);
        summonInput.method_1858(false);
        summonInput.method_1868(TXT);
        summonInput.method_47404(class_2561.method_43471("numen.summon.name_hint"));
        add(summonInput);
        // Optional persona for the new companion — a dropdown of the library (+ 默认). Rendered/routed
        // manually (see render / mouseClicked), like the Settings model dropdown.
        List<Dropdown.Item> items = new ArrayList<>();
        items.add(new Dropdown.Item(PERSONA_DEFAULT, class_1074.method_4662("numen.persona.default")));
        for (PersonaLibrary.Persona p : PersonaLibrary.instance().list()) {
            items.add(new Dropdown.Item(p.id(), p.name()));
        }
        summonPersonaDropdown = new Dropdown(items, summonPersonaId == null ? PERSONA_DEFAULT : summonPersonaId);
        summonPersonaDropdown.setBounds(left + PAD, y + 26, PANEL_W - PAD * 2, 18);
        // REQUIRED provider entry for the new companion — no default item and no fallback:
        // an empty library means creation is blocked (the render paints the pointer to
        // 设置 → 提供商 instead of a dropdown).
        var provEntries = com.dwinovo.numen.agent.llm.ProviderLibrary.instance().list();
        if (!provEntries.isEmpty()) {
            List<Dropdown.Item> provItems = new ArrayList<>();
            for (var e : provEntries) {
                provItems.add(new Dropdown.Item(e.id(), e.name()));
            }
            if (summonProviderId == null) summonProviderId = provEntries.get(0).id();
            summonProviderDropdown = new Dropdown(provItems, summonProviderId);
            summonProviderDropdown.setBounds(left + PAD, y + 48, PANEL_W - PAD * 2, 18);
        }
        // Explicit actions — Enter stays as the fallback confirm (keyPressed), the
        // buttons are the primary path.
        int bw = 64, gap = 8, totalW = bw * 2 + gap;
        int bx = left + (PANEL_W - totalW) / 2;
        int by = y + 74;
        add(new SimpleButton(bx, by, bw, 18, class_2561.method_43471("numen.gui.settings.cancel"),
                b -> { summoning = false; rebuild(); }));
        add(new SimpleButton(bx + bw + gap, by, bw, 18, class_2561.method_43470("创建"),
                b -> doSummon()));
        method_48265(summonInput);
    }

    /** Two buttons for the "delete companion?" confirm bar — Cancel and the destructive Delete. */
    private void buildDismissConfirm() {
        UUID target = dismissPending;
        int bw = 64, gap = 8, totalW = bw * 2 + gap;
        int bx = left + (PANEL_W - totalW) / 2;
        int by = top + HEADER_H + 52;
        add(new SimpleButton(bx, by, bw, 18, class_2561.method_43471("numen.gui.settings.cancel"),
                b -> { dismissPending = null; rebuild(); }));
        add(new SimpleButton(bx + bw + gap, by, bw, 18, class_2561.method_43471("numen.dismiss.delete"), b -> {
            Services.NETWORK.sendToServer(
                    new com.dwinovo.numen.network.payload.DismissRequestPayload(target));
            dismissPending = null;
            if (target.equals(uuid)) {                       // active one is leaving — jump to another / empty
                NumenRoster.Entry next = firstOther(target);
                if (next != null) { switchTo(next.uuid(), next.name()); return; }
                uuid = null; name = null;
            }
            rebuild();
        }));
    }

    /** First roster companion that isn't {@code exclude}, or null if none. */
    private NumenRoster.Entry firstOther(UUID exclude) {
        for (NumenRoster.Entry e : NumenRoster.instance().entries()) {
            if (!e.uuid().equals(exclude)) return e;
        }
        return null;
    }

    private String nameFor(UUID u) {
        for (NumenRoster.Entry e : NumenRoster.instance().entries()) {
            if (e.uuid().equals(u)) return e.name();
        }
        return "?";
    }

    /** Register a widget for EVENTS only; it's rendered manually (on top of the panel) in {@link
     *  #method_25394}. */
    private <T extends class_339> T add(T w) {
        method_25429(w);
        overlay.add(w);
        return w;
    }

    // Shadowless text — BlockFrame is flat, and a drop shadow on DARK text over a LIGHT ground makes
    // the glyph merge with its own shadow ("smudged"). This build's shadowless path ignores the colour
    // PARAM, so we bake the colour into the text's Style instead.
    private void txt(class_332 g, class_2561 c, int x, int y, int color) {
        g.method_51439(field_22793, c.method_27661().method_27694(s -> s.method_27703(
                net.minecraft.class_5251.method_27717(color & 0xFFFFFF))), x, y, -1, false);
    }

    /** The FormattedCharSequence must already carry its colour (see {@link #colored}). */
    private void txt(class_332 g, class_5481 c, int x, int y, int color) {
        g.method_51430(field_22793, c, x, y, -1, false);
    }

    /** A coloured text Component (colour in the Style, so shadowless rendering keeps it). */
    private static class_2561 colored(String s, int color) {
        return class_2561.method_43470(s).method_27694(st -> st.method_27703(
                net.minecraft.class_5251.method_27717(color & 0xFFFFFF)));
    }


    private void buildChatWidgets() {
        int inputY = top + PANEL_H - INPUT_H - PAD;
        int compactW = 26;
        int sendW = 42;
        int stopW = 22;
        int inX = left + PAD + compactW + 4;
        int inW = PANEL_W - PAD * 2 - compactW - sendW - stopW - 12;

        compactButton = add(new SimpleButton(left + PAD, inputY, compactW, INPUT_H,
                class_2561.method_43470("⤬"), b -> loop().requestCompact()));
        compactButton.field_22763 = loop().canCompact();

        input = new FlatEditBox(field_22793, inX + FIELD_INSET_X, inputY + FIELD_INSET_Y,
                inW - FIELD_INSET_X * 2, INPUT_H - FIELD_INSET_Y * 2, class_2561.method_43470("numen.chat.input"));
        input.method_1880(MAX_PROMPT);
        input.method_1858(false);
        input.method_1868(TXT);
        // FlatEditBox draws the hint shadowless and UNDER the caret (same widget pass), so use it
        // directly — no separate screen-side placeholder that would paint over the blinking caret.
        // Faint colour is baked into the Component's Style.
        input.method_47404(Nb.colored(class_1074.method_4662("numen.chat.hint", name == null ? "" : name), TXT_FAINT));
        if (!savedInput.isEmpty()) { input.method_1852(savedInput); savedInput = ""; }
        add(input);
        method_48265(input);

        sendButton = add(new SimpleButton(inX + inW + 4, inputY, sendW, INPUT_H,
                class_2561.method_43471("numen.chat.send"), b -> onSend()));

        stopButton = add(new SimpleButton(inX + inW + 4 + sendW + 4, inputY, stopW, INPUT_H,
                class_2561.method_43470("■"), b -> loop().abort()));
        stopButton.field_22763 = loop().canInterrupt();
    }

    private void selectTab(Tab t) {
        if (t == tab) return;
        tab = t;
        scroll = 0;
        pinBottom = true;
        if (t == Tab.ITEMS) requestInventory();
        if (t == Tab.SETTINGS) initModelMode();
        rebuild();
    }

    /** Decide once (on entering Settings) whether the model field starts as a preset dropdown or a
     *  custom text box: custom-provider or a configured model that isn't a known preset → custom. */
    private void initModelMode() {
        INumenConfig cfg = Services.CONFIG;
        wProvider = cfg.getProvider() == null ? "openai" : cfg.getProvider();
        wApiKey = cfg.getApiKey() == null ? "" : cfg.getApiKey();
        wModel = cfg.getModel() == null ? "" : cfg.getModel();
        wBaseUrl = cfg.getBaseUrl() == null ? "" : cfg.getBaseUrl();
        wProxy = cfg.getProxy() == null ? "" : cfg.getProxy();
        wReasoning = normalizeReasoning(cfg.getReasoningEffort());
        addingSite = false;
        ModelRegistry.Provider mp = ModelRegistry.provider(LlmProviders.normalize(wProvider));
        boolean known = mp != null && mp.models().stream().anyMatch(m -> m.id().equals(wModel));
        customModel = (mp != null && mp.custom()) || (!wModel.isBlank() && !known);
    }

    /** Snapshot the API-key + base-URL fields before a settings rebuild so the edits survive it. */
    private void preserveKeyUrl() {
        if (apiKeyInput != null) wApiKey = apiKeyInput.method_1882();
        if (baseUrlInput != null) wBaseUrl = baseUrlInput.method_1882();
        if (proxyInput != null) wProxy = proxyInput.method_1882();
    }

    // ---- settings tab (config hub: sub-nav + section) ----

    private static final int SET_SP = 33;     // LLM-section row pitch (5 rows + Save must fit)
    private static final int NAV_W = 74;      // left sub-nav column width
    private static final int NAV_SP = 20;     // sub-nav row pitch
    private static final int LIST_ROW = 22;   // MCP / skill list row height

    /** Left x of the section content area (right of the sub-nav column + divider). */
    private int secX() { return left + PAD + NAV_W + 8; }
    /** Width of the section content area. */
    private int secW() { return PANEL_W - PAD - NAV_W - 8 - PAD; }
    /** Top y of section content (below the header). */
    private int secY0() { return top + HEADER_H + 8; }
    /** Bottom y a list row may reach. */
    private int secBottom() { return top + PANEL_H - PAD; }

    private void selectSection(SettingsSection s) {
        if (s == settingsSection) return;
        settingsSection = s;
        settingsScroll = 0;
        addingMcp = false;
        mcpDeletePending = null;
        mcpEditOriginal = null;
        addingPersona = false;
        personaEditId = null;
        personaDeletePending = null;
        addingProvider = false;
        providerEditId = null;
        providerDeletePending = null;
        rebuild();
    }

    /** Dispatch widget building by the active section (skill/MCP lists render manually). */
    private void buildSettingsWidgets() {
        switch (settingsSection) {
            case SKILLS -> buildSkillsWidgets();
            case MCP -> {
                if (mcpDeletePending != null) buildMcpDeleteConfirm();
                else if (addingMcp) buildMcpForm();
                else buildMcpListWidgets();
            }
            case PERSONA -> {
                if (personaDeletePending != null) buildPersonaDeleteConfirm();
                else if (addingPersona) buildPersonaForm();
                else buildPersonaListWidgets();
            }
            case PROVIDER -> {
                if (providerDeletePending != null) buildProviderDeleteConfirm();
                else if (addingProvider) buildProviderForm();
                else buildProviderListWidgets();
            }
        }
    }

    // ---- Provider section: the library of named LLM provider configs companions select from ----

    private void buildProviderListWidgets() {
        add(new SimpleButton(left + PANEL_W - PAD - 64, secY0() - 2, 64, 14,
                class_2561.method_43470("新建"), b -> {
                    addingProvider = true; providerEditId = null;
                    wProvName = ""; wProvProvider = ""; wProvModel = ""; wProvKey = ""; wProvBaseUrl = "";
                    rebuild();
                }));
        // Global proxy (a network-environment property, deliberately NOT per-entry) —
        // relocated here from the removed 模型接入 section: bottom band, field + save.
        int x = secX(), w = secW();
        proxyInput = field(x, top + PANEL_H - PAD - 18, w - 70, 128, Services.CONFIG.getProxy());
        add(new SimpleButton(left + PANEL_W - PAD - 64, top + PANEL_H - PAD - 18, 64, 18,
                class_2561.method_43471("numen.gui.settings.save"), b -> {
                    Services.CONFIG.setProxy(proxyInput.method_1882().trim());
                    Services.CONFIG.save();
                    NumenLlmClient.reset();
                    savedFlashUntil = System.currentTimeMillis() + 1500;
                }));
    }

    /** Five single-line fields; ONLY the name is required to save (an incomplete
     *  entry errors honestly at first use — the library's whole philosophy). */
    private void buildProviderForm() {
        int x = secX(), w = secW();
        int fy = secY0();
        provNameInput = field(x, fy + 11, w, 48, wProvName);
        provProviderInput = field(x, fy + 11 + SET_SP, w, 48, wProvProvider);
        provModelInput = field(x, fy + 11 + 2 * SET_SP, w, 96, wProvModel);
        provKeyInput = field(x, fy + 11 + 3 * SET_SP, w, 256, wProvKey);
        provBaseUrlInput = field(x, fy + 11 + 4 * SET_SP, w, 256, wProvBaseUrl);
        add(new SimpleButton(left + PANEL_W - PAD - 64, top + PANEL_H - PAD - 18, 64, 18,
                class_2561.method_43471("numen.gui.settings.save"), b -> onSaveProvider()));
        add(new SimpleButton(left + PANEL_W - PAD - 64 - 22, top + PANEL_H - PAD - 18, 18, 18,
                class_2561.method_43470("✕"), b -> { addingProvider = false; providerEditId = null; rebuild(); }));
        method_48265(provNameInput);
    }

    private void buildProviderDeleteConfirm() {
        int x = secX();
        int by = secY0() + 24;
        int bw = 64, gap = 8;
        add(new SimpleButton(x, by, bw, 18, class_2561.method_43471("numen.dismiss.delete"), b -> {
            com.dwinovo.numen.agent.llm.ProviderLibrary.instance().remove(providerDeletePending);
            providerDeletePending = null;
            rebuild();
        }));
        add(new SimpleButton(x + bw + gap, by, bw, 18, class_2561.method_43471("numen.gui.settings.cancel"),
                b -> { providerDeletePending = null; rebuild(); }));
    }

    private void onSaveProvider() {
        String name = provNameInput.method_1882().trim();
        if (name.isEmpty()) { warnUntil = System.currentTimeMillis() + 4000; return; }
        var lib = com.dwinovo.numen.agent.llm.ProviderLibrary.instance();
        String provider = provProviderInput.method_1882().trim();
        String model = provModelInput.method_1882().trim();
        String key = provKeyInput.method_1882().trim();
        String baseUrl = provBaseUrlInput.method_1882().trim();
        if (providerEditId != null) {
            var old = lib.get(providerEditId);
            lib.update(new com.dwinovo.numen.agent.llm.ProviderLibrary.Entry(
                    providerEditId, name, provider, model, key, baseUrl,
                    old != null ? old.reasoningEffort() : ""));
        } else {
            lib.create(name, provider, model, key, baseUrl, "");
        }
        addingProvider = false;
        providerEditId = null;
        wProvName = ""; wProvProvider = ""; wProvModel = ""; wProvKey = ""; wProvBaseUrl = "";
        rebuild();
    }

    // ---- Persona section: a library of reusable personas; apply one to the active companion ----

    private void buildPersonaListWidgets() {
        add(new SimpleButton(left + PANEL_W - PAD - 64, secY0() - 2, 64, 14,
                class_2561.method_43471("numen.persona.add"), b -> {
                    addingPersona = true; personaEditId = null;
                    wPersonaName = ""; wPersonaText = "";
                    rebuild();
                }));
    }

    private void buildPersonaForm() {
        int x = secX(), w = secW();
        int fy = secY0() + 14;
        personaNameInput = field(x, fy + 11, w, 48, wPersonaName);
        // Roomy multi-line editor for the persona description (a paragraph, not one line): from below the
        // name field down to just above the Save row.
        int ty = fy + 44;
        int th = (top + PANEL_H - PAD - 22) - ty;
        personaTextArea = new net.minecraft.class_7529(
                field_22793, x, ty, w, th,
                class_2561.method_43471("numen.persona.text_placeholder"), class_2561.method_43473());
        personaTextArea.method_44400(wPersonaText);
        personaTextArea.method_44402(4096);
        add(personaTextArea);
        add(new SimpleButton(left + PANEL_W - PAD - 64, top + PANEL_H - PAD - 18, 64, 18,
                class_2561.method_43471("numen.gui.settings.save"), b -> onSavePersona()));
        add(new SimpleButton(left + PANEL_W - PAD - 64 - 22, top + PANEL_H - PAD - 18, 18, 18,
                class_2561.method_43470("✕"), b -> { addingPersona = false; personaEditId = null; rebuild(); }));
        method_48265(personaNameInput);
    }

    private void buildPersonaDeleteConfirm() {
        int x = secX();
        int by = secY0() + 24;
        int bw = 64, gap = 8;
        add(new SimpleButton(x, by, bw, 18, class_2561.method_43471("numen.dismiss.delete"), b -> {
            com.dwinovo.numen.persona.PersonaLibrary.instance().remove(personaDeletePending);
            personaDeletePending = null;
            rebuild();
        }));
        add(new SimpleButton(x + bw + gap, by, bw, 18, class_2561.method_43471("numen.gui.settings.cancel"),
                b -> { personaDeletePending = null; rebuild(); }));
    }

    private void onSavePersona() {
        String name = personaNameInput.method_1882().trim();
        String text = personaTextArea == null ? "" : personaTextArea.method_44405().trim();
        if (name.isEmpty() || text.isEmpty()) { warnUntil = System.currentTimeMillis() + 4000; return; }
        var lib = com.dwinovo.numen.persona.PersonaLibrary.instance();
        if (personaEditId != null) {
            PersonaLibrary.Persona old = lib.get(personaEditId);
            String oldName = old != null ? old.name() : null;
            lib.update(personaEditId, name, text);
            // Propagate the edit to any loaded companion currently using this persona: a live switch with
            // a reconciliation message (match by library id, or by the old name for pre-id companions).
            for (UUID cu : AgentLoopRegistry.loadedEntityUuids()) {
                EntityAgentLoop l = AgentLoopRegistry.get(cu).orElse(null);
                if (l == null) continue;
                boolean uses = personaEditId.equals(l.personaId())
                        || (l.personaId() == null && oldName != null && oldName.equals(l.personaName()));
                if (uses) l.setPersona(personaEditId, text, name);
            }
        } else {
            lib.create(name, text);
        }
        addingPersona = false;
        personaEditId = null;
        wPersonaName = ""; wPersonaText = "";
        rebuild();
    }

    private void buildMcpDeleteConfirm() {
        int x = secX();
        int by = secY0() + 24;
        int bw = 64, gap = 8;
        add(new SimpleButton(x, by, bw, 18, class_2561.method_43471("numen.dismiss.delete"), b -> {
            com.dwinovo.numen.mcp.client.McpClientManager.deleteServer(mcpDeletePending);
            mcpDeletePending = null;
            rebuild();
        }));
        add(new SimpleButton(x + bw + gap, by, bw, 18, class_2561.method_43471("numen.gui.settings.cancel"),
                b -> { mcpDeletePending = null; rebuild(); }));
    }

    private void buildMcpListWidgets() {
        // "add server" affordance, top-right of the section.
        add(new SimpleButton(left + PANEL_W - PAD - 64, secY0() - 2, 64, 14,
                class_2561.method_43471("numen.mcp.add"), b -> {
                    addingMcp = true; mcpEditOriginal = null;                 // fresh add — not editing
                    wMcpName = ""; wMcpTarget = ""; wMcpHeader = ""; mcpStdio = false;
                    rebuild();
                }));
    }

    /** The add-MCP-server form: name, type (http/stdio) toggle, and URL / command. */
    private void buildMcpForm() {
        int x = secX(), w = secW();
        int fy = secY0() + 14;     // start below the "MCP 工具" title so nothing overlaps
        mcpNameInput = field(x, fy + 11, w, 48, wMcpName);
        // type toggle button (cycles http ↔ stdio; rebuild swaps the URL/command row)
        add(new SimpleButton(x, fy + 34, w, 18,
                class_2561.method_43471(mcpStdio ? "numen.mcp.type_stdio" : "numen.mcp.type_http"),
                b -> { preserveMcpForm(); mcpStdio = !mcpStdio; rebuild(); }));
        mcpTargetInput = field(x, fy + 67, w, 512, wMcpTarget);
        // 4th field: HTTP → request header(s) "Name: Value"; stdio → env "KEY=value" (';'-separated).
        mcpHeaderInput = field(x, fy + 100, w, 1024, wMcpHeader);
        // Save + Cancel
        add(new SimpleButton(left + PANEL_W - PAD - 64, top + PANEL_H - PAD - 18, 64, 18,
                class_2561.method_43471("numen.gui.settings.save"), b -> onSaveMcp()));
        add(new SimpleButton(left + PANEL_W - PAD - 64 - 22, top + PANEL_H - PAD - 18, 18, 18,
                class_2561.method_43470("✕"), b -> { addingMcp = false; mcpEditOriginal = null; rebuild(); }));
        method_48265(mcpNameInput);   // ready to type the name immediately
    }

    private void preserveMcpForm() {
        if (mcpNameInput != null) wMcpName = mcpNameInput.method_1882();
        if (mcpTargetInput != null) wMcpTarget = mcpTargetInput.method_1882();
        if (mcpHeaderInput != null) wMcpHeader = mcpHeaderInput.method_1882();
    }

    private void onSaveMcp() {
        String name = mcpNameInput.method_1882().trim();
        String target = mcpTargetInput.method_1882().trim();
        if (name.isEmpty() || target.isEmpty()) { warnUntil = System.currentTimeMillis() + 4000; return; }
        // When editing, preserve the server's on/off state (a plain edit shouldn't flip its toggle).
        boolean enabled = true;
        if (mcpEditOriginal != null) {
            var orig = com.dwinovo.numen.mcp.client.McpClientManager.spec(mcpEditOriginal);
            if (orig != null) enabled = orig.enabled();
        }
        com.dwinovo.numen.mcp.client.McpClientConfig.ServerSpec spec;
        String extra = mcpHeaderInput == null ? "" : mcpHeaderInput.method_1882();
        if (mcpStdio) {
            String[] parts = target.split("\\s+");
            String command = parts[0];
            List<String> args = new ArrayList<>();
            for (int i = 1; i < parts.length; i++) args.add(parts[i]);
            spec = new com.dwinovo.numen.mcp.client.McpClientConfig.ServerSpec(name, "stdio", "", java.util.Map.of(),
                    command, List.copyOf(args), parseEnv(extra), enabled, 20, 120);
        } else {
            spec = new com.dwinovo.numen.mcp.client.McpClientConfig.ServerSpec(name, "http", target, parseHeader(extra),
                    "", List.of(), java.util.Map.of(), enabled, 20, 120);
        }
        com.dwinovo.numen.mcp.client.McpClientManager.upsertServer(spec);
        // Renamed while editing → upsert wrote the new-named entry; drop the old one.
        if (mcpEditOriginal != null && !mcpEditOriginal.equals(name)) {
            com.dwinovo.numen.mcp.client.McpClientManager.deleteServer(mcpEditOriginal);
        }
        mcpEditOriginal = null;
        addingMcp = false;
        wMcpName = ""; wMcpTarget = ""; wMcpHeader = ""; mcpStdio = false;
        rebuild();
    }

    /** Parse "Name: Value" header lines (multiple separated by ';' or newline) into a map. */
    private static java.util.Map<String, String> parseHeader(String line) {
        return parsePairs(line, ':');
    }

    /** Parse "KEY=value" env lines (multiple separated by ';' or newline) into a map. */
    private static java.util.Map<String, String> parseEnv(String line) {
        return parsePairs(line, '=');
    }

    private static java.util.Map<String, String> parsePairs(String line, char sep) {
        String s = line == null ? "" : line.trim();
        if (s.isEmpty()) return java.util.Map.of();
        java.util.Map<String, String> out = new java.util.LinkedHashMap<>();
        for (String part : s.split("[;\\n]")) {
            String p = part.trim();
            int i = p.indexOf(sep);
            if (i <= 0) continue;
            String k = p.substring(0, i).trim();
            String v = p.substring(i + 1).trim();
            if (!k.isEmpty() && !v.isEmpty()) out.put(k, v);
        }
        return java.util.Map.copyOf(out);
    }

    private void buildSkillsWidgets() {
        // "open skills folder" affordance, top-right of the section.
        add(new SimpleButton(left + PANEL_W - PAD - 64, secY0() - 2, 64, 14,
                class_2561.method_43471("numen.skill.open_dir"), b -> openSkillsFolder()));
    }

    private static void openSkillsFolder() {
        try {
            java.nio.file.Path dir = class_310.method_1551().field_1697.toPath()
                    .resolve("config").resolve(com.dwinovo.numen.Constants.MOD_ID).resolve("skills");
            java.nio.file.Files.createDirectories(dir);
            net.minecraft.class_156.method_668().method_673(dir.toUri());
        } catch (Exception ex) {
            com.dwinovo.numen.Constants.LOG.warn("[numen] open skills folder failed: {}", ex.toString());
        }
    }

    // ==== DEAD CODE — the legacy 模型接入 section was removed from the nav (2026-07-14;
    // the 提供商 library replaces it). buildLlmWidgets / onSaveSettings / buildModelRow /
    // buildApiKeyRow / renderLlmSettings and their dropdown click blocks are unreachable;
    // delete wholesale in a dedicated cleanup commit. ====
    private void buildLlmWidgets() {
        int x = secX(), w = secW();
        int y0 = secY0();

        if (addingSite) {
            // The provider picker is stale in add-site mode (it still holds the "+ 添加站点" sentinel and
            // its bounds overlap the site-name field, stealing that field's clicks so the name can never be
            // typed → Save early-returns). Drop it entirely while the add-site form is up.
            providerDropdown = null;
            // row0: site name + cancel
            siteNameInput = field(x, y0 + 11, w - 20, 64, wSiteName);
            add(new SimpleButton(x + w - 18, y0 + 11, 18, 18, class_2561.method_43470("✕"),
                    b -> { addingSite = false; rebuild(); }));
            buildApiKeyRow(x, y0 + SET_SP + 11, w);
            modelInput = field(x, y0 + 2 * SET_SP + 11, w, 128, wModel);
            baseUrlInput = field(x, y0 + 3 * SET_SP + 11, w, 256, wBaseUrl);
            method_48265(siteNameInput);   // ready to type the name immediately (no click needed)
        } else {
            providerDropdown = new ProviderDropdown(wProvider, true);   // live + "+ 添加站点"
            providerDropdown.setBounds(x, y0 + 11, w, 18);
            buildApiKeyRow(x, y0 + SET_SP + 11, w);
            buildModelRow(x, y0 + 2 * SET_SP + 11, w);
            baseUrlInput = field(x, y0 + 3 * SET_SP + 11, w, 256, wBaseUrl);
            proxyInput = field(x, y0 + 4 * SET_SP + 11, w, 128, wProxy);
            // Reasoning/thinking effort cycle — a compact button in the bottom band, left of Save.
            add(new SimpleButton(x, top + PANEL_H - PAD - 18, 118, 18, reasoningLabel(),
                    b -> { cycleReasoning(); b.method_25355(reasoningLabel()); }));
        }

        add(new SimpleButton(left + PANEL_W - PAD - 64, top + PANEL_H - PAD - 18,
                64, 18, class_2561.method_43471("numen.gui.settings.save"), b -> onSaveSettings()));
    }

    private void buildApiKeyRow(int x, int y, int w) {
        int eyeW = 22;
        apiKeyInput = field(x, y, w - eyeW - 2, 512, wApiKey);
        // Show the real key while editing (focused) or when revealed via the eye — masking with a
        // fixed "•" mis-sizes against the variable-width font, so a long key drifts the caret and
        // leaves gaps while typing. When unfocused + hidden, mask it for shoulder-surfing.
        apiKeyInput.method_1854((text, idx) -> (showKey || (apiKeyInput != null && apiKeyInput.method_25370()))
                ? class_5481.method_30747(text, net.minecraft.class_2583.field_24360)
                : class_5481.method_30747("•".repeat(text.length()), net.minecraft.class_2583.field_24360));
        // Eye icon instead of a 见/隐 glyph: open eye when masked (click to show), slashed when shown.
        add(new SimpleButton(x + w - eyeW, y, eyeW, 18, class_2561.method_43473(),
                b -> { showKey = !showKey; ((SimpleButton) b).icon(showKey ? EYE_OFF : EYE); })
                .icon(showKey ? EYE_OFF : EYE));
    }

    /** Model row: a preset dropdown for the provider's known models, or a free-text box (custom mode)
     *  with a "▾" toggle back to presets. A custom provider (openai-compatible) is always free-text. */
    private void buildModelRow(int x, int y, int w) {
        ModelRegistry.Provider mp = ModelRegistry.provider(LlmProviders.normalize(providerDropdown.selectedId()));
        boolean providerCustom = mp != null && mp.custom();
        if (customModel || providerCustom) {
            customModel = true;
            modelDropdown = null;
            modelInput = field(x, y, providerCustom ? w : w - 20, 128, wModel);
            if (!providerCustom) {     // a way back to the preset list (custom providers have none)
                add(new SimpleButton(x + w - 18, y, 18, 18, class_2561.method_43470("▾"),
                        b -> { preserveKeyUrl(); customModel = false; rebuild(); }));
            }
        } else {
            modelInput = null;
            boolean known = mp != null && mp.models().stream().anyMatch(m -> m.id().equals(wModel));
            String sel = known ? wModel
                    : (mp != null && !mp.models().isEmpty() ? mp.models().get(0).id() : CUSTOM_MODEL);
            modelDropdown = new Dropdown(modelItems(mp), sel);
            modelDropdown.setBounds(x, y, w, 18);
        }
    }

    private List<Dropdown.Item> modelItems(ModelRegistry.Provider mp) {
        List<Dropdown.Item> items = new ArrayList<>();
        if (mp != null) for (ModelRegistry.Model m : mp.models()) items.add(new Dropdown.Item(m.id(), m.id()));
        items.add(new Dropdown.Item(CUSTOM_MODEL, class_1074.method_4662("numen.settings.custom_model")));
        return items;
    }

    /** Shadowless placeholder for an empty, unfocused field — the EditBox's own hint renders with a shadow. */
    private void placeholder(class_332 g, class_342 f, String text) {
        if (f != null && f.method_1882().isEmpty() && !f.method_25370() && text != null && !text.isEmpty()) {
            txt(g, class_2561.method_43470(text), f.method_46426(), f.method_46427(), TXT_FAINT);
        }
    }

    private class_342 field(int x, int y, int w, int max, String value) {
        class_342 e = new FlatEditBox(field_22793, x + FIELD_INSET_X, y + FIELD_INSET_Y,
                w - FIELD_INSET_X * 2, 18 - FIELD_INSET_Y * 2, class_2561.method_43470(""));
        e.method_1880(max);
        e.method_1852(value == null ? "" : value);
        e.method_1858(false);
        e.method_1868(TXT);
        add(e);
        return e;
    }

    private void onSaveSettings() {
        INumenConfig cfg = Services.CONFIG;
        if (addingSite) {                          // create a new user site, then select it
            String name = siteNameInput.method_1882().trim();
            String url = baseUrlInput.method_1882().trim();
            String mdl = modelInput.method_1882().trim();
            if (name.isEmpty() || url.isEmpty()) { warnUntil = System.currentTimeMillis() + 4000; return; }
            String id = ModelRegistry.addCustomSite(name, url, mdl);
            if (id == null) { warnUntil = System.currentTimeMillis() + 4000; return; }
            cfg.setProvider(id);
            cfg.setModel(mdl);
            cfg.setApiKey(apiKeyInput.method_1882());
            cfg.setBaseUrl("");                    // site carries the URL now
            cfg.setProxy(wProxy);
            cfg.save();
            NumenLlmClient.reset();
            addingSite = false;
            wProvider = id; wModel = mdl; wBaseUrl = ""; customModel = false;
            rebuild();
            savedFlashUntil = System.currentTimeMillis() + 1500;
            return;
        }
        cfg.setProvider(providerDropdown.selectedId());
        cfg.setApiKey(apiKeyInput.method_1882());
        String model = customModel
                ? (modelInput != null ? modelInput.method_1882().trim() : "")
                : (modelDropdown != null && !CUSTOM_MODEL.equals(modelDropdown.selectedId())
                        ? modelDropdown.selectedId() : "");
        cfg.setModel(model);
        cfg.setBaseUrl(baseUrlInput.method_1882());
        cfg.setProxy(proxyInput == null ? wProxy : proxyInput.method_1882());
        cfg.setReasoningEffort(wReasoning);
        cfg.save();
        NumenLlmClient.reset();
        savedFlashUntil = System.currentTimeMillis() + 1500;
    }

    // ---- reasoning / thinking effort control ----

    private static final String[] REASONING_LEVELS = {"auto", "low", "medium", "high"};

    /** Coerce any stored value to one of {@link #REASONING_LEVELS} ("auto" = leave to backend default). */
    private static String normalizeReasoning(String v) {
        if (v == null) return "auto";
        String s = v.trim().toLowerCase();
        for (String lvl : REASONING_LEVELS) if (lvl.equals(s)) return lvl;
        return "auto";
    }

    /** Advance the working reasoning level auto → low → medium → high → auto. Saved with the rest on Save. */
    private void cycleReasoning() {
        String cur = normalizeReasoning(wReasoning);
        for (int i = 0; i < REASONING_LEVELS.length; i++) {
            if (REASONING_LEVELS[i].equals(cur)) {
                wReasoning = REASONING_LEVELS[(i + 1) % REASONING_LEVELS.length];
                return;
            }
        }
        wReasoning = "auto";
    }

    private class_2561 reasoningLabel() {
        return class_2561.method_43469("numen.settings.reasoning",
                class_1074.method_4662("numen.settings.reasoning." + normalizeReasoning(wReasoning)));
    }

    private void renderSettings(class_332 g, int mouseX, int mouseY) {
        renderSettingsNav(g);
        switch (settingsSection) {
            case MCP -> renderMcpSection(g, mouseX, mouseY);
            case SKILLS -> renderSkillsSection(g, mouseX, mouseY);
            case PERSONA -> renderPersonaSection(g, mouseX, mouseY);
            case PROVIDER -> renderProviderSection(g, mouseX, mouseY);
        }
    }

    private void renderProviderSection(class_332 g, int mouseX, int mouseY) {
        int x = secX(), w = secW();
        txt(g, class_2561.method_43470("提供商配置"), x, secY0() - 2, TXT);
        if (providerDeletePending != null) {
            var e = com.dwinovo.numen.agent.llm.ProviderLibrary.instance().get(providerDeletePending);
            txt(g, class_2561.method_43470("删除「" + (e != null ? e.name() : "") + "」?正在使用它的同伴将无法对话,直到重新绑定。"),
                    x, secY0() + 10, TXT);
            return;
        }
        if (addingProvider) { renderProviderForm(g); return; }
        // Global proxy row lives in the bottom band (built in buildProviderListWidgets).
        txt(g, class_2561.method_43470("代理(全局,host:port,可空)"), x, top + PANEL_H - PAD - 29, TXT_MUTED);
        if (savedFlashUntil > System.currentTimeMillis()) {
            txt(g, class_2561.method_43471("numen.settings.saved"), x, top + PANEL_H - PAD - 40, OK);
        }
        var list = com.dwinovo.numen.agent.llm.ProviderLibrary.instance().list();
        if (list.isEmpty()) {
            txt(g, class_2561.method_43470("还没有提供商配置——点右上「新建」创建一条"), x, secY0() + 16, TXT_FAINT);
            return;
        }
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        settingsScroll = Math.clamp(settingsScroll, 0, Math.max(0, list.size() - visible));
        for (int i = settingsScroll; i < list.size(); i++) {
            int ry = listY0 + (i - settingsScroll) * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            var e = list.get(i);
            int delX = x + w - 12, editX = x + w - 26;
            txt(g, class_2561.method_43470(e.name()), x, ry + 1, TXT);
            String meta = (nb(e.provider()) ? e.provider() : "?") + " · "
                    + (nb(e.model()) ? e.model() : "?")
                    + (nb(e.apiKey()) ? "" : " · 未填Key");
            txt(g, class_2561.method_43470(clip(meta, w - 30)), x, ry + 11, nb(e.apiKey()) ? TXT_FAINT : FAIL);
            txt(g, class_2561.method_43470("✎"), editX, ry + 6,
                    overDelete(mouseX, mouseY, editX, ry) ? CTA : TXT_FAINT);
            txt(g, class_2561.method_43470("✕"), delX, ry + 6,
                    overDelete(mouseX, mouseY, delX, ry) ? FAIL : TXT_FAINT);
        }
    }

    private void renderProviderForm(class_332 g) {
        int x = secX();
        int fy = secY0();
        txt(g, class_2561.method_43470("名称(必填)"), x, fy, TXT_MUTED);
        txt(g, class_2561.method_43470("服务商(如 openai / deepseek,可后补)"), x, fy + SET_SP, TXT_MUTED);
        txt(g, class_2561.method_43470("模型"), x, fy + 2 * SET_SP, TXT_MUTED);
        txt(g, class_2561.method_43470("API Key"), x, fy + 3 * SET_SP, TXT_MUTED);
        txt(g, class_2561.method_43470("Base URL(可选)"), x, fy + 4 * SET_SP, TXT_MUTED);
    }

    private static boolean nb(String s) {
        return s != null && !s.isBlank();
    }

    private boolean providerClick(int mx, int my) {
        if (addingProvider || providerDeletePending != null) return false;
        int x = secX(), w = secW();
        var list = com.dwinovo.numen.agent.llm.ProviderLibrary.instance().list();
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        int scroll = Math.clamp(settingsScroll, 0, Math.max(0, list.size() - visible));
        for (int i = scroll; i < list.size(); i++) {
            int ry = listY0 + (i - scroll) * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            var e = list.get(i);
            int delX = x + w - 12, editX = x + w - 26;
            if (overDelete(mx, my, editX, ry)) { beginEditProvider(e); return true; }
            if (overDelete(mx, my, delX, ry)) { providerDeletePending = e.id(); rebuild(); return true; }
            if (overRow(mx, my, x, w, ry)) { beginEditProvider(e); return true; }
        }
        return false;
    }

    private void beginEditProvider(com.dwinovo.numen.agent.llm.ProviderLibrary.Entry e) {
        addingProvider = true;
        providerEditId = e.id();
        wProvName = e.name() == null ? "" : e.name();
        wProvProvider = e.provider() == null ? "" : e.provider();
        wProvModel = e.model() == null ? "" : e.model();
        wProvKey = e.apiKey() == null ? "" : e.apiKey();
        wProvBaseUrl = e.baseUrl() == null ? "" : e.baseUrl();
        rebuild();
    }

    /** The config-hub left sub-nav: 模型接入 / MCP / 技能, plus the divider. */
    private void renderSettingsNav(class_332 g) {
        String[] labels = {
                "提供商", class_1074.method_4662("numen.settings.nav.mcp"),
                class_1074.method_4662("numen.settings.nav.skills"), class_1074.method_4662("numen.settings.nav.persona")};
        int navX = left + PAD;
        int y = secY0();
        for (int i = 0; i < labels.length; i++) {
            boolean active = settingsSection == SettingsSection.values()[i];
            int ry = y + i * NAV_SP;
            if (active) {
                g.method_25294(navX - 2, ry - 3, navX - 1, ry + NAV_SP - 5, ACCENT);   // gold left bar
                txt(g, class_2561.method_43470(labels[i]), navX + 3, ry, TXT);
            } else {
                txt(g, class_2561.method_43470(labels[i]), navX + 3, ry, TXT_MUTED);
            }
        }
        int dx = left + PAD + NAV_W + 3;
        g.method_25294(dx, secY0() - 2, dx + 1, secBottom(), BORDER);   // vertical divider
    }

    private void renderLlmSettings(class_332 g) {
        int x = secX();
        int y0 = secY0();
        if (addingSite) {
            txt(g, class_2561.method_43471("numen.settings.site_name"), x, y0, TXT_MUTED);
            txt(g, class_2561.method_43471("numen.gui.settings.api_key"), x, y0 + SET_SP, TXT_MUTED);
            txt(g, class_2561.method_43471("numen.gui.settings.model"), x, y0 + 2 * SET_SP, TXT_MUTED);
            txt(g, class_2561.method_43471("numen.settings.base_url"), x, y0 + 3 * SET_SP, TXT_MUTED);
        } else {
            txt(g, class_2561.method_43471("numen.gui.settings.provider"), x, y0, TXT_MUTED);
            txt(g, class_2561.method_43471("numen.gui.settings.api_key"), x, y0 + SET_SP, TXT_MUTED);
            txt(g, class_2561.method_43471("numen.gui.settings.model"), x, y0 + 2 * SET_SP, TXT_MUTED);
            txt(g, class_2561.method_43471("numen.settings.base_url"), x, y0 + 3 * SET_SP, TXT_MUTED);
            txt(g, class_2561.method_43471("numen.settings.proxy"), x, y0 + 4 * SET_SP, TXT_MUTED);
        }
        if (savedFlashUntil > System.currentTimeMillis()) {
            txt(g, class_2561.method_43471("numen.settings.saved"), x, top + PANEL_H - PAD - 14, OK);
        }
        // the dropdowns themselves render in render, AFTER the widgets (open list on top)
    }

    // ---- MCP section: external server list with a live on/off switch per row ----

    private void renderMcpSection(class_332 g, int mouseX, int mouseY) {
        int x = secX(), w = secW();
        txt(g, class_2561.method_43471("numen.mcp.title"), x, secY0() - 2, TXT);
        if (mcpDeletePending != null) {
            txt(g, class_2561.method_43469("numen.mcp.delete_confirm", mcpDeletePending), x, secY0() + 10, TXT);
            return;
        }
        if (addingMcp) { renderMcpForm(g); return; }
        var servers = com.dwinovo.numen.mcp.client.McpClientManager.servers();
        if (servers.isEmpty()) {
            txt(g, class_2561.method_43471("numen.mcp.empty"), x, secY0() + 16, TXT_FAINT);
            return;
        }
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        settingsScroll = Math.clamp(settingsScroll, 0, Math.max(0, servers.size() - visible));
        for (int i = settingsScroll; i < servers.size(); i++) {
            int row = i - settingsScroll;
            int ry = listY0 + row * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            var h = servers.get(i);
            int togX = x + w - 34, delX = x + w - 12;
            // status dot
            int dy = ry + 3;
            g.method_25294(x, dy, x + 5, dy + 5, mcpDotColor(h.status()));
            Nb.border(g, x, dy, 5, 5, 1, BORDER);
            // name + meta line
            txt(g, class_2561.method_43470(h.name()), x + 10, ry + 1, TXT);
            txt(g, class_2561.method_43470(mcpMeta(h)), x + 10, ry + 11, TXT_FAINT);
            // toggle + delete, right-aligned
            drawToggle(g, togX, ry + 5, h.toggledOn());
            boolean overDel = overDelete(mouseX, mouseY, delX, ry);
            txt(g, class_2561.method_43470("✕"), delX, ry + 6, overDel ? FAIL : TXT_FAINT);
            // hover tooltip: tool names + url/command + any error (not over a control)
            if (overRow(mouseX, mouseY, x, w, ry) && !overToggle(mouseX, mouseY, togX, ry + 5) && !overDel) {
                pendingTip = mcpTooltip(h);
                pendingTipX = mouseX;
                pendingTipY = mouseY;
            }
        }
    }

    /** Add-server form labels + placeholders (fields/buttons are widgets, drawn in the overlay pass). */
    private void renderMcpForm(class_332 g) {
        int x = secX();
        int fy = secY0() + 14;   // matches buildMcpForm
        txt(g, class_2561.method_43471("numen.mcp.form_name"), x, fy, TXT_MUTED);
        // the type row is the self-labelled toggle button (no separate label)
        txt(g, class_2561.method_43471(mcpStdio ? "numen.mcp.form_command" : "numen.mcp.form_url"),
                x, fy + 56, TXT_MUTED);
        txt(g, class_2561.method_43471(mcpStdio ? "numen.mcp.form_env" : "numen.mcp.form_header"), x, fy + 89, TXT_MUTED);
        // field placeholders are drawn in the post-widget pass (see render), so they sit above the frames
    }

    private boolean overDelete(int mx, int my, int delX, int ry) {
        return mx >= delX - 2 && mx < delX + 9 && my >= ry + 2 && my < ry + LIST_ROW - 2;
    }

    private int mcpDotColor(com.dwinovo.numen.mcp.client.McpClientManager.Status s) {
        return switch (s) {
            case CONNECTED -> OK;
            case CONNECTING -> RUN;
            case FAILED -> FAIL;
            case DISABLED -> TXT_FAINT;
        };
    }

    private String mcpMeta(com.dwinovo.numen.mcp.client.McpClientManager.ServerHandle h) {
        return switch (h.status()) {
            case CONNECTED -> class_1074.method_4662("numen.mcp.connected", h.type(), h.toolCount());
            case CONNECTING -> class_1074.method_4662("numen.mcp.connecting", h.type());
            case FAILED -> class_1074.method_4662("numen.mcp.failed", h.type());
            case DISABLED -> class_1074.method_4662("numen.mcp.disabled", h.type());
        };
    }

    private List<class_2561> mcpTooltip(com.dwinovo.numen.mcp.client.McpClientManager.ServerHandle h) {
        List<class_2561> lines = new ArrayList<>();
        lines.add(class_2561.method_43470(h.name()));
        var spec = com.dwinovo.numen.mcp.client.McpClientManager.spec(h.name());
        if (spec != null) {
            lines.add(Nb.colored(spec.isStdio() ? spec.command() : spec.url(), TXT_FAINT));
        }
        if (h.status() == com.dwinovo.numen.mcp.client.McpClientManager.Status.FAILED && !h.error().isBlank()) {
            lines.add(Nb.colored(h.error(), FAIL));
        } else if (!h.toolNames().isEmpty()) {
            lines.add(Nb.colored(String.join(", ", h.toolNames()), TXT_MUTED));
        }
        return lines;
    }

    // ---- Skills section: skill list with a live on/off switch per row ----

    private void renderSkillsSection(class_332 g, int mouseX, int mouseY) {
        int x = secX(), w = secW();
        txt(g, class_2561.method_43471("numen.skill.title"), x, secY0() - 2, TXT);
        var skills = new ArrayList<>(com.dwinovo.numen.agent.skill.SkillRegistry.instance().all());
        if (skills.isEmpty()) {
            txt(g, class_2561.method_43471("numen.skill.empty"), x, secY0() + 16, TXT_FAINT);
            return;
        }
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        settingsScroll = Math.clamp(settingsScroll, 0, Math.max(0, skills.size() - visible));
        for (int i = settingsScroll; i < skills.size(); i++) {
            int row = i - settingsScroll;
            int ry = listY0 + row * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            var s = skills.get(i);
            boolean on = !com.dwinovo.numen.agent.skill.SkillRegistry.instance().isDisabled(s.name());
            txt(g, class_2561.method_43470(s.name()), x, ry + 1, on ? TXT : TXT_FAINT);
            String desc = s.description() == null ? class_1074.method_4662("numen.skill.no_desc") : s.description();
            txt(g, class_2561.method_43470(clip(desc, w - 26)), x, ry + 11, TXT_FAINT);
            drawToggle(g, x + w - 20, ry + 5, on);
            if (overRow(mouseX, mouseY, x, w, ry) && !overToggle(mouseX, mouseY, x + w - 20, ry + 5)
                    && s.description() != null) {
                pendingTip = List.of(class_2561.method_43470(s.name()), Nb.colored(s.description(), TXT_MUTED));
                pendingTipX = mouseX;
                pendingTipY = mouseY;
            }
        }
    }

    private static final java.util.regex.Pattern QUERY_PAT =
            java.util.regex.Pattern.compile("(?s)<query>(.*?)</query>");

    /**
     * The owner's own words from a user message, for display. New messages wrap the owner's text in
     * {@code <query>…</query>} (see {@code EntityAgentLoop.submitPrompt}), so we show only that; legacy
     * untagged messages fall back to the raw text with injected directives stripped. Display-only — the
     * LLM still receives the full user message.
     */
    private static String ownerText(String s) {
        if (s == null) return "";
        java.util.regex.Matcher m = QUERY_PAT.matcher(s);
        StringBuilder b = new StringBuilder();
        while (m.find()) {
            if (b.length() > 0) b.append('\n');
            b.append(m.group(1));
        }
        if (b.length() > 0) return b.toString().strip();
        return stripInjectedDirectives(s);   // legacy / untagged owner message
    }

    /**
     * Strip numen-injected directive blocks ({@code <persona-change>…</persona-change>},
     * {@code <event …>…</event>}) from a user message so only the owner's own words show in chat.
     * The full message (directives included) is still what the LLM receives — this is display-only.
     */
    private static String stripInjectedDirectives(String s) {
        if (s == null) return "";
        String out = s.replaceAll("(?s)<persona-change>.*?</persona-change>", "")
                .replaceAll("(?s)<event\\b[^>]*>.*?</event>", "")
                .replaceAll("(?s)<event\\b[^>]*/>", "");
        return out.strip();
    }

    /** Truncate {@code s} with an ellipsis so it fits in {@code maxW} px. */
    private String clip(String s, int maxW) {
        if (field_22793.method_1727(s) <= maxW) return s;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (field_22793.method_1727(b.toString() + s.charAt(i) + "…") > maxW) break;
            b.append(s.charAt(i));
        }
        return b + "…";
    }

    // ---- shared toggle switch (no vanilla widget for this) ----

    private static final int TOG_W = 18, TOG_H = 10;

    private void drawToggle(class_332 g, int x, int y, boolean on) {
        g.method_25294(x, y, x + TOG_W, y + TOG_H, on ? CTA : FIELD);
        Nb.border(g, x, y, TOG_W, TOG_H, 1, BORDER);
        int knobX = on ? x + TOG_W - 8 : x + 1;
        g.method_25294(knobX, y + 1, knobX + 7, y + TOG_H - 1, ON_CTA);
    }

    private boolean overToggle(int mx, int my, int x, int y) {
        return mx >= x && mx < x + TOG_W && my >= y && my < y + TOG_H;
    }

    private boolean overRow(int mx, int my, int x, int w, int ry) {
        return mx >= x && mx < x + w && my >= ry && my < ry + LIST_ROW;
    }

    /** Settings-tab clicks: the sub-nav column, then per-row toggles in the MCP / skill lists. */
    private boolean settingsClickedAt(double mxd, double myd) {
        int mx = (int) mxd, my = (int) myd;
        int navX = left + PAD, y = secY0();
        if (mx >= navX && mx < navX + NAV_W) {
            for (int i = 0; i < SettingsSection.values().length; i++) {
                int ry = y + i * NAV_SP;
                if (my >= ry - 3 && my < ry + NAV_SP - 5) {
                    selectSection(SettingsSection.values()[i]);
                    return true;
                }
            }
        }
        if (settingsSection == SettingsSection.MCP) return mcpToggleClick(mx, my);
        if (settingsSection == SettingsSection.SKILLS) return skillToggleClick(mx, my);
        if (settingsSection == SettingsSection.PERSONA) return personaClick(mx, my);
        if (settingsSection == SettingsSection.PROVIDER) return providerClick(mx, my);
        return false;
    }

    private boolean mcpToggleClick(int mx, int my) {
        if (addingMcp || mcpDeletePending != null) return false;   // form / confirm widgets handle clicks
        int x = secX(), w = secW();
        var servers = com.dwinovo.numen.mcp.client.McpClientManager.servers();
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        int scroll = Math.clamp(settingsScroll, 0, Math.max(0, servers.size() - visible));
        for (int i = scroll; i < servers.size(); i++) {
            int ry = listY0 + (i - scroll) * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            int togX = x + w - 34, delX = x + w - 12;
            var h = servers.get(i);
            if (overToggle(mx, my, togX, ry + 5)) {
                var st = h.status();
                // CONNECTED / CONNECTING → turn off; DISABLED / FAILED → (re)connect (retry a failed one)
                if (st == com.dwinovo.numen.mcp.client.McpClientManager.Status.CONNECTED
                        || st == com.dwinovo.numen.mcp.client.McpClientManager.Status.CONNECTING) {
                    com.dwinovo.numen.mcp.client.McpClientManager.disableServer(h.name());
                } else {
                    com.dwinovo.numen.mcp.client.McpClientManager.enableServer(h.name());
                }
                return true;
            }
            if (overDelete(mx, my, delX, ry)) {
                mcpDeletePending = h.name();   // ask first — deletion is confirmed via the bar
                rebuild();
                return true;
            }
            if (overRow(mx, my, x, w, ry)) {   // body (name/meta) click → edit this server
                beginEditMcp(h.name());
                return true;
            }
        }
        return false;
    }

    /** Open the add-form PRE-FILLED with {@code name}'s current spec — saving REPLACES the entry. */
    private void beginEditMcp(String name) {
        var spec = com.dwinovo.numen.mcp.client.McpClientManager.spec(name);
        if (spec == null) return;
        mcpEditOriginal = name;
        addingMcp = true;
        mcpStdio = spec.isStdio();
        wMcpName = spec.name();
        if (mcpStdio) {
            StringBuilder cmd = new StringBuilder(spec.command() == null ? "" : spec.command());
            for (String a : spec.args()) cmd.append(' ').append(a);
            wMcpTarget = cmd.toString().trim();
            wMcpHeader = joinPairs(spec.env(), '=');       // stdio → env "KEY=value"
        } else {
            wMcpTarget = spec.url() == null ? "" : spec.url();
            wMcpHeader = joinPairs(spec.headers(), ':');    // http → header "Name: Value"
        }
        rebuild();
    }

    /** Reconstruct the header/env editor line from a spec map ("K: V; K2: V2" or "K=V; K2=V2"). */
    private static String joinPairs(java.util.Map<String, String> m, char sep) {
        if (m == null || m.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        for (var e : m.entrySet()) {
            if (b.length() > 0) b.append("; ");
            b.append(e.getKey()).append(sep == ':' ? ": " : "=").append(e.getValue());
        }
        return b.toString();
    }

    // ---- Persona section render + hit-test ----

    private void renderPersonaSection(class_332 g, int mouseX, int mouseY) {
        int x = secX(), w = secW();
        txt(g, class_2561.method_43471("numen.persona.title"), x, secY0() - 2, TXT);
        if (personaDeletePending != null) {
            PersonaLibrary.Persona p = PersonaLibrary.instance().get(personaDeletePending);
            txt(g, class_2561.method_43469("numen.persona.delete_confirm", p != null ? p.name() : ""),
                    x, secY0() + 10, TXT);
            return;
        }
        if (addingPersona) { renderPersonaForm(g); return; }
        var list = PersonaLibrary.instance().list();
        if (list.isEmpty()) {
            txt(g, class_2561.method_43471("numen.persona.empty"), x, secY0() + 16, TXT_FAINT);
            return;
        }
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        settingsScroll = Math.clamp(settingsScroll, 0, Math.max(0, list.size() - visible));
        for (int i = settingsScroll; i < list.size(); i++) {
            int ry = listY0 + (i - settingsScroll) * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            PersonaLibrary.Persona p = list.get(i);
            int delX = x + w - 12, editX = x + w - 26;
            txt(g, class_2561.method_43470(p.name()), x, ry + 1, TXT);
            String badge = p.preset() ? class_1074.method_4662("numen.persona.preset_badge") + " · " : "";
            txt(g, class_2561.method_43470(clip(badge + p.text(), w - 30)), x, ry + 11, TXT_FAINT);
            if (p.preset()) {
                txt(g, class_2561.method_43470("⧉"), delX, ry + 6,
                        overDelete(mouseX, mouseY, delX, ry) ? CTA : TXT_FAINT);
            } else {
                txt(g, class_2561.method_43470("✎"), editX, ry + 6,
                        overDelete(mouseX, mouseY, editX, ry) ? CTA : TXT_FAINT);
                txt(g, class_2561.method_43470("✕"), delX, ry + 6,
                        overDelete(mouseX, mouseY, delX, ry) ? FAIL : TXT_FAINT);
            }
        }
    }

    private void renderPersonaForm(class_332 g) {
        int x = secX();
        int fy = secY0() + 14;
        txt(g, class_2561.method_43471("numen.persona.form_name"), x, fy, TXT_MUTED);
        txt(g, class_2561.method_43471("numen.persona.form_text"), x, fy + 33, TXT_MUTED);
    }

    /** The active companion's current persona name (green marker in the list), or null. */
    private String activePersonaName() {
        if (uuid == null) return null;
        return AgentLoopRegistry.get(uuid).map(EntityAgentLoop::personaName).orElse(null);
    }

    private boolean personaClick(int mx, int my) {
        if (addingPersona || personaDeletePending != null) return false;
        int x = secX(), w = secW();
        var lib = PersonaLibrary.instance();
        var list = lib.list();
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        int scroll = Math.clamp(settingsScroll, 0, Math.max(0, list.size() - visible));
        for (int i = scroll; i < list.size(); i++) {
            int ry = listY0 + (i - scroll) * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            PersonaLibrary.Persona p = list.get(i);
            int delX = x + w - 12, editX = x + w - 26;
            if (p.preset()) {
                if (overDelete(mx, my, delX, ry)) { lib.clonePersona(p.id()); rebuild(); return true; }
            } else {
                if (overDelete(mx, my, editX, ry)) { beginEditPersona(p); return true; }
                if (overDelete(mx, my, delX, ry)) { personaDeletePending = p.id(); rebuild(); return true; }
                if (overRow(mx, my, x, w, ry)) { beginEditPersona(p); return true; }   // body → edit a custom persona
            }
        }
        return false;
    }

    private void beginEditPersona(PersonaLibrary.Persona p) {
        addingPersona = true;
        personaEditId = p.id();
        wPersonaName = p.name();
        wPersonaText = p.text();
        rebuild();
    }

    private boolean skillToggleClick(int mx, int my) {
        int x = secX(), w = secW();
        var reg = com.dwinovo.numen.agent.skill.SkillRegistry.instance();
        var skills = new ArrayList<>(reg.all());
        int listY0 = secY0() + 14;
        int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
        int scroll = Math.clamp(settingsScroll, 0, Math.max(0, skills.size() - visible));
        for (int i = scroll; i < skills.size(); i++) {
            int ry = listY0 + (i - scroll) * LIST_ROW;
            if (ry + LIST_ROW > secBottom()) break;
            if (overToggle(mx, my, x + w - 20, ry + 5)) {
                String n = skills.get(i).name();
                reg.setEnabled(n, reg.isDisabled(n));   // flip
                return true;
            }
        }
        return false;
    }

    @Override
    public void method_25393() {
        if (tab == Tab.ITEMS && ++tickCounter % INV_REFRESH_TICKS == 0) {
            requestInventory();
        }
    }

    private void requestInventory() {
        // No companion selected (empty roster / hotkey-opened blank panel) → nothing to fetch.
        // The payload's UUID stream-codec can't encode null, so this guard also prevents a crash.
        if (uuid == null) return;
        if (class_310.method_1551().method_1562() != null) {
            Services.NETWORK.sendToServer(new RequestInventoryPayload(uuid));
        }
    }

    private void onSend() {
        if (input == null) return;
        String text = input.method_1882() == null ? "" : input.method_1882().trim();
        if (text.isEmpty()) return;
        // Endpoint check for THIS companion (its provider entry, not the legacy global
        // key): unbound / keyless surfaces as a visible hint, never a crash or a
        // silent no-op — the no-provider safety net.
        String problem = loop().endpointProblem();
        if (problem != null) {
            com.dwinovo.numen.Constants.LOG.warn("[numen-chat] {}", problem);
            warnText = problem;
            warnUntil = System.currentTimeMillis() + 4000;
            return;
        }
        loop().submitPrompt(text);
        input.method_1852("");
        pinBottom = true;
    }

    // ---- input ----

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        int k = keyCode;
        if (dismissPending != null) {
            if (k == 256) { dismissPending = null; rebuild(); return true; }   // Esc cancels the confirm
            return super.method_25404(keyCode, scanCode, modifiers);
        }
        if (summoning) {
            if (k == 257 || k == 335) { doSummon(); return true; }    // Enter
            if (k == 256) { summoning = false; rebuild(); return true; } // Esc cancels (doesn't close panel)
            return super.method_25404(keyCode, scanCode, modifiers);
        }
        if ((k == 257 || k == 335) && input != null && input.method_25370()) {
            onSend();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private void doSummon() {
        String n = summonInput == null ? "" : summonInput.method_1882().trim();
        if (n.isEmpty()) return;
        // A provider entry is REQUIRED — with an empty library there is nothing to
        // select and creation stays blocked (the panel points at 设置 → 提供商).
        if (summonProviderId == null) return;
        // Remember the picks by name; CompanionListPayload applies them when the new companion arrives.
        if (summonPersonaId != null) com.dwinovo.numen.persona.PersonaLibrary.pendSummon(n, summonPersonaId);
        com.dwinovo.numen.agent.llm.ProviderLibrary.pendSummon(n, summonProviderId);
        Services.NETWORK.sendToServer(new com.dwinovo.numen.network.payload.SummonRequestPayload(n));
        summoning = false;
        summonPersonaId = null;
        summonProviderId = null;
        rebuild();   // the new companion arrives via CompanionListPayload — click its avatar to open
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (dismissPending != null) {
            return super.method_25402(mouseX, mouseY, button);   // modal confirm — let its Cancel/Delete buttons handle it
        }
        if (button == 0) {
            // Summon dropdowns get first pick (their open lists overlay the panel).
            if (summoning && summonPersonaDropdown != null && summonPersonaDropdown.mouseClicked(mouseX, mouseY)) {
                String sel = summonPersonaDropdown.selectedId();
                summonPersonaId = PERSONA_DEFAULT.equals(sel) ? null : sel;
                return true;
            }
            if (summoning && summonProviderDropdown != null && summonProviderDropdown.mouseClicked(mouseX, mouseY)) {
                summonProviderId = summonProviderDropdown.selectedId();
                return true;
            }
            UUID close = railCloseAt((int) mouseX, (int) mouseY);
            if (close != null) { dismissPending = close; rebuild(); return true; }   // ✕ → confirm bar
            if (railPlusAt((int) mouseX, (int) mouseY)) {   // + → start the summon name prompt
                summoning = !summoning;
                if (summoning) summonPersonaId = null;   // fresh summon starts at "默认"
                rebuild();
                return true;
            }
            int rail = railIndexAt((int) mouseX, (int) mouseY);
            if (rail >= 0) {
                List<NumenRoster.Entry> entries = NumenRoster.instance().entries();
                if (rail < entries.size()) {
                    boolean wasSummoning = summoning;
                    summoning = false;
                    NumenRoster.Entry e = entries.get(rail);
                    if (e.uuid().equals(uuid)) { if (wasSummoning) rebuild(); }   // already active — just exit summon
                    else switchTo(e.uuid(), e.name());
                }
                return true;
            }
            if (tab == Tab.SETTINGS && providerDropdown != null) {
                String before = providerDropdown.selectedId();
                if (providerDropdown.mouseClicked(mouseX, mouseY)) {
                    if (modelDropdown != null) modelDropdown.close();
                    String sel = providerDropdown.selectedId();
                    if (ProviderDropdown.ADD_SITE.equals(sel)) {            // "+ 添加站点" → add-site editor
                        preserveKeyUrl();
                        addingSite = true; wSiteName = ""; wBaseUrl = ""; wModel = "";
                        rebuild();
                    } else if (!sel.equals(before)) {                      // provider changed → reset model
                        preserveKeyUrl();
                        wProvider = sel;
                        ModelRegistry.Provider mp = ModelRegistry.provider(LlmProviders.normalize(wProvider));
                        customModel = mp != null && mp.custom();
                        wModel = (mp != null && !mp.models().isEmpty()) ? mp.models().get(0).id() : "";
                        rebuild();
                    }
                    return true;
                }
            }
            if (tab == Tab.SETTINGS && modelDropdown != null
                    && modelDropdown.mouseClicked(mouseX, mouseY)) {
                providerDropdown.close();
                if (CUSTOM_MODEL.equals(modelDropdown.selectedId())) {       // "自定义…" → free-text box
                    preserveKeyUrl();
                    customModel = true;
                    wModel = "";
                    rebuild();
                }
                return true;
            }
            if (tab == Tab.SETTINGS && settingsClickedAt(mouseX, mouseY)) return true;
            int my = (int) mouseY;
            if (my >= top && my < top + HEADER_H) {
                for (int i = 0; i < 3; i++) {
                    if (mouseX >= tabX[i] && mouseX < tabX[i] + tabW[i]) {
                        selectTab(Tab.values()[i]);
                        return true;
                    }
                }
            }
            if (tab == Tab.CHAT && toggleFoldAt((int) mouseX, my)) return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    /** If a chat fold-toggle row sits under (mx,my), flip its expanded state. Mirrors renderChat geometry. */
    private boolean toggleFoldAt(int mx, int my) {
        int bodyY = top + HEADER_H + 4;
        int bodyBottom = top + PANEL_H - INPUT_H - PAD - 6;
        int transX = left + PAD;
        int transW = PANEL_W - PAD * 2 - PLAN_W - 8;
        if (mx < transX || mx >= transX + transW || my < bodyY || my >= bodyBottom) return false;
        List<Row> rows = buildRows(transW);
        int idx = (my - (bodyY - scroll)) / LINE_H;
        if (idx < 0 || idx >= rows.size()) return false;
        String key = rows.get(idx).foldKey();
        if (key == null) return false;
        if (!expandedGroups.add(key)) expandedGroups.remove(key);   // toggle open/closed
        return true;
    }

    @Override
    public boolean method_25401(double mx, double my, double sx, double sy) {
        // Wheel over the left rail column scrolls the roster (works on any tab).
        if (sy != 0 && mx >= railX && mx < railX + RAIL_W && maxRailScroll() > 0) {
            railScroll = Math.clamp((long) (railScroll - sy), 0, maxRailScroll());
            return true;
        }
        if (tab == Tab.CHAT && sy != 0) {
            scroll = Math.clamp((long) (scroll - sy * LINE_H * 3), 0, lastMaxScroll);
            pinBottom = scroll >= lastMaxScroll;
            return true;
        }
        if (tab == Tab.SETTINGS && sy != 0 && !addingPersona && !addingProvider) {
            int count = switch (settingsSection) {
                case MCP -> com.dwinovo.numen.mcp.client.McpClientManager.servers().size();
                case SKILLS -> com.dwinovo.numen.agent.skill.SkillRegistry.instance().size();
                case PERSONA -> PersonaLibrary.instance().list().size();
                case PROVIDER -> com.dwinovo.numen.agent.llm.ProviderLibrary.instance().list().size();
                default -> 0;
            };
            int listY0 = secY0() + 14;
            int visible = Math.max(1, (secBottom() - listY0) / LIST_ROW);
            settingsScroll = Math.clamp((long) (settingsScroll - sy), 0, Math.max(0, count - visible));
            return true;
        }
        return super.method_25401(mx, my, sx, sy);
    }

    // ---- render ----

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partial) {
        super.method_25394(g, mouseX, mouseY, partial);
        pendingTip = null;   // recollected each frame by the section renderers

        // ONE merged Cottage sprite: left rail column + panel, continuous header, no gap.
        g.method_52706(
                WORKSPACE_SPRITE, railX, top, RAIL_W + PANEL_W, PANEL_H);
        renderRail(g, mouseX, mouseY);   // avatars + status + summon tile on the rail column

        txt(g, class_2561.method_43470(name == null ? "Numen" : name), left + PAD, top + 7, ON_BAND);
        int afterName = left + PAD + field_22793.method_1727(name == null ? "Numen" : name) + 6;
        if (uuid != null && ClientDeaths.isDead(uuid)) {        // active companion dead — respawn countdown
            long rem = ClientDeaths.remainingMs(uuid);
            txt(g, class_2561.method_43469("numen.respawn", (int) Math.ceil(rem / 1000.0)), afterName, top + 7, ON_BAND);
        } else {
            String pn = activePersonaName();                   // current persona, faint, right after the name
            if (pn != null) txt(g, class_2561.method_43470(pn), afterName, top + 7, ON_BAND_FAINT);
        }
        renderTabs(g, mouseX, mouseY);

        if (dismissPending != null) {
            txt(g, class_2561.method_43469("numen.dismiss.title", nameFor(dismissPending)),
                    left + PAD, top + HEADER_H + 12, TXT);
            txt(g, class_2561.method_43471("numen.dismiss.warning"),
                    left + PAD, top + HEADER_H + 30, FAIL);
        } else if (summoning) {
            txt(g, class_2561.method_43471("numen.summon.title"), left + PAD, top + HEADER_H + 8, TXT);
            txt(g, class_2561.method_43471("numen.summon.hint"),
                    left + PAD, top + HEADER_H + 74, TXT_FAINT);
        } else {
            if (uuid != null) {
                if (compactButton != null) compactButton.field_22763 = loop().canCompact();
                if (stopButton != null) stopButton.field_22763 = loop().canInterrupt();
            }
            switch (tab) {
                case SETTINGS -> renderSettings(g, mouseX, mouseY);   // global — works with no companion
                case CHAT -> { if (uuid != null) renderChat(g); else emptyHint(g); }
                case ITEMS -> { if (uuid != null) renderItems(g, mouseX, mouseY); else emptyHint(g); }
            }
            if (tab == Tab.CHAT && warnUntil > System.currentTimeMillis()) {   // endpoint-problem hint above the input
                txt(g, warnText != null ? class_2561.method_43470(warnText)
                                : class_2561.method_43471("numen.chat.no_key"),
                        left + PAD, top + PANEL_H - INPUT_H - PAD - 11, FAIL);
            }
        }

        // Widgets render LAST, on top of the panel background (fixes the "dim fields" — the panel fill
        // used to paint over the auto-rendered widgets). Text fields are borderless EditBoxes, so draw
        // a parchment field background + border behind each before it renders its text.
        for (class_339 w : overlay) {
            if (w instanceof class_342 eb) {                          // parchment frame, inflated past the inset text
                g.method_52706(
                        FIELD_SPRITE, eb.method_46426() - FIELD_INSET_X, eb.method_46427() - FIELD_INSET_Y,
                        eb.method_25368() + FIELD_INSET_X * 2, eb.method_25364() + FIELD_INSET_Y * 2);
            }
        }
        for (class_339 w : overlay) {
            w.method_25394(g, mouseX, mouseY, partial);
        }
        // Field placeholders, drawn shadowless by us (the EditBox hint renders with a shadow).
        if (tab == Tab.SETTINGS && settingsSection == SettingsSection.PROVIDER && addingProvider) {
            placeholder(g, provProviderInput, "openai / deepseek / …");
            placeholder(g, provKeyInput, "sk-…");
            placeholder(g, provBaseUrlInput, "https://… (OpenAI-compatible)");
        }
        if (tab == Tab.SETTINGS && settingsSection == SettingsSection.MCP && addingMcp) {
            placeholder(g, mcpNameInput, "kfc");
            placeholder(g, mcpTargetInput, mcpStdio ? "cmd /c npx -y <server>" : "https://mcp.mcd.cn");
            placeholder(g, mcpHeaderInput, mcpStdio ? "KEY=value; KEY2=value2" : "Authorization: Bearer <token>");
        }
        if (tab == Tab.SETTINGS && settingsSection == SettingsSection.PERSONA && addingPersona) {
            placeholder(g, personaNameInput, "雷");   // the text area has its own built-in placeholder
        }
        // (Chat-input placeholder is the FlatEditBox hint now — drawn shadowless and under the
        // caret in the widget pass, so it can't paint over the caret like a screen-side draw did.)
        // Summon persona dropdown — drawn late so its open list sits above the summon field.
        if (summoning && summonProviderDropdown == null) {
            // Empty provider library: creation is blocked — paint the pointer instead.
            g.method_51433(field_22793, "先到 设置 → 提供商 新建一条配置", left + PAD, top + HEADER_H + 74, 0xFFCC6666, false);
        }
        if (summoning && summonProviderDropdown != null) {
            summonProviderDropdown.render(g, field_22793, mouseX, mouseY);
        }
        if (summoning && summonPersonaDropdown != null) {
            summonPersonaDropdown.render(g, field_22793, mouseX, mouseY);
        }

        // Hovered MCP / skill row tooltip — drawn last so nothing paints over it.
        if (pendingTip != null) {
            g.method_51434(field_22793, pendingTip, pendingTipX, pendingTipY);
        }
    }

    // ---- left companion rail ----

    /** The folded-in roster (on the merged sprite's rail column): one avatar head per companion below the
     *  green header, active one framed gold, a status dot each, + tile at the bottom. */
    private void renderRail(class_332 g, int mouseX, int mouseY) {
        List<NumenRoster.Entry> entries = NumenRoster.instance().entries();
        int ax = railX + (RAIL_W - RAIL_AV) / 2;
        railScroll = Math.clamp(railScroll, 0, maxRailScroll());     // keep valid as the roster grows/shrinks
        int first = railScroll;
        int startY = railStartY();
        for (int i = first; i < entries.size(); i++) {
            int ay = startY + (i - first) * RAIL_SLOT;
            if (ay + RAIL_AV > railBottomEdge()) break;
            NumenRoster.Entry e = entries.get(i);
            boolean active = e.uuid().equals(uuid);
            // textured socket behind the head (gold-bordered when active), then the avatar, then a status LED
            g.method_52706(active ? AVATAR_FRAME_ACTIVE : AVATAR_FRAME, ax - 2, ay - 2, RAIL_AV + 4, RAIL_AV + 4);
            class_7532.method_52722(g, skinFor(e.uuid()), ax, ay, RAIL_AV);
            if (ClientDeaths.isDead(e.uuid())) {                      // dead — dim veil + respawn countdown
                g.method_25294(ax, ay, ax + RAIL_AV, ay + RAIL_AV, 0xB0101010);
                long rem = ClientDeaths.remainingMs(e.uuid());
                if (rem >= 0) {
                    String c = String.valueOf((int) Math.ceil(rem / 1000.0));
                    txt(g, class_2561.method_43470(c), ax + (RAIL_AV - field_22793.method_1727(c)) / 2, ay + (RAIL_AV - 8) / 2, CTA);
                }
            } else {
                int d = ax + RAIL_AV - 6, e2 = ay + RAIL_AV - 6;     // status LED, bottom-right
                g.method_25294(d, e2, d + 5, e2 + 5, statusColor(e.uuid()));
                Nb.border(g, d, e2, 5, 5, 1, BORDER);
            }
            // hover → a small ✕ badge breaking OUT of the avatar's top-right corner (overhangs the frame).
            // Show it while the cursor is over the avatar OR the badge itself (the badge sticks out, so
            // moving onto it must not make it vanish).
            int bx = ax + RAIL_AV - 3, by = ay - 5;
            boolean overAvatar = mouseX >= ax && mouseX < ax + RAIL_AV && mouseY >= ay && mouseY < ay + RAIL_AV;
            boolean overBadge = mouseX >= bx && mouseX < bx + 9 && mouseY >= by && mouseY < by + 9;
            if (dismissPending == null && (overAvatar || overBadge)) {
                g.method_25294(bx, by, bx + 9, by + 9, FAIL);
                Nb.border(g, bx, by, 9, 9, 1, BORDER);
                txt(g, class_2561.method_43470("✕"), bx + 2, by + 1, ON_BAND);
            }
        }
        // "+" summon tile (baked "+" glyph), pinned to the rail bottom
        int py = top + PANEL_H - PAD - RAIL_AV;
        // scroll cues — gold chevrons when the roster overflows the rail in either direction
        int cx = ax + RAIL_AV / 2;
        if (railScroll > 0) chevron(g, cx, top + 1, true);
        if (railScroll < maxRailScroll()) chevron(g, cx, py - 9, false);
        g.method_52706(summoning ? SUMMON_ACTIVE : SUMMON_SPRITE, ax, py, RAIL_AV, RAIL_AV);
    }

    /** Scroll-affordance chevron sprite (amber pixel-art triangle, up = more above / down = more below).
     *  Blitted at its native 11×6 so the pixels stay crisp (no scaling, no AA). */
    private void chevron(class_332 g, int cx, int y, boolean up) {
        g.method_52706(
                up ? CHEVRON_UP : CHEVRON_DOWN, cx - 5, y, 11, 6);
    }

    /** Bottom edge an avatar may reach (a gap above the pinned "+" tile). */
    private int railBottomEdge() {
        return top + PANEL_H - PAD - RAIL_AV - RAIL_BOT_GAP;
    }

    /** How many avatar slots fit in the rail above the pinned "+" tile. */
    private int railVisibleSlots() {
        int slots = 0;
        while (top + RAIL_TOP + slots * RAIL_SLOT + RAIL_AV <= railBottomEdge()) slots++;
        return Math.max(1, slots);
    }

    private int maxRailScroll() {
        return Math.max(0, NumenRoster.instance().entries().size() - railVisibleSlots());
    }

    /** Y of the first (visible) avatar: centred vertically when the whole roster fits, top-aligned once
     *  it overflows and scrolls. Fixes the big bottom gap + the first avatar poking past the top edge. */
    private int railStartY() {
        int n = NumenRoster.instance().entries().size();
        if (n > railVisibleSlots()) return top + RAIL_TOP;          // scrolling — top-align
        int blockH = Math.max(0, n - 1) * RAIL_SLOT + RAIL_AV;
        int span = railBottomEdge() - (top + RAIL_TOP);
        return top + RAIL_TOP + Math.max(0, (span - blockH) / 2);   // centre the block
    }

    /** The companion whose hover-✕ badge is under (mx,my), or null. Mirrors renderRail geometry. */
    private UUID railCloseAt(int mx, int my) {
        int ax = railX + (RAIL_W - RAIL_AV) / 2;
        List<NumenRoster.Entry> entries = NumenRoster.instance().entries();
        int first = Math.clamp(railScroll, 0, maxRailScroll());
        int startY = railStartY();
        for (int i = first; i < entries.size(); i++) {
            int ay = startY + (i - first) * RAIL_SLOT;
            if (ay + RAIL_AV > railBottomEdge()) break;
            int bx = ax + RAIL_AV - 3, by = ay - 5;   // overhanging top-right badge (matches renderRail)
            if (mx >= bx && mx < bx + 9 && my >= by && my < by + 9) return entries.get(i).uuid();
        }
        return null;
    }

    private boolean railPlusAt(int mx, int my) {
        int ax = railX + (RAIL_W - RAIL_AV) / 2;
        int py = top + PANEL_H - PAD - RAIL_AV;
        return mx >= ax && mx < ax + RAIL_AV && my >= py && my < py + RAIL_AV;
    }

    /** idle = green, working/compacting = amber, queued = gold; faint if no loop yet. */
    private int statusColor(UUID u) {
        return AgentLoopRegistry.get(u).map(loop -> {
            if (loop.isCompacting() || loop.isBusy()) return RUN;
            if (loop.hasQueuedPrompts()) return CTA;
            return OK;
        }).orElse(TXT_FAINT);
    }

    private static class_8685 skinFor(UUID u) {
        class_742 e = ClientNumenLookup.resolve(u);
        return e != null ? e.method_52814() : class_1068.method_4648(u);
    }

    /** Roster index of the avatar under (mx,my), or -1. */
    private int railIndexAt(int mx, int my) {
        int ax = railX + (RAIL_W - RAIL_AV) / 2;
        if (mx < ax || mx >= ax + RAIL_AV) return -1;
        List<NumenRoster.Entry> entries = NumenRoster.instance().entries();
        int first = Math.clamp(railScroll, 0, maxRailScroll());
        int startY = railStartY();
        for (int i = first; i < entries.size(); i++) {
            int ay = startY + (i - first) * RAIL_SLOT;
            if (ay + RAIL_AV > railBottomEdge()) break;
            if (my >= ay && my < ay + RAIL_AV) return i;
        }
        return -1;
    }

    private void emptyHint(class_332 g) {
        txt(g, class_2561.method_43471("numen.empty.no_companions"),
                left + PAD, top + HEADER_H + 10, TXT_FAINT);
    }

    private void renderTabs(class_332 g, int mouseX, int mouseY) {
        String[] labels = tabLabels();
        for (int i = 0; i < 3; i++) {
            boolean active = tab == Tab.values()[i];
            boolean hover = mouseX >= tabX[i] && mouseX < tabX[i] + tabW[i]
                    && mouseY >= top && mouseY < top + HEADER_H;
            int color = (active || hover) ? ON_BAND : (0x00FFFFFF & ON_BAND) | 0xA0000000;   // dim on band
            txt(g, class_2561.method_43470(labels[i]), tabX[i] + 5, top + 7, color);
            if (active) {                                                                     // gold CTA underline
                g.method_25294(tabX[i] + 3, top + HEADER_H - 4, tabX[i] + tabW[i] - 3, top + HEADER_H - 1, ACCENT);
            }
        }
    }

    private static final int ICON = 9;        // native vitals-icon size
    private static final int ICON_STEP = 9;   // touching = one chunky bar

    /** A row of segmented icons for a 0..max stat (2 units per icon): empty sockets first, then
     *  full / half overlaid. Used for hearts (HP) and drumsticks (hunger). */
    private void renderStatRow(class_332 g, int x, int y, float value, float max,
                               net.minecraft.class_2960 full,
                               net.minecraft.class_2960 half,
                               net.minecraft.class_2960 empty) {
        int units = Math.max(1, (int) Math.ceil(max / 2f));
        for (int i = 0; i < units; i++) {
            int ix = x + i * ICON_STEP;
            g.method_52706(empty, ix, y, ICON, ICON);
            float v = value - i * 2f;
            if (v >= 2f)      g.method_52706(full, ix, y, ICON, ICON);
            else if (v >= 1f) g.method_52706(half, ix, y, ICON, ICON);
        }
    }

    /** Live mouse-following 3D portrait of the companion — the body IS a client player entity, so the
     *  vanilla player renderer draws it for free. Sits in a recessed socket (slot_alt stretched). */
    private void renderPortrait(class_332 g, class_742 e,
                                int x, int y, int w, int h, int mouseX, int mouseY) {
        g.method_52706(SLOT_ALT, x, y, w, h);
        if (e == null) return;
        int scale = (int) (h * 0.45f);
        net.minecraft.class_490.method_2486(
                g, x + 2, y + 2, x + w - 2, y + h - 2, scale, 0.0625f,
                (float) mouseX, (float) mouseY, e);
    }

    private void slotBg(class_332 g, net.minecraft.class_2960 sprite, int x, int y) {
        g.method_52706(sprite, x, y, 16, 16);
    }

    private void stackOn(class_332 g, class_1799 st, int x, int y, int mouseX, int mouseY) {
        if (st == null || st.method_7960()) return;
        g.method_51427(st, x, y);
        g.method_51431(field_22793, st, x, y);
        if (mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16) {
            g.method_51446(field_22793, st, mouseX, mouseY);
        }
    }

    /** One equipment/armor socket, read off the live client entity (equipment IS client-synced). */
    private void drawEquip(class_332 g, class_742 e, class_1304 slot,
                           int x, int y, int mouseX, int mouseY) {
        slotBg(g, SLOT_SPRITE, x, y);
        if (e != null) stackOn(g, e.method_6118(slot), x, y, mouseX, mouseY);
    }

    // ---- chat transcript + plan ----

    private void renderChat(class_332 g) {
        int bodyY = top + HEADER_H + 4;
        int bodyBottom = top + PANEL_H - INPUT_H - PAD - 6;
        int transX = left + PAD;
        int transW = PANEL_W - PAD * 2 - PLAN_W - 8;
        int viewH = bodyBottom - bodyY;

        // plan panel divider + content
        int planX = transX + transW + 8;
        g.method_25294(planX - 4, bodyY, planX - 3, bodyBottom, BORDER);
        renderPlan(g, planX, bodyY, bodyBottom);

        List<Row> rows = buildRows(transW);
        int contentH = rows.size() * LINE_H;
        lastMaxScroll = Math.max(0, contentH - viewH);
        if (pinBottom) scroll = lastMaxScroll;
        scroll = Math.clamp((long) scroll, 0, lastMaxScroll);

        g.method_44379(transX, bodyY, transX + transW, bodyBottom);
        int y = bodyY - scroll;
        long t = System.currentTimeMillis();
        Set<String> done = doneIds();
        Set<String> failed = failedIds();
        for (Row row : rows) {
            if (y + LINE_H > bodyY && y < bodyBottom) {
                if (row.foldKey() != null) {                 // clickable fold toggle — glyph baked into text
                    txt(g, row.text, transX, y, row.color);
                } else if (row.toolIds() != null) {          // tool row — status icon + text
                    boolean anyRunning = row.toolIds().stream().anyMatch(id -> !done.contains(id));
                    boolean anyFail = row.toolIds().stream().anyMatch(failed::contains);
                    String icon = anyRunning ? SPIN[(int) ((t / 120) % 4)] : (anyFail ? "✗" : "✔");
                    int ic = anyRunning ? RUN : (anyFail ? FAIL : OK);
                    txt(g, class_2561.method_43470(icon), transX, y, ic);
                    txt(g, row.text, transX + 11, y, row.color);
                } else {
                    txt(g, row.text, transX, y, row.color);
                }
            }
            y += LINE_H;
        }
        g.method_44380();

        // scrollbar — Cottage track + thumb sprites (was off-theme white fills)
        if (lastMaxScroll > 0) {
            int trackH = viewH;
            int thumbH = Math.max(12, trackH * viewH / (viewH + lastMaxScroll));
            int thumbY = bodyY + (trackH - thumbH) * scroll / lastMaxScroll;
            int sbX = transX + transW - 4;
            g.method_52706(SCROLL_TRACK, sbX, bodyY, 4, viewH);
            g.method_52706(SCROLL_THUMB, sbX, thumbY, 4, thumbH);
        }
    }

    /** Flatten the convo into render rows. Tool RESULT messages aren't drawn — they only mark the
     *  matching tool call done (via {@link #doneIds()}); the call line shows the spinner/check. */
    private List<Row> buildRows(int width) {
        List<Row> out = new ArrayList<>();
        Set<String> done = doneIds();
        Set<String> failed = failedIds();
        List<LlmToolCall> group = new ArrayList<>();        // a run of consecutive tool calls
        // The PHYSICAL transcript, not the LLM context: compaction rewires what
        // the model sees but must never eat the owner's visible history.
        for (ConvoState.Msg msg : loop().display()) {
            switch (msg) {
                case ConvoState.Msg.User u -> {
                    flushTools(out, group, done, failed, width);
                    if (ConvoLog.PERSONA_DIVIDER.equals(u.content())) {
                        wrapPlain(out, class_1074.method_4662("numen.chat.persona_changed"), TXT_FAINT, width);
                        continue;
                    }
                    if (ConvoLog.COMPACT_DIVIDER.equals(u.content())) {
                        wrapPlain(out, class_1074.method_4662("numen.chat.compacted"), TXT_FAINT, width);
                        continue;
                    }
                    String shown = ownerText(u.content());       // show only the owner's words, not injected content
                    if (shown.isEmpty()) continue;               // a pure directive/injected message → not shown
                    wrapPlain(out, shown, YOU, width);           // user = teal body, no label
                }
                case ConvoState.Msg.Assistant a -> {
                    AssistantTurn turn = a.turn();
                    if (turn.content() != null && !turn.content().isBlank()) {
                        flushTools(out, group, done, failed, width);   // spoken reply breaks the fold
                        addHeader(out, name, AI, width);         // bold name header on its OWN line
                        wrapPlain(out, turn.content(), AI, width);
                    }
                    group.addAll(turn.toolCalls());
                }
                case ConvoState.Msg.Tool ignored -> { /* result drives done/fail, not a row */ }
            }
        }
        flushTools(out, group, done, failed, width);
        // Prompts still waiting for a protocol-valid splice point (typed
        // mid-task, or pushed in by an external bridge via NumenGateway) —
        // visible immediately so a queued message never feels swallowed.
        for (String queued : loop().queuedPrompts()) {
            String shown = ownerText(queued);       // injected events (persona-change / <event>) → empty → not shown
            if (shown.isEmpty()) continue;
            wrapPlain(out, "⌛ " + shown, TXT_FAINT, width);
        }
        if (loop().isCompacting()) {
            wrapPlain(out, class_1074.method_4662("numen.chat.compacting"), TXT_MUTED, width);
        }
        if (out.isEmpty()) {
            wrapPlain(out, class_1074.method_4662("numen.chat.empty", name), TXT_FAINT, width);
        }
        return out;
    }

    /** Emit rows for a run of consecutive tool calls. A single call is always one plain row. A run of
     *  many stays EXPANDED while any is still running (live per-tool spinners) and AUTO-FOLDS to a muted
     *  "N steps · names" summary once all are done — unless the user clicked it open (keyed by the first
     *  id in {@link #expandedGroups}), in which case it shows a "▾" header + the tool rows. */
    private void flushTools(List<Row> out, List<LlmToolCall> group, Set<String> done, Set<String> failed, int width) {
        if (group.isEmpty()) return;
        if (group.size() == 1) {                                  // single tool — never folds
            addToolRow(out, group.get(0), width);
            group.clear();
            return;
        }
        String key = group.get(0).id();
        boolean running = group.stream().anyMatch(tc -> !done.contains(tc.id()));
        boolean expanded = running || expandedGroups.contains(key);
        if (!expanded) {                                          // folded summary (click to expand)
            List<String> names = new ArrayList<>();
            for (LlmToolCall tc : group) if (!names.contains(tc.name())) names.add(tc.name());
            boolean anyFail = group.stream().anyMatch(tc -> failed.contains(tc.id()));
            String summary = "▸ " + class_1074.method_4662("numen.chat.steps", group.size()) + " · " + String.join(" · ", names);
            out.add(new Row(colored(fitOneLine(summary, width - 2), anyFail ? FAIL : TOOL).method_30937(),
                    anyFail ? FAIL : TOOL, null, key));
        } else {
            if (!running) {                                       // manually expanded → collapsible header
                String hdr = "▾ " + class_1074.method_4662("numen.chat.steps", group.size());
                out.add(new Row(colored(hdr, TXT_MUTED).method_30937(), TXT_MUTED, null, key));
            }
            for (LlmToolCall tc : group) addToolRow(out, tc, width);
        }
        group.clear();
    }

    private void addToolRow(List<Row> out, LlmToolCall tc, int width) {
        class_5481 seq = colored(fitOneLine(toolLine(tc), width - 2 - 11), TOOL).method_30937();
        out.add(new Row(seq, TOOL, List.of(tc.id()), null));
    }

    /** Trim a string with an ellipsis so it fits one line of the given pixel width. */
    private String fitOneLine(String s, int pxWidth) {
        if (field_22793.method_1727(s) <= pxWidth) return s;
        while (s.length() > 1 && field_22793.method_1727(s + "…") > pxWidth) s = s.substring(0, s.length() - 1);
        return s + "…";
    }

    private String toolLine(LlmToolCall tc) {
        String args = tc.arguments() == null ? "" : tc.arguments().replaceAll("\\s+", " ").trim();
        if (args.length() > TOOL_ARG_CHARS) args = args.substring(0, TOOL_ARG_CHARS) + "…";
        return tc.name() + "  " + args;
    }

    /** A bold name header on its OWN line (fixed format — never merges into the body). */
    private void addHeader(List<Row> out, String label, int color, int width) {
        var tc = net.minecraft.class_5251.method_27717(color & 0xFFFFFF);
        class_2561 c = class_2561.method_43470(label).method_27694(s -> s.method_27703(tc).method_10982(true));
        for (class_5481 seq : field_22793.method_1728(c, width - 2)) {
            out.add(new Row(seq, color, null, null));
        }
    }

    /** A plain, regular-weight line (status hints) — colour baked into the style. */
    private void wrapPlain(List<Row> out, String text, int color, int width) {
        for (class_5481 seq : field_22793.method_1728(colored(text, color), width - 2)) {
            out.add(new Row(seq, color, null, null));
        }
    }

    private Set<String> doneIds() {
        Set<String> s = new HashSet<>();
        for (ConvoState.Msg m : loop().display()) {
            if (m instanceof ConvoState.Msg.Tool t) s.add(t.toolCallId());
        }
        return s;
    }

    private Set<String> failedIds() {
        Set<String> s = new HashSet<>();
        for (ConvoState.Msg m : loop().display()) {
            if (m instanceof ConvoState.Msg.Tool t && looksFailed(t.content())) s.add(t.toolCallId());
        }
        return s;
    }

    private static boolean looksFailed(String content) {
        if (content == null) return false;
        String c = content.replaceAll("\\s+", "");
        return c.contains("\"success\":false") || c.startsWith("ERROR") || c.contains("\"error\"");
    }

    /** Right-side PLAN panel: the companion's latest {@code todowrite}, with status glyphs. */
    private void renderPlan(class_332 g, int x, int y, int bottom) {
        txt(g, class_2561.method_43471("numen.chat.plan"), x, y, TXT_MUTED);
        int ly = y + 13;
        JsonArray todos = latestPlan();
        if (todos == null || todos.isEmpty()) {
            txt(g, class_2561.method_43471("numen.chat.no_plan"), x, ly, TXT_FAINT);
            return;
        }
        for (int i = 0; i < todos.size() && ly + LINE_H < bottom; i++) {
            if (!todos.get(i).isJsonObject()) continue;
            JsonObject it = todos.get(i).getAsJsonObject();
            String status = str(it, "status");
            String content = str(it, "content");
            String glyph = switch (status) { case "completed" -> "✔"; case "in_progress" -> "▸"; default -> "○"; };
            int color = switch (status) { case "completed" -> OK; case "in_progress" -> RUN; default -> TXT_FAINT; };
            txt(g, class_2561.method_43470(glyph), x, ly, color);
            // text hierarchy: in-progress = strong (current focus), completed = recede, pending = faint
            int textColor = switch (status) {
                case "in_progress" -> TXT;
                case "completed" -> TXT_MUTED;
                default -> TXT_FAINT;
            };
            List<class_5481> lines = field_22793.method_1728(colored(content, textColor), PLAN_W - 14);
            int sub = 0;
            for (class_5481 seq : lines) {
                if (ly + LINE_H >= bottom) break;
                txt(g, seq, x + 10, ly, textColor);
                ly += LINE_H;
                if (++sub >= 2) break;   // cap each item at 2 lines
            }
            if (lines.isEmpty()) ly += LINE_H;
        }
    }

    /** Parse the most recent todowrite call's todos array, or null. Reads the
     *  physical transcript so the plan survives a context compaction. */
    private JsonArray latestPlan() {
        JsonArray latest = null;
        for (ConvoState.Msg m : loop().display()) {
            if (m instanceof ConvoState.Msg.Assistant a) {
                for (LlmToolCall tc : a.turn().toolCalls()) {
                    if (!"todowrite".equals(tc.name())) continue;
                    try {
                        JsonObject args = JsonParser.parseString(tc.arguments()).getAsJsonObject();
                        if (args.has("todos") && args.get("todos").isJsonArray()) {
                            latest = args.getAsJsonArray("todos");
                        }
                    } catch (RuntimeException ignored) { /* keep the last good one */ }
                }
            }
        }
        return latest;
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    /** The Items tab: a vanilla-inventory-style "companion sheet" — armor column + offhand, a live
     *  mouse-following portrait, the synced 2×2 craft grid + result, segmented heart/drumstick vitals,
     *  and the read-only checkerboard 3×9 storage + hotbar. Body data is fetched on demand via
     *  RequestInventoryPayload (backpack + craft + food); HP + equipment come off the live client entity. */
    private void renderItems(class_332 g, int mouseX, int mouseY) {
        var snap = ClientNumenInventory.get(uuid).orElse(null);
        class_742 e = ClientNumenLookup.resolve(uuid);
        List<class_1799> craft = snap != null ? snap.craft() : List.of();

        // Two centred columns: LEFT = big portrait + armor column + offhand; RIGHT = craft + vitals +
        // 3×9 storage + hotbar. Symmetric framing margins (no lopsided whitespace).
        final int STORAGE_W = 9 * 18;                     // 162 — the widest element (caps the band)
        final int COMP_W = 130 + STORAGE_W;               // left col (130) + right col (storage)
        final int COMP_H = 152;
        int startX = left + (PANEL_W - COMP_W) / 2;
        int cTop = top + HEADER_H + (PANEL_H - HEADER_H - COMP_H) / 2;
        int rightX = startX + 130;

        // -- LEFT: portrait socket, armor column + offhand (vertically centred against the portrait) --
        renderPortrait(g, e, startX + 22, cTop, 84, COMP_H, mouseX, mouseY);
        int armorTop = cTop + (COMP_H - 5 * 18) / 2;
        for (int i = 0; i < ARMOR.length; i++) {
            drawEquip(g, e, ARMOR[i], startX, armorTop + i * 18, mouseX, mouseY);
        }
        drawEquip(g, e, class_1304.field_6171, startX, armorTop + 4 * 18, mouseX, mouseY);

        // -- RIGHT top: synced 2×2 craft grid (+ arrow + result) --
        for (int i = 0; i < 4; i++) {
            int cx = rightX + (i % 2) * 18, cy = cTop + (i / 2) * 18;
            slotBg(g, SLOT_SPRITE, cx, cy);
            stackOn(g, i < craft.size() ? craft.get(i) : class_1799.field_8037, cx, cy, mouseX, mouseY);
        }
        txt(g, class_2561.method_43470("→"), rightX + 38, cTop + 13, TXT_MUTED);
        int resultX = rightX + 54, resultY = cTop + 9;
        slotBg(g, SLOT_SPRITE, resultX, resultY);
        stackOn(g, craft.size() > 4 ? craft.get(4) : class_1799.field_8037, resultX, resultY, mouseX, mouseY);

        // -- RIGHT mid: segmented hearts + drumsticks --
        if (e != null) renderStatRow(g, rightX, cTop + 46, e.method_6032(), e.method_6063(),
                HEART_FULL, HEART_HALF, HEART_EMPTY);
        int food = (snap != null && snap.loaded()) ? snap.foodLevel() : 0;
        renderStatRow(g, rightX, cTop + 46 + ICON + 2, food, 20, FOOD_FULL, FOOD_HALF, FOOD_EMPTY);

        // -- RIGHT bottom: checkerboard 3×9 storage + hotbar --
        int storeY = cTop + 74;
        if (snap == null) {
            txt(g, class_2561.method_43471("numen.status.loading"), rightX, storeY + 4, TXT_FAINT);
            return;
        }
        if (!snap.loaded() || snap.items().isEmpty()) {
            txt(g, class_2561.method_43471("numen.status.asleep"), rightX, storeY + 4, TXT_FAINT);
            return;
        }
        List<class_1799> items = snap.items();
        for (int i = 9; i < 36; i++) {                     // storage rows (slots 9..35)
            int col = (i - 9) % 9, row = (i - 9) / 9;
            int x = rightX + col * 18, y = storeY + row * 18;
            slotBg(g, ((col + row) & 1) == 0 ? SLOT_SPRITE : SLOT_ALT, x, y);
            stackOn(g, items.get(i), x, y, mouseX, mouseY);
        }
        int hotbarY = storeY + 3 * 18 + 6;                 // hotbar (slots 0..8)
        for (int i = 0; i < 9; i++) {
            int x = rightX + i * 18;
            slotBg(g, (i & 1) == 0 ? SLOT_SPRITE : SLOT_ALT, x, hotbarY);
            stackOn(g, items.get(i), x, hotbarY, mouseX, mouseY);
        }
    }

    private static net.minecraft.class_2960 spr(String name) {
        return net.minecraft.class_2960.method_60655(com.dwinovo.numen.Constants.MOD_ID, name);
    }
    private static final net.minecraft.class_2960 SLOT_SPRITE = spr("slot");
    private static final net.minecraft.class_2960 SLOT_ALT = spr("slot_alt");        // checkerboard
    /** Parchment frame (reuses the button sprite) behind text fields. */
    private static final net.minecraft.class_2960 FIELD_SPRITE = spr("button");
    private static final net.minecraft.class_2960 HEART_FULL = spr("heart_full");
    private static final net.minecraft.class_2960 HEART_HALF = spr("heart_half");
    private static final net.minecraft.class_2960 HEART_EMPTY = spr("heart_empty");
    private static final net.minecraft.class_2960 FOOD_FULL = spr("food_full");
    private static final net.minecraft.class_2960 FOOD_HALF = spr("food_half");
    private static final net.minecraft.class_2960 FOOD_EMPTY = spr("food_empty");
    private static final net.minecraft.class_2960 SCROLL_TRACK = spr("scroll_track");
    private static final net.minecraft.class_2960 SCROLL_THUMB = spr("scroll_thumb");

    @Override
    public boolean method_25421() {
        return false;
    }

    /** A rendered transcript line. {@code toolIds} non-null = a tool row (status icon = spinner/✔/✗).
     *  {@code foldKey} non-null = a clickable fold toggle (the group's first id); both null = plain text. */
    private record Row(class_5481 text, int color, List<String> toolIds, String foldKey) {}
}
