package com.dwinovo.numen.entity;

import net.minecraft.class_2183;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * Drives a companion {@link class_3222} body the way a client's key presses
 * would: by setting the player's
 * movement INPUTS ({@code zza}/{@code xxa}, sprint, sneak, jump) and aim, then
 * letting vanilla player physics ({@code LivingEntity.travel}) do the actual
 * stepping, collision and 0.6-block step-up. Replaces the old {@code BodyMotor}
 * which wrote velocity directly onto a Mob's MoveControl.
 *
 * <p>A fake player has no client to send movement packets, so the server's own
 * player tick runs {@code travel} against these inputs and nothing overrides the
 * resulting position — that is what makes input-driving a server-side body work.
 * Inputs are momentary: set them every tick while moving, and {@link #halt} every
 * tick while stopped (otherwise the last forward input keeps it walking).
 */
public final class InputDriver {

    private InputDriver() {}

    /** Face {@code target} (yaw only) and push full forward. Call each tick while travelling. */
    public static void stepToward(class_3222 p, class_243 target, boolean sprint) {
        faceYaw(p, target);
        p.field_6250 = 1.0f;
        p.field_6212 = 0.0f;
        p.method_5728(sprint && !p.method_5715());
    }

    /** Aim the eyes at a point (yaw + pitch) — e.g. a block being mined or placed. */
    public static void lookAt(class_3222 p, class_243 point) {
        p.method_5702(class_2183.class_2184.field_9851, point);
    }

    /**
     * Upward impulse, routed the way vanilla routes pressing the jump key: a ground hop
     * on land ({@code jumpFromGround}), or a swim-up stroke in water/lava (vanilla
     * {@code jumpInLiquid} = +0.04/tick). Holding jump whenever the feet sink below the
     * lane is what keeps a body riding the water surface — a fake player has no
     * client to translate a key into the liquid case, so we do it here. Call every tick
     * you want to keep rising; in water it's the per-tick stroke, not a one-shot.
     */
    public static void jump(class_3222 p) {
        if (p.method_24828()) {
            p.method_6043();
        } else if (p.method_5799() || p.method_5771()) {
            p.method_18799(p.method_18798().method_1031(0.0, 0.04, 0.0));
        }
    }

    public static void sneak(class_3222 p, boolean on) {
        p.method_5660(on);
    }

    /** Zero all locomotion input. Call each tick while idle/arrived. */
    public static void halt(class_3222 p) {
        p.field_6250 = 0.0f;
        p.field_6212 = 0.0f;
        p.method_5728(false);
    }

    /** Turn the body (and head) to face {@code target} horizontally — travel goes where yaw points. */
    private static void faceYaw(class_3222 p, class_243 target) {
        double dx = target.field_1352 - p.method_23317();
        double dz = target.field_1350 - p.method_23321();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        p.method_36456(yaw);
        p.method_5847(yaw);
    }
}
