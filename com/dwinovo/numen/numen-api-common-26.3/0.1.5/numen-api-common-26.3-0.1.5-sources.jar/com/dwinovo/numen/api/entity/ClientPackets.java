package com.dwinovo.numen.api.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundSetHeldSlotPacket;
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerSlotStateChangedPacket;
import net.minecraft.network.protocol.game.ServerboundEditBookPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerLoadedPacket;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.network.protocol.game.ServerboundRenameItemPacket;
import net.minecraft.network.protocol.game.ServerboundSelectTradePacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundSetBeaconPacket;
import net.minecraft.network.protocol.game.ServerboundSignUpdatePacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.SignTextSlot;
import net.minecraft.world.phys.Vec3;

/**
 * 她的客户端会发给服务端的那些包,由这里代发(同伴的是 {@link NumenPlayer#packets})。<b>这是仓库里替她把客户端的包喂给服务端的唯一出口</b>:
 * 别处不直接调她连接上的 {@code handleXxx},每种包在这里一个方法。真玩家在界面里按一个钮、写一块牌子、选一笔交易、
 * 按 E,客户端发的是一个包,校验和落地全是原版服务端收包时做的;她没有客户端,这里把同一个包交给她连接上原版的
 * {@code ServerGamePacketListenerImpl.handleXxx},和 {@link Mouse}、{@link Hotbar} 送挖掘、切格是同一个入口。校验一条也不另写:
 * 附魔的等级与青金石、交易的材料与次数、告示牌要是 {@code playerWhoMayEdit} 且没涂蜡、书的页数、界面要 {@code stillValid},
 * 原版不认就静默不做。
 *
 * <p><b>发完要读回来。</b>原版拒绝时不报错也不回话(客户端靠下行的同步包才看到结果),所以调用方发完要去看世界、物品、界面真的变了没有,
 * 如实说成了或没成。同步处理的包(按钮、改名、选交易、信标、槽开关、玩家指令、交互)在方法返回时就落地了,读回来就是;写告示牌和写书
 * 原版先把文字交给过滤({@code filterTextPacket}),再排进服务端任务队列执行,方法返回时还没落地:读回来的活交给
 * {@link #afterHandled},排在它们后面。(过滤服务是异步的服务器——Mojang 的文字过滤配置——上,排进去的时候还没过滤完,读回来会看见没变;
 * 没有开过滤的服务器上过滤是当场完成的。)
 *
 * <p>只在服务端线程上用。
 */
public final class ClientPackets {

    private final ServerPlayer body;

    public ClientPackets(ServerPlayer body) {
        this.body = body;
    }

    /** 点"重生"(她死了以后):原版的 {@code PlayerList.respawn} 把她放回世界。 */
    public void respawn() {
        body.connection.handleClientCommand(
                new ServerboundClientCommandPacket(ServerboundClientCommandPacket.Action.PERFORM_RESPAWN));
    }

    /**
     * 答传送编号:服务端每次传送她都等客户端报这个数,连同客户端把传送落到自己身上之后的位置与朝向——服务端已经把她的身体
     * 放到了传送点,报的就是她此刻的位置与朝向,和原版客户端落定之后报的一样。
     *
     * <p>服务端把这个报告当一次移动来查,起点是它记下的"这一刻开头她在哪"({@code resetPosition})。真玩家的这个起点由网络层每刻
     * 的 {@code tickPlayer} 记下,传送与回执之间总隔着一次;她的一刻不走那趟(身体由 {@link Physics} 推动),所以回执前先记下她此刻的位置,
     * 和真玩家回执时服务端手里的起点一样,这次移动是零。
     */
    public void acceptTeleport(int id) {
        body.connection.resetPosition();
        body.connection.handleAcceptTeleportPacket(new ServerboundAcceptTeleportationPacket(id,
                body.getX(), body.getY(), body.getZ(), body.getYRot(), body.getXRot()));
    }

    /** 左键挥一下(打、挖的每一下):原版服务端按主手物品的攻击动作挥手给看着她的人,并把攻击蓄力清零。 */
    public void punch() {
        body.connection.handlePunch(ServerboundPunchPacket.INSTANCE);
    }

    /** 报"世界加载好了":服务端开始给她发区块后,客户端加载完就发这个,在这之前服务端不收她的动作包。 */
    public void playerLoaded() {
        body.connection.handleAcceptPlayerLoad(new ServerboundPlayerLoadedPacket());
    }

    /** 玩家动作:挖掘的开始、中止、完成,松开右键,丢东西,主副手交换。{@code sequence} 是挖掘方块动作的序号,别的动作为 0。 */
    public void playerAction(ServerboundPlayerActionPacket.Action action, BlockPos pos, Direction face, int sequence) {
        body.connection.handlePlayerAction(new ServerboundPlayerActionPacket(action, pos, face, sequence));
    }

    /**
     * 中键把背包里第 {@code slot} 格的东西换进快捷栏。1.21.2 起客户端的中键包只说"对着哪个方块或实体"、不再指名背包的格,
     * 服务端收包后自己找格({@code ServerGamePacketListenerImpl.tryPickItem});这里指名了格,就照它找到格以后做的:
     * 选中一个合适的快捷栏格、和那一格对换({@code Inventory.pickSlot}),再告诉客户端选中哪格、同步背包。
     * 对换照原版写在这里,不调 {@code pickSlot}:Paper 给它加了参数,两边签名不同。
     */
    public void pickItem(int slot) {
        Inventory inventory = body.getInventory();
        inventory.setSelectedSlot(inventory.getSuitableHotbarSlot());
        ItemStack held = inventory.getItem(inventory.getSelectedSlot());
        inventory.setItem(inventory.getSelectedSlot(), inventory.getItem(slot));
        inventory.setItem(slot, held);
        pickedSync();
    }

    /**
     * 创造模式中键一样背包里没有的东西:服务端在合适的快捷栏格放一叠它,原来占着那格的挪去空格({@code Inventory.addAndPickItem},
     * 同样照原版写在这里,理由同 {@link #pickItem}),再告诉客户端选中哪格、同步背包。
     */
    public void pickNew(ItemStack stack) {
        Inventory inventory = body.getInventory();
        inventory.setSelectedSlot(inventory.getSuitableHotbarSlot());
        ItemStack displaced = inventory.getItem(inventory.getSelectedSlot());
        if (!displaced.isEmpty()) {
            int free = inventory.getFreeSlot();
            if (free != -1) {
                inventory.setItem(free, displaced);
            }
        }
        inventory.setItem(inventory.getSelectedSlot(), stack);
        pickedSync();
    }

    private void pickedSync() {
        body.connection.send(new ClientboundSetHeldSlotPacket(body.getInventory().getSelectedSlot()));
        body.inventoryMenu.broadcastChanges();
    }

    /** 数字键、滚轮:选中快捷栏第 {@code slot} 格。 */
    public void setCarriedItem(int slot) {
        body.connection.handleSetCarriedItem(new ServerboundSetCarriedItemPacket(slot));
    }

    /** 写告示牌:{@code lines} 至多四行,不足的补空行(原版一次换掉整面的四行)。 */
    public void signUpdate(BlockPos pos, boolean front, List<String> lines) {
        List<String> four = new ArrayList<>(lines);
        while (four.size() < 4) {
            four.add("");
        }
        body.connection.handleSignUpdate(new ServerboundSignUpdatePacket(pos, List.copyOf(four),
                front ? SignTextSlot.FRONT : SignTextSlot.BACK));
    }

    /**
     * 书与笔:{@code slot} 是快捷栏的格(0 到 8)或副手(40),{@code title} 有值就署名成成书。原版只认这两种格。
     */
    public void editBook(int slot, List<String> pages, Optional<String> title) {
        body.connection.handleEditBook(new ServerboundEditBookPacket(slot, pages, title));
    }

    /** 铁砧改名:开着的界面是铁砧时,换掉要起的名字。 */
    public void renameItem(String name) {
        body.connection.handleRenameItem(new ServerboundRenameItemPacket(name));
    }

    /** 交易界面里选第 {@code index} 笔(从 0 起):原版自己把付款从背包填进付款格。 */
    public void selectTrade(int index) {
        body.connection.handleSelectTrade(new ServerboundSelectTradePacket(index));
    }

    /** 信标界面里定主、副效果。 */
    public void setBeacon(Optional<Holder<MobEffect>> primary, Optional<Holder<MobEffect>> secondary) {
        body.connection.handleSetBeaconPacket(new ServerboundSetBeaconPacket(primary, secondary));
    }

    /** 开着的界面里按第 {@code button} 个钮(附魔台、切石机、织布机、讲台的钮号随界面而定)。 */
    public void menuButton(int button) {
        body.connection.handleContainerButtonClick(
                new ServerboundContainerButtonClickPacket(body.containerMenu.containerId, button));
    }

    /** 合成器界面里开关第 {@code slot} 格:{@code enabled} 为真是开着、能放东西。 */
    public void slotState(int slot, boolean enabled) {
        body.connection.handleContainerSlotStateChanged(
                new ServerboundContainerSlotStateChangedPacket(slot, body.containerMenu.containerId, enabled));
    }

    /** 玩家能力:客户端切换创造飞行时发的包({@code LocalPlayer.onUpdateAbilities})。{@code flying} 是想要的状态,服务端只在身体许飞({@code mayfly})时认。 */
    public void flying(boolean flying) {
        Abilities wanted = new Abilities();
        wanted.flying = flying;
        body.connection.handlePlayerAbilities(new ServerboundPlayerAbilitiesPacket(wanted));
    }

    /** 玩家指令:起床、鞘翅起飞、骑着时开坐骑的物品栏……。 */
    public void command(ServerboundPlayerCommandPacket.Action action) {
        body.connection.handlePlayerCommand(new ServerboundPlayerCommandPacket(body, action));
    }

    /**
     * 原版把写字的包排在服务端任务队列里;{@code readBack} 排在它后面,到它跑的时候文字已经落地(或被原版拒了),可以读回来。
     * 任务队列是先进先出,所以只要在发包之后排,就一定在它后面。
     */
    public void afterHandled(Runnable readBack) {
        body.level().getServer().execute(readBack);
    }

    private static List<ItemStack> equipment(Entity target) {
        List<ItemStack> out = new ArrayList<>();
        if (target instanceof LivingEntity living) {
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                out.add(living.getItemBySlot(slot).copy());
            }
        }
        return out;
    }

    private static boolean same(List<ItemStack> before, List<ItemStack> after) {
        for (int i = 0; i < before.size(); i++) {
            if (!ItemStack.matches(before.get(i), after.get(i))) {
                return false;
            }
        }
        return true;
    }
}
