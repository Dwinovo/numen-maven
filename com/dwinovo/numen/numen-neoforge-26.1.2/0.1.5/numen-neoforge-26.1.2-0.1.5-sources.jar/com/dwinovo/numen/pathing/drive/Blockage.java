package com.dwinovo.numen.pathing.drive;

import com.dwinovo.numen.pathing.plan.MoveKind;
import com.dwinovo.numen.pathing.plan.Reason;
import com.dwinovo.numen.pathing.search.Search;
import com.dwinovo.numen.pathing.search.SearchResult;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 一步走不下去:卡在哪一格、那一格此刻是什么方块、哪种走法、为什么。原因二选一——前提在活世界上复核不成立,是
 * {@code reason}({@link Reason},与规划报的是同一套);前提成立而身体做不到,是 {@code hitch}。
 *
 * @param reason 复核不成立的那一条前提;不是复核的事为 null
 * @param hitch  执行里出的事;是复核的事为 null
 */
public record Blockage(BlockPos cell, BlockState block, MoveKind move, Reason reason, Hitch hitch) {

    /** 搜索里离目标最近的节点上朝目标的那一步被拒了,说成一条阻碍(那一格在这次搜索读到的世界里是什么方块);回执与诊断共用这一处。 */
    public static Blockage refused(Search search, SearchResult.Blocking blocking) {
        BlockPos cell = blocking.fails().cell();
        return new Blockage(cell, search.view().getBlockState(cell), blocking.move(), blocking.fails().reason(), null);
    }

    /** 前提成立、身体却做不到的几种情况。 */
    public enum Hitch {
        /** 这一步超过了期限({@link Watchdog})。 */
        STUCK,
        /** 要挖、要开的那一格看不见(准星碰不上它)。 */
        OCCLUDED,
        /** 要放的那一格没有一个点得中的面。 */
        NO_FACE,
        /** 手上拿不到要放的料。 */
        NO_MATERIALS,
        /** 复核时这一步落到的已经不是规划的那个节点(比如脚下的落点变了)。 */
        DIVERTED,
        /** 走着这一步,身体落回了路线上前面一步的起点:这一步没走成。 */
        FELL_BACK,
        /** 走着这一步,身体落在了路线之外的节点上(撞着规划看不见的东西滑到了旁边一行):这一步没把身体带到它的落点。 */
        LOST,
        /** 空中被围住:从身体此刻的位置往哪个方向推演都撞方块。 */
        BOXED,
        /** 滑翔着被方块顶住:身体一秒没离开原地,{@link Watchdog} 判卡住,那一格是顶着身体的方块。 */
        PINNED
    }
}
