package com.dwinovo.numen.tools;

import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import com.mojang.datafixers.util.Either;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Unit;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;


/**
 * {@code use sleep} 的业务半边:<b>上床,然后确认她真的睡着了</b>。
 *
 * <h2>为什么它这么薄</h2>
 * 找床归 {@code scan_blocks}(现在能写 {@code #minecraft:beds},一句话覆盖全部颜色),
 * 走过去归 {@code numen.move.walk}——那两件事今天已经各有一个统一的实现,再包一份进来就是第三个入口。
 * 这里只做别处做不了的那一件:<b>把原版的睡眠判定翻译成模型能接住的回执</b>。
 *
 * <h2>三态,不是两态</h2>
 * {@code startSleepInBed} 返回 {@code Either<Problem, Unit>},而 {@code right} 只意味着
 * "没被拒绝"——它不等于"睡着了"。真判据是 {@code isSleeping()}。所以中间那一态必须存在:
 * <b>请求被接受了,但她并没有进入睡眠状态</b>。少了它,一次右键成功就会被当成睡着。
 *
 * <p>被拒绝时的措辞直接用原版自己的({@code BedSleepingProblem.message()})——白天、床被占、
 * 附近有怪、离得太远,一句都不用我们编,而且跟着语言文件走。
 */
public final class SleepOps {

    /** 原版判"够不够得着床"的盒子({@code Player.startSleepInBed} 用的就是这个)。 */
    private static final int REACH_H = 3;
    private static final int REACH_V = 2;

    /** 躺下了没有、在哪张床。 */
    public record Slept(@com.dwinovo.numen.api.sdk.Doc("The bed's head.") BlockPos bed, boolean sleeping) {}

    /**
     * @param at 指定哪张床;为 null 时用手边够得着的那张
     * @throws ApiError 没有床({@code not_found});原版拒绝或没真躺下({@code failed},数据里是那张床)
     */
    public static Slept sleep(BlockPos at, NumenPlayer self) {
        boolean given = at != null;
        BlockPos bedHead = given ? headOf(self.level(), at) : nearestBedHeadInReach(self);
        if (bedHead == null) {
            throw noBed(self.getInventory(), given);
        }

        Either<Player.BedSleepingProblem, Unit> result = self.startSleepInBed(bedHead);
        Player.BedSleepingProblem rejection = result.left().orElse(null);

        // 这三条的顺序就是判据本身:先看原版拒没拒,再看她是不是真躺下了。
        if (rejection != null) {
            throw new ApiError(ErrorKind.FAILED, explain(rejection) + " (bed at " + pretty(bedHead) + ")", null,
                    new Slept(bedHead, false));
        }
        if (!self.isSleeping()) {
            throw new ApiError(ErrorKind.FAILED, "the sleep request was accepted but you did not actually enter sleep "
                    + "— something cancelled it in the same tick; look around before assuming you rested", null,
                    new Slept(bedHead, false));
        }
        return new Slept(bedHead, true);
    }

    /**
     * 拒绝理由<b>用原版自己的话</b>——它已经足够具体("there are monsters nearby"、
     * "the bed is too far away"、"you can only sleep at night and during thunderstorms"),
     * 我们再翻一遍只会得到一份要跟着原版措辞走的硬编码。而且它跟着语言文件,主人也看得懂。
     *
     * <p>{@code OTHER_PROBLEM} 原版没配文案({@code message()} 是 {@code null},它在别处另行处理),没有别的可说——
     * 不能因为 null 就炸,那会把"她睡不着"变成"工具报错",而模型对后者无从下手。
     */
    static String explain(Player.BedSleepingProblem problem) {
        var vanilla = problem.message();
        return vanilla != null
                ? vanilla.getString()
                : "the bed refused you (no reason given)";
    }

    /** 手边够得着的床(原版口径:床的任一半在 ±3/±2/±3 内),归一到床头。 */
    private static BlockPos nearestBedHeadInReach(NumenPlayer self) {
        Level level = self.level();
        BlockPos me = self.blockPosition();
        BlockPos best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(
                me.offset(-REACH_H, -REACH_V, -REACH_H),
                me.offset(REACH_H, REACH_V, REACH_H))) {
            BlockPos head = headOf(level, p);
            if (head == null) {
                continue;
            }
            double d = head.distSqr(me);
            if (d < bestDistSq) {
                bestDistSq = d;
                best = head;
            }
        }
        return best;
    }

    /**
     * 这一格是床的话,给出它的<b>床头</b>;不是床则 null。
     *
     * <p>床占两格而 {@code startSleepInBed} 只认床头,所以从任一半算得出来——省得模型
     * 撞运气给了床尾那格。
     */
    private static BlockPos headOf(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof BedBlock)
                || !state.hasProperty(BedBlock.PART)
                || !state.hasProperty(BedBlock.FACING)) {
            return null;   // 认床看类型不看 id:模组的床自动算数,不用列 16 种颜色
        }
        return state.getValue(BedBlock.PART) == BedPart.HEAD
                ? pos.immutable()
                : pos.relative(state.getValue(BedBlock.FACING)).immutable();
    }

    /** 没床时把下一步递到她面前——包括"你自己身上就带着一张"({@code inventory} 是她的背包)。 */
    static ApiError noBed(net.minecraft.world.Container inventory, boolean coordsGiven) {
        String carried = carriedBed(inventory);
        String base = coordsGiven
                ? "there is no bed at those coordinates"
                : "there is no bed within reach (you must be standing next to one)";
        String next = carried != null
                ? " You are carrying " + carried + " — place it on flat ground and try again."
                : " `numen.scan.blocks(\"#minecraft:beds\")` finds one; `numen.move.walk(bed.pos, 2)`, "
                        + "then `numen.use.sleep()` again.";
        return new ApiError(ErrorKind.NOT_FOUND, base + "." + next, null);
    }

    /** 背包里的第一张床;没有则 null。 */
    private static String carriedBed(net.minecraft.world.Container inv) {
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem block
                    && block.getBlock() instanceof BedBlock) {
                return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString()
                        + " x" + stack.getCount();
            }
        }
        return null;
    }



    private static String pretty(BlockPos p) {
        return p.getX() + "," + p.getY() + "," + p.getZ();
    }
}
