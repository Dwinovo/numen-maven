package com.dwinovo.numen.core.blueprint;

import com.dwinovo.numen.core.task.build.BuildTaskRecord;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * 蓝图仓库:{@code schematics/} 目录下的结构文件。
 *
 * <p>目录名取社区通用的那个:玩家下载来的图纸本来就躺在那儿,不必再为我们
 * 单独搬一次家。旧的 {@code config/numen/blueprints} 继续兜底读取,已经放
 * 进去的图纸不会失踪。
 *
 * <p>支持两种载体,同一数据形态(原版结构 NBT:size + palette/palettes + blocks):
 * <ul>
 *   <li>{@code .nbt}——结构方块导出的压缩二进制,游戏内即可制作,网络资源海量;</li>
 *   <li>{@code .snbt}——同一数据的打包文本形态(gametest 用的那种),可读可 diff。</li>
 * </ul>
 *
 * <p>加载即展开为 {@link BuildTaskRecord.Target} 全量格集:调色板态原样入格
 * (朝向、轴向、半砖上下……由 setBlock 精确落位),显式空气格是"清空"指令,
 * 稀疏缺省格不触碰;门、床这类双格方块在模板里本就两半俱全,逐格写入天然成对。
 * 方块实体数据(箱子内容等)暂不携带。
 */
public final class BlueprintStore {

    private BlueprintStore() {}

    /** 单张蓝图的格数上限(防误载巨图把任务撑爆)。 */
    private static final int MAX_CELLS = 32768;

    /**
     * 展开结果:目标格集 + 旋转后的占地尺寸 + 方块实体数据 + 待生成的摆设实体
     * + <b>加载时就掉掉的格数</b>。
     *
     * <p>最后那个数不是给日志看的:掉格必须有账。不记的话,一张一千格的图纸掉了两百
     * 格,任务会报"八百格全部达标",而缺的那五分之一无人知晓。
     */
    public record Loaded(List<BuildTaskRecord.Target> targets, class_2382 size,
                         java.util.Map<Long, class_2487> blockEntityData,
                         List<BuildTaskRecord.EntitySpawn> entities,
                         java.util.Map<Long, List<BuildTaskRecord.CellNeed>> cellNeeds,
                         int dropped) {}

    /** 支持的图纸扩展名。 */
    private static final List<String> EXTENSIONS = List.of(".nbt", ".snbt", ".litematic", ".schem");

    /** 主目录:社区通用的 {@code schematics/}(不存在则建,新图纸也写这里)。 */
    public static Path dir(MinecraftServer server) {
        Path dir = server.method_3831().resolve("schematics");
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            throw new RuntimeException("cannot create blueprint directory " + dir, e);
        }
        return dir;
    }

    /** 查找顺序:主目录优先,旧目录兜底(只读,不自动创建)。 */
    private static List<Path> searchRoots(MinecraftServer server) {
        List<Path> roots = new ArrayList<>(2);
        roots.add(dir(server));
        // 字面量,不用 Constants.CONFIG_ROOT:这是"蓝图曾经放在哪"的历史事实,
        // 配置根将来若改名,这条兜底路径不该跟着改——那样就找不到老蓝图了。
        Path legacy = server.method_3831().resolve("config").resolve("numen").resolve("blueprints");
        if (Files.isDirectory(legacy)) {
            roots.add(legacy);
        }
        return roots;
    }

    /** 列出可用蓝图名(不含扩展名,排序稳定;同名以主目录为准)。 */
    public static List<String> list(MinecraftServer server) {
        java.util.Set<String> names = new java.util.LinkedHashSet<>();
        for (Path root : searchRoots(server)) {
            try (var stream = Files.list(root)) {
                stream.forEach(path -> {
                    String file = path.getFileName().toString();
                    String lower = file.toLowerCase(Locale.ROOT);
                    for (String ext : EXTENSIONS) {
                        if (lower.endsWith(ext)) {
                            names.add(file.substring(0, file.lastIndexOf('.')));
                            return;
                        }
                    }
                });
            } catch (IOException e) {
                throw new RuntimeException("cannot list blueprint directory " + root, e);
            }
        }
        List<String> sorted = new ArrayList<>(names);
        sorted.sort(Comparator.naturalOrder());
        return sorted;
    }

    /** 只读尺寸(列表工具的概要用)。 */
    public static class_2382 peekSize(MinecraftServer server, String name) {
        class_2487 tag = readTag(server, name);
        class_2499 size = tag.method_68569("size");
        return new class_2382(size.method_68576(0, 0), size.method_68576(1, 0), size.method_68576(2, 0));
    }

    /**
     * 展开蓝图为目标格集。
     *
     * @param anchor           落位基点 = 旋转后结构的最小角(x/y/z 最小处)
     * @param rotationQuarters 顺时针旋转的四分之一圈数(0-3)
     */
    public static Loaded load(class_3218 level, String name, class_2338 anchor, int rotationQuarters) {
        class_2487 tag = readTag(level.method_8503(), name);
        class_2499 sizeTag = tag.method_68569("size");
        int sx = sizeTag.method_68576(0, 0);
        int sy = sizeTag.method_68576(1, 0);
        int sz = sizeTag.method_68576(2, 0);

        // 多调色板结构(沉船等)取第一板;常规结构用单板。
        class_2499 paletteTag;
        if (tag.method_10554("palettes").isPresent()) {
            paletteTag = tag.method_68569("palettes").method_68588(0);
        } else {
            paletteTag = tag.method_68569("palette");
        }
        List<class_2680> palette = new ArrayList<>(paletteTag.size());
        class_2470 rotation = switch (Math.floorMod(rotationQuarters, 4)) {
            case 1 -> class_2470.field_11463;
            case 2 -> class_2470.field_11464;
            case 3 -> class_2470.field_11465;
            default -> class_2470.field_11467;
        };
        for (int i = 0; i < paletteTag.size(); i++) {
            palette.add(class_2512.method_10681(
                    level.method_45448(class_7924.field_41254), paletteTag.method_68582(i)).method_26186(rotation));
        }

        class_2499 blocks = tag.method_68569("blocks");
        if (blocks.size() > MAX_CELLS) {
            throw new IllegalArgumentException("blueprint " + name + " has " + blocks.size()
                    + " cells, exceeding the " + MAX_CELLS + " cap");
        }
        int quarters = Math.floorMod(rotationQuarters, 4);
        // 按位置去重:多区域的 litematic 可以在同一世界坐标给出两条(常见于一个
        // 区域填空气、另一个填墙)。不去重的话 targetByPos 只留最后一条而 targets
        // 两条都在——报价翻倍、分母虚高,而且必有一条永远对不上,最后以"她站不住"
        // 收场,病因指错方向。工具入口本来就是这么去重的,这条入口漏了。
        java.util.LinkedHashMap<Long, BuildTaskRecord.Target> byPos = new java.util.LinkedHashMap<>();
        java.util.Map<Long, class_2487> beData = new java.util.HashMap<>();
        java.util.Map<Long, List<BuildTaskRecord.CellNeed>> needs = new java.util.HashMap<>();
        int dropped = 0;
        for (int i = 0; i < blocks.size(); i++) {
            class_2487 cell = blocks.method_68582(i);
            class_2499 pos = cell.method_68569("pos");
            int x = pos.method_68576(0, 0);
            int y = pos.method_68576(1, 0);
            int z = pos.method_68576(2, 0);
            // 调色板下标来自文件,越界就是文件坏了——跳过这一格并记一笔,而不是让一个
            // 数组越界从工具调用里抛出去。整张图纸都坏的话下面 targets 为空,报错自然。
            int paletteIndex = cell.method_68083("state", -1);
            if (paletteIndex < 0 || paletteIndex >= palette.size()) {
                dropped++;
                continue;
            }
            class_2680 state = palette.get(paletteIndex);
            // 能不能建走同一个判据(工具入口那边拿它当拒绝理由,这边拿它当跳过条件)
            if (com.dwinovo.numen.core.build.BuildStates.unbuildableReason(state) != null) {
                dropped++;
                continue;
            }
            // 双格方块的次半不进目标集:主半的 setPlacedBy 自己会造它。不剔的话床头
            // 可能先于床脚落位,而床的那一步会往<b>目标集之外</b>再写一块床头——一件料
            // 换三块床方块,且可能覆写掉已砌好的内墙,来回重建死转。这不算掉格。
            if (com.dwinovo.numen.core.build.BuildStates.isSecondaryHalf(state)) {
                continue;
            }
            int rx;
            int rz;
            switch (quarters) {
                case 1 -> { rx = sz - 1 - z; rz = x; }
                case 2 -> { rx = sx - 1 - x; rz = sz - 1 - z; }
                case 3 -> { rx = z; rz = sx - 1 - x; }
                default -> { rx = x; rz = z; }
            }
            // 记账用的物品与工具那条入口共用同一张表(耕地/土径算土,高草算矮草)。
            // 推不出物品的方块(带花的花盆之类)整格跳过——留着只会是一个永远付不起
            // 的格子:预检数不到空气,逐格闸门也过不去,最后报"还差 air x37"。
            //
            // 记账物品要按<b>归一后</b>的方块查:装着水的炼药锅归一成空锅,而
            // water_cauldron 自己没有物品。按原始态查的话它是空气,整格被丢掉——
            // 而归一那条锅的规则本来就是专为救这一类写的。带蜡烛的蛋糕同理。
            //
            // 而且是<b>问方块自己</b>(中键取方块那条路),不查写死的表:小麦答种子、
            // 洞穴藤蔓答发光浆果、竹笋答竹子、连枝的瓜藤答瓜种。此前这里靠一张十三行
            // 的对照表,每行都是被咬过一次才补上的,而且只认原版——模组的作物一个都不认。
            class_2680 placed = com.dwinovo.numen.core.build.BuildStates.normalize(state);
            class_2338 world = anchor.method_10069(rx, y, rz);
            // 探针给<b>这一格自己的坐标</b>,不是锚点。给锚点的话所有格共用同一个探针点,
            // 而方块自述里有几种会去读那一格的方块实体——续建时锚点格本身就立着图纸放的
            // 东西,一面红旗就能把整张图纸的记账物品带偏。(带方块实体的方块已经在
            // materialItem 里整体不问了,这里是第二道:探针点本来就该是本格。)
            var payItem = com.dwinovo.numen.core.build.BuildStates
                    .materialItem(placed, level, world);
            if (payItem == net.minecraft.class_1802.field_8162 && !placed.method_26215()) {
                dropped++;
                continue;
            }
            // 同坐标后写覆盖先写:方块实体数据与逐格料单要跟着一起清,否则存活的那一条
            // 会串上前一条的数据(一块空白告示牌顶着别人的字)
            beData.remove(world.method_10063());
            needs.remove(world.method_10063());
            byPos.put(world.method_10063(), new BuildTaskRecord.Target(state, payItem, world,
                    state.method_26204().method_40142().method_40237().method_29177().method_12832(),
                    null, null, null));
            // 方块实体数据只搬装饰性的那部分(告示牌的字、旗帜的花纹);容器内容一律
            // 不搬——图纸是文件,照搬等于凭空造物品
            class_2487 safe = null;
            if (cell.method_10562("nbt").isPresent()) {
                safe = com.dwinovo.numen.core.build.BlueprintSafety
                        .safeBlockEntityData(state, cell.method_68568("nbt"));
                if (safe != null) {
                    beData.put(world.method_10063(), safe);
                }
            }
            // 这一格要几叠料:带花的花盆是盆加花两件,带花纹的旗帜是一叠但要组件一致。
            // 一格一件是特例而不是通则,这张料单整个盖过默认的"一件本方块的物品"。
            var cellNeeds = com.dwinovo.numen.core.build.BuildStates
                    .cellNeeds(placed, safe, level, world, level.method_30349());
            if (!cellNeeds.isEmpty()) {
                needs.put(world.method_10063(), cellNeeds);
            }
        }
        // 摆设实体(展示框、盔甲架、画):随图纸一起旋转,躯壳照生,身上的东西剥掉
        List<BuildTaskRecord.EntitySpawn> spawns = new ArrayList<>();
        for (class_2520 t : tag.method_68569("entities")) {
            // 1.21.5 的 getListOrEmpty 不按元素类型筛,强转前先挡一手,坏文件不 CCE
            if (!(t instanceof class_2487 e)) {
                continue;
            }
            class_2487 safe = com.dwinovo.numen.core.build.BlueprintSafety
                    .safeEntityData(e.method_68568("nbt"), level.method_30349());
            if (safe == null) {
                continue;
            }
            class_2499 at = e.method_68569("pos");
            if (at.size() != 3) {
                continue;
            }
            double ex = at.method_68574(0, 0);
            double ey = at.method_68574(1, 0);
            double ez = at.method_68574(2, 0);
            double rx;
            double rz;
            switch (quarters) {
                case 1 -> { rx = sz - ez; rz = ex; }
                case 2 -> { rx = sx - ex; rz = sz - ez; }
                case 3 -> { rx = ez; rz = sx - ex; }
                default -> { rx = ex; rz = ez; }
            }
            spawns.add(new BuildTaskRecord.EntitySpawn(
                    anchor.method_10263() + rx, anchor.method_10264() + ey, anchor.method_10260() + rz, rotation, safe));
        }
        List<BuildTaskRecord.Target> targets = new ArrayList<>(byPos.values());
        class_2382 size = (quarters % 2 == 0) ? new class_2382(sx, sy, sz) : new class_2382(sz, sy, sx);
        return new Loaded(targets, size, beData, spawns, needs, dropped);
    }

    private static class_2487 readTag(MinecraftServer server, String name) {
        for (Path base : searchRoots(server)) {
            Path nbt = base.resolve(name + ".nbt");
            Path snbt = base.resolve(name + ".snbt");
            Path litematic = base.resolve(name + ".litematic");
            Path schem = base.resolve(name + ".schem");
            try {
                if (Files.exists(nbt)) {
                    return class_2507.method_30613(nbt, class_2505.method_53898());
                }
                if (Files.exists(snbt)) {
                    return class_2512.method_32260(Files.readString(snbt));
                }
                // 社区格式:读出 gzip NBT 后转成原版结构形态,下游管线无感
                if (Files.exists(litematic)) {
                    return BlueprintFormats.fromLitematic(
                            class_2507.method_30613(litematic, class_2505.method_53898()));
                }
                if (Files.exists(schem)) {
                    return BlueprintFormats.fromSchem(
                            class_2507.method_30613(schem, class_2505.method_53898()));
                }
            } catch (Exception e) {
                throw new IllegalArgumentException("blueprint " + name + " cannot be read: " + e.getMessage(), e);
            }
        }
        throw new IllegalArgumentException("blueprint " + name + " not found; use blueprint_list first");
    }
}
