package com.dwinovo.numen.task.move;

import com.dwinovo.numen.api.task.TaskResult;
import com.dwinovo.numen.nav.Feet;
import com.dwinovo.numen.nav.NavText;
import com.dwinovo.numen.nav.Survey;
import com.dwinovo.numen.nav.Terrain;
import com.dwinovo.numen.nav.ThrowawayBlocks;
import com.dwinovo.numen.nav.Trip;
import com.dwinovo.numen.nav.Walked;
import com.dwinovo.numen.nav.Walking;
import com.dwinovo.numen.task.base.AbstractCompanionTask;
import com.dwinovo.numen.task.base.Precondition;
import com.dwinovo.numen.pathing.api.Outcome;
import com.dwinovo.numen.pathing.search.Goal;
import com.dwinovo.numen.pathing.search.Goals;
import com.dwinovo.numen.pathing.search.Route;
import com.dwinovo.numen.pathing.spec.RouteSpec;
import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.task.Preparation;
import com.dwinovo.numen.api.task.TaskState;
import com.dwinovo.numen.FailureType;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * 跟着走一阵。默认跟主人,点名了就跟那一只;到点({@link FollowTaskRecord#forTicks})就以成功收场,睡着的也醒来收这个尾
 * ({@link #canRun})。
 *
 * <h2>跟到了就休眠,不是结束</h2>
 * 跟到了(这一趟的目标自己说到了,{@link Goals#within} 落脚点附近 {@code keepWithin} 格)之后
 * {@link #canRun} 返 false:身体让给别人(她可以站着看你、可以被反射拿去吃东西),主人一走远
 * 它自己就醒过来。这跟原版 {@code Goal.canUse()} 是同一个道理——<b>休眠不是失败</b>,不发结果、
 * 不腾槽、不惊动模型。到没到只看目标,这里不另拿距离判"差不多到了";离主人多远只决定要不要起步。
 *
 * <h2>够不着就报出去</h2>
 * 跟着走和 {@code numen.move.walk} 是同一套走法({@link Walking#spec}):可挖可搭,只看价钱,权限层说不许的格是墙。真没有路
 * (隔着权限层不许动的地方、主人拒了又绕不开)就不是暂时的——退避多少次都一样。那就以失败收场,把原因交给模型,它决定换个办法、
 * 或者告诉主人。一个明确的失败原因不能攥在手里站着空算。主人飞在半空时跟的是他脚下能站的地方({@link #anchor}),一般够得着;
 * 真够不着也照样报。派下来那一刻就够不着的,受理之前就判({@link #preparation}),当场回、不受理。
 *
 * <h2>目标没了,主人和别人不一样</h2>
 * <b>主人下线是暂时的</b>——他会回来,所以休眠等着,到点为止。而点名跟的
 * 那只羊死了、或者走出加载范围被卸载了,再等也不会回来:那时收尾报给模型,让它决定下
 * 一步。一套逻辑通吃的话,要么她对着一只死羊站到天荒地老,要么主人一下线任务就没了。
 *
 * <p><b>{@code nav.tick()} 的返回值一个都不能丢</b>:{@link Trip} 收场之后就稳定地是那个结局,
 * 不接住就是她永久定在原地而 {@code task status} 照说"执行中"——主人完全看不出她卡住了。
 * 这里接住的方式就是把它变成任务的结果。
 *
 * <p><b>目标跟着挪</b>:他走出上次定下的落脚点两格外,就把新目标交给在走的这一趟({@link Trip#retarget}),
 * 在走的路还算数就照走,不算数才重搜——挪多远才值得换在这里定。
 */
public final class FollowCompanionTask extends AbstractCompanionTask<FollowTaskRecord, Walked> {

    /** 跟到之后,他比 {@code keepWithin} 多走出这么远才重新起步,免得在临界距离上抖着走走停停。 */
    private static final double RESUME_MARGIN = 2.0;

    /** 上一刻是不是在走——用来只在真正起步/到位时重建导航。 */
    private boolean moving;
    /** 在走的这一趟朝着的落脚点;他挪出它 {@link #RETARGET_DISTANCE} 格外才换目标。 */
    private class_2338 heading;

    /** 他挪出上次的落脚点这么远(格)才把新目标交给在走的这一趟。 */
    private static final double RETARGET_DISTANCE = 2.0;

    /** 受理之前的准备规划到的那条路:第一趟照它走;没有、或已经用过为 null。 */
    private Route seed;
    /** 到点的那一刻(游戏刻);开工之前是 -1。 */
    private long endsAt = -1;

    public FollowCompanionTask(NumenPlayer player, FollowTaskRecord record) {
        super(player, record);
    }

    /** 跟着走是走路:坐着任何载具都先下来。 */
    @Override
    protected List<Precondition> preconditions() {
        return List.of(Precondition.onFoot(player));
    }

    @Override
    public boolean canRun(NumenPlayer companion) {
        if (timeUp()) {
            return true;
        }
        class_1297 target = target(companion);
        if (target == null) {
            // 点名的目标没了:要放它跑一刻才收得了尾(canRun 返 false 的任务不会 tick,
            // 也就永远报不出去)。跟的是主人就单纯睡着等他回来。
            return r.target != null;
        }
        if (moving) {
            // 在走的这一趟到没到,只看它的目标
            return true;
        }
        // 迟滞:走出 keepWithin + margin 才起步——一跟到就起步会让她在临界距离上一步一停地抖
        return companion.method_19538().method_1022(target.method_19538()) > r.keepWithin + RESUME_MARGIN;
    }

    /**
     * 受理之前:要跟的人此刻离她远到要起步时,一次只搜不走地规划过去的路——按同一份规格确证走不到(没有路、要的料没有、权限层
     * 不许……),就是开工后第一趟会报的那句"跟不上",当场回,不受理。预算用完、路伸进没加载的区块只是没搜完,不能证明到不了
     * ({@link Outcome.OutOfBudget}、{@link Outcome.Unloaded}),照样受理:搜出的那条路,或朝他推进的那一截,是第一趟的开头
     * ({@link Trip#prepared})。就在身边、主人不在线,当场就绪。
     */
    @Override
    protected Preparation preparation() {
        class_1297 target = target(player);
        if (target == null || !canRun(player)) {
            return Preparation.READY;
        }
        class_2338 anchor = anchor(target);
        RouteSpec spec = Walking.spec(player.method_51469());
        Survey survey = Survey.of(player, List.of(new Survey.Leg(goal(anchor), spec)), ThrowawayBlocks.factory());
        return new Preparation() {
            @Override
            public Preparation.Readiness poll() {
                List<Survey.Found> found = survey.poll();
                if (found == null) {
                    return null;
                }
                Survey.Found leg = found.get(0);
                if (leg.reached() || unfinished(leg.outcome())) {
                    seed = leg.reached() ? leg.route() : leg.partial();
                    return Preparation.Readiness.READY;
                }
                return Preparation.Readiness.refused(TaskResult.fail(com.dwinovo.numen.script.ErrorKind.NO_PATH,
                        "can't keep up: " + NavText.failure(leg.outcome(), player, Feet.cell(player), anchor, spec,
                                ThrowawayBlocks.factory()),
                        null, value()));
            }

            @Override
            public void cancel() {
                survey.cancel();
            }
        };
    }

    /** 这次规划没搜完:预算用完、路伸进了没加载的区块,没有证据说走不到。 */
    static boolean unfinished(Outcome outcome) {
        return outcome instanceof Outcome.OutOfBudget || outcome instanceof Outcome.Unloaded;
    }

    @Override
    protected void onStart() {
        moving = false;
        if (endsAt < 0) {
            endsAt = player.method_37908().method_8510() + r.forTicks;
        }
    }

    /** 到点了。 */
    private boolean timeUp() {
        return endsAt >= 0 && player.method_37908().method_8510() >= endsAt;
    }

    @Override
    protected TaskState onTick() {
        if (timeUp()) {
            stopNav();
            return TaskState.SUCCESS;
        }
        class_1297 target = target(player);
        if (target == null) {
            if (r.target == null) {
                return TaskState.RUNNING;   // 主人下线:canRun 已经挡住了,这里只是防御
            }
            stopNav();
            fail("the entity you were following is gone (killed, or it left the loaded area)",
                    FailureType.TARGET_LOST);
            return TaskState.FAILED;
        }
        class_2338 anchor = anchor(target);
        if (nav == null) {
            heading = anchor;
            // 受理之前规划好的那条只用在第一趟
            nav = Trip.prepared(player, goal(anchor), Walking.spec(player.method_51469()), seed, anchor);
            seed = null;
        } else if (anchor.method_10262(heading) > RETARGET_DISTANCE * RETARGET_DISTANCE) {
            heading = anchor;
            nav.retarget(goal(anchor), anchor);
        }
        moving = true;
        switch (nav.tick()) {
            case RUNNING -> { }
            case ARRIVED -> {
                stopNav();
                moving = false;
            }
            case FAILED -> {
                // 够不着就是这件活的结果:原因与清单交给模型,别攥着站在原地空算
                String why = nav.failReason();
                FailureType type = nav.failType();
                stopNav();
                fail("can't keep up: " + why, type);
                return TaskState.FAILED;
            }
        }
        // 到点之前不返终态;只有够不着和目标没了才提前收场。
        return TaskState.RUNNING;
    }

    /**
     * 跟着谁。没点名就是主人;点名了就按 UUID 现查——每次都查,因为它随时可能死掉或者
     * 走出加载范围,而那两件事对我们是同一个答案:不在了。
     *
     * <p>不同维度天然落进 null:{@code ServerLevel.getEntity} 只认自己这一层。
     */
    private class_1297 target(NumenPlayer companion) {
        if (r.target == null) {
            var owner = companion.resolveOwnerPlayer();
            return owner == null || owner.method_37908() != companion.method_37908() ? null : owner;
        }
        class_1297 e = ((class_3218) companion.method_37908()).method_66347(r.target);
        return e == null || e.method_31481() ? null : e;
    }

    /** 跟到落脚点 {@code anchor} 附近 {@code keepWithin} 格内。 */
    private Goal goal(class_2338 anchor) {
        return Goals.within(Goals.at(anchor), 0, r.keepWithin);
    }

    /**
     * 跟到哪一格:他所在那一列里身体待得住的地方({@link Terrain#settle})——他站着就是他脚下,悬空(飞行、跳跃、本来就会飞)
     * 时是他下方的地面。那一列都待不住(悬在虚空上)就还是他那一格:那里够不着,于是照实报,而不是假装找到了。
     */
    private class_2338 anchor(class_1297 target) {
        return Terrain.of(player).settle(target.method_24515());
    }

    /** 收尾时她在哪、离跟着的人还差多远(超出说好的距离多少)、这一路做了什么。 */
    @Override
    protected Walked value() {
        class_1297 target = target(player);
        double left = target == null ? 0 : Math.max(0, player.method_19538().method_1022(target.method_19538()) - r.keepWithin);
        return walked(player.method_19538(), Math.round(left * 10.0) / 10.0);
    }

    @Override
    protected String successMessage() {
        // 到点走到 SUCCESS;被换掉、被叫停走的是 cancelledMessage。
        return "followed " + r.who() + " for " + r.forTicks / 20 + " s";
    }
}
