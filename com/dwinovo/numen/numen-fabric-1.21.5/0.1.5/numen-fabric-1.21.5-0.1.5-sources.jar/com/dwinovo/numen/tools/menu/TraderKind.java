package com.dwinovo.numen.tools.menu;

import com.dwinovo.numen.PlayerInv;
import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.permission.Action;
import com.dwinovo.numen.api.sdk.Call;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import com.dwinovo.numen.tools.inventory.InvApi.Stack;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1728;
import net.minecraft.class_1799;
import net.minecraft.class_1914;
import net.minecraft.class_1915;
import net.minecraft.class_1916;
import net.minecraft.class_3851;

/**
 * 村民与流浪商人的交易界面:每一笔的付出(一件或两件)、得到、已用次数与上限、是不是卖空了,村民的等级与经验;选一笔就是
 * {@code SelectTrade}(编号减一),原版自己把付款从背包填进付款格,选完只选不取——结果格的东西用 {@code numen.gui.take} 或
 * {@code numen.gui.quick} 取,和从别的容器里拿东西一样。材料够不够、次数用没用完,原版在结果格出不出东西里体现,读回来结果格没有
 * 这笔的产物就是没成,把要的和带的说出来。
 */
final class TraderKind implements MenuKind.Chooses<class_1728> {

    @Override
    public Class<class_1728> menu() {
        return class_1728.class;
    }

    @Override
    public String name() {
        return "a villager's trade window";
    }

    @Override
    public Screen read(class_1728 menu, NumenPlayer her) {
        class_1916 offers = menu.method_17438();
        List<Screen.Trade> trades = new ArrayList<>();
        for (int i = 0; i < offers.size(); i++) {
            class_1914 offer = offers.get(i);
            List<Stack> pay = new ArrayList<>();
            pay.add(stack(offer.method_19272()));
            if (!offer.method_8247().method_7960()) {
                pay.add(stack(offer.method_8247()));
            }
            trades.add(new Screen.Trade(i + 1, pay, stack(offer.method_8250()), offer.method_8249(), offer.method_8248(),
                    offer.method_8255()));
        }
        class_1297 trader = merchant(her);
        return trader instanceof class_3851 villager
                ? new Screen.Trading(trades, Optional.of(villager.method_7231().comp_3522()),
                        Optional.of(menu.method_19254()))
                : new Screen.Trading(trades, Optional.empty(), Optional.empty());
    }

    /** 用这只商人的交易,是对一只实体的"用":权限层按它裁决。 */
    @Override
    public Action gate(class_1728 menu, NumenPlayer her) {
        class_1297 trader = merchant(her);
        return trader == null ? null : Action.useEntity(trader);
    }

    @Override
    public String choose(class_1728 menu, NumenPlayer her, Pick first, Pick second) {
        if (second != null) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "a trade window takes one trade number", Call.of("numen.gui.view"));
        }
        int n = first.numberIn("trade", menu.method_17438().size());
        class_1914 offer = menu.method_17438().get(n - 1);
        her.packets().selectTrade(n - 1);
        if (!class_1799.method_31577(menu.method_7611(2).method_7677(), offer.method_8250())) {
            throw refused(her, n, offer);
        }
        return "selected trade " + n + ": the result slot (window slot 2) holds " + Receipt.stack(menu.method_7611(2).method_7677());
    }

    /** 这笔没备好:卖空了,或者她带的付不起——读到的事实。 */
    private static ApiError refused(NumenPlayer her, int n, class_1914 offer) {
        if (offer.method_8255()) {
            return new ApiError(ErrorKind.FAILED, "trade " + n + " is sold out (" + offer.method_8249() + " of "
                    + offer.method_8248() + " used)", Call.of("numen.gui.view"));
        }
        List<String> asks = new ArrayList<>();
        for (class_1799 cost : new class_1799[] {offer.method_19272(), offer.method_8247()}) {
            if (!cost.method_7960()) {
                asks.add(Receipt.stack(cost) + " (you carry " + PlayerInv.carriedCount(her.method_31548(), cost.method_7909())
                        + ")");
            }
        }
        return new ApiError(ErrorKind.FAILED, "trade " + n + " is not ready: it asks for " + String.join(" and ", asks),
                Call.of("numen.gui.view"));
    }

    private static Stack stack(class_1799 stack) {
        return Stack.of(stack, stack.method_7947());
    }

    /** 此刻在和她交易的那只商人(在她附近的实体里找):原版把"谁在和谁交易"记在商人身上。 */
    private static class_1297 merchant(NumenPlayer her) {
        for (class_1297 each : her.method_37908().method_8390(class_1297.class, her.method_5829().method_1014(16.0),
                e -> e instanceof class_1915 m && m.method_8257() == her)) {
            return each;
        }
        return null;
    }
}
