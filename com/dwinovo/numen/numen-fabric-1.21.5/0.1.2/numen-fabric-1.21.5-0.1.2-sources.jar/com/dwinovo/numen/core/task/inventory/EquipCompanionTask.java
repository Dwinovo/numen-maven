package com.dwinovo.numen.core.task.inventory;
import com.dwinovo.numen.core.PlayerInv;
import com.dwinovo.numen.core.FailureType;

import com.dwinovo.numen.task.TaskState;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.core.task.base.AbstractCompanionTask;
import com.dwinovo.numen.core.task.base.Precondition;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

/**
 * {@code equip_item} on the player body. Equips the way a real player does — by holding the item and
 * RIGHT-CLICKING it: the item's own use behaviour does the equip, with the proper sound + events and
 * routing to the correct slot. That one native path covers vanilla armor (the {@code Equippable}
 * component), shields, AND modded accessories like Curios / Trinkets (their right-click handler slots
 * the item into a curio slot) — no per-mod integration. Explicit main/off-hand requests are a direct
 * item-conserving placement instead; a vanilla-slot direct set is the fallback if the right-click
 * didn't take. One-tick (all work in {@link #onStart()}).
 */
public final class EquipCompanionTask extends AbstractCompanionTask<EquipTaskRecord> {

    private String message = "";
    private boolean equipped = false;
    private String slotName = "";
    private TaskState result;

    public EquipCompanionTask(NumenPlayer player, EquipTaskRecord record) {
        super(player, record);
    }

    @Override
    protected List<Precondition> preconditions() {
        return List.of(() -> findItem(player.method_31548()) >= 0 ? null
                : new Precondition.Failure("no " + r.label + " in inventory to equip",
                        FailureType.NO_MATERIAL));
    }

    @Override
    protected void onStart() {
        class_1661 inv = player.method_31548();
        int invSlot = findItem(inv);   // precondition guarantees >= 0

        // Explicit hand placement: just select / set it, no right-click (we don't want to "use" a
        // shield or tool, only hold it).
        if (r.slot == class_1304.field_6173) {
            player.holdInHand(invSlot);
            succeed("holding " + r.label + " in main hand", "mainhand");
            return;
        }
        if (r.slot == class_1304.field_6171) {
            directSet(class_1304.field_6171, invSlot, inv.method_5438(invSlot).method_46651(1));
            return;
        }

        // Default: equip via a native right-click. The held item's use behaviour equips it — vanilla
        // armor (Equippable), or a Curios/Trinkets accessory (its mod's right-click handler) — to the
        // right slot, with sound + events. Confirmed by the item leaving the 36 carried slots
        // (a count that includes the armor slots never changes: the helmet only moved from the
        // hotbar to the head, and the reply would then lie "holding … in main hand").
        class_1792 want = inv.method_5438(invSlot).method_7909();
        int before = PlayerInv.carriedCount(inv, want);
        player.holdInHand(invSlot);
        player.field_13974.method_14256(player, player.method_37908(), player.method_6047(), class_1268.field_5808);
        if (PlayerInv.carriedCount(inv, want) < before) {
            succeed("equipped " + r.label + slotSuffix(want), foundVanillaSlot(want));
            return;
        }

        // Right-click didn't equip it (e.g. an item with no equip-on-use behaviour). Fall back to a
        // direct vanilla-slot set. The item is currently held in the selected hotbar slot.
        class_1799 one = inv.method_5438(invSlot).method_46651(1);
        class_1304 target = resolveSlot(one);
        if (target == class_1304.field_6173) {
            succeed("holding " + r.label + " in main hand", "mainhand");   // already in hand
            return;
        }
        if (target != null) {
            directSet(target, inv.method_67532(), one);
            return;
        }
        fail(r.label + " can't be equipped" + (r.slot != null ? " in " + r.slot.method_5923() : ""),
                FailureType.UNKNOWN);
    }

    @Override
    protected TaskState onTick() {
        return result != null ? result : TaskState.FAILED;   // fail() short-circuits before here
    }

    /** No nav / overlay to release. */
    @Override
    protected void cleanup() {}

    /** Direct, item-conserving set of one item into {@code slot}, stowing whatever was there (and
     *  dropping it only if the inventory is full). Used for off-hand and as the right-click fallback. */
    private void directSet(class_1304 slot, int fromSlot, class_1799 one) {
        class_1661 inv = player.method_31548();
        class_1799 previous = player.method_6118(slot).method_7972();
        if (!previous.method_7960() && previous.method_7909() == one.method_7909()) {
            succeed(r.label + " already equipped in " + slot.method_5923(), slot.method_5923());
            return;
        }
        inv.method_5434(fromSlot, 1);
        player.method_5673(slot, one);
        if (!previous.method_7960()) {
            inv.method_7394(previous);                              // mutates `previous` down by what fit
            if (!previous.method_7960() && player.method_37908() instanceof class_3218 sl) {
                player.method_5775(sl, previous);       // overflow → drop(1.21.2+ 首参收 ServerLevel)
            }
        }
        inv.method_5431();
        succeed("equipped " + r.label + " in " + slot.method_5923(), slot.method_5923());
    }

    private int findItem(class_1661 inv) {
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 st = inv.method_5438(i);
            if (!st.method_7960() && st.method_7909() == r.item) return i;
        }
        return -1;
    }

    /** The vanilla equipment slot this item routes to, honouring an explicit non-hand request. */
    private class_1304 resolveSlot(class_1799 stack) {
        if (r.slot == null) return player.method_32326(stack);
        if (r.slot == class_1304.field_6173 || r.slot == class_1304.field_6171) return r.slot;
        return player.method_32326(stack) == r.slot ? r.slot : null;
    }

    /** After a right-click equip, find which vanilla armor/off-hand slot now holds the item (null = a
     *  modded accessory slot we can't name). */
    private String foundVanillaSlot(class_1792 want) {
        for (class_1304 s : class_1304.values()) {
            if (s == class_1304.field_6173) continue;
            if (player.method_6118(s).method_7909() == want) return s.method_5923();
        }
        return null;
    }

    private String slotSuffix(class_1792 want) {
        String s = foundVanillaSlot(want);
        return s != null ? " in " + s : " (accessory slot)";
    }

    private void succeed(String msg, String slot) {
        message = msg;
        slotName = slot == null ? "" : slot;
        equipped = true;
        result = TaskState.SUCCESS;
        succeed();   // base: park + stamp SUCCESS so the equip finalizes this same tick
    }

    @Override
    protected Map<String, Object> resultData() {
        Map<String, Object> data = new HashMap<>();
        data.put("item", r.label);
        if (equipped && !slotName.isEmpty()) data.put("slot", slotName);
        return data;
    }

    @Override
    protected String successMessage() {
        return message;
    }

    @Override
    protected String cancelledMessage() {
        return "equip interrupted";
    }
}
