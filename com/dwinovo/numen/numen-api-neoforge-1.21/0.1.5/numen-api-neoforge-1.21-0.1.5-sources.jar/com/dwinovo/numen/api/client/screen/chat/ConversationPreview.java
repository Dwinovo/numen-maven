package com.dwinovo.numen.api.client.screen.chat;

import com.dwinovo.numen.api.agent.conversation.Conversation;
import com.dwinovo.numen.api.agent.conversation.Transcript;
import com.dwinovo.numen.api.agent.llm.ConvoState;
import com.dwinovo.numen.api.client.agent.RemoteCompanions;
import com.dwinovo.numen.api.client.agent.Conversations;
import com.dwinovo.numen.api.client.agent.NumenRoster;
import com.dwinovo.numen.api.client.chat.ChatDisplayModes;
import com.dwinovo.numen.api.data.ModLanguageData;
import net.minecraft.client.resources.language.I18n;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 左栏会话列表里每行的"最后一句"(Telegram 那一行淡字):谁说的、说了什么、什么时候。
 * 来源和面板正文同一份——成员日志按会话印归并后的最后一条可见消息;所以左栏和正文永远对得上。
 *
 * <p>归并要排序,左栏每帧要画每一行,所以按"会话 id + 各成员日志行数"缓存:行数没变,最后一句就没变。
 */
public final class ConversationPreview {

    /** 一行:显示文本(多人会话里带说话人),和它的时间戳。 */
    public record Line(String text, long ts) {}

    /** {@code saidAt} = 她们每句可见的话的时间戳,升序;数未读只比大小,不每帧重新解析。 */
    private record Cached(int lines, Line line, List<Long> saidAt) {}

    private static final Map<String, Cached> CACHE = new HashMap<>();

    private ConversationPreview() {}

    /** 这个会话最后一句;还没说过话是 null。 */
    public static Line last(Conversation c) {
        return cached(c).line();
    }

    /** {@code since} 之后她们说了几句(主人自己的话不算未读)。 */
    public static int unread(Conversation c, long since) {
        int n = 0;
        for (long ts : cached(c).saidAt()) {
            if (ts > since) n++;
        }
        return n;
    }

    private static Cached cached(Conversation c) {
        Conversations convos = Conversations.instance();
        // 和面板正文同一个出口:服务端大脑下它按会话要最近一页并接上实时推来的行
        List<Transcript.Entry> merged = RemoteCompanions.transcript(c.id());
        int total = merged.size();
        Cached hit = CACHE.get(c.id());
        if (hit != null && hit.lines() == total) {
            return hit;
        }
        boolean group = convos.soloOf(c) == null;
        Line out = null;
        List<Long> saidAt = new java.util.ArrayList<>();
        for (Transcript.Entry e : merged) {
            if (e.ts() > 0 && e.msg() instanceof ConvoState.Msg.Assistant a
                    && !ChatDisplayModes.current().assistantText(a.turn().content()).isBlank()) {
                saidAt.add(e.ts());
            }
        }
        for (int i = merged.size() - 1; i >= 0 && out == null; i--) {
            Transcript.Entry e = merged.get(i);
            if (e.msg() instanceof ConvoState.Msg.User u) {
                String t = flat(com.dwinovo.numen.api.agent.conversation.Quote.parse(
                        ChatDisplayModes.current().userText(u.content())).body());   // 引的那句不进预览
                if (!t.isEmpty()) {
                    out = new Line(I18n.get(ModLanguageData.Keys.RAIL_YOU) + ": " + t, e.ts());
                }
            } else if (e.msg() instanceof ConvoState.Msg.Assistant a) {
                String t = flat(ChatDisplayModes.current().assistantText(a.turn().content()));
                if (!t.isEmpty()) {
                    // 群里标谁说的;就他俩不标——只可能是她
                    String who = group ? NumenRoster.instance().name(e.companion()) : null;
                    out = new Line(who == null ? t : who + ": " + t, e.ts());
                }
            }
        }
        Cached fresh = new Cached(total, out, List.copyOf(saidAt));
        CACHE.put(c.id(), fresh);
        return fresh;
    }

    /** 压成一行:换行变空格,好塞进一行淡字里。 */
    private static String flat(String s) {
        return s == null ? "" : s.replace('\n', ' ').replace('\r', ' ').strip();
    }
}
