package com.dwinovo.numen.api.client.chat;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.client.screen.UiTheme;
import com.dwinovo.numen.api.mixin.inject.ChatComponentAccessor;

import net.minecraft.client.GuiMessage;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 同伴对话在聊天框里的唯一出样口——聊天框是不开面板时的全量实时面:
 *
 * <pre>
 * 你 → sadasdas:帮我看看矿洞          (整行暗灰;语音带「(语音)」记号)
 * sadasdas:我看看…▌                    (流式行:边生成边长,完成后定格)
 * ⚙ sadasdas · move_goto               (工具调用,最暗的状态行)
 * sadasdas:到了,矿洞在这边……          (回复全文,不折叠)
 * </pre>
 *
 * 统一格式统一配色,整体比真人聊天暗一层;没有尖括号,不冒充真人发言。
 * 瞬态提示(没能送达/先选人/没听清)不进聊天框,走 {@code TalkHint#flash}。
 *
 * <p>流式实现:原版聊天行不可编辑,靠"摘掉旧行 → 补一条更长的新行"
 * 模拟打字机(经 {@link ChatComponentAccessor});每个同伴最多一条在飞行,
 * 完成后由定格行接替。在飞行不记日志,只有定格行经 {@code addMessage} 进一次日志。
 * 客户端主线程专用。
 */
public final class ChatLines {

    /** 自己发言:暗一层的灰(知道自己说了什么,回显只为日志完整)。 */
    private static final int OWN = 0xAAB0B8;
    /** 同伴正文:近白——正文必须一眼可读,"退后"交给名字配色与工具行。 */
    private static final int TEXT = 0xE8EBEF;
    /** 每个同伴的在飞流式行(摘行用的句柄)。 */
    private static final Map<UUID, GuiMessage> LIVE = new HashMap<>();

    private ChatLines() {}

    /**
     * 主人发出的一句(文字或语音),回显为暗灰字幕行。
     *
     * <p>只记"你说了这句话",不载她此刻的处境:聊天行是不可变的日志,印上去的状态
     * 她一开口就成了假话,还永远挂在那儿。状态归活的界面——头顶气泡第二行写她正在
     * 干什么,面板把还没被消费的那条画成 ⌛ 泡。
     */
    public static void owner(String companionName, String text, boolean voice) {
        add(Component.translatable(voice ? Keys.CHAT_OWNER_VOICE : Keys.CHAT_OWNER, companionName, text)
                .withColor(OWN));
    }

    /** 同伴的回复定格行:加粗着色名字 + 近白正文,全文显示不折叠。 */
    public static void companion(String companionName, String text) {
        String flat = text.replaceAll("\\s+", " ").trim();
        if (flat.isEmpty()) {
            return;
        }
        add(name(companionName).append(Component.literal(flat).withColor(TEXT)));
    }

    /** 系统性提醒(连接失败/配置问题):琥珀警示行——玩家必须知道发生了什么,
     *  不能让失败沉进日志里变成"已读不回"。 */
    public static void notice(String companionName, String text) {
        add(Component.literal("⚠ " + companionName + ":").withColor(0xE0A53A)
                .append(Component.literal(text).withColor(OWN)));
    }

    /**
     * 流式行更新:摘掉这只同伴的旧行,补上更长的新行(带光标记号)。
     * 新行永远落在聊天最新位,像正在打字。
     */
    public static void streaming(UUID companion, String companionName, String partial) {
        // 崩溃护栏:摘行手术碰的是原版聊天内部结构,出错宁可这帧不更新
        com.dwinovo.numen.api.client.ui.SafeUi.run("chat-streaming", () -> {
            ChatComponent chat = Minecraft.getInstance().gui.getChat();
            ChatComponentAccessor acc = (ChatComponentAccessor) chat;
            removeLive(acc, companion);
            MutableComponent line = name(companionName)
                    .append(Component.literal(partial).withColor(TEXT))
                    .append(Component.literal("▌").withColor(OWN));
            // 同原版 addMessage(Component) 的标签与入栏顺序,只是不记日志:
            // 日志里只留定格行,不留打字机的每一帧
            Minecraft mc = Minecraft.getInstance();
            GuiMessage message = new GuiMessage(mc.gui.getGuiTicks(), line, null,
                    mc.isSingleplayer() ? GuiMessageTag.systemSinglePlayer() : GuiMessageTag.system());
            acc.numen$addMessageToDisplayQueue(message);
            acc.numen$addMessageToQueue(message);
            LIVE.put(companion, message);
        });
    }

    /** 流式收尾:摘掉在飞行(定格行由调用方随后补上)。 */
    public static void streamingDone(UUID companion) {
        com.dwinovo.numen.api.client.ui.SafeUi.run("chat-streaming", () -> {
            ChatComponent chat = Minecraft.getInstance().gui.getChat();
            removeLive((ChatComponentAccessor) chat, companion);
        });
    }

    /** 退出世界:清句柄(聊天框本身随会话销毁)。 */
    public static void clearLive() {
        LIVE.clear();
    }

    private static void removeLive(ChatComponentAccessor acc, UUID companion) {
        GuiMessage old = LIVE.remove(companion);
        if (old != null && acc.numen$allMessages().remove(old)) {
            acc.numen$refreshTrimmedMessages();
        }
    }

    /** 加粗的主题色名字前缀——同伴行的视觉锚点。 */
    private static MutableComponent name(String companionName) {
        return Component.literal(companionName + ":")
                .withColor(UiTheme.current().reply() & 0xFFFFFF)
                .withStyle(s -> s.withBold(true));
    }

    private static void add(Component line) {
        Minecraft.getInstance().gui.getChat().addMessage(line);
    }
}
