package com.dwinovo.numen.plugins;

import com.dwinovo.numen.ModJar;
import com.dwinovo.numen.plugins.ysm.Ysm;
import com.dwinovo.numen.plugins.ysm.YsmHost;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModList;

import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * 本加载器内嵌了哪些联动、各自要谁——以及加载器替它们做的那几件事。
 *
 * <p>清单在这里,不做扫描:内嵌联动是<b>闭合集合</b>,数量由我们自己定;扫描是给开放
 * 集合用的。列在一处,"现在内嵌了哪些、各自要谁"一眼答得完。闸门本身三个加载器共用,
 * 见 {@link Gate}。
 *
 * <h2>联动的类型只许出现在嵌套类里</h2>
 * 本类自己的方法(含 lambda 编译出来的合成方法)一个都不能提联动的类型:校验器为了核对
 * 参数类型会把它们提前加载,而开发运行(datagen、runClient)里联动不在类路径上——
 * compileOnly——提前加载就是 {@code ClassNotFoundException},整个模组入口跟着炸。
 * 各联动的接线放进各自的嵌套类,闸门开了才碰到它。
 */
public final class Builtin {

    private Builtin() {}

    public static void registerAll(IEventBus modBus) {
        Gate gate = new Gate(ModList.get()::isLoaded, ModJar::find);
        gate.open("yes_steve_model", "ysm", content -> () -> YsmOnForge.install(content));
        gate.open("touhou_little_maid", "tlm",
                content -> () -> com.dwinovo.numen.plugins.tlm.NumenTlm.install(modBus, content));
        gate.open("kaleidoscope_cookery", "kaleidoscope",
                content -> () -> com.dwinovo.numen.plugins.kaleidoscope.NumenKaleidoscope.install(content));
        gate.open("curios", "curios", () -> com.dwinovo.numen.plugins.curios.NumenCurios::install);
        gate.open("ftbquests", "ftbquests",
                content -> () -> com.dwinovo.numen.plugins.ftbquests.NumenFtbQuests.install(content));
        // 这一代 Forge 上的 Litematica 是 Forgematica,它登记的模组 id 是 forgematica(包与类同 Litematica)
        gate.openClientMod(LitematicaOnForge.TARGET_MOD, "litematica", content -> () -> LitematicaOnForge.install(content));
        gate.openClientMod("jei", "jei", () -> JeiOnForge::install);
    }

    /** JEI 联动要加载器答的一件事:流体成分在 Forge 上是 {@code FluidStack},数量直接是毫桶。 */
    private static final class JeiOnForge implements com.dwinovo.numen.plugins.jei.JeiHost {
        static void install() {
            com.dwinovo.numen.plugins.jei.NumenJei.install(new JeiOnForge());
        }

        @Override
        public long milliBuckets(Object fluid) {
            return ((net.minecraftforge.fluids.FluidStack) fluid).getAmount();
        }
    }

    /** Litematica(Forge 上是 Forgematica)联动不需要加载器替它做什么事:函数都在主人的客户端上跑。 */
    private static final class LitematicaOnForge {
        static final String TARGET_MOD = "forgematica";

        static void install(Path content) {
            com.dwinovo.numen.plugins.litematica.NumenLitematica.install(TARGET_MOD, content);
        }
    }

    /** YSM 联动只写原版;它要的加载器专属的两件事,Forge 的答案在这里。 */
    private static final class YsmOnForge implements YsmHost {
        static void install(Path content) {
            com.dwinovo.numen.plugins.ysm.NumenYsm.install(new YsmOnForge(), content);
        }

        @Override
        public void onServerTick(Consumer<MinecraftServer> listener) {
            MinecraftForge.EVENT_BUS.addListener((TickEvent.ServerTickEvent e) -> {
                // Forge 的 tick 事件一 tick 发两次(START/END),不判 phase 会跑两遍
                if (e.phase == TickEvent.Phase.END) listener.accept(e.getServer());
            });
        }

        @Override
        public Ysm.Storage storage() {
            return Ysm.Storage.FORGE;
        }
    }
}
