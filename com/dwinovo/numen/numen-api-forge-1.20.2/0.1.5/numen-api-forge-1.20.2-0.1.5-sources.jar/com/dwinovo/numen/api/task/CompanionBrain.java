package com.dwinovo.numen.api.task;

import com.dwinovo.numen.api.entity.NumenPlayer;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;

/**
 * 一具身体的调度器——{@code CompanionTickDispatcher} 按 UUID 存的那个值。
 *
 * <p>每刻问一次谁拿身体({@link TaskSelector}),然后把完成的结果送出去。
 *
 * <pre>
 * 1. 反射     多个,按注册号(小的先)   等模型就晚了(摔落/换气/自卫/进食/脱困)
 * 2. 同步     0 或 1 个                回合挂着等它,有界短
 * 3. 当前任务 0 或 1 个                主人说什么就是什么
 * 4. 空闲姿态 多个                     没别的事可做时(说话时看着主人)
 * </pre>
 *
 * <h2>没有链、没有优先级数字</h2>
 * 层是固定的三层,层内除了反射都最多一个候选——<b>没有任何需要比较的地方</b>。
 * 让每种行为各当一条竞价链的话,每加一种常驻行为就多一条链、多一个要调的浮点数,
 * 而她下一秒干什么会取决于一堆主人看不见的分数。反射之间的先后写在注册号上,
 * 与原版 {@code addGoal(int priority, goal)} 同一惯例。
 *
 * <p>常驻和一次性也不再是两种东西:同一个 {@link Task} 放进第 3 层,
 * {@code tick()} 返终态就是有界的(干完腾位),永远返 RUNNING 就是常驻的
 * (占着直到主人换掉它)。
 */
final class CompanionBrain {

    /** 结算完等着送回主人的记录。 */
    private final Deque<TaskRecord<?>> outbox = new ArrayDeque<>();

    /** 回合挂着等的同步动作。 */
    final TaskSlot sync = new TaskSlot(outbox::addLast, this::letGo);
    /** 她现在在做的事:钓鱼、跟随、挖 64 块——常驻还是一次性只看 tick 返不返终态。 */
    final TaskSlot current = new TaskSlot(outbox::addLast, this::letGo);
    /** 受理之前在准备的那一次调用:结论出来才受理进 {@link #current},见 {@link Preparation}。 */
    final Preparing preparing = new Preparing();

    private final List<Task> reflexes;
    /** 空闲姿态:没别的事做时才轮到,连身体都不算真正占用。视线一面、跳一面,同时成立时都做。 */
    private final List<Task> idlePoses;
    /** 水里的漂浮:不是哪一层的出价,是身体的基本面,每刻在谁拿身体之后补一手,见 {@link FloatChain}。 */
    private final com.dwinovo.numen.api.task.chain.FloatChain floating = new com.dwinovo.numen.api.task.chain.FloatChain();

    /**
     * 重启前留下、还没接回来的那件活:身体进世界那一刻从落盘记录接手,第一次 tick 时取走重放;那之前派下新活
     * 就被新活顶替。null = 没有,或者已经取走。见 {@link TaskPersistence}。
     */
    private TaskPersistence.LeftOver leftOver;

    /** 这个大脑伺候的那具身体。首次 tick 时认下，以后不换。 */
    private NumenPlayer body;

    /** 上一刻的赢家,用来在切换的那一刻(而不是每刻)通知它丢了身体。 */
    private Task holder;

    /** 进度变化最快多久推一次(刻)。一秒足够"在动"的观感,又不至于每刻一个包。 */
    private static final int TASK_PUSH_GAP_TICKS = 20;

    /** 上一次推给主人的任务 id(""=闲着)。 */
    private String pushedTaskId = "";
    /** 上一次推给主人的那行人话——进度写在里面,它一变主人就该看见。 */
    private String pushedDescribe = "";
    /** 距上次推过了几刻。 */
    private int ticksSinceTaskPush;

    CompanionBrain() {
        this.reflexes = List.copyOf(BrainChains.build());
        // 说话时看着主人排在当前任务<b>之下</b>——她挖着矿跟你说话不回头,
        // 这是旧调度里就有的关系(它的出价本来就低于 LLM 基准价),不是新决定。
        this.idlePoses = List.of(new com.dwinovo.numen.api.task.chain.SpeakingLookChain());
    }

    /**
     * 还是不是同一具身体。
     *
     * <p>同伴的 UUID 跨存档不变，身体实例却是新的。而任务把身体记在自己身上
     * ({@code AbstractCompanionTask.player} 是 final 的)，所以一个大脑<b>不能跨身体复用</b>：
     * 旧任务会拿旧 {@code ServerLevel} 去读方块，而那个 level 记的主线程早就结束了，
     * {@code getChunk} 会把活派进一个再也没人抽取的队列然后 {@code join()} —— 新 Server thread
     * 永久 park，世界再也加载不出来。
     *
     * <p>正常情况下关服就会把整表作废({@code ServerLifecycle})，轮不到这里。它是不变式本身：
     * 哪天又有哪张静态表漏了，最坏是大脑重建，不是服务端线程死锁。
     */
    boolean boundTo(NumenPlayer companion) {
        return body == null || body == companion;
    }

    /**
     * 这具身体换了驱动者(被反射或同步动作顶掉、槽里的活被新活换掉):旧驱动者按着的键一律松开——键盘全松,鼠标挖掘进度清零、
     * 右键放开——新的从一具干净的身体开始。松手只在这一处:任务被顶掉或换掉时不必各自记得松,它们只管留着或收掉自己的逻辑状态。
     */
    private void letGo(NumenPlayer companion) {
        companion.controls().releaseAll();
        companion.mouse().releaseAll();
    }

    /** 绑着的那具身体已经离开世界了 —— 这才是"该换大脑"。 */
    boolean boundBodyGone() {
        return body == null || body.isRemoved();
    }

    /** 身体进世界那一刻:接手重启前留下的那件活。 */
    void inherit(TaskPersistence.LeftOver left) {
        leftOver = left;
    }

    /** 取走重启前留下的那件活(只有一次);没有就是 null。 */
    TaskPersistence.LeftOver takeLeftOver() {
        TaskPersistence.LeftOver left = leftOver;
        leftOver = null;
        return left;
    }

    /**
     * 往当前任务槽派一件新活({@code runner} 是跑它的任务,准备过的就是准备它的那一个)——派活只有这一个入口。重启前留下、
     * 还没接回来的那件由它顶替,和槽里原有的活被换掉一样告诉她。
     */
    void assign(NumenPlayer companion, TaskRecord<?> record, Task runner) {
        TaskPersistence.LeftOver superseded = takeLeftOver();
        if (superseded != null) {
            TaskPersistence.superseded(companion, superseded);
        }
        current.put(companion, record, runner);
    }

    void tick(NumenPlayer companion) {
        body = companion;
        // 准备不占身体:先问它有没有结论,就绪的这一刻受理进槽,接着和槽里的活一样参加这一刻的选择
        preparing.tick();
        floating.release(companion);
        Task winner = TaskSelector.select(reflexes, slotTask(sync, companion),
                slotTask(current, companion), idlePoses, companion);

        if (holder != null && holder != winner) {
            holder.stop(companion, Task.StopReason.PREEMPTED);
            letGo(companion);
        }
        holder = winner;

        // 没轮到的槽这一刻不烧预算——身体被别人占着不是它的错。
        if (winner != syncProxy) {
            sync.freeze();
        }
        if (winner != currentProxy) {
            current.freeze();
        }

        if (winner == syncProxy) {
            sync.tick(companion);
        } else if (winner == currentProxy) {
            current.tick(companion);
        } else if (winner != null) {
            winner.tick(companion);
        }

        // 谁拿身体都一样:没人按移动和跳跃键、也没沉在水下时,身体自己浮着
        floating.assist(companion);

        // 每刻结算:主人按停止会在带外把记录标成终态,而客户端串行的派发器会一直
        // 卡到那一个结果送出——不能等这个槽下次赢了才结算。
        sync.settleIfTerminal(companion);
        current.settleIfTerminal(companion);
        // 手上的活干完了就把记录抹掉,免得重启后凭空捡回一件早就完成的活。
        if (current.isEmpty() && !wasIdle) {
            TaskPersistence.forget(companion);
        }
        if (current.isEmpty() && sync.isEmpty()) {
            // 她闲下来了:被任务按住的本能一律解除。按住是临时的,不该指望谁去显式还
            // —— 任务可能被抢占、被换掉、身体可能没了,那些路径上没人有机会解锁。
            companion.resumeAllReflexes();
        }
        wasIdle = current.isEmpty();
        // 顺序有意义,别调回来:先让状态归位,再宣布结果。
        //
        // task_finished 一到客户端就<b>同步</b>开一轮(急件),而组装请求那一刻会读
        // <current_task>。所以宣布在前的话,她拿到的必然是上一次推的旧进度——限速是
        // 一秒一推,那份快照可能差着几十个。表现是任务明明干完了,她还在说"还差一点
        // 我给你收尾",因为镜像那段的措辞("This background call is ACTIVE")比事件硬。
        //
        // 两个包在同一刻按调用序发出、按发出序到达,所以这不是偶发竞态:宣布在前就<b>每次</b>
        // 都错。把清空排在前面,她读到的就是"已经空了"。
        syncCurrentTask(companion);
        shipResults(companion);
    }

    /**
     * 把「她现在在做什么」推给主人——<b>槽变了才推</b>。
     *
     * <p>叫在每个改动槽的地方(这里、死亡丢弃、离场结算),因为槽的转换只发生在本类里,
     * 所以这就是那件事的唯一出口:派发、重放、被顶替、干完、死亡清空,客户端看到的是
     * 同一条消息。客户端不推断,只照抄——它看不见重放起来的活。
     */
    private void syncCurrentTask(NumenPlayer companion) {
        TaskRecord<?> rec = current.record();
        String id = rec == null ? "" : rec.publicId();
        String desc = rec == null ? "" : rec.describe();
        ticksSinceTaskPush++;
        // 换活立刻推;同一件活只有那行人话变了才推(进度就写在里面),而且限速——
        // 不限速的话「挖 7/64」每刻都在变,一秒 20 个包;只在换活时推又会让进度
        // 永远停在受理那一刻,主人看着像卡住了。
        boolean swapped = !id.equals(pushedTaskId);
        if (!swapped && (desc.equals(pushedDescribe) || ticksSinceTaskPush < TASK_PUSH_GAP_TICKS)) {
            return;
        }
        pushedTaskId = id;
        pushedDescribe = desc;
        ticksSinceTaskPush = 0;
        com.dwinovo.numen.api.agent.request.TaskReport msg;
        if (rec == null) {
            msg = com.dwinovo.numen.api.agent.request.TaskReport.none();
        } else {
            long startedTick = Math.max(0, rec.getStartedGameTime());
            long elapsedMs = Math.max(0, companion.level().getGameTime() - startedTick) * 50L;
            msg = new com.dwinovo.numen.api.agent.request.TaskReport(id, rec.getToolName(), desc, rec.activity(),
                    rec.getDeadlineGameTime() >= TaskRecord.NO_DEADLINE, elapsedMs);
        }
        // 她的大脑直接收这一份(主人在不在线都要,她下一轮读 <current_task>)
        com.dwinovo.numen.api.brain.CompanionLoops.get(companion.getUUID()).ifPresent(brain -> brain.onCurrentTask(msg));
    }

    /** 上一刻当前任务槽是不是空的——用来只在"刚变空"那一刻清记录,不必每刻写盘。 */
    private boolean wasIdle = true;

    /** 死亡:丢掉在跑的任务与在准备的调用。 */
    void dropActiveNoResult(NumenPlayer companion) {
        // 在准备的那次调用也不回结果:客户端按死因结算了在飞的调用
        preparing.drop();
        sync.dropNoResult(companion);
        current.dropNoResult(companion);
        holder = null;
        // 死亡把这件活的前提一并带走了:工具和材料掉在尸体旁,位置从矿洞变成了主人身边。
        // 所以登记也得抹掉 —— 不抹的话复活后的新大脑会照着旧登记重放一遍
        // (TaskPersistence 是给"身体没了但意图还在"写的:重启、休眠、换肤重建),
        // 于是她空着手回去接着挖,而模型刚收到的是 task_finished(interrupted)。
        // 要不要接着干由她自己看了事件再决定,不由代码替她决定。
        TaskPersistence.forget(companion);
        syncCurrentTask(companion);
    }

    /** 身体离开世界:在准备的调用回一条没开始的结果,两个槽就地结算(它们不会再被 tick),结果照送。 */
    void finalizeActive(NumenPlayer companion) {
        preparing.withdraw(TaskRecord.StopCause.BODY_LEFT.words());
        sync.finalizeInline(companion);
        current.finalizeInline(companion);
        holder = null;
        // 这具身体的这一段到头了:按着的键、按住的本能都不带进下一段(Paper 上重生沿用同一个对象,不会像新对象那样天然是干净的)
        letGo(companion);
        companion.resumeAllReflexes();
        // 同 tick():状态先归位再宣布结果 —— 结果一到就同步开轮,那一刻会读 <current_task>。
        syncCurrentTask(companion);
        shipResults(companion);
    }

    // ---- 槽的代理:让选择器能像问一个 Task 那样问一个槽 ----

    private final Task syncProxy = new SlotProxy(() -> sync);
    private final Task currentProxy = new SlotProxy(() -> current);

    private Task slotTask(TaskSlot slot, NumenPlayer companion) {
        if (slot.isEmpty()) {
            return null;
        }
        return slot == sync ? syncProxy : currentProxy;
    }

    /**
     * 把一个槽包成 {@link Task} 给选择器看。
     *
     * <p>选择器只认识"能不能跑",不该知道槽是什么;而槽的 tick 需要结算、送结果,
     * 不是一个纯粹的 Task。这层薄包装让两边各自保持简单。
     */
    private static final class SlotProxy implements Task {
        private final java.util.function.Supplier<TaskSlot> slot;

        SlotProxy(java.util.function.Supplier<TaskSlot> slot) {
            this.slot = slot;
        }

        @Override public boolean canRun(NumenPlayer companion) {
            return slot.get().canRun(companion);
        }

        @Override public TaskState tick(NumenPlayer companion) {
            slot.get().tick(companion);
            return TaskState.RUNNING;
        }

        @Override public void stop(NumenPlayer companion, StopReason why) {
            slot.get().loseBody(companion);
        }

        @Override public String name() {
            return "slot";
        }
    }

    /** 这次调用派下来的那件活:两个槽里在跑的,或者已经结算、还排着没送出去的;都没有是 null。 */
    TaskRecord<?> recordOf(String toolCallId) {
        for (TaskRecord<?> r : new TaskRecord<?>[] {sync.record(), current.record()}) {
            if (r != null && toolCallId.equals(r.getToolCallId())) {
                return r;
            }
        }
        for (TaskRecord<?> r : outbox) {
            if (toolCallId.equals(r.getToolCallId())) {
                return r;
            }
        }
        return null;
    }

    /**
     * 把结算好的记录送出去。
     *
     * <p>异步任务的收尾走 {@link com.dwinovo.numen.api.event.NumenEvents}:主人离线时<b>照发</b>,它自己会进她的收件箱等主人
     * 回来。同步动作的结果交回派它的那次调用自己的回信口({@link TaskDispatch#runSync} 绑在记录上):模型的调用由
     * 网络入口回给发来它的主人客户端——主人已经下线时那条调用属于一个随客户端一起消失的回合,重登后发请求时由
     * {@code ProtocolView} 给它补上失败结果;{@code /numen drive} 派的回给发令人。
     */
    private void shipResults(NumenPlayer companion) {
        while (!outbox.isEmpty()) {
            TaskRecord<?> rec = outbox.pollFirst();
            TaskResult result = rec.getResult();
            if (rec.isAsync()) {
                String status = switch (rec.getState()) {
                    case SUCCESS -> "done";
                    case TIMEOUT -> "timeout";
                    case CANCELLED -> "stopped";
                    default -> "failed";
                };
                com.dwinovo.numen.api.event.NumenEvents.taskFinished(
                        companion, rec.publicId(), rec.getToolName(), status, result, rec.function());
                continue;
            }
            rec.reply().accept(result);
        }
    }
}
