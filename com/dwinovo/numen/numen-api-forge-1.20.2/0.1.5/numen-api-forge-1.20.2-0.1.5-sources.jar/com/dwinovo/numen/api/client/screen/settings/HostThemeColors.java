package com.dwinovo.numen.api.client.screen.settings;

import com.dwinovo.numen.api.client.screen.UiTheme;
import com.dwinovo.numen.api.client.ui.NumenTheme;

/**
 * 宿主主题 → NumenUI 令牌的桥。内嵌进 G 面板的 NumenUI 组件必须穿宿主的
 * 皮肤(纸面底、金色 CTA、主题化正文色),否则就是客厅里的异色地砖;
 * 独立新式屏幕(如 /numen 设置)才用 NumenTheme 自带配色。
 * 按主题实例记忆化——渲染帧内零分配的纪律不破。
 */
public final class HostThemeColors {

    private static UiTheme cachedTheme;
    private static NumenTheme.Colors cached;

    private HostThemeColors() {}

    public static NumenTheme.Colors current() {
        UiTheme th = UiTheme.current();
        if (th != cachedTheme || cached == null) {
            cachedTheme = th;
            cached = bridge(th);
        }
        return cached;
    }

    private static NumenTheme.Colors bridge(UiTheme th) {
        boolean dark = th.isDark();
        return new NumenTheme.Colors(
                th.surface(),                          // panelBg(下拉弹层底=宿主纸面)
                th.cardFill(), th.surfaceBorder(),     // sectionBg / divider
                th.text(), th.textDim(), th.faint(),   // 文字三级:正文;次级(标签、副标题、说明);最淡的只给占位字、时间戳、置灰
                th.cta(), th.fail(), th.ok(), th.run(),   // accent/danger/success/warning(主题琥珀)
                th.aiFill(), th.aiBorder(),            // 输入底/描边(STT 字段=全线基准:奶油底浅灰边)
                // hover:指针反馈的叠加色(不是实底)。chipFill 只有 13% 不透明,铺在
                // 8.6% 的控件底上前后差值肉眼不可辨,动效等于白做;改取主题文字色作
                // 叠加基色——亮主题文字深/暗主题文字浅,亮度感知自动成立。不透明度取 11%:
                // 再深整行就压成一块灰,行里的淡字(副标题、人设摘要)落在上面看不清。
                (th.text() & 0xFFFFFF) | 0x1C000000,
                (th.cta() & 0xFFFFFF) | 0x30000000,    // selected:金色淡染,与宿主选中语言一致
                th.field(), th.text(),                 // badge 底/字
                dark ? mix(th.ok(), 0xFF000000, 0.62f)    // toast info:绿系(正常=成功语义)
                     : mix(th.ok(), 0xFFFFFFFF, 0.78f),
                dark ? mix(th.run(), 0xFF000000, 0.55f)   // toast warn:暗主题深调/亮主题浅调
                     : mix(th.run(), 0xFFFFFFFF, 0.72f),
                dark ? mix(th.fail(), 0xFF000000, 0.55f)  // toast error 同理
                     : mix(th.fail(), 0xFFFFFFFF, 0.72f),
                th.text());                            // toast 文字跟主题
    }

    private static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return 0xFF000000
                | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8)
                | (int) (ab + (bb - ab) * t);
    }
}
