package com.dwinovo.numen.api.client.screen;

import com.dwinovo.numen.api.agent.conversation.Conversation;
import com.dwinovo.numen.api.client.agent.ChatFolders;
import com.dwinovo.numen.api.client.agent.Conversations;
import com.dwinovo.numen.api.client.agent.NumenRoster;
import com.dwinovo.numen.api.client.skin.ConversationFaces;
import com.dwinovo.numen.api.client.ui.Anim;
import com.dwinovo.numen.api.client.ui.NumenStyle;
import com.dwinovo.numen.api.client.ui.NumenTheme;
import com.dwinovo.numen.api.client.ui.TextClip;
import com.dwinovo.numen.api.client.ui.mc.McDrawSurface;
import com.dwinovo.numen.api.client.ui.widget.Button;
import com.dwinovo.numen.api.client.ui.widget.DialogBox;
import com.dwinovo.numen.api.client.ui.widget.Label;
import com.dwinovo.numen.api.client.ui.widget.TextField;
import com.dwinovo.numen.api.data.ModLanguageData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.language.I18n;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.util.Mth;

/**
 * 分组卡(Telegram 的新建/编辑分组):一个名字框,下面一格格会话的头像,点一下收进来、再点拿出去;
 * 收尾 [取消][保存]。名字空着或一个会话都没勾时保存点不动——Telegram 也要名字、也要至少一个会话。
 * 标题、字段、按钮行、键盘与出没都是 {@link ModalCard} 那一套;头像格的画法、勾上的那枚角标照邀请卡。
 *
 * <p>会话多了一屏放不下两行时,头像格上下滚。
 */
public final class FolderEditPanel extends ModalCard {

    /** 屏幕侧的面:改的是哪个分组、存、关卡。 */
    public interface Host {
        /** 开卡时的底稿:编辑是那个分组本身;新建是 id 为 null 的一份(可能已经预先勾上了一个会话)。 */
        ChatFolders.Folder draft();

        void onSave(String name, List<String> conversationIds);

        void onClose();
    }

    private static final int FACE = 26;
    private static final int TILE_W = 40;
    private static final int TILE_GAP = 4;
    private static final int NAME_H = 9;
    /** 一格的高:脸、名字,再留一道缝。 */
    private static final int TILE_H = FACE + 4 + NAME_H + 5;
    /** 头像格露出的行数;更多就滚。 */
    private static final int ROWS = 2;
    /** 名字字段到"会话"那行标签、标签到头像格的距离。 */
    private static final int SECTION_GAP = 8;
    private static final int LABEL_H = 12;

    private final Host host;
    private ChatFolders.Folder draft;
    private String name = "";
    private List<Conversation> everyone = List.of();
    private final Set<String> picked = new LinkedHashSet<>();
    private Button save;
    /** 头像格的几何(渲染与命中共用)。 */
    private int gridX, gridY, gridW, perRow;
    /** 头像格滚了多少像素,按趋近走向 scrollTo。 */
    private float scroll, scrollTo;
    private long lastFrameMs;

    public FolderEditPanel(Host host) {
        this.host = host;
        Minecraft mc = Minecraft.getInstance();
        ui.setClipboard(() -> mc.keyboardHandler.getClipboard(),
                s -> mc.keyboardHandler.setClipboard(s));
        // 文本编辑交给真 EditBox(只收事件、不自绘),画面仍归 NumenUI——见 McTextInput。
        ui.setInputFactory(com.dwinovo.numen.api.client.ui.mc.McTextInput.factory());
    }

    @Override
    void reset() {
        draft = host.draft();
        name = draft.name();
        everyone = Conversations.instance().all();
        picked.clear();
        // 只认此刻还在左栏上的:遣散掉的那只的私聊在这里没有格子,也就不该算"勾着"
        for (Conversation conv : everyone) {
            if (draft.chats().contains(conv.id())) picked.add(conv.id());
        }
        scroll = scrollTo = 0f;
    }

    /** 名字字段 + "会话"标签 + 两行头像格。 */
    @Override
    int height() {
        return heightFor(FIELD_H + SECTION_GAP + LABEL_H + ROWS * TILE_H);
    }

    @Override
    protected void layout(int top) {
        title(t(draft.id() == null ? ModLanguageData.Keys.FOLDER_NEW : ModLanguageData.Keys.FOLDER_EDIT));
        int fx = x + DialogBox.PAD_X, fw = w - DialogBox.PAD_X * 2;
        TextField nameField = field(fx, top, fw, t(ModLanguageData.Keys.FOLDER_NAME),
                new TextField(name, v -> name = v));
        int ry = top + FIELD_H + SECTION_GAP;

        Label chatsLabel = ui.add(new Label(t(ModLanguageData.Keys.FOLDER_CHATS), Label.Role.SECONDARY));
        chatsLabel.setBounds(fx, ry, fw, 9);
        ry += LABEL_H;
        perRow = Math.max(1, (fw + TILE_GAP) / (TILE_W + TILE_GAP));
        gridW = perRow * TILE_W + (perRow - 1) * TILE_GAP;
        gridX = fx;
        gridY = ry;

        save = buttons(t(ModLanguageData.Keys.GUI_SETTINGS_CANCEL), host::onClose,
                t(ModLanguageData.Keys.GUI_SETTINGS_SAVE), this::confirm);
        save.setEnabled(canSave());
        ui.requestFocus(nameField);
    }

    private boolean canSave() {
        return !name.isBlank() && !picked.isEmpty();
    }

    private void confirm() {
        if (!canSave()) return;
        host.onSave(name, new ArrayList<>(picked));
        host.onClose();
    }

    private int rowsTotal() {
        return (everyone.size() + perRow - 1) / perRow;
    }

    private float maxScroll() {
        return Math.max(0, rowsTotal() * TILE_H - ROWS * TILE_H);
    }

    private int tileX(int i) {
        return gridX + (i % perRow) * (TILE_W + TILE_GAP);
    }

    private int tileY(int i) {
        return gridY + (i / perRow) * TILE_H - Math.round(scroll);
    }

    // ---- 宿主转发面 ----

    @Override
    protected void paint(McDrawSurface s, NumenTheme.Colors c, int mouseX, int mouseY, long nowMs, float alpha) {
        float dt = lastFrameMs == 0 ? 0.016f : Math.min(0.1f, (nowMs - lastFrameMs) / 1000f);
        lastFrameMs = nowMs;
        scroll = Anim.approach(scroll, scrollTo, 18f, dt);
        int hot = tileAt(mouseX, mouseY);
        int gridH = ROWS * TILE_H;
        s.pushScissor(gridX - 3, gridY - 3, gridW + 6, gridH + 3);
        for (int i = 0; i < everyone.size(); i++) {
            Conversation conv = everyone.get(i);
            int tx = tileX(i), ty = tileY(i);
            if (ty + TILE_H < gridY || ty > gridY + gridH) continue;
            boolean on = picked.contains(conv.id());
            int fx = tx + (TILE_W - FACE) / 2, fy = ty + 2;
            int border = on ? c.accent() : hot == i ? NumenStyle.hoverBrighten(c.inputBorder()) : c.inputBorder();
            NumenStyle.box(s, fx - 2, fy - 2, FACE + 4, FACE + 4, c.inputBg(), border);
            ConversationFaces.draw(s.graphics(), conv, fx, fy, FACE);
            if (on) {
                // 勾上的右上角一小块强调色,和邀请卡同一个记号
                s.fillRect(fx + FACE - 5, fy - 3, 7, 7, c.accent());
            }
            String shown = TextClip.fit(s, conv.displayName(NumenRoster.instance()::name), TILE_W);
            s.drawText(shown, tx + (TILE_W - s.textWidth(shown)) / 2, fy + FACE + 4,
                    on ? c.textPrimary() : c.textSecondary(), false);
        }
        s.popScissor();
        float max = maxScroll();
        if (max > 0) {
            // 滚得动时右缘一道细滑块:露出的那段占全长的比例
            int barH = Math.max(6, Math.round(gridH * gridH / (gridH + max)));
            int barY = gridY + Math.round((gridH - barH) * (scroll / max));
            s.fillRect(gridX + gridW + 4, barY, NumenStyle.SCROLLBAR_W, barH, c.inputBorder());
        }
        if (save != null) save.setEnabled(canSave());
    }

    /** 鼠标下的那一格(everyone 下标),不在格上或滚出去了则 -1。 */
    private int tileAt(double mx, double my) {
        if (my < gridY || my >= gridY + ROWS * TILE_H || mx < gridX || mx >= gridX + gridW) return -1;
        for (int i = 0; i < everyone.size(); i++) {
            int tx = tileX(i), ty = tileY(i);
            if (mx >= tx && mx < tx + TILE_W && my >= ty && my < ty + TILE_H) return i;
        }
        return -1;
    }

    @Override
    boolean mouseClicked(double mx, double my, int button) {
        int i = tileAt(mx, my);
        if (button == 0 && i >= 0) {
            String id = everyone.get(i).id();
            if (!picked.remove(id)) picked.add(id);
            return true;
        }
        return ui.mouseClicked(mx, my, button);
    }

    @Override
    boolean mouseScrolled(double mx, double my, double delta) {
        if (my >= gridY && my < gridY + ROWS * TILE_H && maxScroll() > 0) {
            scrollTo = Mth.clamp(scrollTo - (float) delta * TILE_H, 0f, maxScroll());
            return true;
        }
        return ui.mouseScrolled(mx, my, delta);
    }

    private static String t(String key) {
        return I18n.get(key);
    }
}
