package com.dwinovo.numen.api.task;

import com.dwinovo.numen.api.entity.NumenPlayer;

import java.util.function.Consumer;

/**
 * 一个装着任务的位置——身体只有两个:同步动作一个,当前任务一个。
 *
 * <p><b>它只做"装着一个任务"这一件事</b>:谁拿身体交给 {@link TaskSelector} 判,
 * 进度与结算由任务自己管。
 *
 * <h2>为什么抢占不结算</h2>
 * 只有任务在<b>自己被 tick 的时候</b>走到终态才结算(建结果 → 进出箱 → 腾位)。
 * 被反射抢占从不结算,所以"抢占—恢复"过的任务照样只发<b>恰好一个</b>结果——
 * 客户端那条 tool_call 等的就是这一个。{@link #freeze} 把被抢占那一刻的 deadline
 * 往后推一刻,免得它在别人占着身体时被冤枉成超时。
 */
final class TaskSlot {

    private final Consumer<TaskRecord<?>> outbox;
    /** 槽里的活被换掉也是换了驱动者:大脑把身体上按着的键与鼠标松开。 */
    private final Consumer<NumenPlayer> letGo;

    private Task task;
    private TaskRecord<?> record;

    TaskSlot(Consumer<TaskRecord<?>> outbox, Consumer<NumenPlayer> letGo) {
        this.outbox = outbox;
        this.letGo = letGo;
    }

    boolean isEmpty() {
        return record == null;
    }

    TaskRecord<?> record() {
        return record;
    }

    /** 槽里的任务此刻能不能跑;空槽返回 false。 */
    boolean canRun(NumenPlayer companion) {
        return record != null && record.getState() == TaskState.RUNNING && task.canRun(companion);
    }

    /**
     * 放一个新任务进来,{@code runner} 是跑它的那个任务。槽里原来那个按<b>被换掉</b>结算并送结果——不能让它悄悄
     * 消失:模型手上握着它的 tool_call,那条调用要么有结果要么永远悬着。
     */
    void put(NumenPlayer companion, TaskRecord<?> rec, Task runner) {
        if (record != null) {
            task.stop(companion, Task.StopReason.REPLACED);
            letGo.accept(companion);
            record.stop(TaskRecord.StopCause.REPLACED);
            settle(companion);
        }
        rec.setState(TaskState.RUNNING);
        rec.markStarted(companion.level().getGameTime());
        task = runner;
        record = rec;
        task.start(companion);
        // start() 里就走到终态的(一次性动作把活全干完了 / 前置条件不通过)当刻结算,
        // 免得它空占一刻 RUNNING —— 那一刻里的一次"停止"会给已经干完的事发中断。
        settleIfTerminal(companion);
    }

    /** 前进一刻:先看 deadline,再跑一刻,走到终态就结算。 */
    void tick(NumenPlayer companion) {
        if (record == null) {
            return;
        }
        if (record.getState() == TaskState.RUNNING) {
            if (companion.level().getGameTime() >= record.getDeadlineGameTime()) {
                record.setState(TaskState.TIMEOUT);
            } else {
                record.setState(task.tick(companion));
            }
        }
        settleIfTerminal(companion);
    }

    /** 丢掉身体但不拆掉任务——被更高层抢占时用,状态全留着,下次接着跑。 */
    void loseBody(NumenPlayer companion) {
        if (task != null) {
            task.stop(companion, Task.StopReason.PREEMPTED);
        }
    }

    /** 被抢占这一刻不算它的预算:deadline 往后推一刻(只会往后,不会往前)。 */
    void freeze() {
        if (record != null && record.getState() == TaskState.RUNNING) {
            record.extendDeadlineTo(record.getDeadlineGameTime() + 1);
        }
    }

    /**
     * 走到终态就结算。<b>每刻都要调</b>,哪怕这一刻是别人拿着身体——主人按停止会
     * 在带外把记录标成 CANCELLED,而客户端严格串行的工具派发器会一直卡到那一个
     * 结果送出为止,不能等这个槽下次赢了才结算。
     */
    void settleIfTerminal(NumenPlayer companion) {
        if (record != null && record.getState().isTerminal()) {
            settle(companion);
        }
    }

    /** 从外面叫停(主人按停止、task_stop、命令):标成取消并记下是谁,下一次结算会送出结果。 */
    void cancel(TaskRecord.StopCause cause) {
        if (record != null && record.getState() == TaskState.RUNNING) {
            record.stop(cause);
        }
    }

    /** 身体要离开世界了:就地结算(它不会再被 tick),让 cleanup 跑完、结果送出。 */
    void finalizeInline(NumenPlayer companion) {
        if (record == null) {
            return;
        }
        record.stop(TaskRecord.StopCause.BODY_LEFT);
        settle(companion);
    }

    /**
     * 死亡:丢掉任务但<b>不发工具结果</b>——那条 tool_call 客户端已经用死因结算过了。
     * 但异步任务要补一条收尾事件:派发回执写着"完成会自动收到 task_finished,
     * 不要轮询",丢掉却不发收尾等于毁约。
     */
    void dropNoResult(NumenPlayer companion) {
        if (record != null && record.isAsync()) {
            com.dwinovo.numen.api.event.NumenEvents.taskFinished(companion, record.publicId(),
                    record.getToolName(), "interrupted", TaskResult.cancelled("任务因她死亡而中断"), record.function());
        }
        if (record != null) {
            com.dwinovo.numen.api.permission.ConsentDesk.of(companion).release(record,
                    com.dwinovo.numen.api.permission.ConsentDesk.Withdrawal.DIED);
        }
        task = null;
        record = null;
    }

    /**
     * 结算:结果进出箱,腾位。槽放开这条记录的同一刻,主人为它答应下来的任务期授权与它没等到答复的
     * 征询一并清掉——授权的作用域就是任务,由放开任务的这一处收口。征询撤回的原因是叫停它的那一方
     * (主人按了停止、身体离开世界……),没人叫停就是任务自己收场了。
     */
    private void settle(NumenPlayer companion) {
        TaskResult result = task.result(record.getState());
        TaskRecord.StopCause cause = record.getStopCause();
        record.setResult(cause == null ? result : result.stoppedBy(cause));
        com.dwinovo.numen.api.permission.ConsentDesk.of(companion).release(record,
                cause == null ? com.dwinovo.numen.api.permission.ConsentDesk.Withdrawal.TASK_ENDED : cause.withdrawal());
        outbox.accept(record);
        task = null;
        record = null;
    }
}
