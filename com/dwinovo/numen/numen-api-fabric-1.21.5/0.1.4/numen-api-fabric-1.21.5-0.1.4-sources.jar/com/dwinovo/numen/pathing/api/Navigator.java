package com.dwinovo.numen.pathing.api;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import com.dwinovo.numen.pathing.body.Body;
import com.dwinovo.numen.pathing.drive.Driver;
import com.dwinovo.numen.pathing.drive.LiveWorld;
import com.dwinovo.numen.pathing.drive.PathLog;
import com.dwinovo.numen.pathing.plan.BodySnapshot;
import com.dwinovo.numen.pathing.plan.CostModel;
import com.dwinovo.numen.pathing.search.Favoring;
import com.dwinovo.numen.pathing.search.Origin;
import com.dwinovo.numen.pathing.search.Route;
import com.dwinovo.numen.pathing.search.RoutePlanner;
import com.dwinovo.numen.pathing.search.Search;
import com.dwinovo.numen.pathing.search.Searches;
import com.dwinovo.numen.pathing.search.WorldSnapshot;

/**
 * 寻路的门面:一具身体加宿主的端口。规划是查询——{@link #plan} 只搜不走,不占身体、不碰世界,交出候选路线与预算账;
 * 执行是任务——{@link #drive} 交出一次在走的导航。请求、结局、账单都是数据,
 * 模块里没有给模型或玩家看的话。
 *
 * <p>只在世界所在的线程上调用;搜索在工作线程上跑,读的是派发那一刻在世界线程上拷下的快照。
 */
public final class Navigator {

    private final Body body;
    private final Ports ports;

    private Navigator(Body body, Ports ports) {
        this.body = body;
        this.ports = ports;
    }

    public static Navigator of(Body body, Ports ports) {
        return new Navigator(body, ports);
    }

    /** 只搜不走:从身体脚下(或接在 {@link PlanQuery#after} 那条路线后面)出候选路线。 */
    public Planning plan(PlanQuery query) {
        class_3222 entity = body.entity();
        BodySnapshot snapshot = body.snapshot();
        String who = PathLog.who(entity);
        class_2338 from;
        Route.Leg arrival = null;
        if (query.after() != null) {
            Route previous = query.after();
            from = previous.end();
            arrival = previous.legs().isEmpty() ? null : previous.legs().get(previous.legs().size() - 1);
        } else {
            Optional<class_2338> start = Origin.of(new LiveWorld(entity.method_51469()), snapshot.stats(),
                    entity.method_23317(), entity.method_23318(), entity.method_23321());
            if (start.isEmpty()) {
                class_2338 at = entity.method_24515();
                PathLog.info("{} 规划 去 {}:起点待不住 {}", who, query.goal(), PathLog.body(entity));
                return new Planning(new PlanResult(List.of(),
                        new Outcome.Stranded(at, entity.method_37908().method_8320(at)), null));
            }
            from = start.get();
        }
        long t0 = System.nanoTime();
        WorldSnapshot view = WorldSnapshot.around(entity.method_51469(), from);
        CostModel model = CostModel.of(query.spec(), snapshot, ports.terrain(), ports.materials(), ports.threats());
        PathLog.mainThread(who, "规划时拷快照与组成本模型", System.nanoTime() - t0);
        RoutePlanner.Query planned = new RoutePlanner.Query(view, model, from, query.goal(), query.budget(),
                query.candidates(), arrival);
        Search probe = new Search(view, model, from, query.goal(), query.budget(), Favoring.NONE).after(arrival);
        return new Planning(Searches.submit(planned), probe, who);
    }

    /** 去:交出一次在走的导航,宿主每刻 {@link Navigation#tick} 一次。 */
    public Navigation drive(NavRequest request) {
        class_3222 entity = body.entity();
        PathLog.debug("{} 出发 去 {} {} 预算 {}{} 刻速 {} {}", PathLog.who(entity), request.goal(),
                PathLog.spec(request.spec()), request.budget(),
                request.route() != null ? " 先照候选 " + PathLog.route(request.route()) : "",
                PathLog.num(entity.method_37908().method_54719().method_54748()), PathLog.body(entity));
        return new Navigation(new Driver(body, ports.effector(), ports.terrain(), ports.materials(), ports.threats(),
                request.goal(), request.spec(), request.budget(), request.route(), request.through()), entity);
    }
}
