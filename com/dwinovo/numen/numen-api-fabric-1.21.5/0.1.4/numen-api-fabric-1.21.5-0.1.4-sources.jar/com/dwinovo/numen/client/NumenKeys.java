package com.dwinovo.numen.client;

import com.dwinovo.numen.data.ModLanguageData.Keys;
import net.minecraft.class_1074;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import com.dwinovo.numen.agent.conversation.Conversation;
import com.dwinovo.numen.client.agent.Conversations;
import com.dwinovo.numen.client.agent.NumenRoster;
import com.dwinovo.numen.client.chat.CompanionChatScreen;
import com.dwinovo.numen.client.chat.CompanionWheelScreen;
import com.dwinovo.numen.client.chat.QuickVoice;
import com.dwinovo.numen.client.chat.SelectedCompanion;
import com.dwinovo.numen.client.screen.NumenScreen;
import org.lwjgl.glfw.GLFW;

/**
 * Shared key mappings: defined once here, registered by each loader's client
 * init (Fabric {@code KeyMappingHelper} / NeoForge {@code RegisterKeyMappingsEvent}),
 * polled once per client tick via {@link #tick()}.
 *
 * <p>快捷交互三件套围绕「当前交互对象」({@link SelectedCompanion}):
 * 轮盘选人 → 对话键发文字 → 语音键按住说话。默认键位都避开原版占用,
 * Controls 的 Numen 区可随意改绑。
 */
public final class NumenKeys {

    /** Dedicated vanilla Controls category so the binding is easy to find and rebind (Options → Controls → Numen). */
    public static final String CATEGORY = com.dwinovo.numen.data.ModLanguageData.Keys.KEY_CATEGORY_NUMEN;

    /** G — open the companion roster panel (or straight into chat with a single pet). */
    public static final class_304 OPEN_ROSTER = new class_304(
            com.dwinovo.numen.data.ModLanguageData.Keys.KEY_OPEN_ROSTER,
            class_3675.class_307.field_1668, GLFW.GLFW_KEY_G,
            CATEGORY);

    /** R(按住)— 同伴轮盘:滚轮/指向选中当前交互对象,松开确认。 */
    public static final class_304 COMPANION_WHEEL = new class_304(
            com.dwinovo.numen.data.ModLanguageData.Keys.KEY_COMPANION_WHEEL,
            class_3675.class_307.field_1668, GLFW.GLFW_KEY_R,
            CATEGORY);

    /** Y — 快捷对话:对当前交互对象弹极简输入框(准星指着谁则优先谁)。 */
    public static final class_304 TALK_COMPANION = new class_304(
            com.dwinovo.numen.data.ModLanguageData.Keys.KEY_TALK_COMPANION,
            class_3675.class_307.field_1668, GLFW.GLFW_KEY_Y,
            CATEGORY);

    /** V(按住)— 快捷语音:对讲机式,松开把转写发给当前交互对象。 */
    public static final class_304 QUICK_VOICE = new class_304(
            com.dwinovo.numen.data.ModLanguageData.Keys.KEY_QUICK_VOICE,
            class_3675.class_307.field_1668, GLFW.GLFW_KEY_V,
            CATEGORY);

    private static boolean voiceWasDown;

    private NumenKeys() {}

    /** Per-client-tick poll; key presses only register while no screen is open. */
    public static void tick() {
        class_310 mc = class_310.method_1551();
        while (OPEN_ROSTER.method_1436()) {
            if (mc.field_1724 != null && mc.field_1755 == null) {
                NumenScreen.openWorkspace();
            }
        }
        while (COMPANION_WHEEL.method_1436()) {
            if (mc.field_1724 == null || mc.field_1755 != null) {
                continue;
            }
            if (NumenRoster.instance().entries().isEmpty()) {
                com.dwinovo.numen.client.hud.TalkHint.flash(class_1074.method_4662(Keys.KEYS_NO_COMPANION), 3000);
                continue;
            }
            mc.method_1507(new CompanionWheelScreen());
        }
        while (TALK_COMPANION.method_1436()) {
            if (mc.field_1724 == null || mc.field_1755 != null) {
                continue;
            }
            // 有征询挂着先答征询:对象是最早在等的那位,不看准星——右上角弹出来说按这个键答的就是她
            var asking = com.dwinovo.numen.client.consent.ConsentCards.first();
            if (asking != null) {
                mc.method_1507(new CompanionChatScreen(Conversations.instance().of(asking.companion())));
                continue;
            }
            Conversation target = SelectedCompanion.resolveTarget();
            if (target == null) {
                com.dwinovo.numen.client.hud.TalkHint.flash(class_1074.method_4662(Keys.KEYS_PICK_FIRST,
                        COMPANION_WHEEL.method_16007().getString()), 3000);
                continue;
            }
            mc.method_1507(new CompanionChatScreen(target));
        }
        // 快捷语音:按下沿开录,抬起沿(或任何界面弹开)收音发送
        boolean voiceDown = QUICK_VOICE.method_1434() && mc.field_1724 != null && mc.field_1755 == null;
        if (voiceDown && !voiceWasDown) {
            QuickVoice.press();
        } else if (!voiceDown && voiceWasDown) {
            QuickVoice.release();
        }
        voiceWasDown = voiceDown;
    }
}
