package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.CompanionRegistry;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.entity.NumenPlayer;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.UUID;

/**
 * Client → Server: the owner asked to permanently delete a companion from the panel (rail ✕ → confirm).
 * This side only checks the companion is the caller's; what dismissal does is {@link Companions#dismiss}.
 */
public record DismissRequestPayload(UUID uuid) implements class_8710 {

    public static final class_9154<DismissRequestPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "dismiss_request"));

    public static final class_9139<ByteBuf, DismissRequestPayload> STREAM_CODEC =
            class_9139.method_56434(class_4844.field_48453, DismissRequestPayload::uuid, DismissRequestPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Server main thread. */
    public static void handle(DismissRequestPayload p, class_3222 owner) {
        MinecraftServer server = ((class_3218) owner.method_37908()).method_8503();
        if (server == null || p.uuid() == null) return;

        // 活体看身体上的主人;休眠 / 没加载的看注册表
        NumenPlayer body = NumenPlayer.findByUuid(server, p.uuid());
        boolean callers;
        if (body != null) {
            callers = body.isOwnedByPlayer(owner.method_5667());
        } else {
            CompanionRegistry.Entry e = CompanionRegistry.get(server).find(p.uuid());
            callers = e != null && e.owner().equals(owner.method_5667());
        }
        if (!callers) return;
        Companions.dismiss(server, owner.method_5667(), List.of(p.uuid()));
    }
}
