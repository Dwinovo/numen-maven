package com.dwinovo.numen.pathing.body;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4050;
import net.minecraft.class_5134;
import net.minecraft.class_5635;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import com.dwinovo.numen.pathing.plan.BodySnapshot;
import com.dwinovo.numen.pathing.plan.Breath;
import com.dwinovo.numen.pathing.world.BodyStats;

/**
 * 从一具真实的身体上抄下规划要的身体快照,原版口径只此一处:尺寸取原版的姿势尺寸,迈步、起跳、重力、交互距离、
 * 摔落、水下移动、挖掘速度取同名属性,细雪托不托得住照原版看脚上的皮靴,冰霜行者看靴子的附魔,游戏模式、血量、饱食度、
 * 主背包照抄;氧气、水下呼吸附魔(属性 {@code oxygen_bonus})、水下呼吸类效果还剩几刻、头上是不是海龟壳照抄,原版永远不扣氧
 * 的(能在水下呼吸、无敌)记成效果无穷。
 *
 * <p>挖掘效率属性里手上那件自己带的修饰符(效率附魔)要扣掉:挑工具时每件按它自己的修饰符加回去,不扣就会把手上那件的
 * 附魔算到每一件头上。
 *
 * <p>只在世界所在的线程上调用;抄出来的快照可以交给搜索线程。
 */
public final class Snapshots {

    private Snapshots() {}

    public static BodySnapshot of(class_3222 body) {
        BodyStats stats = stats(body);
        BodySnapshot.Mining mining = new BodySnapshot.Mining(efficiencyBesidesHand(body),
                body.method_45325(class_5134.field_49076),
                body.method_45325(class_5134.field_51576),
                class_1292.method_5576(body) ? class_1292.method_5575(body) : -1,
                body.method_6059(class_1294.field_5901) ? body.method_6112(class_1294.field_5901).method_5578() : -1);
        List<class_1799> inventory = List.copyOf(body.method_31548().method_67533());
        return new BodySnapshot(stats, body.field_13974.method_14257(), body.method_6032(),
                body.method_45325(class_5134.field_49079),
                body.method_45325(class_5134.field_49077), body.method_7344().method_7586(),
                body.method_45325(class_5134.field_51578), inventory, mining, breath(body));
    }

    /**
     * 憋气的本钱。水下呼吸类效果照原版 {@code MobEffectUtil.hasWaterBreathing} 认水下呼吸与潮涌能量两种,取剩得久的;
     * 能在水下呼吸的实体({@code canBreatheUnderwater})与无敌的玩家原版不扣氧({@code LivingEntity.baseTick}),记成无穷。
     */
    private static Breath breath(class_3222 body) {
        double shield = body.method_6094() || body.method_31549().field_7480 ? Double.POSITIVE_INFINITY
                : Math.max(remaining(body, class_1294.field_5923), remaining(body, class_1294.field_5927));
        return new Breath(body.method_5669(), body.method_5748(), body.method_45325(class_5134.field_51583),
                shield, body.method_6118(class_1304.field_6169).method_31574(class_1802.field_8090));
    }

    /** 这个效果还剩几刻;没有为 0,不限时为无穷。 */
    private static double remaining(class_3222 body, class_6880<class_1291> effect) {
        class_1293 instance = body.method_6112(effect);
        if (instance == null) {
            return 0;
        }
        return instance.method_48559() ? Double.POSITIVE_INFINITY : instance.method_5584();
    }

    /** 第 0 层要的那几项物理量:尺寸、迈步、起跳、重力、交互距离、细雪与冰霜行者。 */
    public static BodyStats stats(class_3222 body) {
        return new BodyStats(body.method_18377(class_4050.field_18076), body.method_18377(class_4050.field_18081),
                body.method_49476(), body.method_45325(class_5134.field_23728), body.method_56989(),
                body.method_55754(), class_5635.method_32355(body), frostWalker(body));
    }

    /** 脚上的靴子带冰霜行者。 */
    private static boolean frostWalker(class_3222 body) {
        class_6880<class_1887> frost = body.method_37908().method_30349().method_30530(class_7924.field_41265)
                .method_46747(class_1893.field_9122);
        return class_1890.method_8225(frost, body.method_6118(class_1304.field_6166)) > 0;
    }

    /** 挖掘效率属性去掉手上那件自己的修饰符之后的值。 */
    private static double efficiencyBesidesHand(class_3222 body) {
        class_1324 live = body.method_5996(class_5134.field_51581);
        Set<class_2960> ofHand = new HashSet<>();
        body.method_6047().method_57354(class_1304.field_6173, (holder, modifier) -> {
            if (holder.method_40225(class_5134.field_51581.method_40230().orElseThrow())) {
                ofHand.add(modifier.comp_2447());
            }
        });
        class_1324 rest = new class_1324(class_5134.field_51581, changed -> {});
        rest.method_6192(live.method_6201());
        for (class_1322 modifier : live.method_6195()) {
            if (!ofHand.contains(modifier.comp_2447())) {
                rest.method_26835(modifier);
            }
        }
        return rest.method_6194();
    }
}
