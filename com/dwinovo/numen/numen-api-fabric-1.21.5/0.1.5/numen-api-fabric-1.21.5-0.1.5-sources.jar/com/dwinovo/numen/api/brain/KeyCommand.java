package com.dwinovo.numen.api.brain;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.library.EntryId;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * {@code /numen key <服务商> <key>}:把 key 存进他自己的钥匙串(面板钥匙串页存的是同一本,同走
 * {@link Libraries#saveOwnKey})。服务商写模型档案里的服务商名(补全列他档案用到的与已存过的)。
 *
 * <p>key 不进日志、不进回执全文:回执只露前后几位,只回给他自己、不广播给其他管理员。多人服上第一次存,
 * 和面板一样提醒一次"服主看得到这把 key"。原版与两个加载器不记录玩家执行的命令;Paper 默认会记,服主要知道这一点。
 */
public final class KeyCommand {

    /** 回执里露出 key 的头几位与末几位;短于这两段之和加一的 key 一位也不露。 */
    private static final int SHOWN_HEAD = 3;
    private static final int SHOWN_TAIL = 2;

    private KeyCommand() {}

    public static LiteralArgumentBuilder<class_2168> node() {
        return class_2170.method_9247("key").then(class_2170.method_9244("service", StringArgumentType.word())
                .suggests((ctx, builder) -> class_2172.method_9265(services(ctx.getSource()), builder))
                .then(class_2170.method_9244("key", StringArgumentType.greedyString()).executes(KeyCommand::save)));
    }

    private static java.util.Set<String> services(class_2168 source) {
        return source.method_9228() instanceof class_3222 player
                ? Libraries.of(player.field_13995).keyServices(player.method_5667(), false) : java.util.Set.of();
    }

    private static int save(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 owner = ctx.getSource().method_9207();
        String service = StringArgumentType.getString(ctx, "service");
        String key = StringArgumentType.getString(ctx, "key").strip();
        if (!EntryId.segment(service) || key.isEmpty()) {
            ctx.getSource().method_9213(class_2561.method_43471(Keys.COMMAND_KEY_USAGE));
            return 0;
        }
        boolean remind = Libraries.of(owner.field_13995).saveOwnKey(owner.method_5667(), service, key);
        ctx.getSource().method_9226(() -> class_2561.method_43469(Keys.COMMAND_KEY_SAVED, service, preview(key)), false);
        if (remind) {
            ctx.getSource().method_9226(() -> class_2561.method_43471(Keys.KEY_OWNER_SEES), false);
        }
        return 1;
    }

    /** key 的头几位和末几位,中间换成省略号;太短的整个藏起来。 */
    static String preview(String key) {
        if (key.length() <= SHOWN_HEAD + SHOWN_TAIL + 1) {
            return "…";
        }
        return key.substring(0, SHOWN_HEAD) + "…" + key.substring(key.length() - SHOWN_TAIL);
    }
}
