package com.dwinovo.numen.api.entity;

import com.dwinovo.numen.api.brain.Whispers;
import com.dwinovo.numen.api.event.NumenEvents;
import java.util.function.Consumer;
import net.minecraft.class_243;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2668;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_3244;
import net.minecraft.class_7438;
import net.minecraft.class_7439;

/**
 * 客户端那一半。这具身体没有客户端,凡是服务端"发出去、然后等对面回话"的握手都会永远悬着;
 * 这里代替客户端把回话送回去。服务端对她说的话(系统聊天与动作栏)真客户端会显示给玩家看,这里交给模型。
 *
 * <h2>边界:只回握手、只传话,不报物理</h2>
 * 这里只认三类下行包:<b>服务端会等回执</b>的握手(传送编号、区块加载完毕)、<b>服务端对她说的话</b>,和<b>本该由客户端应用的击退</b>。走路、视角这些"客户端本地算、
 * 再上报给服务端"的东西不归这儿——那是 {@link NumenPlayer#method_5773()} 里自己跑的物理:服务端算出来就是结果,
 * 没有谁在等一个回复。所以这个类不会长成一个客户端实现,它的面就是原版那几处握手加上聊天栏与动作栏、玩家打她的击退。
 *
 * <h2>对她说的话,各有一个出处</h2>
 * <ul>
 *   <li>她自己执行的指令说的话(指令回给来源的、指令直接对她说的)是那条指令的回执,执行期间由
 *       {@link #runCommand} 收给那条指令,不再当事件交;</li>
 *   <li>她自己的死亡广播就是死亡事件里那句死因({@link NumenPlayer#deathMessage}),不再交一遍;</li>
 *   <li>别的玩家私聊她({@code /msg},聊天类型 {@code msg_command_incoming} 的玩家聊天包)是对她说的话,交给 {@link Whispers}:
 *       主人的进她的单聊会话,别人的按旁听档进收件箱;公屏上的聊天(别的类型)不是对她说的,不读;</li>
 *   <li>其余的交成 {@code server_message} 事件:聊天栏同一句刷屏折叠,动作栏当一格、最新的为准,见
 *       {@link ServerMessages}。这种事件捎带投递,不单独叫醒她。</li>
 * </ul>
 * 文字在服务端按服务端的语言表拼出来,和指令回执({@code Echo})用的是同一个拼法。
 *
 * <p>反过来说,原版那趟 {@code ServerGamePacketListenerImpl.tick()} 也不能直接拿来跑:
 * 它是 {@code resetPosition()} 记下当前位置 → {@code doTick()} → {@code absMoveTo(firstGood)},
 * 为"客户端权威的身体"写的——真玩家的 {@code doTick()} 不推动身体,最后那一下是在确认他
 * 还在客户端说的位置上。而我们的身体恰恰靠 {@code doTick()} 里的 {@code travel()} 走路,
 * 跑那趟 tick 等于每刻把她拽回原地。
 *
 * <h2>晚一刻回,不当场回</h2>
 * 回执排进队列、下一刻交还,而不是在 {@code send} 里当场调用。当场回意味着在原版自己的
 * 跨维度搬运流程中途重入它的包处理器——那时她已经 {@code setServerLevel} 了但还没
 * {@code addDuringTeleport}。真客户端本来也要一个来回才答,晚一刻既更像真的,也不必赌
 * 原版中途的状态是自洽的。
 *
 * <h2>玩家打她的击退:客户端本该应用的那个速度包</h2>
 * 原版玩家攻击另一名玩家时,把击退算进目标的速度、给目标发一个速度包,随即把服务端上的速度清回原值——击退是由目标的客户端
 * 收到包后应用的。她没有客户端,所以不接的话玩家打她纹丝不动。这里只接这一种:发给她自己的速度包、而且发的当时
 * {@code hurtMarked} 为真(原版清它在发包之后)。别的速度包不归这里:怪打她的击退由服务端实体追踪发出,那时 {@code hurtMarked}
 * 已经清了,而且服务端上的速度本来就是对的。
 *
 * <h2>死了以后点"重生"</h2>
 * 真客户端死后看到死亡画面,玩家点"重生"就发一个 {@code PERFORM_RESPAWN},由原版的 {@code PlayerList.respawn} 把玩家按重生点规则放回世界。
 * {@link #respawn} 代她点这个按钮,重生本身全是原版做的:没有加入广播(不经 {@code placeNewPlayer}),落点、床与重生锚的消耗、
 * 掉落与经验、{@code keepInventory} 都照原版。原版重生会换一个新的 {@code ServerPlayer} 对象(模组上 {@code PlayerListRespawnMixin}
 * 让它仍是 {@link NumenPlayer}),所以这一份"客户端"跟着她换身体({@link #movedTo}),等着回的传送回执不会丢给旧身体。
 * Paper 上重生沿用原来的对象,{@code movedTo} 是原地不动。
 *
 * <h2>答话挂在服务端 tick 上,不挂实体 tick</h2>
 * {@link #answer()} 由 {@code CompanionTickDispatcher} 每刻遍历玩家列表时调用。挂
 * {@code NumenPlayer.tick()} 是不行的:实体 tick 只在她所在区块已经进入实体刻时才跑,
 * 而换维度刚落地的那片区块恰恰还没进——回执要等区块,区块要等她把加载垫盖下去,
 * 互相等着。真客户端答话从不看服务端有没有在 tick 她,这里同理。
 */
@com.dwinovo.numen.api.Internal
public final class FakeClient {

    /** 这一份"客户端"此刻代答的身体;原版重生换了身体对象时由 {@link #movedTo} 换成新的。 */
    private NumenPlayer player;

    /**
     * 待回的传送编号,-1 表示没有。
     *
     * <p>服务端每次 {@code connection.teleport()} 都记下一个编号等客户端报数,而清掉
     * {@code awaitingPositionFromClient}、把身体落定到目标点、以及<b>清掉"正在换维度"这个
     * 旗标</b>的唯一一处就是收到这个回执时
     * ({@code ServerGamePacketListenerImpl.handleAcceptTeleportPacket})。没有超时兜底。
     * 回执不来,她就永远卡在"正在换维度":传送门冷却不再递减(原版只在不换维度时减),
     * 而且一直免疫伤害(那个旗标直接进 {@code isInvulnerableTo})。
     *
     * <p>只留最后一个编号不是偷懒:服务端手里也只有一个 {@code awaitingTeleport},
     * 早先的编号对不上,原版收到了也照样忽略。
     */
    private int awaitingTeleport = -1;

    /**
     * 服务端说了"开始加载区块",在等客户端报"加载好了"。{@code ServerPlayer.hasClientLoaded()} 为假时服务端不收她的任何动作包
     * (挖、放、用、玩家指令),她也不受伤;真客户端加载完世界就发 {@code ServerboundPlayerLoadedPacket},没人替她发就要等原版 60 刻的
     * 兜底计时。她没有世界要加载:加入与重生这两条原版流程一走完就报({@link #arrived}、{@link #respawn}),她一到就能动手、也能挨打,
     * 和没有这道门的版本一样;换维度这类流程中途发来的,和传送编号一样晚一刻回({@link #answer})。
     */
    private boolean awaitingLoaded;

    /** 待应用的击退速度(原版交给目标客户端的那个),下一刻应用;没有是 null。 */
    private class_243 knockback;

    /** 服务端对她说的话,折叠后交成事件。 */
    private final ServerMessages messages;

    /** 她正在执行的那条指令收话的地方;没在执行指令时为 null。 */
    private Consumer<class_2561> commandOutput;

    /**
     * 她到达了(加入并做完平台的加入后步骤,见 {@link Arrivals})。到达之前发给她的聊天(例如 Paper 在她加入列表之后才广播的、她自己的
     * 加入消息)不算"听到的话"(她自己执行的指令的回执除外):大脑此时还没建好,模组上本来也听不到,两个平台同一个行为。
     */
    private boolean arrived;

    FakeClient(NumenPlayer player) {
        this.player = player;
        this.messages = new ServerMessages((text, overlay, repeats) -> NumenEvents.serverMessage(this.player, text,
                overlay, repeats, ServerMessages.WINDOW_TICKS / 20));
    }

    /**
     * 原版重生给她换了新身体:这一份"客户端"带着手里的一切(等着回的传送编号、折叠中的话、已到达)转交给它。
     * 由 {@link NumenPlayer#method_5878} 调,那是原版重生里新身体接上旧身体的那一处。
     */
    FakeClient movedTo(NumenPlayer next) {
        this.player = next;
        return this;
    }

    /**
     * 代她点"重生"(她的身体已经死了):原版的 {@code PlayerList.respawn} 把她放回世界,返回重生后的身体
     * (模组上是新对象,Paper 上还是原来那个)。重生期间原版发给她的包照常经 {@link #onOutbound},落点的传送编号随后由 {@link #answer} 回执。
     */
    NumenPlayer respawn() {
        class_3244 connection = player.field_13987;
        player.packets().respawn();
        // 重生流程走完、连接已换上新身体,这时报"加载好了"落在新身体上
        answerLoaded();
        return (NumenPlayer) connection.method_32311();
    }

    /**
     * 服务端刚往"客户端"发了一个包。<b>平台挂点。</b>模组上由 {@code MixinServerCommonPacketListener} 在
     * {@code ServerCommonPacketListenerImpl.send} 开头调(NeoForge 的频道检查在 {@code Connection.send} 之前就会抛异常,只能在这里截);
     * Paper 上由 {@code FakeConnection.send} 调(Paper 的发送最终落在这里)。调用方保证:主线程,她这一条连接发出的每个下行包
     * 在被丢弃之前都交来一次,且只交她的连接的。
     */
    public void onOutbound(class_2596<?> packet) {
        if (packet instanceof class_2708 teleport) {
            awaitingTeleport = teleport.comp_3133();
        } else if (packet instanceof class_2668 event
                && event.method_11491() == class_2668.field_46637) {
            awaitingLoaded = true;
        } else if (packet instanceof class_2743 motion
                && motion.method_11818() == player.method_5628() && player.field_6037) {
            knockback = new class_243(motion.method_11815(), motion.method_11816(), motion.method_11819());
        } else if (packet instanceof class_7439 said) {
            heard(said.comp_763(), said.comp_906());
        } else if (arrived && packet instanceof class_7438 chat
                && chat.comp_943().comp_919().method_40225(class_2556.field_39799)) {
            // 签了名的私聊带着发话人的 uuid;正文是服务端加工过的那一版,没有就是原文
            class_2561 text = chat.comp_1103();
            Whispers.heard(player, chat.comp_1099(), chat.comp_943().comp_920().getString(),
                    text != null ? text.getString() : chat.comp_1102().comp_1090());
        }
    }

    /** 她到达了:从这一刻起,服务端对她说的话才交给大脑。{@link CompanionFactory} 在到达的加入步骤做完时调。 */
    void arrived() {
        arrived = true;
        answerLoaded();
    }

    /**
     * 以她的名义执行一条指令:{@code command} 跑的期间服务端对她说的每一句都是这条指令说的,交给 {@code output},
     * 与指令回给来源的话收在同一份回执里。指令执行是同步的,这期间到她这儿的话不会有别的出处。
     */
    public void runCommand(Consumer<class_2561> output, Runnable command) {
        Consumer<class_2561> outer = commandOutput;
        commandOutput = output;
        try {
            command.run();
        } finally {
            commandOutput = outer;
        }
    }

    private void heard(class_2561 content, boolean overlay) {
        if (commandOutput != null) {
            commandOutput.accept(content);
            return;
        }
        if (!arrived) {
            return;   // 到达之前的话不进事件流(指令回执在上面已经收走)
        }
        String text = content.getString();
        if (player.method_29504() && text.equals(player.deathMessage())) {
            return;
        }
        messages.heard(text, overlay, player.field_13995.method_3780());
    }

    /** 服务端在等"加载好了"就报。 */
    private void answerLoaded() {
        if (awaitingLoaded) {
            awaitingLoaded = false;
            player.packets().playerLoaded();
        }
    }

    /** 每刻一次:把攒下的回执交还服务端、应用待应用的击退,剩下的全由原版自己做;折叠窗口到了的话交出去。 */
    public void answer() {
        messages.tick(player.field_13995.method_3780());
        if (knockback != null) {
            player.method_18799(knockback);
            knockback = null;
        }
        answerLoaded();
        if (awaitingTeleport < 0) {
            return;
        }
        int id = awaitingTeleport;
        awaitingTeleport = -1;
        player.packets().acceptTeleport(id);
        // 真客户端落地后紧接着报一个移动包,原版收到它时把玩家的区块位置挪到新地方(票据、加载、刷怪都随之过去)。
        // 她被传到别处(召唤、指令、换维度)时没人替她走这一步,区块还留在原地,新地方的实体不走刻。
        player.method_51469().method_14178().method_14096(player);
    }
}
