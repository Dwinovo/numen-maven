package com.dwinovo.numen.api.brain;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.entity.CompanionRegistry;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * 指令里"他名下的一只同伴"这个参数:补全列他名下各只的名字,读出来要么是唯一的一只、要么说清为什么不行。
 * {@code /numen group}、{@code /numen companion} 共用,名字带空格或不是英文字母的要加引号。
 */
final class CompanionArgument {

    private CompanionArgument() {}

    static RequiredArgumentBuilder<class_2168, String> of(String name) {
        return class_2170.method_9244(name, StringArgumentType.string()).suggests(CompanionArgument::suggest);
    }

    private static CompletableFuture<Suggestions> suggest(CommandContext<class_2168> ctx,
                                                          SuggestionsBuilder builder) {
        class_3222 player = ctx.getSource().method_44023();
        if (player == null) {
            return builder.buildFuture();
        }
        return class_2172.method_9264(CompanionRegistry.get(player.field_13995).ownedBy(player.method_5667()).stream()
                .map(entry -> StringArgumentType.escapeIfRequired(entry.getValue().name())), builder);
    }

    /** 他指的同伴;没有或重名就说出来,返回 {@code null}。 */
    static Map.Entry<UUID, CompanionRegistry.Entry> resolve(CommandContext<class_2168> ctx, String name,
                                                           class_3222 owner) {
        String given = StringArgumentType.getString(ctx, name);
        List<Map.Entry<UUID, CompanionRegistry.Entry>> named = CompanionRegistry.get(owner.field_13995)
                .ownedBy(owner.method_5667()).stream().filter(entry -> entry.getValue().name().equalsIgnoreCase(given))
                .toList();
        if (named.size() == 1) {
            return named.get(0);
        }
        ctx.getSource().method_9213(named.isEmpty() ? class_2561.method_43469(Keys.COMMAND_NO_SUCH_COMPANION, given)
                : class_2561.method_43469(Keys.COMMAND_SEVERAL_NAMED, named.size(), given));
        return null;
    }
}
