package com.dwinovo.numen.entity;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1792;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8791;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * The companion body: a server-side fake {@link class_3222}. Replaces the old
 * custom {@code NumenEntity} Mob so the companion is a first-class player —
 * native interaction/combat code paths (universal mod compatibility), its own
 * player inventory, and free chunk loading + playerdata persistence by virtue of
 * being a list-resident player.
 *
 * <h2>Identity &amp; ownership</h2>
 * Created by {@link CompanionFactory} with a stable per-companion UUID (carried
 * in the {@link GameProfile}); the enumerable index lives in
 * {@link CompanionRegistry}. Unlike the Mob, a fake player cannot carry custom
 * {@code SynchedEntityData}, so the owner is a plain server-side field persisted
 * to the companion's own playerdata {@code .dat} via
 * {@link #method_5652}. Owner checks are UUID comparisons — never
 * vanilla {@code isOwnedBy} (which resolves through a level and breaks across
 * dimensions).
 */
public final class NumenPlayer extends class_3222 {

    private static final String NBT_KEY_OWNER = "NumenOwner";

    /** Owner's player UUID. Null only transiently before the first assignment. */
    private UUID ownerUuid;

    /** Latched once we've handled this body's death, so the post-death routine runs exactly once. */
    private boolean deathHandled;

    public NumenPlayer(MinecraftServer server, class_3218 level, GameProfile profile,
                        class_8791 clientInformation) {
        super(server, level, profile, clientInformation);
    }

    /**
     * 点亮全部皮肤覆盖层(帽子/夹克/左右袖/左右裤腿)与披风。假玩家没有客户端上报的
     * 模型定制,不设这个字节客户端只渲染单层基础皮肤。该字节是同步实体数据、不随 .dat
     * 存取,故每次进世界都要重设一次(经 {@code protected} 的 DATA_PLAYER_MODE_CUSTOMISATION
     * 访问,子类内可见)。
     */
    public void showAllSkinLayers() {
        method_5841().method_12778(field_7518, (byte) 0x7f);
    }

    /** The loaded companion body with this UUID, or {@code null} if not spawned. */
    public static NumenPlayer findByUuid(MinecraftServer server, UUID uuid) {
        return server.method_3760().method_14602(uuid) instanceof NumenPlayer ap ? ap : null;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public void setOwnerUuid(UUID ownerUuid) {
        this.ownerUuid = ownerUuid;
    }

    /** Cross-dimension safe owner check — UUID comparison, not level-scoped lookup. */
    public boolean isOwnedByPlayer(UUID playerUuid) {
        return ownerUuid != null && ownerUuid.equals(playerUuid);
    }

    /** The owner as an online player, server-wide; null when offline. */
    public class_3222 resolveOwnerPlayer() {
        return ownerUuid == null ? null : method_37908().method_8503().method_3760().method_14602(ownerUuid);
    }


    /** True if {@code item} sits anywhere in the inventory (hotbar/main/offhand all count). */
    public boolean ensureInInventory(class_1792 item) {
        var inv = method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_31574(item)) return true;
        }
        return false;
    }

    /**
     * Hold the item in inventory slot {@code slot} in the main hand the way a real player
     * does — a hotbar slot is simply SELECTED (number-key); a main-inventory slot is SWAPPED
     * into the currently selected hotbar slot (item-conserving). This is the only correct way
     * to "switch to hand": calling {@code setItemInHand(MAIN_HAND, stack)} overwrites the held
     * item (losing it) and aliases ONE {@link net.minecraft.class_1799} across two
     * slots, which corrupts the inventory once the stack is consumed. No-op for {@code slot < 0}.
     */
    public void holdInHand(int slot) {
        if (slot < 0) {
            return;
        }
        var inv = method_31548();
        if (net.minecraft.class_1661.method_7380(slot)) {
            inv.method_61496(slot);
            return;
        }
        int selected = inv.method_67532();
        net.minecraft.class_1799 held = inv.method_5438(selected);
        inv.method_5447(selected, inv.method_5438(slot));
        inv.method_5447(slot, held);
    }

    // ---- server tick (restore the movement pass a fake connection skips) ----

    /**
     * Drive the body's own movement physics. A real {@link class_3222} runs
     * {@code travel} (against {@code zza}/{@code xxa}), food, air and pose inside
     * {@link #method_14226()}, which the network layer invokes via
     * {@code connection.tick()}. A fake player's connection is a no-op, so
     * {@code doTick()} never fires and the body would only ever turn (a direct
     * {@code setYRot} write) without walking. The entity system already calls
     * {@code super.tick()} (menus / container / position sync), so we add the
     * missing {@code doTick()} movement pass here in our own {@code tick()}
     * override. Every 10 ticks we resync the
     * connection position and let chunk loading follow the body so it never
     * walks out of its loaded area.
     */
    @Override
    public void method_5773() {
        // A fake player isn't auto-removed on death (no client to send a respawn packet), so it would
        // sit at 0 HP forever. Detect death once, hand off to the recoverable-death routine (stop the
        // brain, schedule a respawn at the owner), and skip the normal movement/AI tick for this corpse.
        if (!deathHandled && (method_6032() <= 0.0f || method_29504())) {
            deathHandled = true;
            Companions.onDeath(this);
            return;
        }
        if (method_37908() instanceof class_3218 sl && sl.method_8510() % 10 == 0) {
            this.field_13987.method_14372();
            sl.method_14178().method_14096(this);
        }
        super.method_5773();
        try {
            this.method_14226();
        } catch (Exception ignored) {
            // fake-connection internals can NPE on edge cases; a swallowed tick
            // beats crashing the server for a cosmetic pass
        }
    }

    @Override
    public void method_5652(class_2487 output) {
        super.method_5652(output);
        if (ownerUuid != null) {
            output.method_67494(NBT_KEY_OWNER, class_4844.field_25122, ownerUuid);   // 1.21.5 codec-based NBT
        }
    }

    @Override
    public void method_5749(class_2487 input) {
        super.method_5749(input);
        input.method_67491(NBT_KEY_OWNER, class_4844.field_25122).ifPresent(uuid -> this.ownerUuid = uuid);
    }
}
