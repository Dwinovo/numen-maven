package com.dwinovo.numen.client;

import com.dwinovo.numen.client.screen.NumenScreen;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Shared key mappings: defined once here, registered by each loader's client
 * init (Fabric {@code KeyMappingHelper} / NeoForge {@code RegisterKeyMappingsEvent}),
 * polled once per client tick via {@link #tick()}.
 */
public final class NumenKeys {

    /**
     * N — open the companion roster panel (or straight into chat with a single pet).
     * 1.21.6+ vanilla binds Quick Actions to G by default, and vanilla's key lookup
     * is one-mapping-per-key (Fabric keeps it; only NeoForge patches in multi-dispatch),
     * so a G default would never receive clicks on Fabric.
     */
    public static final class_304 OPEN_ROSTER = new class_304(
            com.dwinovo.numen.data.ModLanguageData.Keys.KEY_OPEN_ROSTER,
            class_3675.class_307.field_1668, GLFW.GLFW_KEY_N,
            class_304.class_11900.field_62556);

    private NumenKeys() {}

    /** Per-client-tick poll; key presses only register while no screen is open. */
    public static void tick() {
        while (OPEN_ROSTER.method_1436()) {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 != null && mc.field_1755 == null) {
                NumenScreen.openWorkspace();
            }
        }
    }
}
