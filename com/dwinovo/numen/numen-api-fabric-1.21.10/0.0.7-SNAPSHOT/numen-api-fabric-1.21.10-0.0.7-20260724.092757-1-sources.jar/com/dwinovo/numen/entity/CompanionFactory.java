package com.dwinovo.numen.entity;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_8791;
import net.minecraft.class_8792;
import net.minecraft.server.MinecraftServer;
import java.util.Set;
import java.util.UUID;

/**
 * Spawns and despawns companion {@link NumenPlayer} bodies through the vanilla
 * player-join path — entirely public API, no loader-specific construction needed
 * (the only fake piece is {@link FakeConnection}, which is common).
 *
 * <p>{@link net.minecraft.class_3324#method_14570} adds the body
 * to the player list (→ chunk loading for free) and to the level, but does NOT
 * load a hand-built fake player's {@code .dat} (that path is tied to the real
 * login flow) — so {@link #spawn} restores position / inventory / owner from disk
 * explicitly afterwards.
 * {@link net.minecraft.class_3324#method_14611} saves that data back and
 * removes the body — so despawn is a clean, persisted dormancy.
 */
@com.dwinovo.numen.api.Internal
public final class CompanionFactory {

    private CompanionFactory() {}

    /**
     * Bring a companion into the world. On first creation pass a {@code pos}
     * (the spawn location, e.g. beside the owner); on a respawn from dormancy
     * pass {@code null} to keep the position restored from its {@code .dat}.
     */
    public static NumenPlayer spawn(MinecraftServer server, UUID companionUuid, String name,
                                     UUID ownerUuid, class_3218 level, class_243 pos) {
        // 借来的正版皮肤(Mojang 签名的 textures,注册表持久化)注入档案——客户端只认
        // 签过名的皮肤数据;没有则回落原版默认皮肤(按 UUID 哈希抽取)。
        // authlib 9(1.21.9+)把 GameProfile 变成不可变 record,属性只能在构造时给全。
        CompanionRegistry.Entry reg = CompanionRegistry.get(server).find(companionUuid);
        GameProfile profile;
        if (reg != null && !reg.skinValue().isEmpty()) {
            com.google.common.collect.Multimap<String, com.mojang.authlib.properties.Property> props =
                    com.google.common.collect.LinkedHashMultimap.create();
            props.put("textures", new com.mojang.authlib.properties.Property(
                    "textures", reg.skinValue(), reg.skinSig().isEmpty() ? null : reg.skinSig()));
            profile = new GameProfile(companionUuid, name,
                    new com.mojang.authlib.properties.PropertyMap(props));
        } else {
            profile = new GameProfile(companionUuid, name);
        }
        NumenPlayer player = new NumenPlayer(server, level, profile, class_8791.method_53821());
        FakeConnection connection = new FakeConnection();
        server.method_3760().method_14570(connection, player,
                class_8792.method_53824(profile, false));
        // placeNewPlayer does NOT load a hand-built fake player's .dat, so restore
        // it ourselves: position, inventory, health, owner from
        // disk. Without this a respawned companion spawns at 0,0,0 with no items.
        loadPlayerData(server, player);
        // 假玩家没有客户端上报的模型定制:点亮全部皮肤覆盖层与披风,否则只显示单层基础皮肤。
        // 每次 spawn(首建与重生)都重设——该字节是同步实体数据、不随 .dat 存取。
        player.showAllSkinLayers();
        // Companions are always survival, whatever the world's default game type — their whole design
        // (gather/drops, real combat, recoverable death) is survival-shaped, and placeNewPlayer would
        // otherwise hand a creative world's body instabuild (no block drops, breaks auto_mine). Forced
        // here after the .dat restore so a stale saved game type can't override it.
        player.method_7336(class_1934.field_9215);
        // First spawn has no .dat to restore the owner from; set it explicitly.
        if (player.getOwnerUuid() == null) {
            player.setOwnerUuid(ownerUuid);
        }
        // An explicit pos (fresh summon) overrides the restored position; a respawn
        // from dormancy passes null to keep exactly what the .dat restored.
        if (pos != null) {
            player.method_48105(level, pos.field_1352, pos.field_1351, pos.field_1350, Set.of(), player.method_36454(), player.method_36455(), false);
        }
        return player;
    }

    /**
     * Restore a fake player's saved state from its playerdata {@code .dat}
     * ({@link net.minecraft.class_3324#method_14600} +
     * {@link net.minecraft.class_1297#method_5651}). {@code placeNewPlayer}
     * skips this for hand-constructed players, so we invoke the same load
     * ourselves. No-op on first summon (no file yet).
     */
    private static void loadPlayerData(MinecraftServer server, NumenPlayer player) {
        // 1.21.9+ 拆掉了 PlayerList.load(player, reporter):改为按 NameAndId 读回原始
        // CompoundTag,再自己包一层 TagValueInput 喂给 player.load。
        server.method_3760().method_14600(new net.minecraft.class_11560(player.method_7334()))
                .map(tag -> net.minecraft.class_11352.method_71417(
                        net.minecraft.class_8942.field_60348, player.method_56673(), tag))
                .ifPresent(player::method_5651);
    }

    /** Save the companion's data and remove it from the world (dormancy). */
    public static void despawn(MinecraftServer server, NumenPlayer player) {
        // Tell tool packs the body is leaving so they can finalize their own
        // per-companion work (e.g. clear a mining crack overlay) instead of leaving
        // it orphaned once the body drops out of the tick loop's player list.
        CompanionLifecycle.fireRemove(player);
        server.method_3760().method_14611(player);
    }
}
