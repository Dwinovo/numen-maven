package com.dwinovo.numen.entity;

import com.dwinovo.numen.network.payload.ClientUiActionPayload;
import com.dwinovo.numen.platform.Services;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * The unified server-side {@code /numen} command tree — one root with
 * per-companion verbs. Lives entirely on the server so it never collides with
 * the client command dispatcher; the two inherently client-local verbs
 * ({@code settings}, {@code reset}) act on the caller's own client by firing a
 * {@link ClientUiActionPayload} back at them.
 *
 * <pre>
 *   /numen player summon &lt;name&gt;    summon the named companion (idempotent — reuses an existing one)
 *   /numen player despawn &lt;name&gt;   permanently dismiss the named companion (gone for good)
 *   /numen settings                  open the settings GUI on the caller's client
 *   /numen reset                     clear the caller's conversation loops
 * </pre>
 */
@com.dwinovo.numen.api.Internal
public final class NumenCommands {

    private NumenCommands() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("numen")
                .then(class_2170.method_9247("player")
                        .then(class_2170.method_9247("summon")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> summon(ctx, StringArgumentType.getString(ctx, "name")))))
                        .then(class_2170.method_9247("despawn")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> despawn(ctx, StringArgumentType.getString(ctx, "name"))))))
                .then(class_2170.method_9247("settings")
                        .executes(ctx -> clientAction(ctx, ClientUiActionPayload.Action.OPEN_SETTINGS)))
                .then(class_2170.method_9247("reset")
                        .executes(ctx -> clientAction(ctx, ClientUiActionPayload.Action.RESET_LOOPS))));
    }

    private static int summon(CommandContext<class_2168> ctx, String name)
            throws CommandSyntaxException {
        class_3222 owner = ctx.getSource().method_9207();
        class_3218 level = (class_3218) owner.method_51469();
        NumenPlayer body = Companions.summon(
                level.method_8503(), owner.method_5667(), name, level, owner.method_73189());
        // Push the updated roster so the owner's G panel can reach the new companion.
        Companions.syncRosterToOwner(level.method_8503(), owner);
        ctx.getSource().method_9226(() ->
                class_2561.method_43470("Summoned companion '" + name + "' (" + body.method_5667() + ")"), false);
        return 1;
    }

    private static int despawn(CommandContext<class_2168> ctx, String name)
            throws CommandSyntaxException {
        class_3222 owner = ctx.getSource().method_9207();
        var server = owner.method_51469().method_8503();
        // Permanent dismissal: removes the live body AND its registry entry (and any same-name
        // duplicates), so it does NOT come back on the next login. NOT dormancy.
        int dismissed = Companions.dismissByName(server, owner.method_5667(), name);
        if (dismissed == 0) {
            ctx.getSource().method_9213(
                    class_2561.method_43470("No companion of yours named '" + name + "'"));
            return 0;
        }
        Companions.syncRosterToOwner(server, owner);
        ctx.getSource().method_9226(() -> class_2561.method_43470(
                "Dismissed companion '" + name + "' — gone for good"
                        + (dismissed > 1 ? " (cleaned up " + dismissed + " duplicates)" : "")), false);
        return dismissed;
    }

    private static int clientAction(CommandContext<class_2168> ctx,
                                    ClientUiActionPayload.Action action)
            throws CommandSyntaxException {
        class_3222 caller = ctx.getSource().method_9207();
        Services.NETWORK.sendToPlayer(caller, new ClientUiActionPayload(action));
        return 1;
    }
}
