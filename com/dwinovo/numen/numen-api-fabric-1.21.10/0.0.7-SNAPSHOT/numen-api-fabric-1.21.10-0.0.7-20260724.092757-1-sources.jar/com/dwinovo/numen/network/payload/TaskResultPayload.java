package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.agent.tool.ServerToolTransport;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server-to-client payload: result of a previously requested tool execution.
 * Server drains task outboxes each tick and ships completed results back to
 * the owning player; the player's {@code EntityAgentLoop} feeds them into
 * the LLM conversation as {@code role:tool} messages, then triggers the
 * next turn when all pending results are in.
 *
 * <h2>Pairing</h2>
 * {@link #toolCallId} matches the one in the originating {@link ExecuteToolPayload}
 * and, transitively, the LLM's tool_call.id — this is the field that
 * threads request→execution→reply through the network boundary.
 *
 * <h2>Result body</h2>
 * Pre-serialised JSON string ({@link com.dwinovo.numen.task.TaskResult#toJson}).
 * Server-side decisions about field shape live in {@code TaskResult}; the
 * network layer just shuttles bytes.
 */
public record TaskResultPayload(UUID entityUuid,
                                 String toolCallId,
                                 String resultJson) implements class_8710 {

    public static final int MAX_TOOL_CALL_ID_LENGTH = 128;
    public static final int MAX_RESULT_JSON_LENGTH = 16 * 1024;

    public static final class_9154<TaskResultPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "task_result"));

    public static final class_9139<class_9129, TaskResultPayload> STREAM_CODEC =
            class_9139.method_56436(
                    class_4844.field_48453, TaskResultPayload::entityUuid,
                    class_9135.method_56364(MAX_TOOL_CALL_ID_LENGTH), TaskResultPayload::toolCallId,
                    class_9135.method_56364(MAX_RESULT_JSON_LENGTH), TaskResultPayload::resultJson,
                    TaskResultPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on client main thread (network layer arranges that). */
    public static void handle(TaskResultPayload p) {
        Constants.LOG.debug("[numen-net] task_result entity={} tool_call_id={} → {}",
                p.entityUuid(), p.toolCallId(), truncate(p.resultJson(), 200));
        ServerToolTransport.deliver(p.toolCallId(), p.resultJson());
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
