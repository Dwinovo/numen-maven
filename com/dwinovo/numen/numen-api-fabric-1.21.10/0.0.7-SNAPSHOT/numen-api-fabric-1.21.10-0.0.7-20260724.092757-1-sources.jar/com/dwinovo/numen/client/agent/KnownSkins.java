package com.dwinovo.numen.client.agent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1068;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_8685;

/**
 * Companion skin lookup, done the way vanilla TAB does it: skins live in the
 * connection's player-info table, NOT on the entity — companions are placed via
 * {@code PlayerList.placeNewPlayer} (same mechanism as Carpet bots), so their info
 * entry persists at ANY distance while the entity itself is only synced within
 * tracking range. Resolving through the entity was the old bug: past tracking
 * range the avatar snapped back to the default Steve/Alex.
 *
 * <p>The last-known cache stays as a belt for transient windows (dimension hops,
 * brief re-login races); the default skin only ever shows for a companion whose
 * info entry has never been seen this session.
 */
public final class KnownSkins {

    private static final Map<UUID, class_8685> LAST = new ConcurrentHashMap<>();

    private KnownSkins() {}

    /** The companion's skin: player-info table first (distance-independent, and
     *  remembered), else last known, else default. */
    public static class_8685 of(UUID uuid) {
        var conn = class_310.method_1551().method_1562();
        if (conn != null) {
            class_640 info = conn.method_2871(uuid);
            if (info != null) {
                class_8685 s = info.method_52810();
                LAST.put(uuid, s);
                return s;
            }
        }
        class_8685 cached = LAST.get(uuid);
        return cached != null ? cached : class_1068.method_4648(uuid);
    }

    /** World left — cached textures die with the connection. */
    public static void clear() {
        LAST.clear();
    }
}
