package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.CompanionSpeech;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client → Server:同伴的大脑开始/结束输出(回合进行中或语音在播)。
 * 纯姿态信号——身体据此在说话期间注视主人(闲时链消费),不承载任何
 * 逻辑状态,丢了漂了都无害。只在状态翻转时发,不逐 tick 刷。
 */
public record SpeakingStatePayload(UUID entityUuid, boolean speaking) implements class_8710 {

    public static final class_9154<SpeakingStatePayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "speaking_state"));

    public static final class_9139<class_9129, SpeakingStatePayload> STREAM_CODEC =
            class_9139.method_56435(
                    class_4844.field_48453, SpeakingStatePayload::entityUuid,
                    class_9135.field_48547, SpeakingStatePayload::speaking,
                    SpeakingStatePayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Server main thread. 只认主人本人发来的状态。 */
    public static void handle(SpeakingStatePayload p, class_3222 sender) {
        var companion = com.dwinovo.numen.entity.NumenPlayer.findByUuid(
                sender.method_51469().method_8503(), p.entityUuid());
        if (companion == null || !companion.isOwnedByPlayer(sender.method_5667())) return;
        CompanionSpeech.setSpeaking(p.entityUuid(), p.speaking());
    }
}
