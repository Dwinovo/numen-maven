package com.dwinovo.numen.client.screen.items;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.ClientNumenLookup;
import com.dwinovo.numen.client.data.ClientNumenInventory;
import com.dwinovo.numen.client.screen.Nb;
import com.dwinovo.numen.client.screen.UiTheme;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1074;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_742;

/**
 * The Items tab: a vanilla-inventory-style "companion sheet" — armor column + offhand, a live
 * mouse-following portrait, the synced 2×2 craft grid + result, segmented heart/drumstick vitals,
 * and the read-only checkerboard 3×9 storage + hotbar. Body data is fetched on demand (the screen
 * re-requests it every second while this tab is open); HP + equipment come off the live client
 * entity. Stateless — everything is drawn fresh from the snapshot each frame.
 */
public final class ItemsView {

    private static final int ICON = 9;        // native vitals-icon size
    private static final int ICON_STEP = 9;   // touching = one chunky bar
    /** Armor column (top → bottom); offhand is drawn separately below it. */
    private static final class_1304[] ARMOR = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

    private static class_2960 spr(String name) {
        return class_2960.method_60655(Constants.MOD_ID, name);
    }
    private static final class_2960 SLOT_SPRITE = spr("slot");
    private static final class_2960 SLOT_ALT = spr("slot_alt");        // checkerboard
    private static final class_2960 HEART_FULL = spr("heart_full");
    private static final class_2960 HEART_HALF = spr("heart_half");
    private static final class_2960 HEART_EMPTY = spr("heart_empty");
    private static final class_2960 FOOD_FULL = spr("food_full");
    private static final class_2960 FOOD_HALF = spr("food_half");
    private static final class_2960 FOOD_EMPTY = spr("food_empty");

    private ItemsView() {}

    public static void render(class_332 g, class_327 font, UUID uuid,
                              int left, int top, int panelW, int panelH, int headerH,
                              int mouseX, int mouseY) {
        UiTheme th = UiTheme.current();
        var snap = ClientNumenInventory.get(uuid).orElse(null);
        class_742 e = ClientNumenLookup.resolve(uuid);
        List<class_1799> craft = snap != null ? snap.craft() : List.of();

        // Two centred columns: LEFT = big portrait + armor column + offhand; RIGHT = craft + vitals +
        // 3×9 storage + hotbar. Symmetric framing margins (no lopsided whitespace).
        final int STORAGE_W = 9 * 18;                     // 162 — the widest element (caps the band)
        final int COMP_W = 130 + STORAGE_W;               // left col (130) + right col (storage)
        final int COMP_H = 152;
        int startX = left + (panelW - COMP_W) / 2;
        int cTop = top + headerH + (panelH - headerH - COMP_H) / 2;
        int rightX = startX + 130;

        // -- LEFT: portrait socket, armor column + offhand (vertically centred against the portrait) --
        renderPortrait(g, e, startX + 22, cTop, 84, COMP_H, mouseX, mouseY);
        int armorTop = cTop + (COMP_H - 5 * 18) / 2;
        for (int i = 0; i < ARMOR.length; i++) {
            drawEquip(g, font, e, ARMOR[i], startX, armorTop + i * 18, mouseX, mouseY);
        }
        drawEquip(g, font, e, class_1304.field_6171, startX, armorTop + 4 * 18, mouseX, mouseY);

        // -- RIGHT top: synced 2×2 craft grid (+ arrow + result) --
        for (int i = 0; i < 4; i++) {
            int cx = rightX + (i % 2) * 18, cy = cTop + (i / 2) * 18;
            slotBg(g, SLOT_SPRITE, cx, cy);
            stackOn(g, font, i < craft.size() ? craft.get(i) : class_1799.field_8037, cx, cy, mouseX, mouseY);
        }
        Nb.text(g, font, "→", rightX + 38, cTop + 13, th.textDim());
        int resultX = rightX + 54, resultY = cTop + 9;
        slotBg(g, SLOT_SPRITE, resultX, resultY);
        stackOn(g, font, craft.size() > 4 ? craft.get(4) : class_1799.field_8037, resultX, resultY, mouseX, mouseY);

        // -- RIGHT mid: segmented hearts + drumsticks --
        if (e != null) renderStatRow(g, rightX, cTop + 46, e.method_6032(), e.method_6063(),
                HEART_FULL, HEART_HALF, HEART_EMPTY);
        int food = (snap != null && snap.loaded()) ? snap.foodLevel() : 0;
        renderStatRow(g, rightX, cTop + 46 + ICON + 2, food, 20, FOOD_FULL, FOOD_HALF, FOOD_EMPTY);

        // -- RIGHT bottom: checkerboard 3×9 storage + hotbar --
        int storeY = cTop + 74;
        if (snap == null) {
            Nb.text(g, font, class_1074.method_4662("numen.status.loading"), rightX, storeY + 4, th.faint());
            return;
        }
        if (!snap.loaded() || snap.items().isEmpty()) {
            Nb.text(g, font, class_1074.method_4662("numen.status.asleep"), rightX, storeY + 4, th.faint());
            return;
        }
        List<class_1799> items = snap.items();
        for (int i = 9; i < 36; i++) {                     // storage rows (slots 9..35)
            int col = (i - 9) % 9, row = (i - 9) / 9;
            int x = rightX + col * 18, y = storeY + row * 18;
            slotBg(g, ((col + row) & 1) == 0 ? SLOT_SPRITE : SLOT_ALT, x, y);
            stackOn(g, font, items.get(i), x, y, mouseX, mouseY);
        }
        int hotbarY = storeY + 3 * 18 + 6;                 // hotbar (slots 0..8)
        for (int i = 0; i < 9; i++) {
            int x = rightX + i * 18;
            slotBg(g, (i & 1) == 0 ? SLOT_SPRITE : SLOT_ALT, x, hotbarY);
            stackOn(g, font, items.get(i), x, hotbarY, mouseX, mouseY);
        }
    }

    /** A row of segmented icons for a 0..max stat (2 units per icon): empty sockets first, then
     *  full / half overlaid. Used for hearts (HP) and drumsticks (hunger). */
    private static void renderStatRow(class_332 g, int x, int y, float value, float max,
                                      class_2960 full, class_2960 half, class_2960 empty) {
        int units = Math.max(1, (int) Math.ceil(max / 2f));
        for (int i = 0; i < units; i++) {
            int ix = x + i * ICON_STEP;
            g.method_52706(net.minecraft.class_10799.field_56883, empty, ix, y, ICON, ICON);
            float v = value - i * 2f;
            if (v >= 2f)      g.method_52706(net.minecraft.class_10799.field_56883, full, ix, y, ICON, ICON);
            else if (v >= 1f) g.method_52706(net.minecraft.class_10799.field_56883, half, ix, y, ICON, ICON);
        }
    }

    /** Live mouse-following 3D portrait of the companion — the body IS a client player entity, so the
     *  vanilla player renderer draws it for free. Sits in a recessed socket (slot_alt stretched). */
    private static void renderPortrait(class_332 g, class_742 e,
                                       int x, int y, int w, int h, int mouseX, int mouseY) {
        g.method_52706(net.minecraft.class_10799.field_56883, SLOT_ALT, x, y, w, h);
        if (e == null) return;
        int scale = (int) (h * 0.45f);
        net.minecraft.class_490.method_2486(
                g, x + 2, y + 2, x + w - 2, y + h - 2, scale, 0.0625f,
                (float) mouseX, (float) mouseY, e);
    }

    private static void slotBg(class_332 g, class_2960 sprite, int x, int y) {
        g.method_52706(net.minecraft.class_10799.field_56883, sprite, x, y, 16, 16);
    }

    private static void stackOn(class_332 g, class_327 font, class_1799 st, int x, int y, int mouseX, int mouseY) {
        if (st == null || st.method_7960()) return;
        g.method_51427(st, x, y);
        g.method_51431(font, st, x, y);
        if (mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16) {
            g.method_51446(font, st, mouseX, mouseY);
        }
    }

    /** One equipment/armor socket, read off the live client entity (equipment IS client-synced). */
    private static void drawEquip(class_332 g, class_327 font, class_742 e, class_1304 slot,
                                  int x, int y, int mouseX, int mouseY) {
        slotBg(g, SLOT_SPRITE, x, y);
        if (e != null) stackOn(g, font, e.method_6118(slot), x, y, mouseX, mouseY);
    }
}
