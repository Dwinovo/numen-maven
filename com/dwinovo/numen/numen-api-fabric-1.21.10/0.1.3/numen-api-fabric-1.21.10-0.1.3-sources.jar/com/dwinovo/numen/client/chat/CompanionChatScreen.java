package com.dwinovo.numen.client.chat;

import com.dwinovo.numen.api.Delivery;
import com.dwinovo.numen.api.NumenGateway;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import com.dwinovo.numen.client.agent.EntityAgentLoop;
import com.dwinovo.numen.client.agent.NumenRoster;
import com.dwinovo.numen.client.screen.Nb;
import com.dwinovo.numen.client.screen.UiTheme;
import com.dwinovo.numen.client.screen.chat.ChatInputBar;
import com.dwinovo.numen.client.screen.settings.HostThemeColors;
import com.dwinovo.numen.client.ui.RoundRect;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_742;

/**
 * 快捷对话:按对话键(默认 Y,入口在 {@code NumenKeys})对「当前交互
 * 对象」弹出这一条极简输入行——就一行,回车说出去立刻关屏,回复会浮
 * 在它头顶的气泡里。收件人由 {@code SelectedCompanion} 解析:准星指着
 * 谁优先谁,否则是轮盘选中的那位。屏只是输入法,不是对话窗口;历史与
 * 长文在 G 面板。准星提示见 {@code TalkHint}。
 *
 * <p>输入行与 G 面板是<b>同一条</b>({@link ChatInputBar}):斜杠补全弹层、
 * {@code /skills} 这类面板、回车先补后发,两处一模一样,不另写一套。不带麦克风键
 * ——快捷语音有自己的按住说话键。命令跑完的回话走准星提示层闪一下,屏照关。
 *
 * <p>与 {@code @名字} 路由是同一条管线({@link NumenGateway#enqueue}),
 * 对应两种社交距离:@ 是远程喊话,这里是走到跟前说话。
 */
public class CompanionChatScreen extends class_437 {

    private static final int INPUT_W = 300;
    /** 与 G 面板输入行同高。 */
    private static final int INPUT_H = 18;

    private final UUID companionUuid;
    private final String companionName;
    private ChatInputBar inputBar;

    public CompanionChatScreen(UUID companionUuid, String companionName) {
        super(class_2561.method_43470("Numen face-to-face chat"));
        this.companionUuid = companionUuid;
        this.companionName = companionName == null ? "?" : companionName;
    }

    /**
     * 准星此刻指着的「自己的」同伴,不在指着返回 null。花名册只含本人的
     * 同伴,身份校验是白送的;别人的同伴不响应(它的大脑不在你机器上)。
     */
    public static class_742 crosshairCompanion() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1724.method_7325()) return null;
        if (!(mc.field_1765 instanceof class_3966 hit)) return null;
        if (!(hit.method_17782() instanceof class_742 body)) return null;
        for (NumenRoster.Entry entry : NumenRoster.instance().entries()) {
            if (entry.uuid().equals(body.method_5667())) {
                return body;
            }
        }
        return null;
    }

    private EntityAgentLoop loop() {
        return AgentLoopRegistry.getOrCreate(companionUuid);
    }

    /** 名字牌(说给谁)的宽度:它和输入行同排,占掉输入卡最左边这一截。 */
    private int tagW() {
        return this.field_22793.method_1727(companionName) + 12;
    }

    @Override
    protected void method_25426() {
        // 输入框的真控件挂到本屏上:只注册事件、不进 renderables,画面归 NumenUI。
        // 屏幕作用域——关屏时在 removed() 卸掉。
        com.dwinovo.numen.client.ui.mc.McTextInput.mountVia(this::method_25429, this::method_25395);
        String kept = inputBar != null ? inputBar.text() : "";
        int x = (this.field_22789 - INPUT_W) / 2;
        int y = this.field_22790 - 44;
        inputBar = new ChatInputBar(new BarHost(), EnumSet.of(ChatInputBar.Key.SEND, ChatInputBar.Key.STOP));
        int lead = tagW() + 6;
        inputBar.build(x + lead, y, INPUT_W - lead, INPUT_H);
        if (!kept.isEmpty()) inputBar.setText(kept);
    }

    /** 输入行的宿主:说话走 Gateway 然后关屏;命令的回话闪在准星提示层,屏也关。 */
    private final class BarHost implements ChatInputBar.Host {
        @Override public void onSend(String text) {
            Delivery sent = NumenGateway.enqueue(companionUuid, text);
            if (sent != Delivery.REJECTED) {
                ChatLines.owner(companionName, text, false);
            } else {
                com.dwinovo.numen.client.hud.TalkHint.flash(companionName + " 没能收到——它可能不在线", 3000);
            }
            method_25419();
        }

        @Override public void onAbort() { loop().abort(); }

        @Override public boolean canAbort() { return loop().canInterrupt(); }

        @Override public String hint() {
            return "想说什么…(回车说出去,Esc 算了)";
        }

        @Override public EntityAgentLoop loop() { return CompanionChatScreen.this.loop(); }

        /** 只注册事件,不进 renderables——画面归 NumenUI。见 {@code McTextInput}。 */
        @Override public void onCommandReply(String reply) {
            if (reply == null || reply.isBlank()) {
                return;   // 不吭声的命令,或面板已在输入行原位打开——屏留着
            }
            // 行数越多给的时间越长——一屏技能清单三秒看不完
            long life = 4000L + reply.split("\n").length * 600L;
            com.dwinovo.numen.client.hud.TalkHint.flash(reply, life);
            method_25419();
        }
    }

    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float partialTicks) {
        // 刻意留空:super.render 默认会画菜单模糊+压暗遮罩,面对面说话
        // 不该把世界糊掉——她就站在你面前
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partialTicks) {
        UiTheme th = UiTheme.current();
        int x = (this.field_22789 - INPUT_W) / 2;
        int y = this.field_22790 - 44;

        // 输入卡:与 G 面板同方言的浅底粗边卡片;输入行(含弹层/面板)画在它上面
        RoundRect.card(g, x - 8, y - 6, x + INPUT_W + 8, y + INPUT_H + 4, 4,
                th.aiFill(), th.border());
        // 名字牌:与输入行同排、占卡片最左一截,标明这句话说给谁。不放输入框上方——
        // 斜杠补全弹层和 /skills 面板都贴着输入框往上长,上面那块地是它们的
        int tagW = tagW();
        RoundRect.card(g, x - 4, y + 1, x - 4 + tagW, y + INPUT_H - 1, 3, th.band(), th.border());
        Nb.text(g, this.field_22793, companionName, x + 2, y + (INPUT_H - this.field_22793.field_2000) / 2 + 1,
                th.onBand());
        inputBar.render(g, mouseX, mouseY, net.minecraft.class_156.method_658(), HostThemeColors.current());

        String tip = inputBar.tooltipAt(mouseX, mouseY);
        if (tip != null) {
            g.method_51438(this.field_22793, class_2561.method_43470(tip), mouseX, mouseY);
        }
        super.method_25394(g, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        // 输入行先拿:弹层的上下/Tab/回车、面板的整个键盘、回车发送。它不要的(比如
        // 没开面板时的 Esc)才落到屏幕——Esc 关屏
        if (inputBar != null && inputBar.keyPressed(event.comp_4795(), event.comp_4797())) {
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (inputBar != null && inputBar.charTyped((char) event.comp_4793())) {
            return true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (inputBar != null && inputBar.mouseClicked(event.comp_4798(), event.comp_4799(), event.method_74245())) {
            return true;
        }
        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25432() {
        com.dwinovo.numen.client.ui.mc.McTextInput.mountVia(null, null);
        super.method_25432();
    }
}
