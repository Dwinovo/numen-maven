package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.entity.NumenPlayer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1874;
import net.minecraft.class_3218;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_3975;
import net.minecraft.class_7923;
import net.minecraft.class_8059;
import net.minecraft.class_8786;

/**
 * 配方书:做一样东西的每一条配方,像 JEI 的一页({@code numen.inv.recipes})。合成配方的事实(装得下的最小的格、照她背着的还缺什么)
 * 与合成时查的同一处读({@link CraftOps})。
 */
public final class RecipeBook {

    private RecipeBook() {}

    /** 做这样东西的每一条配方,每个工位;找不到就是空表(它靠挖或交易得来,不是做出来的)。 */
    public static List<com.dwinovo.numen.core.tools.Recipe> recipesFor(class_1792 target, NumenPlayer self) {
        class_3218 level = self.method_51469();
        List<com.dwinovo.numen.core.tools.Recipe> out = new ArrayList<>();
        for (class_8786<?> holder : level.method_8433().method_8126()) {
            // 每条配方自成一格:整合包里一条坏配方(产出为 null、输入表为 null)只丢它自己,绝不让它杀掉整个查询。见 RecipeProbe。
            try {
                class_1860<?> r = holder.comp_1933();
                if (r instanceof class_3955 cr) {
                    // 产出依赖输入的配方(烟花、镶零件的装备)静态描述答不了;这一代没有 PlacementInfo,空输入表的老启发式一并保留
                    if (cr.method_8118() || cr.method_8117().isEmpty()
                            || cr.method_8117().stream().allMatch(class_1856::method_8103)) {
                        continue;
                    }
                    class_1799 result = RecipeProbe.resultOf(cr, level.method_30349());
                    if (!result.method_7960() && result.method_7909() == target) {
                        out.add(CraftOps.recipe(holder, cr, result, self));
                    }
                } else if (r instanceof class_1874 cook) {
                    class_1799 result = RecipeProbe.resultOf(cook, level.method_30349());
                    if (!result.method_7960() && result.method_7909() == target) {
                        out.add(station(holder, cookingStation(cook.method_17716()), result,
                                List.of(describeIngredient(cook.method_8117().get(0))),
                                Optional.of(cook.method_8167())));
                    }
                } else if (r instanceof class_3975 sc) {
                    class_1799 result = RecipeProbe.resultOf(sc, level.method_30349());
                    if (!result.method_7960() && result.method_7909() == target) {
                        out.add(station(holder, com.dwinovo.numen.core.tools.Recipe.Station.STONECUTTER, result,
                                List.of(describeIngredient(sc.method_8117().get(0))), Optional.empty()));
                    }
                } else if (r instanceof class_8059 sm) {
                    // 锻造不走展示产出,保留空输入 assemble 的既有语义:变换配方(下界合金升级)照样给出产物,纹饰配方产出(空的)基底、
                    // 自然排除
                    // 这一代的 assemble 收容器(还没有 SmithingRecipeInput)
                    class_1799 result = RecipeProbe.probe(() -> sm.method_8116(
                            new net.minecraft.class_1277(3), level.method_30349()));
                    if (!result.method_7960() && result.method_7909() == target) {
                        out.add(station(holder, com.dwinovo.numen.core.tools.Recipe.Station.SMITHING, result, List.of(),
                                Optional.empty()));
                    }
                }
            } catch (RuntimeException broken) {
                com.dwinovo.numen.core.Constants.LOG.debug(
                        "[numen-recipe] 配方 {} 坏了,跳过: {}", holder.comp_1932(), broken.toString());
            }
        }
        return out;
    }

    /** 不在合成格里做的一条配方。 */
    private static com.dwinovo.numen.core.tools.Recipe station(class_8786<?> holder,
                                                              com.dwinovo.numen.core.tools.Recipe.Station station,
                                                              class_1799 result, List<String> ingredients,
                                                              Optional<Integer> ticks) {
        return new com.dwinovo.numen.core.tools.Recipe(holder.comp_1932().toString(), station,
                class_7923.field_41178.method_10221(result.method_7909()).toString(), result.method_7947(), ingredients,
                Optional.empty(), Optional.empty(), ticks);
    }

    private static com.dwinovo.numen.core.tools.Recipe.Station cookingStation(class_3956<?> type) {
        return type == class_3956.field_17547 ? com.dwinovo.numen.core.tools.Recipe.Station.BLASTING
                : type == class_3956.field_17548 ? com.dwinovo.numen.core.tools.Recipe.Station.SMOKING
                : type == class_3956.field_17549 ? com.dwinovo.numen.core.tools.Recipe.Station.CAMPFIRE
                : com.dwinovo.numen.core.tools.Recipe.Station.SMELTING;
    }

    /**
     * 一样料的叫法:单一物品就是它;一类有共同后缀的写成 {@code planks(any)};不然把每一种都列出来——免得一类料把模型引到某一种具体的
     * 东西上。合成缺料时说缺什么用的是同一套叫法。
     */
    static String describeIngredient(class_1856 ing) {
        List<String> paths = java.util.Arrays.stream(ing.method_8105())   // 1.21.1: getItems() -> ItemStack[]
                .map(s -> class_7923.field_41178.method_10221(s.method_7909()).method_12832())
                .distinct()
                .toList();
        if (paths.isEmpty()) {
            return "?";
        }
        if (paths.size() == 1) {
            return paths.get(0);
        }
        String suffix = commonSuffixToken(paths);
        if (suffix != null) {
            return suffix + "(any)";
        }
        return "any[" + String.join("/", paths) + "]";
    }

    private static String commonSuffixToken(List<String> paths) {
        String token = null;
        for (String p : paths) {
            int u = p.lastIndexOf('_');
            String t = u < 0 ? p : p.substring(u + 1);
            if (token == null) {
                token = t;
            } else if (!token.equals(t)) {
                return null;
            }
        }
        return token;
    }
}
