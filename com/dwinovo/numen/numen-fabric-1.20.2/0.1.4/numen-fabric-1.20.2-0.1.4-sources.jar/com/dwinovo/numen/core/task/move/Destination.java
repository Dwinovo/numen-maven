package com.dwinovo.numen.core.task.move;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import com.dwinovo.numen.core.nav.DigQuote;
import com.dwinovo.numen.core.nav.NavText;
import com.dwinovo.numen.core.nav.Terrain;
import com.dwinovo.numen.core.route.Stop;
import com.dwinovo.numen.core.route.Target;
import com.dwinovo.numen.core.task.dig.DigTaskRecord;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.pathing.body.Snapshots;
import com.dwinovo.numen.pathing.search.Goal;
import com.dwinovo.numen.pathing.search.Goals;
import com.dwinovo.numen.pathing.spec.RouteSpec;

/**
 * 去处:路线描述里的一站({@link Stop})按那一刻的世界编成的寻路目标。写法到目标的对应只在这里:
 * <ul>
 *   <li>{@code at}:位置——一格、一列、一个高度({@link Goals#at}、{@link Goals#column}、{@link Goals#level});站到一块方块上面
 *       也是 {@code at}:坐标是它上面脚所在的那一格;</li>
 *   <li>{@code near}:离它不超过 {@code range} 格({@link Goals#within});</li>
 *   <li>{@code use}:用那一格方块——站在它敞开的面前、看得见、点得到({@link Goals#use});</li>
 *   <li>{@code dig}:挖那一格方块——站到手够得着它、身体不占着它、挡着视线的都是 {@code numen.work.dig} 清得掉的地方
 *       ({@link Goals#dig},清不清得掉按 {@link #clearing} 问),那一格本身留给 {@code numen.work.dig};</li>
 *   <li>{@code place}:往那一格里放——手够得着它、身体不占着它({@link Goals#place});</li>
 *   <li>{@code away}:离它至少 {@code range} 格({@link Goals#within} 的最大是无穷)。</li>
 * </ul>
 * 一只实体按编目标那一刻它所在的那一格算。一堆格子(一团矿)对每一种到达都成立:{@code at}、{@code near}、{@code use}、
 * {@code place} 是到了其中任何一格就算({@link Goals#anyOf});{@code dig} 是够得着其中任意一个 {@code numen.work.dig} 挖得成的方块,
 * 同样划算的站位里优先一次够得着最多格的({@link Goals#dig(List, com.dwinovo.numen.pathing.world.BodyStats, Goals.Clearing)});
 * {@code away} 是离其中每一格都够远({@link Goals#allOf})。成员有界:只取离出发点最近的 {@link #MEMBERS} 格({@code use} 至多
 * {@link #USE_MEMBERS} 个)。
 *
 * <p>这一趟走不通的写法(站不进去、半空、没东西可用、四面封死)当场以带提醒的 {@link IllegalArgumentException} 交出,规划把它写进
 * 那一段的为什么;要不要提醒一律问模块({@link Terrain}),这里不另判。
 *
 * @param goal   编好的目标;{@code use} 的候选站位按编的那一刻的世界列定
 * @param toward 给人说"朝哪儿"的那一格(回执里的方向与距离)
 */
public record Destination(Stop stop, Goal goal, class_2338 toward) {

    /** 一堆格子至多取几个成员:估价与判到没到逐个问成员,几十个仍是一次比较的量级。 */
    static final int MEMBERS = 64;
    /** {@code use} 至多几个成员。 */
    static final int USE_MEMBERS = 8;
    /** {@code use} 至多为几个能点的方块列候选站位:每列一个都要在它周围一两千个节点上打射线。 */
    static final int USE_TRIES = 16;

    /**
     * 按此刻的世界把一站编成去处;这一趟走不通的写法抛出带提醒的 {@link IllegalArgumentException}。
     *
     * @param spec 走到这里的规格:许挖许放时,站不进去、站不上去的格由寻路去挖、去垫,不算走不通
     * @param from 从哪儿去:坐标缺的那一截照它补("朝哪儿"那一格),一堆格子按离它的远近挑成员
     */
    public static Destination of(NumenPlayer her, Stop stop, RouteSpec spec, class_2338 from) {
        if (stop.to() instanceof Target.Cells cells) {
            return cells(her, stop, spec, cells.cells(), from);
        } else if (stop.to() instanceof Target.Cell cell) {
            return cell(her, stop, spec, cell.pos());
        } else if (stop.to() instanceof Target.Mob mob) {
            class_1297 entity = mob.ref().in(her.method_51469());
            if (entity == null || entity == her) {
                throw new IllegalArgumentException("no entity with id " + mob.ref() + " is here — it died, left, "
                        + "or ids changed with a restart; numen.scan.entities() lists who is around");
            }
            return cell(her, stop, spec, entity.method_24515());
        } else if (stop.to() instanceof Target.Column column) {
            Goals.Position position = Goals.column(column.x(), column.z());
            return new Destination(stop, ranged(stop, position), new class_2338(column.x(), from.method_10264(), column.z()));
        } else {
            Target.Height height = (Target.Height) stop.to();
            return new Destination(stop, Goals.level(height.y()),
                    new class_2338(from.method_10263(), height.y(), from.method_10260()));
        }
    }

    /** {@code at}、{@code near}、{@code away} 对一个位置:正好在、不超过 {@code range}、至少 {@code range}。 */
    private static Goal ranged(Stop stop, Goals.Position position) {
        return switch (stop.arrive()) {
            case NEAR -> Goals.within(position, 0, stop.range());
            case AWAY -> Goals.within(position, stop.range(), Double.POSITIVE_INFINITY);
            default -> position;
        };
    }

    /** 一格的去处。 */
    private static Destination cell(NumenPlayer her, Stop stop, RouteSpec spec, class_2338 cell) {
        Terrain terrain = Terrain.of(her);
        Goal goal = switch (stop.arrive()) {
            case AT -> {
                if (!spec.changes() && !terrain.standable(cell)) {
                    throw new IllegalArgumentException(terrain.fits(cell.method_10263(), cell.method_10264(), cell.method_10260())
                            ? GotoReminders.midAir(cell, ground(terrain, cell))
                            : GotoReminders.occupied(cell, NavText.name(terrain.state(cell)),
                                    terrain.standingOn(cell)));
                }
                yield Goals.at(cell);
            }
            case NEAR, AWAY -> ranged(stop, Goals.at(cell));
            case USE -> use(her, terrain, cell);
            case DIG -> dig(her, terrain, cell);
            case PLACE -> reach(her, cell);
        };
        return new Destination(stop, goal, cell);
    }

    /** 一堆格子:按离出发点的远近挑成员,按到达方式编成"多个取其一"(见类说明)。 */
    private static Destination cells(NumenPlayer her, Stop stop, RouteSpec spec, List<class_2338> all, class_2338 from) {
        List<class_2338> nearest = all.stream().sorted(Comparator.comparingDouble(c -> c.method_10262(from))).toList();
        Terrain terrain = Terrain.of(her);
        List<Goal> members = new ArrayList<>();
        class_2338 toward = nearest.get(0);
        switch (stop.arrive()) {
            case AT -> {
                toward = null;
                for (class_2338 cell : nearest) {
                    // 许挖许放时站不进去的格由寻路去挖、去垫;没加载的列此刻判不了,留给走到那儿时的规划
                    if (spec.changes() || !terrain.loaded(cell.method_10263(), cell.method_10260()) || terrain.standable(cell)) {
                        members.add(Goals.at(cell));
                        toward = toward == null ? cell : toward;
                        if (members.size() == MEMBERS) {
                            break;
                        }
                    }
                }
                if (members.isEmpty()) {
                    throw new IllegalArgumentException(GotoReminders.cellsNowhereToStand(nearest.size()));
                }
            }
            case NEAR, AWAY, PLACE -> {
                for (class_2338 cell : nearest.subList(0, Math.min(MEMBERS, nearest.size()))) {
                    members.add(stop.arrive() == Stop.Arrive.PLACE ? reach(her, cell) : ranged(stop, Goals.at(cell)));
                }
                if (stop.arrive() == Stop.Arrive.AWAY) {
                    return new Destination(stop, Goals.allOf(members), toward);
                }
            }
            case USE -> {
                int tried = 0;
                class_2338 firstTried = null;
                toward = null;
                for (class_2338 cell : nearest) {
                    if (!terrain.clickable(cell)) {
                        continue;
                    }
                    Goals.Use use = terrain.use(cell);
                    firstTried = firstTried == null ? cell : firstTried;
                    tried++;
                    if (!use.sealed() && !use.stands().isEmpty()) {
                        members.add(use);
                        toward = toward == null ? cell : toward;
                    }
                    if (members.size() == USE_MEMBERS || tried == USE_TRIES) {
                        break;
                    }
                }
                if (firstTried == null) {
                    throw new IllegalArgumentException(GotoReminders.cellsNothingToUse(nearest.size()));
                }
                if (members.isEmpty()) {
                    throw new IllegalArgumentException(GotoReminders.cellsNoneUsable(tried, firstTried));
                }
            }
            case DIG -> {
                DigQuote pricing = DigQuote.of(her, DigTaskRecord.TARGET_SPEC);
                DigQuote clearing = clearing(her);
                List<Goals.DigTarget> targets = new ArrayList<>();
                String firstWhy = null;
                toward = null;
                for (class_2338 cell : nearest) {
                    // 没加载的列此刻判不了,留给走到那儿时的规划;空气与流体没有可挖的;挖不成的不去
                    boolean loaded = terrain.loaded(cell.method_10263(), cell.method_10260());
                    if (loaded && !terrain.clickable(cell)) {
                        continue;
                    }
                    String why = loaded ? undiggable(pricing, clearing, terrain, cell) : null;
                    if (why != null) {
                        firstWhy = firstWhy == null ? why : firstWhy;
                        continue;
                    }
                    // 挖它本身的价钱与 numen.work.dig 挑目标时同一个报价;没加载的列此刻读不到,不另收
                    targets.add(new Goals.DigTarget(cell,
                            loaded ? pricing.price(cell, terrain.state(cell)).cost() : 0));
                    toward = toward == null ? cell : toward;
                    if (targets.size() == MEMBERS) {
                        break;
                    }
                }
                if (targets.isEmpty()) {
                    throw new IllegalArgumentException(firstWhy != null
                            ? GotoReminders.cellsNoneDiggable(nearest.size(), firstWhy)
                            : GotoReminders.cellsNothingToDig(nearest.size()));
                }
                return new Destination(stop, Goals.dig(targets, Snapshots.stats(her), clearing.clearing()), toward);
            }
        }
        return new Destination(stop, members.size() == 1 ? members.get(0) : Goals.anyOf(members), toward);
    }

    /** 用一格方块的目标;没有可点的轮廓、四面封死、够得着的地方一处也站不了,都当场提醒。 */
    private static Goals.Use use(NumenPlayer her, Terrain terrain, class_2338 cell) {
        String block = NavText.name(terrain.state(cell));
        if (!terrain.clickable(cell)) {
            throw new IllegalArgumentException(GotoReminders.nothingToUse(cell, block));
        }
        Goals.Use use = terrain.use(cell);
        if (use.sealed()) {
            List<GotoReminders.Cover> covers = new ArrayList<>();
            for (class_2350 side : class_2350.values()) {
                class_2338 front = cell.method_10093(side);
                covers.add(new GotoReminders.Cover(side.method_10151(), NavText.name(terrain.state(front)), front));
            }
            covers.sort(Comparator.comparingDouble(c -> c.at().method_19770(her.method_33571())));
            throw new IllegalArgumentException(GotoReminders.sealed(cell, block, covers));
        }
        if (use.stands().isEmpty()) {
            throw new IllegalArgumentException(GotoReminders.nowhereToStand(cell, block,
                    use.open().stream().map(class_2350::method_10151).toList()));
        }
        return use;
    }

    /**
     * 往一格里放方块的目标:手够得着它、身体不占着它。{@code numen.build.place} 判"这一格够不够得着"问的也是它,走到了就放得了。
     */
    public static Goal reach(NumenPlayer her, class_2338 cell) {
        return Goals.place(cell, Snapshots.stats(her));
    }

    /** 挖一格方块的目标;空气、流体没有可挖的,站到哪儿 {@code numen.work.dig} 都挖不成的({@link #undiggable}),都当场提醒。 */
    private static Goal dig(NumenPlayer her, Terrain terrain, class_2338 cell) {
        if (!terrain.clickable(cell)) {
            throw new IllegalArgumentException(GotoReminders.nothingToDig(cell, NavText.name(terrain.state(cell))));
        }
        DigQuote clearing = clearing(her);
        String why = undiggable(DigQuote.of(her, DigTaskRecord.TARGET_SPEC), clearing, terrain, cell);
        if (why != null) {
            throw new IllegalArgumentException(why + ".");
        }
        return Goals.dig(cell, Snapshots.stats(her), clearing.clearing());
    }

    /**
     * 站到哪儿 {@code numen.work.dig} 都挖不成 {@code cell} 的缘由;挖得成为 null。问的是 {@code numen.work.dig} 挑目标时问的同几件事:按
     * {@link DigTaskRecord#TARGET_SPEC} 挖它进不进得了(物理上挖不挖得动、规则许不许),每一面是不是都贴着清不掉的方块。
     */
    private static String undiggable(DigQuote pricing, DigQuote clearing, Terrain terrain, class_2338 cell) {
        String refused = pricing.uncleared(cell);
        if (refused != null) {
            return GotoReminders.cantDig(cell, NavText.name(terrain.state(cell)), refused);
        }
        return clearing.walledIn(cell);
    }

    /**
     * 到了之后 {@code numen.work.dig} 清得掉哪些挡着视线的格:它清遮挡用的那份规格({@link DigTaskRecord#SPEC}),按此刻的身体与许可。
     * 走路许不许挖是这一趟自己的事,与它无关。
     */
    private static DigQuote clearing(NumenPlayer her) {
        return DigQuote.of(her, DigTaskRecord.SPEC);
    }

    /** 那一列里往下第一个站得住的节点;一直到底都没有为 null。 */
    private static class_2338 ground(Terrain terrain, class_2338 cell) {
        class_2338 settled = terrain.settle(cell);
        return terrain.standable(settled) ? settled : null;
    }
}
