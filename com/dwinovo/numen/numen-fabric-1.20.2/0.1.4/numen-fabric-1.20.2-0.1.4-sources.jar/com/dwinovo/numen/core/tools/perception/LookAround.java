package com.dwinovo.numen.core.tools.perception;

import com.dwinovo.numen.core.nav.Feet;
import com.dwinovo.numen.core.nav.Terrain;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.pathing.spec.RouteSpec;
import com.dwinovo.numen.pathing.world.Semantics;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3532;

/**
 * Egocentric spatial view: renders the blocks around the companion as an
 * agent-centred character grid (top-down, one cell per block, North up) rather
 * than a flat coordinate list. Each cell is semantic-pooled to the movement
 * class AND the vertical affordance at the companion's Y band — flat / step-up /
 * step-down / drop / wall / water / lava — so the model reads terrain, obstacles,
 * gaps and jumpable ledges as a map instead of probing single cells.
 *
 * <p>The representation follows the egocentric semantic grid shown to help LLM
 * spatial reasoning in Gao et al., "Exploring Spatial Representation to Enhance
 * LLM Reasoning in Aerial Vision-Language Navigation" (arXiv:2410.08500). The
 * vertical affordance encoding (collapsing a few height slices into one movement
 * symbol) and the hazard "inflation" buffer follow the occupancy-grid / layered
 * costmap practice in autonomous-driving navigation (e.g. Occ3D; ROS Nav2
 * costmap_2d). Sparse far-field objects are left to {@code scan blocks} /
 * {@code scan entities}; this map is the dense near-field half. The command and its
 * shortcut ({@code scan map}) are declared in {@link ScanCommands}.
 *
 * <p>Where she can stand and where her body fits are read off her {@link Terrain} — the pathing module's terrain
 * geometry (layer 0) bound to her body, the very rules the route planner walks by, so the map and the walk never
 * disagree.
 */
final class LookAround {

    static final int DEFAULT_RADIUS = 8;
    static final int MIN_RADIUS = 4;
    static final int MAX_RADIUS = 16;
    /** How far below foot level a floor may sit before the cell reads as a drop. */
    private static final int DROP_DEPTH = 3;

    // Cell glyphs.
    private static final char YOU = '@';
    private static final char FLAT = '.';       // walkable, same level
    private static final char STEP_UP = '^';    // walkable by a 1-block jump up
    private static final char STEP_DOWN = ',';  // walkable, 1-2 blocks down
    private static final char DROP = 'v';        // drop of DROP_DEPTH+ blocks
    private static final char WALL = '#';        // blocked / step up >= 2
    private static final char WATER = '~';
    private static final char HAZARD = '!';      // lava / fire
    private static final char CAUTION = 'x';     // inflation buffer next to a hazard
    private static final char TREE = 'T';
    private static final char UNLOADED = '?';

    private LookAround() {}

    /**
     * The map of the {@code (2 * radius + 1)}-wide square around her feet; {@code radius} is clamped to 4-16: the map row
     * by row (north first), the cell it is centred on, her facing and the legend.
     */
    static ScanApi.GroundMap render(NumenPlayer self, int asked) {
        int radius = class_3532.method_15340(asked, MIN_RADIUS, MAX_RADIUS);
        Terrain view = Terrain.of(self);
        class_2338 center = Feet.cell(self);
        int cx = center.method_10263();
        int cy = center.method_10264();
        int cz = center.method_10260();

        int size = 2 * radius + 1;
        char[][] grid = new char[size][size];
        for (int r = 0; r < size; r++) {
            int dz = r - radius;                 // r=0 is north (-Z), top
            for (int c = 0; c < size; c++) {
                int dx = c - radius;             // c=0 is west (-X), left
                grid[r][c] = (dx == 0 && dz == 0)
                        ? YOU
                        : classify(view, cx + dx, cy, cz + dz);
            }
        }
        inflateHazards(grid, size);

        java.util.List<String> rows = new java.util.ArrayList<>();
        for (int r = 0; r < size; r++) {
            StringBuilder row = new StringBuilder();
            for (int c = 0; c < size; c++) {
                row.append(grid[r][c]);
                if (c < size - 1) {
                    row.append(' ');
                }
            }
            rows.add(row.toString());
        }
        String legend = "@ you | . flat | ^ step-up 1 | , step-down 1-2 | v drop>=" + DROP_DEPTH
                + " | # wall/blocked | ~ water | ! lava/hazard | x caution | T tree | ? unloaded";
        return new ScanApi.GroundMap(rows, center, self.method_5735().method_10151(), legend);
    }

    /** Semantic-pool the column at (x,z) to one movement-affordance glyph at the companion's Y band. */
    private static char classify(Terrain view, int x, int feetY, int z) {
        if (!view.loaded(x, z)) {
            return UNLOADED;
        }
        class_2680 feetState = view.state(new class_2338(x, feetY, z));
        class_2680 headState = view.state(new class_2338(x, feetY + 1, z));

        if (lava(view, x, feetY, z) || lava(view, x, feetY + 1, z)) {
            return HAZARD;
        }
        if (feetState.method_26204() instanceof class_2404 || headState.method_26204() instanceof class_2404) {
            return WATER;
        }

        // Highest surface you could stand on within a jump-up / short-drop band. Going down the column, the
        // first liquid you would step onto is the surface: a lake level with the shore is water, not a pit.
        Integer standY = null;
        for (int y = feetY + 1; y >= feetY - DROP_DEPTH; y--) {
            if (view.standingSpot(new class_2338(x, y, z), RouteSpec.defaults())) {
                standY = y;
                break;
            }
            class_2680 floor = view.state(new class_2338(x, y - 1, z));
            if (y <= feetY && lava(view, x, y - 1, z)) {
                return HAZARD;
            }
            if (y <= feetY && floor.method_26204() instanceof class_2404) {
                return WATER;
            }
        }
        if (standY == null) {
            boolean bodyClear = view.fits(x, feetY, z);
            if (!bodyClear) {
                return (isTree(feetState) || isTree(headState)) ? TREE : WALL;
            }
            return DROP; // body clear but no floor within reach -> open pit/void
        }
        int delta = standY - feetY;
        if (delta >= 2) {
            return WALL;
        }
        if (delta == 1) {
            return STEP_UP;
        }
        if (delta == 0) {
            return FLAT;
        }
        if (delta >= -2) {
            return STEP_DOWN;
        }
        return DROP;
    }

    private static boolean lava(Terrain view, int x, int y, int z) {
        return view.is(new class_2338(x, y, z), Semantics.Kind.LAVA);
    }

    /** Layered-costmap style: ring a caution buffer around lava/fire so the model keeps clear of edges. */
    private static void inflateHazards(char[][] grid, int size) {
        boolean[][] near = new boolean[size][size];
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (grid[r][c] == HAZARD) {
                    for (int dr = -1; dr <= 1; dr++) {
                        for (int dc = -1; dc <= 1; dc++) {
                            int nr = r + dr;
                            int nc = c + dc;
                            if (nr >= 0 && nr < size && nc >= 0 && nc < size) {
                                near[nr][nc] = true;
                            }
                        }
                    }
                }
            }
        }
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (near[r][c] && isWalkable(grid[r][c])) {
                    grid[r][c] = CAUTION;
                }
            }
        }
    }

    private static boolean isWalkable(char c) {
        return c == FLAT || c == STEP_UP || c == STEP_DOWN;
    }

    private static boolean isTree(class_2680 state) {
        return state.method_26164(class_3481.field_15475) || state.method_26164(class_3481.field_15503);
    }
}
