package com.dwinovo.numen.core.mixin;

import com.dwinovo.numen.core.act.Drops;
import net.minecraft.class_1282;
import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 掉落物的两件事交给 {@link Drops}:同种的两堆并成一堆(并过去几件),挨打挨到没了(是什么打的)。原版与两个加载器都没有这两件事的
 * 事件;不跟并堆,并进别的一堆的会被当成不见了,不记伤害来源,就说不出是岩浆、火还是仙人掌毁的。
 *
 * <p>并堆挂在 {@code tryToMerge}(两堆碰面的那一趟)的头尾:这一代没有包住整个方法的注入,拿不到并堆那个静态方法前后的件数,
 * 而两只实体各自的件数在这一趟前后看得见——少了的是并过去的那一只。
 */
@Mixin(class_1542.class)
public abstract class ItemEntityDropsMixin {

    /** 这一趟开始时这一堆的件数。每只实体只由一个线程刻它,所以存在实体自己身上。 */
    @Unique
    private int numen$countBefore;
    /** 这一趟开始时对面那一堆的件数。 */
    @Unique
    private int numen$otherBefore;

    @Inject(method = "tryToMerge", at = @At("HEAD"))
    private void numen$beforeMerge(class_1542 other, CallbackInfo ci) {
        numen$countBefore = ((class_1542) (Object) this).method_6983().method_7947();
        numen$otherBefore = other.method_6983().method_7947();
    }

    @Inject(method = "tryToMerge", at = @At("RETURN"))
    private void numen$followMerge(class_1542 other, CallbackInfo ci) {
        class_1542 self = (class_1542) (Object) this;
        int selfMoved = numen$countBefore - self.method_6983().method_7947();
        int otherMoved = numen$otherBefore - other.method_6983().method_7947();
        if (selfMoved > 0) {
            Drops.merged(other, self, selfMoved);
        } else if (otherMoved > 0) {
            Drops.merged(self, other, otherMoved);
        }
    }

    @Inject(method = "hurt", at = @At("RETURN"))
    private void numen$destroyed(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Drops.hurt((class_1542) (Object) this, source);
    }
}
