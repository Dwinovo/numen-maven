package com.dwinovo.numen.core.gear;

import com.dwinovo.numen.api.gear.GearSlot;
import com.dwinovo.numen.api.gear.GearSource;
import com.dwinovo.numen.entity.NumenPlayer;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1304;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

/**
 * 原版的四件甲,作为第一个 {@link GearSource} 经 {@code NumenApi.registerGear} 登记——和模组的饰品栏同一扇门。
 *
 * <p>判据全部取自身体物品栏菜单里真实的 {@code ArmorSlot}:放入问 {@link class_1735#method_7680}(NeoForge 改写成
 * {@code stack.canEquip},Fabric 是原版判据,各加载器用各自的原版规则),取出问 {@link class_1735#method_7674}
 * (绑定诅咒),写入走 {@link class_1735#method_53512}(触发 {@code onEquipItem},有穿戴音效)。
 * 和玩家在背包界面里拖动盔甲是同一条路径,这里不另写一份规则。
 */
public final class VanillaArmor implements GearSource {

    /** 物品栏菜单里 {@code ARMOR_SLOT_START + i} 对应的部位,顺序即 {@code <worn>} 与自动选位的顺序。 */
    private static final class_1304[] PIECES = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

    /** 四个槽名,按 {@link #PIECES} 的顺序。{@code slot=armor} 展开成的就是它。 */
    public static final List<String> NAMES = List.of(
            PIECES[0].method_5923(), PIECES[1].method_5923(), PIECES[2].method_5923(), PIECES[3].method_5923());

    @Override
    public List<GearSlot> slots(NumenPlayer body) {
        List<GearSlot> out = new ArrayList<>(PIECES.length);
        for (int i = 0; i < PIECES.length; i++) {
            out.add(new Piece(NAMES.get(i), body.field_7498.method_7611(class_1723.field_30806 + i), body));
        }
        return out;
    }

    /** 哪几个部位的真实格子肯收它——与 {@link Piece#refuseWear} 是同一个判据。 */
    @Override
    public Set<String> kindsOf(NumenPlayer body, class_1799 stack) {
        Set<String> kinds = new LinkedHashSet<>();
        for (int i = 0; i < PIECES.length; i++) {
            if (body.field_7498.method_7611(class_1723.field_30806 + i).method_7680(stack)) {
                kinds.add(NAMES.get(i));
            }
        }
        return kinds;
    }

    private record Piece(String name, class_1735 slot, NumenPlayer body) implements GearSlot {

        @Override
        public class_1799 worn() {
            return slot.method_7677();
        }

        @Override
        public Optional<String> refuseWear(class_1799 one) {
            return slot.method_7680(one) ? Optional.empty()
                    : Optional.of(id(one) + " can't be worn on " + name);
        }

        /** 原版 {@code ArmorSlot} 只在一种情况下不许摘:带"阻止换甲"效果的附魔,也就是绑定诅咒。 */
        @Override
        public Optional<String> refuseRemove() {
            class_1799 worn = slot.method_7677();
            return worn.method_7960() || slot.method_7674(body) ? Optional.empty()
                    : Optional.of(id(worn) + " is stuck on " + name + " (curse of binding)");
        }

        @Override
        public class_1799 swap(class_1799 in) {
            class_1799 old = slot.method_7677();
            slot.method_7673(in);
            return old;
        }

        private static String id(class_1799 stack) {
            return class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
        }
    }
}
