package com.dwinovo.numen.core.mixin;

import com.dwinovo.numen.core.act.Drops;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 玩家的手挖掉一格的那一段:原版不论秒破、累着进度挖碎还是服务端延迟落地(在她自己的玩家刻里,不在挖掘任务的刻里),都经
 * {@code destroyBlock};这一段里生成的掉落物是这一挖的,由 {@link Drops} 认领。原版没有"谁的手挖掉了这一格、掉了什么"的事件,
 * NeoForge 的掉落事件 Fabric 没有,common 不按加载器分支,所以挂在两边共有的这一处。
 *
 * <p>这一代没有包住整个方法的注入,开头记下开始、每个出口记下结束。
 */
@Mixin(class_3225.class)
public abstract class ServerPlayerGameModeDropsMixin {

    @Shadow
    @Final
    protected class_3222 player;

    @Inject(method = "destroyBlock", at = @At("HEAD"))
    private void numen$breakStarts(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        Drops.breakStarts(player);
    }

    @Inject(method = "destroyBlock", at = @At("RETURN"))
    private void numen$breakEnds(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        Drops.breakEnds();
    }
}
