package com.dwinovo.numen.core.act;

import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2680;

/**
 * The two "swap the best implement into the main hand" helpers, unified from
 * the duplicated block-breaking and combat inventory scans.
 *
 * <p>Both scan the WHOLE inventory (not just the hotbar) and swap via
 * {@link NumenPlayer#holdInHand(int)} so the selected item matches the action
 * the task is about to perform.
 */
public final class ToolSelect {

    private ToolSelect() {}

    /**
     * Hold the best implement for breaking {@code state}: among tools that beat
     * the bare hand, one that actually harvests the block (correct tier when the
     * block gates its drops) outranks a merely faster one.
     */
    public static void holdBestTool(NumenPlayer p, class_2680 state) {
        class_1661 inv = p.method_31548();
        boolean tierGated = state.method_29291();
        int harvest = -1, any = -1;
        float harvestSpeed = 1.0f, anySpeed = 1.0f;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            float spd = s.method_7924(state);
            if (spd <= 1.0f) continue;
            if (!tierGated || s.method_7951(state)) {
                if (spd > harvestSpeed) { harvestSpeed = spd; harvest = i; }
            } else if (spd > anySpeed) {
                anySpeed = spd;
                any = i;
            }
        }
        int best = harvest >= 0 ? harvest : any;
        if (best >= 0) {
            p.holdInHand(best);
        }
    }
}
