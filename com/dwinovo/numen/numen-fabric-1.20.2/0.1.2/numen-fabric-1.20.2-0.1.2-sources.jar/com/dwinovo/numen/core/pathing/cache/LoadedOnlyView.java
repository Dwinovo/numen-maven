package com.dwinovo.numen.core.pathing.cache;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;

/**
 * 活世界的"只读已加载"视图:读到未加载区块一律返回空气/空流体,
 * <b>绝不触发同步区块加载或生成</b>({@code getChunkNow} 只查内存)。
 * 执行期逐 tick 的成本复核与格集重算读的世界经此钳制——路径末端
 * 伸进未生成地形时,每 tick 的读取不会把服务端线程卡在原地生成
 * 区块上。已加载区块的读取与直读 level 完全一致。
 */
public final class LoadedOnlyView implements class_1922 {

    private static final class_2680 AIR = class_2246.field_10124.method_9564();

    private final class_3218 level;

    private LoadedOnlyView(class_3218 level) {
        this.level = level;
    }

    /**
     * 包一层钳制视图;非服务端世界(测试壳)直接返回原视图,不钳制。
     */
    public static class_1922 of(class_1937 level) {
        return level instanceof class_3218 server ? new LoadedOnlyView(server) : level;
    }

    /** (方块坐标)所在 chunk 此刻是否已加载在内存中。 */
    public boolean isLoaded(int x, int z) {
        return chunkAt(x, z) != null;
    }

    private class_2818 chunkAt(int blockX, int blockZ) {
        return level.method_14178().method_21730(blockX >> 4, blockZ >> 4);
    }

    @Override
    public class_2680 method_8320(class_2338 pos) {
        if (level.method_31606(pos)) {
            return AIR;
        }
        class_2818 chunk = chunkAt(pos.method_10263(), pos.method_10260());
        return chunk == null ? AIR : chunk.method_8320(pos);
    }

    @Override
    public class_3610 method_8316(class_2338 pos) {
        if (level.method_31606(pos)) {
            return class_3612.field_15906.method_15785();
        }
        class_2818 chunk = chunkAt(pos.method_10263(), pos.method_10260());
        return chunk == null ? class_3612.field_15906.method_15785() : chunk.method_8316(pos);
    }

    @Override
    public class_2586 method_8321(class_2338 pos) {
        class_2818 chunk = chunkAt(pos.method_10263(), pos.method_10260());
        return chunk == null ? null : chunk.method_8321(pos);
    }

    @Override
    public int method_31605() {
        return level.method_31605();
    }

    @Override
    public int method_31607() {
        return level.method_31607();
    }
}
