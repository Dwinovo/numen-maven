package com.dwinovo.numen.core.task.fish;
import com.dwinovo.numen.core.FailureType;

import com.dwinovo.numen.core.Constants;
import com.dwinovo.numen.core.mixin.FishingHookAccessor;
import com.dwinovo.numen.core.pathing.calc.NavGoal;
import com.dwinovo.numen.core.pathing.execute.PlayerNav;
import com.dwinovo.numen.core.pathing.util.BlockHelper;
import com.dwinovo.numen.core.task.base.AbstractCompanionTask;
import com.dwinovo.numen.core.task.base.Precondition;
import com.dwinovo.numen.entity.InputDriver;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.task.TaskState;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1542;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3959;

/** Tick-driven vanilla fishing from a nearby water surface. */
public final class FishCompanionTask extends AbstractCompanionTask<FishTaskRecord> {

    private enum Phase { POSITION, PREPARE, AIM, WAIT, COLLECT, COOLDOWN }

    private record FishingSetup(class_2338 stance, class_2338 water) {}

    private static final int STANCE_SEARCH_RADIUS = 12;
    private static final int STANCE_SEARCH_Y = 4;
    private static final int MAX_STANCE_CHECKS = 256;
    private static final int MAX_POSITION_FAILURES = 3;
    private static final double NAV_SPEED = 1.0;

    private static final int CAST_SEARCH_RADIUS = 10;
    private static final int CAST_SEARCH_Y = 4;
    private static final double MIN_CAST_DISTANCE = 4.0;
    private static final double IDEAL_CAST_DISTANCE = 6.0;
    private static final double WATER_SURFACE_OFFSET = 0.85;
    private static final int AIM_TICKS = 3;
    private static final int CAST_SETTLE_TIMEOUT = 5 * 20;
    private static final int CAST_LIFETIME = 60 * 20;
    private static final int COOLDOWN_TICKS = 10;
    private static final int MAX_FAILED_CASTS = 5;

    /** Vanilla reels the loot toward the player, but terrain can stop it short. */
    private static final double LOOT_SEARCH_RADIUS = 18.0;
    private static final double PICKUP_REACH_SQR = 1.5;
    private static final int LOOT_DISCOVERY_TICKS = 10;
    /** Let vanilla's reel impulse bring the catch back before chasing it. */
    private static final int LOOT_RETURN_GRACE_TICKS = 20;
    private static final int LOOT_CLOSE_WAIT_TICKS = 20;
    private static final int LOOT_COLLECTION_TIMEOUT = 20 * 20;

    private static final double FISHING_DRAG = 0.92;
    private static final double FISHING_GRAVITY = 0.03;
    private static final int MAX_FLIGHT_TICKS = 80;

    private final Set<class_2338> rejectedStances = new HashSet<>();
    private final Set<class_2338> rejectedTargets = new HashSet<>();
    /** 本次收线的战果簿记:先快照现场旧物,差集出的新掉落才算这一竿的。 */
    private final com.dwinovo.numen.core.task.base.DropTracker caught =
            new com.dwinovo.numen.core.task.base.DropTracker();
    /** 判定够不着而放弃的战果 id(留在地上,不再追)。 */
    private final Set<Integer> abandonedLoot = new HashSet<>();

    private Phase phase = Phase.POSITION;
    private class_2338 stance;
    private class_2338 target;
    private int phaseTicks;
    private int failedCasts;
    private int positionFailures;
    private class_1542 lootTarget;
    private int lootCloseTicks;
    private int unreachableLoot;

    public FishCompanionTask(NumenPlayer player, FishTaskRecord record) {
        super(player, record);
    }

    @Override
    protected List<Precondition> preconditions() {
        return List.of(() -> findRodSlot() >= 0 ? null
                : new Precondition.Failure("fish needs a fishing rod in inventory",
                        FailureType.WRONG_TOOL));
    }

    @Override
    protected TaskState onTick() {
        if (player.method_29504()) return TaskState.CANCELLED;

        InputDriver.halt(player);
        if (phase == Phase.POSITION) return positionForFishing();
        if (phase == Phase.COLLECT) return collectCaughtLoot();
        // requested == 0 = 主人没说钓几条 —— 这一行永远不成立,任务就是常驻的:
        // 一直钓下去,直到主人换掉她手上的活。同一段逻辑,两种用法。
        if (r.requested > 0 && r.caught() >= r.requested) return TaskState.SUCCESS;

        int rodSlot = findRodSlot();
        if (rodSlot < 0) {
            discardHook();
            fail("fishing stopped because there is no fishing rod left", FailureType.WRONG_TOOL);
            return TaskState.FAILED;
        }
        player.holdInHand(rodSlot);
        if (!player.method_6047().method_31574(class_1802.field_8378)) return TaskState.RUNNING;

        return switch (phase) {
            case POSITION -> throw new IllegalStateException("position phase handled above");
            case PREPARE -> prepare();
            case AIM -> aimAndCast();
            case WAIT -> waitForBite();
            case COLLECT -> throw new IllegalStateException("collect phase handled above");
            case COOLDOWN -> coolDown();
        };
    }

    private TaskState positionForFishing() {
        if (stance == null || target == null) {
            FishingSetup setup = findFishingSetup();
            if (setup == null) {
                fail("no safe dry fishing stance with reachable water nearby; move close to a shoreline and try fish again",
                        FailureType.OUT_OF_REACH);
                return TaskState.FAILED;
            }
            stance = setup.stance();
            target = setup.water();
        }

        if (atStance()) {
            stopNav();
            phase = Phase.PREPARE;
            return TaskState.RUNNING;
        }
        if (nav == null) {
            nav = PlayerNav.toGoal(player, () -> NavGoal.exact(stance), NAV_SPEED, this::atStance);
        }
        return switch (nav.tick()) {
            case RUNNING -> TaskState.RUNNING;
            case ARRIVED -> {
                stopNav();
                phase = Phase.PREPARE;
                yield TaskState.RUNNING;
            }
            case FAILED -> {
                rejectedStances.add(stance);
                stopNav();
                stance = null;
                target = null;
                if (++positionFailures >= MAX_POSITION_FAILURES) {
                    fail("nearby dry fishing stances were unreachable; move onto a clear shoreline and try fish again",
                            FailureType.NO_PATH);
                    yield TaskState.FAILED;
                }
                yield TaskState.RUNNING;
            }
        };
    }

    private FishingSetup findFishingSetup() {
        class_2338 current = feet();
        if (isDryStance(current) && !rejectedStances.contains(current)) {
            class_2338 water = findCastTarget(current, player.method_33571());
            if (water != null) return new FishingSetup(current, water);
            // Already safely on land but no water is in casting range. Long-distance
            // water discovery belongs to the model's locate/move step, not this job.
            return null;
        }

        List<class_2338> candidates = new ArrayList<>();
        class_2338 origin = player.method_24515();
        for (int dy = -STANCE_SEARCH_Y; dy <= STANCE_SEARCH_Y; dy++) {
            for (int dx = -STANCE_SEARCH_RADIUS; dx <= STANCE_SEARCH_RADIUS; dx++) {
                for (int dz = -STANCE_SEARCH_RADIUS; dz <= STANCE_SEARCH_RADIUS; dz++) {
                    if (dx * dx + dz * dz > STANCE_SEARCH_RADIUS * STANCE_SEARCH_RADIUS) continue;
                    class_2338 candidate = origin.method_10069(dx, dy, dz);
                    if (!rejectedStances.contains(candidate) && isDryStance(candidate)) {
                        candidates.add(candidate.method_10062());
                    }
                }
            }
        }
        candidates.sort(Comparator.comparingDouble(current::method_10262));
        int checks = Math.min(MAX_STANCE_CHECKS, candidates.size());
        for (int i = 0; i < checks; i++) {
            class_2338 candidate = candidates.get(i);
            class_243 eye = new class_243(candidate.method_10263() + 0.5,
                    candidate.method_10264() + player.method_5751(), candidate.method_10260() + 0.5);
            class_2338 water = findCastTarget(candidate, eye);
            if (water != null) return new FishingSetup(candidate, water);
        }
        return null;
    }

    private TaskState prepare() {
        if (player.field_7513 != null) {
            discardHook();
            return TaskState.RUNNING;
        }

        class_2338 current = feet();
        if (!isDryStance(current)) {
            resetPositioning();
            return TaskState.RUNNING;
        }
        if (!current.equals(stance)) {
            stance = current;
            target = null;
        }
        if (target == null || !isCastableSurface(target)
                || !trajectoryClear(player.method_33571(), target)) {
            target = findCastTarget(stance, player.method_33571());
        }
        if (target == null && !rejectedTargets.isEmpty()) {
            // A tiny pond may expose only one valid landing cell. After trying all
            // distinct candidates, permit another ballistic attempt instead of
            // converting one unlucky cast into a permanent "no water" verdict.
            rejectedTargets.clear();
            target = findCastTarget(stance, player.method_33571());
        }
        if (target == null) {
            fail("no unobstructed fishing cast is available from this dry stance; move along the shoreline and try again",
                    FailureType.OUT_OF_REACH);
            return TaskState.FAILED;
        }

        phase = Phase.AIM;
        phaseTicks = 0;
        aimAtTarget();
        return TaskState.RUNNING;
    }

    private TaskState aimAndCast() {
        if (!isCastableSurface(target) || !trajectoryClear(player.method_33571(), target)) {
            return failedCast("the selected water surface became obstructed", true);
        }
        aimAtTarget();
        if (++phaseTicks < AIM_TICKS) return TaskState.RUNNING;

        double pitch = castPitchDegrees(player.method_33571(), target);
        player.field_13974.method_14256(player, player.method_37908(), player.method_6047(), class_1268.field_5808);
        r.castOnce();
        if (player.field_7513 == null) {
            return failedCast("the fishing rod did not cast", false);
        }
        Constants.LOG.debug("[numen-fish] cast={} target={} pitch={}", r.casts(),
                target.method_23854(), String.format(java.util.Locale.ROOT, "%.1f", pitch));
        phase = Phase.WAIT;
        phaseTicks = 0;
        return TaskState.RUNNING;
    }

    private TaskState waitForBite() {
        class_1536 hook = player.field_7513;
        if (hook == null || hook.method_31481()) {
            return failedCast("the fishing hook disappeared before a catch", false);
        }
        phaseTicks++;

        class_1297 hooked = hook.method_26957();
        if (hooked != null) {
            reelIn();
            return failedCast("the hook caught an entity instead of landing cleanly", true);
        }

        int nibble = ((FishingHookAccessor) (Object) hook).numen$getNibble();
        if (isBiteWindow(nibble)) {
            beginLootCollection();
            r.caughtOne();
            Constants.LOG.debug("[numen-fish] caught={}/{} casts={}",
                    r.caught(), r.requested, r.casts());
            return TaskState.RUNNING;
        }

        boolean inWater = hook.method_37908().method_8316(hook.method_24515()).method_15767(class_3486.field_15517);
        if (!inWater && phaseTicks >= CAST_SETTLE_TIMEOUT) {
            Constants.LOG.debug("[numen-fish] miss hook={} on_ground={} age={}",
                    hook.method_24515().method_23854(), hook.method_24828(), phaseTicks);
            return failedCast("the fishing hook did not settle in water", true);
        }
        if (phaseTicks >= CAST_LIFETIME) {
            return failedCast("no bite arrived before the cast timed out", false);
        }
        return TaskState.RUNNING;
    }

    /**
     * Finish the semantic catch, not merely the rod interaction: walk to every
     * ItemEntity created by this reel until vanilla pickup absorbs it. Fishing
     * loot is launched toward the owner, but a bank, slab or ledge can intercept
     * it several blocks away (the exact failure seen in ordinary play-testing).
     */
    private TaskState collectCaughtLoot() {
        phaseTicks++;
        if (phaseTicks <= LOOT_DISCOVERY_TICKS) caught.discover(player.method_37908(), lootBox());

        if (phaseTicks >= LOOT_COLLECTION_TIMEOUT) {
            int remaining = liveCaught().size();
            fail("reeled in fishing loot but timed out while retrieving " + remaining
                    + " dropped loot item(s)", FailureType.NO_PATH);
            return TaskState.FAILED;
        }

        // A vanilla reel launches its loot toward the owner. Planning against that
        // still-moving entity makes the body step off the bank to "meet" a catch
        // that would have arrived by itself. Hold the known-safe stance briefly;
        // genuine stranded loot is still path-found after this grace period.
        boolean returningLoot = !liveCaught().isEmpty();
        if (returningLoot && phaseTicks <= LOOT_RETURN_GRACE_TICKS) {
            return TaskState.RUNNING;
        }

        if (lootTarget != null) {
            if (lootTarget.method_31481()) {
                lootTarget = null;
                lootCloseTicks = 0;
                stopNav();
            } else if (player.method_5858(lootTarget) <= PICKUP_REACH_SQR) {
                // Give vanilla collision pickup a full second. This also produces
                // a useful failure for a full inventory instead of looping forever.
                stopNav();
                if (++lootCloseTicks >= LOOT_CLOSE_WAIT_TICKS) abandonLootTarget();
                return TaskState.RUNNING;
            } else {
                lootCloseTicks = 0;
                if (nav == null) {
                    nav = new PlayerNav(player, lootTarget::method_24515, NAV_SPEED,
                            () -> lootTarget == null || lootTarget.method_31481()
                                    || player.method_5858(lootTarget) <= PICKUP_REACH_SQR);
                }
                switch (nav.tick()) {
                    case RUNNING -> { return TaskState.RUNNING; }
                    case ARRIVED -> { return TaskState.RUNNING; }
                    case FAILED -> {
                        abandonLootTarget();
                        return TaskState.RUNNING;
                    }
                }
            }
        }

        class_3218 level = (class_3218) player.method_37908();
        caught.prune(level);
        lootTarget = caught.nearest(level, player, abandonedLoot).orElse(null);
        if (lootTarget != null) {
            stopNav();
            return TaskState.RUNNING;
        }

        // A freshly spawned catch can be absorbed on the same tick or become
        // query-visible one tick later. Keep the short discovery window before
        // deciding that there is nothing left to retrieve.
        if (phaseTicks < LOOT_DISCOVERY_TICKS) return TaskState.RUNNING;
        if (unreachableLoot > 0) {
            fail("reeled in fishing loot but could not reach " + unreachableLoot
                    + " dropped loot item(s)", FailureType.NO_PATH);
            return TaskState.FAILED;
        }
        clearLootTracking();
        beginCooldown();
        return TaskState.RUNNING;
    }

    private void beginLootCollection() {
        caught.clear();
        abandonedLoot.clear();
        lootTarget = null;
        lootCloseTicks = 0;
        unreachableLoot = 0;
        caught.rememberExisting(player.method_37908(), lootBox());

        reelIn();
        phase = Phase.COLLECT;
        phaseTicks = 0;
        stopNav();
        caught.discover(player.method_37908(), lootBox());
    }

    /** 收线战果的搜索范围:落点可能被岸坡/台阶截在几格外。 */
    private class_238 lootBox() {
        return player.method_5829().method_1014(LOOT_SEARCH_RADIUS);
    }

    /** 仍在世且未被放弃的本竿战果。 */
    private List<class_1542> liveCaught() {
        return caught.live((class_3218) player.method_37908(), abandonedLoot);
    }

    private void abandonLootTarget() {
        if (lootTarget != null) abandonedLoot.add(lootTarget.method_5628());
        unreachableLoot++;
        lootTarget = null;
        lootCloseTicks = 0;
        stopNav();
    }

    private void clearLootTracking() {
        caught.clear();
        abandonedLoot.clear();
        lootTarget = null;
        lootCloseTicks = 0;
        unreachableLoot = 0;
        stopNav();
    }

    private TaskState coolDown() {
        if (++phaseTicks < COOLDOWN_TICKS) return TaskState.RUNNING;
        // requested == 0 = 主人没说钓几条 —— 这一行永远不成立,任务就是常驻的:
        // 一直钓下去,直到主人换掉她手上的活。同一段逻辑,两种用法。
        if (r.requested > 0 && r.caught() >= r.requested) return TaskState.SUCCESS;
        phase = Phase.PREPARE;
        phaseTicks = 0;
        return TaskState.RUNNING;
    }

    private TaskState failedCast(String reason, boolean rejectTarget) {
        class_2338 failedTarget = target;
        discardHook();
        if (rejectTarget && failedTarget != null) rejectedTargets.add(failedTarget);
        if (++failedCasts >= MAX_FAILED_CASTS) {
            fail(reason + " after " + failedCasts
                    + " attempts; move to a clearer shoreline and try fish again", FailureType.OUT_OF_REACH);
            return TaskState.FAILED;
        }
        phase = Phase.PREPARE;
        phaseTicks = 0;
        if (rejectTarget) target = null;
        return TaskState.RUNNING;
    }

    private void beginCooldown() {
        phase = Phase.COOLDOWN;
        phaseTicks = 0;
        failedCasts = 0;
        rejectedTargets.clear();
    }

    private void resetPositioning() {
        discardHook();
        stopNav();
        clearLootTracking();
        phase = Phase.POSITION;
        phaseTicks = 0;
        stance = null;
        target = null;
        rejectedTargets.clear();
    }

    private void reelIn() {
        if (player.field_7513 != null && player.method_6047().method_31574(class_1802.field_8378)) {
            player.field_13974.method_14256(player, player.method_37908(), player.method_6047(),
                    class_1268.field_5808);
        }
    }

    private int findRodSlot() {
        var inventory = player.method_31548();
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_31574(class_1802.field_8378)) return i;
        }
        return -1;
    }

    private class_2338 findCastTarget(class_2338 fromStance, class_243 eye) {
        List<class_2338> candidates = new ArrayList<>();
        for (int dy = -CAST_SEARCH_Y; dy <= CAST_SEARCH_Y; dy++) {
            for (int dx = -CAST_SEARCH_RADIUS; dx <= CAST_SEARCH_RADIUS; dx++) {
                for (int dz = -CAST_SEARCH_RADIUS; dz <= CAST_SEARCH_RADIUS; dz++) {
                    double horizontal = Math.sqrt(dx * dx + dz * dz);
                    if (horizontal < MIN_CAST_DISTANCE || horizontal > CAST_SEARCH_RADIUS) continue;
                    class_2338 candidate = fromStance.method_10069(dx, dy, dz);
                    if (!rejectedTargets.contains(candidate) && isCastableSurface(candidate)) {
                        candidates.add(candidate.method_10062());
                    }
                }
            }
        }
        candidates.sort(Comparator.comparingDouble(candidate -> castScore(fromStance, candidate)));
        for (class_2338 candidate : candidates) {
            if (trajectoryClear(eye, candidate)) return candidate;
        }
        return null;
    }

    private double castScore(class_2338 fromStance, class_2338 candidate) {
        double dx = candidate.method_10263() - fromStance.method_10263();
        double dz = candidate.method_10260() - fromStance.method_10260();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return Math.abs(horizontal - IDEAL_CAST_DISTANCE)
                + Math.abs(candidate.method_10264() - fromStance.method_10264()) * 0.35
                - waterNeighbourCount(candidate) * 0.04;
    }

    private int waterNeighbourCount(class_2338 pos) {
        int count = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (isCastableSurface(pos.method_10069(dx, 0, dz))) count++;
            }
        }
        return count;
    }

    private boolean isCastableSurface(class_2338 pos) {
        var fluid = player.method_37908().method_8316(pos);
        if (!fluid.method_15767(class_3486.field_15517) || !fluid.method_15771()) return false;
        if (player.method_37908().method_8316(pos.method_10084()).method_15767(class_3486.field_15517)) return false;
        return player.method_37908().method_8320(pos.method_10084())
                .method_26220(player.method_37908(), pos.method_10084()).method_1110();
    }

    private boolean isDryStance(class_2338 pos) {
        return player.method_37908().method_8316(pos).method_15769()
                && player.method_37908().method_8316(pos.method_10084()).method_15769()
                && BlockHelper.canWalkThrough(player.method_37908(), pos)
                && BlockHelper.canWalkThrough(player.method_37908(), pos.method_10084())
                && BlockHelper.canWalkOn(player.method_37908(), pos.method_10074());
    }

    private boolean atStance() {
        return stance != null && feet().equals(stance) && isDryStance(stance);
    }

    private class_2338 feet() {
        return BlockHelper.playerFeet(player.method_37908(), player.method_23317(), player.method_23318(), player.method_23321());
    }

    private void aimAtTarget() {
        InputDriver.lookAt(player, castAimPoint(player.method_33571(), target));
    }

    private static class_243 castAimPoint(class_243 eye, class_2338 target) {
        double tx = target.method_10263() + 0.5;
        double tz = target.method_10260() + 0.5;
        double dx = tx - eye.field_1352;
        double dz = tz - eye.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 1.0e-6) return new class_243(tx, waterSurfaceY(target), tz);
        double pitch = Math.toRadians(castPitchDegrees(eye, target));
        double scale = 16.0 / horizontal;
        return new class_243(eye.field_1352 + dx * scale,
                eye.field_1351 - Math.tan(pitch) * 16.0,
                eye.field_1350 + dz * scale);
    }

    private boolean trajectoryClear(class_243 eye, class_2338 target) {
        double tx = target.method_10263() + 0.5;
        double tz = target.method_10260() + 0.5;
        double dx = tx - eye.field_1352;
        double dz = tz - eye.field_1350;
        double directDistance = Math.sqrt(dx * dx + dz * dz);
        if (directDistance < 1.0e-6) return false;
        double ux = dx / directDistance;
        double uz = dz / directDistance;
        // Vanilla spawns the bobber 0.3 blocks in front of the player's eyes.
        class_243 pos = eye.method_1031(ux * 0.3, 0.0, uz * 0.3);
        double distance = Math.sqrt((tx - pos.field_1352) * (tx - pos.field_1352) + (tz - pos.field_1350) * (tz - pos.field_1350));
        double pitch = Math.toRadians(solvePitchDegrees(distance, waterSurfaceY(target) - eye.field_1351));
        double horizontalVelocity = 0.6 * Math.cos(pitch) + 0.5;
        double verticalVelocity = -Math.tan(pitch) * horizontalVelocity;
        double travelled = 0.0;

        for (int tick = 0; tick < MAX_FLIGHT_TICKS; tick++) {
            verticalVelocity -= FISHING_GRAVITY;
            double fraction = Math.min(1.0, (distance - travelled) / horizontalVelocity);
            class_243 next = pos.method_1031(ux * horizontalVelocity * fraction,
                    verticalVelocity * fraction, uz * horizontalVelocity * fraction);
            class_239 hit = player.method_37908().method_17742(new class_3959(pos, next,
                    class_3959.class_3960.field_17558, class_3959.class_242.field_1348, player));
            if (hit.method_17783() != class_239.class_240.field_1333) return false;
            travelled += horizontalVelocity * fraction;
            if (travelled >= distance - 1.0e-6) return true;
            pos = next;
            horizontalVelocity *= FISHING_DRAG;
            verticalVelocity *= FISHING_DRAG;
        }
        return false;
    }

    private static double castPitchDegrees(class_243 eye, class_2338 target) {
        double dx = target.method_10263() + 0.5 - eye.field_1352;
        double dz = target.method_10260() + 0.5 - eye.field_1350;
        double distance = Math.max(0.1, Math.sqrt(dx * dx + dz * dz) - 0.3);
        return solvePitchDegrees(distance, waterSurfaceY(target) - eye.field_1351);
    }

    static double solvePitchDegrees(double horizontalDistance, double targetHeight) {
        double low = -45.0;
        double high = 55.0;
        for (int i = 0; i < 32; i++) {
            double mid = (low + high) * 0.5;
            double height = trajectoryHeightAtDistance(horizontalDistance, mid);
            if (height > targetHeight) {
                low = mid;  // trajectory is high: aim farther down
            } else {
                high = mid;
            }
        }
        return (low + high) * 0.5;
    }

    static double trajectoryHeightAtDistance(double horizontalDistance, double pitchDegrees) {
        double pitch = Math.toRadians(pitchDegrees);
        double horizontalVelocity = 0.6 * Math.cos(pitch) + 0.5;
        double verticalVelocity = -Math.tan(pitch) * horizontalVelocity;
        double travelled = 0.0;
        double height = 0.0;
        for (int tick = 0; tick < MAX_FLIGHT_TICKS; tick++) {
            verticalVelocity -= FISHING_GRAVITY;
            double nextDistance = travelled + horizontalVelocity;
            double nextHeight = height + verticalVelocity;
            if (nextDistance >= horizontalDistance) {
                double fraction = (horizontalDistance - travelled) / horizontalVelocity;
                return height + verticalVelocity * fraction;
            }
            travelled = nextDistance;
            height = nextHeight;
            horizontalVelocity *= FISHING_DRAG;
            verticalVelocity *= FISHING_DRAG;
        }
        return Double.NEGATIVE_INFINITY;
    }

    private static double waterSurfaceY(class_2338 target) {
        return target.method_10264() + WATER_SURFACE_OFFSET;
    }

    static boolean isBiteWindow(int nibbleTicks) {
        return nibbleTicks > 0;
    }

    private void discardHook() {
        class_1536 hook = player.field_7513;
        if (hook != null) {
            hook.method_31472();
            if (player.field_7513 == hook) player.field_7513 = null;
        }
    }

    @Override
    public void stop(NumenPlayer companion, StopReason why) {
        boolean wasPositioning = phase == Phase.POSITION;
        boolean wasCollecting = phase == Phase.COLLECT;
        super.stop(companion, why);
        discardHook();
        if (wasCollecting) {
            // Survival preemption may stop the navigator, but the already-caught
            // drops remain the same bounded sub-goal when the LLM task resumes.
            stopNav();
        } else if (!wasPositioning) {
            resetPositioning();
        }
    }

    @Override
    protected void cleanup() {
        InputDriver.halt(player);
        discardHook();
        clearLootTracking();
        super.cleanup();
    }

    @Override
    protected Map<String, Object> resultData() {
        Map<String, Object> data = new HashMap<>();
        data.put("requested", r.requested);
        data.put("caught", r.caught());
        data.put("casts", r.casts());
        return data;
    }

    @Override
    protected String successMessage() {
        return "completed " + r.caught() + " successful fishing catch(es)";
    }

    @Override
    protected String timeoutMessage() {
        return "fishing timed out after " + r.caught() + "/" + r.requested + " successful catches";
    }

    @Override
    protected String cancelledMessage() {
        return "fishing interrupted after " + r.caught() + "/" + r.requested + " successful catches";
    }
}
