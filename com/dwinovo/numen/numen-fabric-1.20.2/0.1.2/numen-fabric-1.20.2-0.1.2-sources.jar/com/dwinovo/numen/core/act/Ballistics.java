package com.dwinovo.numen.core.act;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.DoubleUnaryOperator;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

/** Projectile aiming helpers for gravity-affected arrows. */
public final class Ballistics {

    public record Aim(class_243 lookPoint, class_243 direction, double travelTicks) {}

    private record SimulationHit(double ticks, double centerDistance) {}

    private static final int MAX_SIMULATION_TICKS = 80;
    private static final double PROJECTILE_EYE_OFFSET = 0.10000000149011612;
    private static final double EPS = 1.0e-6;

    private Ballistics() {}

    public static Aim findArrowShot(class_1937 level, class_1297 shooter, class_1297 target,
                                    double velocity, double gravity, double drag,
                                    double hitboxRadius, double maxRange,
                                    boolean copiesShooterVelocity) {
        if (velocity <= EPS || gravity < 0.0 || drag <= 0.0 || target.method_31481()) {
            return null;
        }
        class_243 eye = projectileStart(shooter);
        class_243 lookOrigin = shooter.method_33571();
        class_238 box = target.method_5829();
        class_243 center = boxCenter(box);
        if (eye.method_1025(center) > maxRange * maxRange) {
            return null;
        }

        class_243 currentLook = shooter.method_5828(1.0f).method_1029();
        class_243 targetVelocity = target.method_18798();
        class_243 shooterVelocity = inheritedVelocity(shooter.method_18798(), shooter.method_24828(), copiesShooterVelocity);
        List<class_243> candidates = new ArrayList<>();

        addDragAwareCandidates(candidates, eye, box, targetVelocity, velocity, gravity, drag, hitboxRadius);
        addParabolicFallbackCandidates(candidates, eye, box, targetVelocity, velocity, gravity);
        candidates.sort(Comparator.comparingDouble(direction -> angleDegrees(currentLook, direction)));

        Aim best = null;
        double bestScore = Double.MAX_VALUE;
        for (class_243 direction : candidates) {
            if (direction == null || direction.method_1027() < EPS) continue;
            direction = direction.method_1029();
            SimulationHit hit = simulate(level, shooter, target, targetVelocity, eye,
                    direction.method_1021(velocity).method_1019(shooterVelocity), gravity, drag, hitboxRadius);
            if (hit == null) continue;
            double score = hit.centerDistance + angleDegrees(currentLook, direction) * 0.03 + hit.ticks * 0.01;
            if (score < bestScore) {
                bestScore = score;
                best = new Aim(lookOrigin.method_1019(direction.method_1021(64.0)), direction, hit.ticks);
            }
        }
        return best;
    }

    /** A simple no-drag fallback retained for callers that only need a look point. */
    public static class_243 aimPoint(class_243 eye, class_243 target, double v, double g) {
        class_243 direction = solveDirection(eye, target, v, g);
        return direction == null ? target : eye.method_1019(direction.method_1021(64.0));
    }

    static class_243 projectileStart(double x, double eyeY, double z) {
        return new class_243(x, eyeY - PROJECTILE_EYE_OFFSET, z);
    }

    static class_243 inheritedVelocity(class_243 movement, boolean onGround, boolean copiesShooterVelocity) {
        if (!copiesShooterVelocity) {
            return new class_243(0.0, 0.0, 0.0);
        }
        return new class_243(movement.field_1352, onGround ? 0.0 : movement.field_1351, movement.field_1350);
    }

    static class_243 solveDirection(class_243 eye, class_243 target, double velocity, double gravity) {
        double dx = target.field_1352 - eye.field_1352;
        double dz = target.field_1350 - eye.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < EPS) {
            return target.method_1020(eye).method_1029();
        }
        double y = target.field_1351 - eye.field_1351;
        double v2 = velocity * velocity;
        double root = v2 * v2 - gravity * (gravity * horizontal * horizontal + 2.0 * y * v2);
        if (root < 0.0) {
            return null;
        }
        double tanTheta = (v2 - Math.sqrt(root)) / (gravity * horizontal);
        class_243 lookPoint = new class_243(target.field_1352, eye.field_1351 + tanTheta * horizontal, target.field_1350);
        class_243 direction = lookPoint.method_1020(eye);
        return direction.method_1027() < EPS ? null : direction.method_1029();
    }

    static class_243 directionByTime(class_243 eye, class_243 target, double ticks,
                                double velocity, double gravity, double drag) {
        if (ticks <= EPS || velocity <= EPS || drag <= 0.0) {
            return null;
        }
        double rPow = Math.pow(drag, ticks);
        double resistance = drag - 1.0;
        double distanceTerm = rPow - 1.0;
        if (Math.abs(resistance) < EPS || Math.abs(distanceTerm) < EPS) {
            return null;
        }
        double horizontalFactor = resistance / (velocity * distanceTerm);
        double verticalGravity = gravity * (rPow - drag * ticks + ticks - 1.0)
                / (velocity * resistance * distanceTerm);
        class_243 direction = new class_243(
                (target.field_1352 - eye.field_1352) * horizontalFactor,
                (target.field_1351 - eye.field_1351) * horizontalFactor + verticalGravity,
                (target.field_1350 - eye.field_1350) * horizontalFactor);
        return allFinite(direction) ? direction : null;
    }

    static class_243 velocityOnImpact(class_243 initialDirection, double ticks,
                                 double velocity, double gravity, double drag) {
        if (initialDirection == null || ticks <= EPS || velocity <= EPS || drag <= 0.0) {
            return null;
        }
        double rPow = Math.pow(drag, ticks);
        double resistance = drag - 1.0;
        if (Math.abs(resistance) < EPS) {
            return null;
        }
        double logDrag = Math.log(drag);
        class_243 impact = new class_243(
                (initialDirection.field_1352 * rPow * logDrag * velocity) / resistance,
                (initialDirection.field_1351 * resistance * rPow * logDrag * velocity
                        - gravity * (rPow * logDrag - drag + 1.0)) / (resistance * resistance),
                (initialDirection.field_1350 * rPow * logDrag * velocity) / resistance);
        return allFinite(impact) && impact.method_1027() >= EPS ? impact : null;
    }

    public static double angleDegrees(class_243 a, class_243 b) {
        if (a == null || b == null || a.method_1027() < EPS || b.method_1027() < EPS) {
            return Double.MAX_VALUE;
        }
        double dot = a.method_1029().method_1026(b.method_1029());
        dot = clamp(dot, -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    private static void addDragAwareCandidates(List<class_243> out, class_243 eye, class_238 box, class_243 targetVelocity,
                                               double velocity, double gravity, double drag,
                                               double hitboxRadius) {
        class_243 center = boxCenter(box);
        double distance = eye.method_1022(center);
        double maxTravelTime = clamp(distance / velocity * 1.75, 1.0, MAX_SIMULATION_TICKS);
        TimeSearchResult result = findMinimum(0.05, maxTravelTime, ticks -> {
            class_243 direction = directionByTime(eye, center.method_1019(targetVelocity.method_1021(ticks)),
                    ticks, velocity, gravity, drag);
            return direction == null ? Double.MAX_VALUE : Math.abs(direction.method_1033() - 1.0);
        });
        if (result.delta > 0.1) {
            return;
        }

        double preciseTicks = result.ticks;
        double roundedTicks = Math.max(1.0, Math.rint(preciseTicks));
        class_243 impactCenter = center.method_1019(targetVelocity.method_1021(preciseTicks));
        class_238 predictedBox = box.method_997(targetVelocity.method_1021(preciseTicks));
        addHittablePointCandidate(out, eye, impactCenter, predictedBox.method_1014(hitboxRadius),
                preciseTicks, roundedTicks, velocity, gravity, drag);
        for (class_243 point : sampleBox(predictedBox.method_1014(hitboxRadius))) {
            addDirectionForTime(out, eye, point, preciseTicks, velocity, gravity, drag);
            addDirectionForTime(out, eye, point, roundedTicks, velocity, gravity, drag);
        }
    }

    private static void addHittablePointCandidate(List<class_243> out, class_243 eye, class_243 impactCenter,
                                                  class_238 targetBox, double preciseTicks, double roundedTicks,
                                                  double velocity, double gravity, double drag) {
        class_243 centerDirection = directionByTime(eye, impactCenter, preciseTicks, velocity, gravity, drag);
        if (centerDirection == null) return;
        class_243 inbound = velocityOnImpact(centerDirection.method_1029(), preciseTicks, velocity, gravity, drag);
        if (inbound == null) return;
        class_243 point = findHittablePosition(eye, inbound.method_1029(), impactCenter, targetBox);
        if (point == null) return;
        addDirectionForTime(out, eye, point, preciseTicks, velocity, gravity, drag);
        addDirectionForTime(out, eye, point, roundedTicks, velocity, gravity, drag);
    }

    static class_243 findHittablePosition(class_243 eye, class_243 directionOnImpact,
                                     class_243 entityPositionOnImpact, class_238 targetBox) {
        if (directionOnImpact == null || directionOnImpact.method_1027() < EPS) return null;
        class_243 virtualEye = eye.method_1031(0.0,
                directionOnImpact.field_1351 * -eye.method_1022(entityPositionOnImpact),
                0.0);
        class_243 center = boxCenter(targetBox);
        class_243 best = null;
        double bestScore = Double.MAX_VALUE;

        Optional<class_243> entry = targetBox.method_992(virtualEye, center);
        if (entry.isPresent()) {
            class_243 point = entry.get().method_1019(center.method_1020(entry.get()).method_1021(0.35));
            best = point;
            bestScore = point.method_1025(center) * 0.5;
        }

        for (class_243 point : sampleBox(targetBox)) {
            if (targetBox.method_992(virtualEye, point).isEmpty()) continue;
            double score = point.method_1025(center);
            if (score < bestScore) {
                bestScore = score;
                best = point;
            }
        }
        return best;
    }

    private static void addDirectionForTime(List<class_243> out, class_243 eye, class_243 point, double ticks,
                                            double velocity, double gravity, double drag) {
        class_243 direction = directionByTime(eye, point, ticks, velocity, gravity, drag);
        if (direction == null) {
            return;
        }
        double length = direction.method_1033();
        if (length < EPS || Math.abs(length - 1.0) > 0.15) {
            return;
        }
        addCandidate(out, direction.method_1029());
    }

    private static void addParabolicFallbackCandidates(List<class_243> out, class_243 eye, class_238 box,
                                                       class_243 targetVelocity, double velocity,
                                                       double gravity) {
        double estimateTicks = clamp(eye.method_1022(boxCenter(box)) / velocity, 0.0, 30.0);
        class_238 predictedBox = box.method_997(targetVelocity.method_1021(estimateTicks));
        for (class_243 point : sampleBox(predictedBox)) {
            addCandidate(out, solveDirection(eye, point, velocity, gravity));
        }
    }

    private static void addCandidate(List<class_243> out, class_243 direction) {
        if (direction == null || direction.method_1027() < EPS || !allFinite(direction)) {
            return;
        }
        class_243 normalized = direction.method_1029();
        for (class_243 existing : out) {
            if (angleDegrees(existing, normalized) < 0.05) {
                return;
            }
        }
        out.add(normalized);
    }

    private static SimulationHit simulate(class_1937 level, class_1297 shooter, class_1297 target, class_243 targetVelocity,
                                          class_243 start, class_243 initialVelocity, double gravity,
                                          double drag, double hitboxRadius) {
        class_243 pos = start;
        class_243 velocity = initialVelocity;
        for (int tick = 1; tick <= MAX_SIMULATION_TICKS; tick++) {
            class_243 next = pos.method_1019(velocity);
            class_238 baseTargetBox = target.method_5829().method_997(targetVelocity.method_1021(tick));
            class_238 targetBox = baseTargetBox.method_1014(hitboxRadius);
            class_243 segmentStart = pos;
            Optional<class_243> targetHit = targetBox.method_992(segmentStart, next);
            double targetDistance = targetHit.map(hit -> hit.method_1025(segmentStart)).orElse(Double.MAX_VALUE);

            class_3965 blockHit = level.method_17742(new class_3959(
                    pos, next, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, shooter));
            double blockDistance = blockHit.method_17783() == class_239.class_240.field_1333
                    ? Double.MAX_VALUE : blockHit.method_17784().method_1025(pos);
            double entityDistance = firstOtherEntityDistance(shooter, target, pos, next, hitboxRadius);

            if (targetHit.isPresent() && targetDistance <= blockDistance + EPS
                    && targetDistance <= entityDistance + EPS) {
                return new SimulationHit(tick, distanceToSegment(boxCenter(baseTargetBox), segmentStart, next));
            }
            if (blockDistance < Double.MAX_VALUE || entityDistance < Double.MAX_VALUE) {
                return null;
            }

            pos = next;
            velocity = velocity.method_1021(drag).method_1031(0.0, -gravity, 0.0);
        }
        return null;
    }

    private static double firstOtherEntityDistance(class_1297 shooter, class_1297 target, class_243 from, class_243 to,
                                                   double hitboxRadius) {
        class_238 hitbox = new class_238(
                from.field_1352 - hitboxRadius, from.field_1351 - hitboxRadius, from.field_1350 - hitboxRadius,
                from.field_1352 + hitboxRadius, from.field_1351 + hitboxRadius, from.field_1350 + hitboxRadius);
        class_238 sweep = hitbox.method_18804(to.method_1020(from)).method_1014(1.0);
        class_3966 hit = class_1675.method_18075(
                shooter, from, to, sweep,
                e -> e != shooter && e != target && !e.method_7325() && e.method_5863() && e.method_5805(),
                Double.MAX_VALUE);
        return hit == null ? Double.MAX_VALUE : hit.method_17784().method_1025(from);
    }

    private static double distanceToSegment(class_243 point, class_243 from, class_243 to) {
        class_243 segment = to.method_1020(from);
        double lengthSqr = segment.method_1027();
        if (lengthSqr < EPS) {
            return point.method_1022(from);
        }
        double t = clamp(point.method_1020(from).method_1026(segment) / lengthSqr, 0.0, 1.0);
        return point.method_1022(from.method_1019(segment.method_1021(t)));
    }

    private static List<class_243> sampleBox(class_238 box) {
        double[] xs = axisSamples(box.field_1323, box.field_1320);
        double[] ys = axisSamples(box.field_1322, box.field_1325);
        double[] zs = axisSamples(box.field_1321, box.field_1324);
        List<class_243> out = new ArrayList<>(xs.length * ys.length * zs.length);
        for (double x : xs) {
            for (double y : ys) {
                for (double z : zs) {
                    out.add(new class_243(x, y, z));
                }
            }
        }
        return out;
    }

    private static double[] axisSamples(double min, double max) {
        double size = max - min;
        if (size <= 0.2) {
            return new double[] { (min + max) * 0.5 };
        }
        double inset = Math.min(0.15, size * 0.25);
        return new double[] { (min + max) * 0.5, min + inset, max - inset };
    }

    private static class_243 boxCenter(class_238 box) {
        return new class_243((box.field_1323 + box.field_1320) * 0.5,
                (box.field_1322 + box.field_1325) * 0.5,
                (box.field_1321 + box.field_1324) * 0.5);
    }

    private record TimeSearchResult(double ticks, double delta) {}

    private static TimeSearchResult findMinimum(double from, double to, DoubleUnaryOperator function) {
        double lower = from;
        double upper = to;
        while (upper - lower > 1.0e-4) {
            double mid = (lower + upper) * 0.5;
            double leftValue = function.applyAsDouble((lower + mid) * 0.5);
            double rightValue = function.applyAsDouble((mid + upper) * 0.5);
            if (leftValue < rightValue) {
                upper = mid;
            } else {
                lower = mid;
            }
        }
        double ticks = (lower + upper) * 0.5;
        return new TimeSearchResult(ticks, function.applyAsDouble(ticks));
    }

    private static boolean allFinite(class_243 value) {
        return Double.isFinite(value.field_1352) && Double.isFinite(value.field_1351) && Double.isFinite(value.field_1350);
    }

    private static class_243 projectileStart(class_1297 shooter) {
        return projectileStart(shooter.method_23317(), shooter.method_23320(), shooter.method_23321());
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
