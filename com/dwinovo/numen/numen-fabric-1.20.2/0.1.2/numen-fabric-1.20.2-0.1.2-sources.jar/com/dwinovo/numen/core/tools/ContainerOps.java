package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.task.TaskResult;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1734;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

/**
 * Container-GUI tool implementation — the business half of {@code TransferTool}:
 * {@code transfer} moves stacks between the open container menu and the backpack,
 * one {@link Move} per slot-to-slot step.
 */
public final class ContainerOps {

    /** One transfer; its @Arg components become the {@code moves} array item schema. */
    public record Move(
int from,
Integer to,
Integer count) {}

    public String transfer(
List<Move> moves,
            NumenPlayer self) {
        class_1703 menu = self.field_7512;
        if (menu == null) {
            return TaskResult.fail("no GUI open — interact_at a container or machine first.").toJson();
        }
        if (moves.isEmpty()) {
            throw new IllegalArgumentException("moves must contain at least one transfer");
        }

        int max = menu.field_7761.size() - 1;
        StringBuilder out = new StringBuilder();
        int step = 0;
        for (Move m : moves) {
            step++;
            int from = m.from();
            Integer to = m.to();
            Integer count = m.count();

            out.append(step).append(". ");
            if (from < 0 || from > max) {
                out.append("from slot ").append(from).append(" OUT OF RANGE (0..").append(max)
                        .append(") — skipped; inspect_gui for indices.\n");
                continue;
            }
            if (to != null && (to < 0 || to > max)) {
                out.append("to slot ").append(to).append(" OUT OF RANGE (0..").append(max)
                        .append(") — skipped; inspect_gui for indices.\n");
                continue;
            }
            try {
                out.append(to == null ? route(menu, self, from, count)
                                      : place(menu, self, from, to, count));
            } catch (RuntimeException ex) {
                out.append("slot ").append(from).append(" — ERROR: ").append(ex.getMessage())
                        .append(" (earlier transfers already applied).");
            }
            out.append("\n");
        }
        return TaskResult.ok(out.toString().stripTrailing()).toJson();
    }

    /** No destination: shift the whole stack to the other section, menu-routed (deposit/take/feed). */
    private static String route(class_1703 menu, NumenPlayer entity, int from, Integer count) {
        class_1799 before = menu.field_7761.get(from).method_7677().method_7972();
        if (before.method_7960()) {
            if (menu.field_7761.get(from) instanceof class_1734) {
                // Empty crafting result = the grid doesn't form a valid recipe (usually a mis-placed
                // 2x2 layout). Point the model back at the recipe so it self-corrects.
                return "slot " + from + " (crafting result) is empty — the grid doesn't form a valid "
                        + "recipe yet. Call lookup_recipe for the exact layout, then inspect_gui and match "
                        + "it onto the grid cell-for-cell (a smaller recipe goes top-left; 2x2 slot "
                        + "indices are easy to guess wrong).";
            }
            return "slot " + from + " is empty — nothing to move.";
        }
        menu.method_7593(from, 0, class_1713.field_7794, entity);
        class_1799 after = menu.field_7761.get(from).method_7677();
        int moved = before.method_7947() - (sameItem(before, after) ? after.method_7947() : 0);
        String note = (count != null) ? " (count ignored — routing moves the whole stack; give `to` "
                + "for an exact amount)" : "";
        if (moved <= 0) {
            return "slot " + from + " (" + name(before) + ") didn't move — the other section is full "
                    + "or won't accept it." + note;
        }
        return "routed " + moved + " " + name(before) + " from slot " + from + " to the other section "
                + "(deposit/take/feed)." + (after.method_7960() ? "" : " " + after.method_7947() + " left in slot "
                + from + ".") + note;
    }

    /** A destination slot: place exactly there — empty→move, same item→merge, different item→swap. */
    private static String place(class_1703 menu, NumenPlayer entity, int from, int to, Integer count) {
        if (from == to) {
            return "slot " + from + " → itself — nothing to do.";
        }
        class_1799 fromBefore = menu.field_7761.get(from).method_7677().method_7972();
        class_1799 toBefore = menu.field_7761.get(to).method_7677().method_7972();
        if (fromBefore.method_7960()) {
            return "slot " + from + " is empty — nothing to move.";
        }

        boolean exact = count != null && count > 0;
        boolean differentItem = !toBefore.method_7960() && !sameItem(toBefore, fromBefore);

        if (exact && differentItem) {
            return "can't move " + count + " from slot " + from + " — slot " + to + " holds "
                    + name(toBefore) + ". Omit count to swap the whole stacks instead.";
        }

        if (exact) {
            int want = Math.min(count, fromBefore.method_7947());
            MenuOps.dripInto(menu, entity, from, to, want);
        } else {
            menu.method_7593(from, 0, class_1713.field_7790, entity);          // grab the stack
            menu.method_7593(to, 0, class_1713.field_7790, entity);            // place / merge / swap
            if (!menu.method_34255().method_7960()) {
                menu.method_7593(from, 0, class_1713.field_7790, entity);      // settle leftover / swapped item back
            }
        }

        class_1799 fromAfter = menu.field_7761.get(from).method_7677();
        class_1799 toAfter = menu.field_7761.get(to).method_7677();
        int moved = fromBefore.method_7947() - (sameItem(fromBefore, fromAfter) ? fromAfter.method_7947() : 0);

        if (differentItem) {     // whole-stack onto a different item = swap
            if (sameItem(toAfter, fromBefore) && sameItem(fromAfter, toBefore)) {
                return "swapped slot " + from + " (" + name(fromBefore) + ") ⇄ slot " + to + " ("
                        + name(toBefore) + ").";
            }
            return "slot " + from + " → " + to + ": nothing moved — slot " + to + " refused it "
                    + "(output-only slot?).";
        }
        if (moved <= 0) {
            return "slot " + from + " → " + to + ": nothing moved — slot " + to
                    + (toBefore.method_7960() ? " refused it (output-only slot?)." : " is already full.");
        }
        String verb = toBefore.method_7960() ? "moved " : "merged ";
        return verb + moved + " " + name(fromBefore) + " from slot " + from + " to slot " + to
                + " (slot " + to + " now " + toAfter.method_7947()
                + (fromAfter.method_7960() ? "; slot " + from + " emptied)." : "; " + fromAfter.method_7947()
                + " left in slot " + from + ").");
    }

    private static boolean sameItem(class_1799 a, class_1799 b) {
        return class_1799.method_31577(a, b);
    }

    private static String name(class_1799 stack) {
        return stack.method_7960() ? "nothing" : class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
    }
}
