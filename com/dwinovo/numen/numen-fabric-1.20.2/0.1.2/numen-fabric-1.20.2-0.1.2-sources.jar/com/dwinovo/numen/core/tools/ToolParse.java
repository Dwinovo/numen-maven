package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.core.init.InitTag;
import com.dwinovo.numen.core.task.MouseButton;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * 工具入口共享的参数解析件——此前 scan_blocks 与 mine 各抄一份方块 id
 * 解析、interact_at 与 interact_entity 各抄一份按键解析,在这里合一。
 * 物品 id 解析用引擎的 {@code ToolArgs.parseItem},不在此重复。
 */
public final class ToolParse {

    private ToolParse() {}

    /**
     * 宽松的方块 id 集:解析失败/未知/air 的条目跳过,保留输入顺序
     * (消息里的"第一个目标"标签依赖顺序)。
     *
     * <p><b>{@code #} 开头的条目是标签</b>,原样展开成它当下的全部成员——{@code #minecraft:beds}
     * 是"床这一类"而不是某一种颜色的床。这是原版自己的语法(标签文件的 {@code values} 里就用
     * 它引用别的标签),不是我们发明的写法,所以模型写出来的和它在数据包里见过的一致。
     *
     * <p>标签内容来自数据包,世界加载后才有,所以这里<b>每次调用现查</b>——{@code /reload}
     * 改了标签下一次就生效。
     */
    public static Set<class_2248> parseBlocks(List<String> ids) {
        Set<class_2248> out = new LinkedHashSet<>();
        if (ids == null) return out;
        for (String raw : ids) {
            if (raw == null) continue;
            class_6862<class_2248> tag = InitTag.parseRef(class_7924.field_41254, raw);
            if (tag != null) {
                for (class_6880<class_2248> holder : class_7923.field_41175.method_40286(tag)) {
                    class_2248 b = holder.comp_349();
                    if (b != class_2246.field_10124) out.add(b);
                }
                continue;
            }
            class_2960 id = class_2960.method_12829(raw);
            if (id == null) continue;
            class_2248 b = class_7923.field_41175.method_10223(id);
            if (b != null && b != class_2246.field_10124) out.add(b);
        }
        return out;
    }

    /** 左键=攻击、右键=使用;缺参或非法值直接报参数错。 */
    public static MouseButton parseButton(String button) {
        if (button == null) {
            throw new IllegalArgumentException("missing required argument: button");
        }
        return switch (button) {
            case "left" -> MouseButton.LEFT;
            case "right" -> MouseButton.RIGHT;
            default -> throw new IllegalArgumentException(
                    "button must be 'left' or 'right', got: " + button);
        };
    }
}
