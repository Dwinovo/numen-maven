package com.dwinovo.numen.core.pathing.moves.movements;
import com.dwinovo.numen.core.pathing.moves.AimGeometry;

import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import com.dwinovo.numen.core.pathing.moves.CalculationContext;
import com.dwinovo.numen.core.pathing.moves.Input;
import com.dwinovo.numen.core.pathing.moves.Movement;
import com.dwinovo.numen.core.pathing.moves.MovementHelper;
import com.dwinovo.numen.core.pathing.moves.MovementState;
import com.dwinovo.numen.core.pathing.moves.MovementStatus;
import com.dwinovo.numen.core.pathing.moves.MutableMoveResult;

import static com.dwinovo.numen.core.pathing.moves.ActionCosts.CENTER_AFTER_FALL_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.COST_INF;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.FALL_N_BLOCKS_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.LADDER_DOWN_ONE_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.WALK_OFF_BLOCK_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.WALK_ONE_BLOCK_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.WALK_ONE_OVER_SOUL_SAND_COST;

/** 下一格:走下水平相邻且低一格的落点;落点更深时由成本函数移交坠落语义。 */
public class MovementDescend extends Movement {

    /** 冲出边缘阶段的计 tick(前 20 tick 冲 fakeDest 加速离沿)。 */
    private int numTicks = 0;
    /** 执行层根据下一动作注入的强制稳走标志。 */
    private boolean forceSafeMode = false;

    public MovementDescend(class_3222 player, class_2338 src, class_2338 dest) {
        super(player, src, dest,
                new class_2338[]{dest.method_10086(2), dest.method_10084(), dest}, dest.method_10074());
    }

    @Override
    public void reset() {
        super.reset();
        numTicks = 0;
        forceSafeMode = false;
    }

    /** 由路径执行器调用:下一动作需要本次下降稳着走。 */
    public void forceSafeMode() {
        forceSafeMode = true;
    }

    /**
     * 成本。先按 落点下一格 / 落点格 / 落点上格(含落沙链)三挖序累加;
     * 从梯/藤出发不可行;落点下二格不可站则转坠落分档;落点是梯/藤或
     * 会被霜行者冻住则不可行(退化为平移处理);否则走离边缘 + 落一格。
     */
    public static void cost(CalculationContext context, int x, int y, int z,
                            int destX, int destZ, MutableMoveResult res) {
        double totalCost = 0;
        class_2680 destDown = context.get(destX, y - 1, destZ);
        totalCost += MovementHelper.getMiningDurationTicks(context, destX, y - 1, destZ, destDown, false);
        if (totalCost >= COST_INF) {
            return;
        }
        totalCost += MovementHelper.getMiningDurationTicks(context, destX, y, destZ, false);
        if (totalCost >= COST_INF) {
            return;
        }
        // 三格里只有最上面那格需要考虑引落沙链
        totalCost += MovementHelper.getMiningDurationTicks(context, destX, y + 1, destZ, true);
        if (totalCost >= COST_INF) {
            return;
        }

        class_2248 fromDown = context.get(x, y - 1, z).method_26204();
        if (fromDown == class_2246.field_9983 || fromDown == class_2246.field_10597) {
            return;
        }

        class_2680 below = context.get(destX, y - 2, destZ);
        if (!MovementHelper.canWalkOn(context, destX, y - 2, destZ, below)) {
            // 下面还空:转坠落分档
            dynamicFallCost(context, x, y, z, destX, destZ, totalCost, below, res);
            return;
        }

        if (destDown.method_26204() == class_2246.field_9983 || destDown.method_26204() == class_2246.field_10597) {
            return;
        }
        if (MovementHelper.canUseFrostWalker(context, destDown)) {
            return; // 走过去水面会被冻住,这一步实际是平移
        }

        // 走半格加 0.3 到边缘,剩下 0.2 与下落并行
        double walk = WALK_OFF_BLOCK_COST;
        if (fromDown == class_2246.field_10114) {
            walk *= WALK_ONE_OVER_SOUL_SAND_COST / WALK_ONE_BLOCK_COST;
        }
        totalCost += walk + Math.max(FALL_N_BLOCKS_COST[1], CENTER_AFTER_FALL_COST);
        res.x = destX;
        res.y = y - 1;
        res.z = destZ;
        res.cost = totalCost;
    }

    /**
     * 坠落分档:逐层向下扫,遇水(可穿、非流动、非水面行走、下有底)
     * 即落水;遇梯/藤(净坠 ≤11 才抓得住)重置有效落速继续;可站且
     * 净坠不超无水上限则落地;超限但有水桶且不超水桶上限则加放桶价
     * 并返回 true(执行期需要放水桶);下半砖/不可站(如岩浆)放弃。
     */
    public static boolean dynamicFallCost(CalculationContext context, int x, int y, int z,
                                          int destX, int destZ, double frontBreak,
                                          class_2680 below, MutableMoveResult res) {
        if (frontBreak != 0 && context.get(destX, y + 2, destZ).method_26204() instanceof class_2346) {
            // 前壁要挖就会惊动这根沙柱塌进坑里(还可能填掉要落的水),放弃
            return false;
        }
        if (!MovementHelper.canWalkThrough(context, destX, y - 2, destZ, below)) {
            return false;
        }
        double costSoFar = 0;
        int effectiveStartHeight = y;
        for (int fallHeight = 3; true; fallHeight++) {
            int newY = y - fallHeight;
            if (newY < context.worldBottom) {
                // 末地可能一路落进虚空,别读世界外的方块
                return false;
            }
            boolean reachedMinimum = fallHeight >= context.minFallHeight;
            class_2680 ontoBlock = context.get(destX, newY, destZ);
            // 被梯/藤重置后的净坠高度
            int unprotectedFallHeight = fallHeight - (y - effectiveStartHeight);
            double tentativeCost = WALK_OFF_BLOCK_COST
                    + FALL_N_BLOCKS_COST[unprotectedFallHeight] + frontBreak + costSoFar;
            if (reachedMinimum && MovementHelper.isWater(ontoBlock)) {
                if (!MovementHelper.canWalkThrough(context, destX, newY, destZ, ontoBlock)) {
                    return false;
                }
                if (context.assumeWalkOnWater) {
                    return false;
                }
                if (MovementHelper.isFlowing(context.view, destX, newY, destZ, ontoBlock)) {
                    return false;
                }
                if (!MovementHelper.canWalkOn(context, destX, newY - 1, destZ)) {
                    // 水太浅会直接穿透砸到下面的东西
                    return false;
                }
                // 落水,不需要水桶
                res.x = destX;
                res.y = newY;
                res.z = destZ;
                res.cost = tentativeCost;
                return false;
            }
            if (unprotectedFallHeight <= 11
                    && (ontoBlock.method_26204() == class_2246.field_10597 || ontoBlock.method_26204() == class_2246.field_9983)) {
                // 净坠 ≥11 格时抓不住梯/藤;抓住即重置落速
                costSoFar += FALL_N_BLOCKS_COST[unprotectedFallHeight - 1]; // 落到该格顶面(不含该格)
                costSoFar += LADDER_DOWN_ONE_COST;
                effectiveStartHeight = newY;
                continue;
            }
            if (MovementHelper.canWalkThrough(context, destX, newY, destZ, ontoBlock)) {
                continue;
            }
            if (!MovementHelper.canWalkOn(context, destX, newY, destZ, ontoBlock)) {
                return false; // 岩浆之类:不可穿也不可站
            }
            if (MovementHelper.isBottomSlab(ontoBlock)) {
                return false; // 落半砖判定飘忽且额外摔伤
            }
            if (reachedMinimum && unprotectedFallHeight <= context.maxFallHeightNoWater + 1) {
                // fallHeight=4 时落点上格恰好低三格,是无水上限。
                // 硬着陆按原版伤害(净坠-3,每格 1 点)计痛感罚金:摔不死的高度
                // 仍是路,但有无伤走法(楼梯、逐级下)时代价表会自动让位。
                int fallDamage = Math.max(0, (unprotectedFallHeight - 1) - 3);
                res.x = destX;
                res.y = newY + 1;
                res.z = destZ;
                res.cost = tentativeCost + fallDamage * context.fallDamageCostPerPoint;
                return false;
            }
            if (reachedMinimum && context.hasWaterBucket
                    && unprotectedFallHeight <= context.maxFallHeightBucket + 1) {
                res.x = destX;
                res.y = newY + 1; // 砸在 newY 那块上,落点是它上面
                res.z = destZ;
                res.cost = tentativeCost + context.placeBucketCost();
                return true; // 需要执行期放水桶
            } else {
                return false;
            }
        }
    }

    @Override
    public double calculateCost(CalculationContext context, MutableMoveResult result) {
        cost(context, src.method_10263(), src.method_10264(), src.method_10260(), dest.method_10263(), dest.method_10260(), result);
        if (result.y != dest.method_10264()) {
            return COST_INF; // 落点更深,该位置属于坠落而非下降
        }
        return result.cost;
    }

    @Override
    protected Set<class_2338> calculateValidPositions() {
        return Set.of(src, dest.method_10084(), dest);
    }

    @Override
    public MovementState updateState(MovementState state) {
        super.updateState(state);
        if (state.getStatus() != MovementStatus.RUNNING) {
            return state;
        }

        class_2338 feet = feet(player);
        class_2338 fakeDest = new class_2338(dest.method_10263() * 2 - src.method_10263(), dest.method_10264(),
                dest.method_10260() * 2 - src.method_10260());
        if ((feet.equals(dest) || feet.equals(fakeDest))
                && (MovementHelper.isLiquid(player.method_37908().method_8320(dest))
                        || player.method_23318() - dest.method_10264() < 0.5)) {
            // 等真正落地再报成功,否则下一动作接飞
            return state.setStatus(MovementStatus.SUCCESS);
        }
        if (safeMode()) {
            // 稳走:瞄 src→dest 的 0.83 处,不看满 dest,防冲过
            double aimX = (src.method_10263() + 0.5) * 0.17 + (dest.method_10263() + 0.5) * 0.83;
            double aimZ = (src.method_10260() + 0.5) * 0.17 + (dest.method_10260() + 0.5) * 0.83;
            float yaw = AimGeometry.yawTo(player.method_33571(),
                    new class_243(aimX, dest.method_10264(), aimZ));
            state.setTarget(new MovementState.MovementTarget(yaw, player.method_36455(), false))
                    .setInput(Input.MOVE_FORWARD, true);
            return state;
        }
        double diffX = player.method_23317() - (dest.method_10263() + 0.5);
        double diffZ = player.method_23321() - (dest.method_10260() + 0.5);
        double ab = Math.sqrt(diffX * diffX + diffZ * diffZ);
        double x = player.method_23317() - (src.method_10263() + 0.5);
        double z = player.method_23321() - (src.method_10260() + 0.5);
        double fromStart = Math.sqrt(x * x + z * z);
        if (!feet.equals(dest) || ab > 0.25) {
            if (numTicks++ < 20 && fromStart < 1.25) {
                // 前 20 tick 冲过冲点加速离沿
                AimGeometry.moveTowards(player, state, fakeDest);
            } else {
                AimGeometry.moveTowards(player, state, dest);
            }
        }
        return state;
    }

    /**
     * 是否需要稳走:被执行层强制;或落点前方一格"下不可穿、上两格可穿"
     * (直冲会卡进去);或前方三格身位有危险格。
     */
    public boolean safeMode() {
        if (forceSafeMode) {
            return true;
        }
        class_2338 into = destOvershoot();
        if (skipToAscend()) {
            return true;
        }
        for (int i = 0; i <= 2; i++) {
            if (MovementHelper.avoidWalkingInto(player.method_37908().method_8320(into.method_10086(i)))) {
                return true;
            }
        }
        return false;
    }

    /** 冲过头会不会正好嵌进"下一格是墙、上两格是洞"的台阶口。 */
    public boolean skipToAscend() {
        class_2338 into = destOvershoot();
        class_1937 level = player.method_37908();
        return !MovementHelper.canWalkThrough(level, into)
                && MovementHelper.canWalkThrough(level, into.method_10084())
                && MovementHelper.canWalkThrough(level, into.method_10086(2));
    }

    /** dest 再沿同方向一格(疾跑冲过时会撞到的柱)。 */
    private class_2338 destOvershoot() {
        int dx = dest.method_10263() - src.method_10263();
        int dz = dest.method_10260() - src.method_10260();
        return dest.method_10069(dx, 0, dz);
    }
}
