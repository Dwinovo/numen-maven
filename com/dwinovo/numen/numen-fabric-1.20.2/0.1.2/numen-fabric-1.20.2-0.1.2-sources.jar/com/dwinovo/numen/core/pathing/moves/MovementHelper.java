package com.dwinovo.numen.core.pathing.moves;

import com.dwinovo.numen.core.pathing.settings.NavSettings;
import net.minecraft.class_10;
import net.minecraft.class_1922;
import net.minecraft.class_2189;
import net.minecraft.class_2190;
import net.minecraft.class_2211;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2334;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2349;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2383;
import net.minecraft.class_2384;
import net.minecraft.class_2397;
import net.minecraft.class_2404;
import net.minecraft.class_2480;
import net.minecraft.class_2482;
import net.minecraft.class_2484;
import net.minecraft.class_2488;
import net.minecraft.class_2506;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2553;
import net.minecraft.class_2577;
import net.minecraft.class_2667;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_2760;
import net.minecraft.class_2771;
import net.minecraft.class_2778;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3621;
import net.minecraft.class_3736;
import net.minecraft.class_4770;
import net.minecraft.class_5542;
import net.minecraft.class_5546;
import net.minecraft.class_5689;
import net.minecraft.class_5800;

import static com.dwinovo.numen.core.pathing.moves.ActionCosts.COST_INF;

/**
 * 移动原语与搜索共用的静态方块判定库(BlockGetter 域):
 * 可穿行 / 可跳穿 / 可站立 / 禁挖 / 流体流动 / 破坏成本等。
 * 位置无关的判定拆成三态预筛(YES/NO/MAYBE),MAYBE 再做位置精判,
 * 让绝大多数格子只看 BlockState 就能出结论。
 */
public final class MovementHelper {

    private MovementHelper() {}

    /** 三态判定结果:仅看 BlockState 能否定论,MAYBE 需要位置精判。 */
    public enum Ternary {
        YES, MAYBE, NO
    }

    // ==================== 可穿行(身体能否占据该格) ====================

    public static boolean canWalkThrough(CalculationContext context, int x, int y, int z) {
        return canWalkThrough(context.view, context.loadedTest, x, y, z, context.get(x, y, z));
    }

    public static boolean canWalkThrough(CalculationContext context, int x, int y, int z, class_2680 state) {
        return canWalkThrough(context.view, context.loadedTest, x, y, z, state);
    }

    /** 实时世界重载(chunk 视为全部已加载)。 */
    public static boolean canWalkThrough(class_1922 level, class_2338 pos) {
        return canWalkThrough(level, ChunkLoadedTest.ALWAYS,
                pos.method_10263(), pos.method_10264(), pos.method_10260(), level.method_8320(pos));
    }

    public static boolean canWalkThrough(class_1922 view, ChunkLoadedTest loaded,
                                         int x, int y, int z, class_2680 state) {
        Ternary result = canWalkThroughBlockState(state);
        if (result == Ternary.YES) {
            return true;
        }
        if (result == Ternary.NO) {
            return false;
        }
        return canWalkThroughPosition(view, loaded, x, y, z, state);
    }

    /** 三态预筛:只看 BlockState。 */
    public static Ternary canWalkThroughBlockState(class_2680 state) {
        class_2248 block = state.method_26204();
        if (block instanceof class_2189) {
            return Ternary.YES;
        }
        if (block instanceof class_4770 || block == class_2246.field_10589 || block == class_2246.field_10343
                || block == class_2246.field_10027 || block == class_2246.field_10302
                || block instanceof class_2190 || block == class_2246.field_10422
                || block instanceof class_2480 || block instanceof class_2482
                || block instanceof class_2533 || block == class_2246.field_21211
                || block == class_2246.field_10455 || block == class_2246.field_16999
                || block == class_2246.field_28048 || block instanceof class_5542
                || block instanceof class_5800 || block == class_2246.field_28682
                || block == class_2246.field_27879) {
            return Ternary.NO;
        }
        if (NavSettings.get().blocksToAvoid().contains(block)) {
            return Ternary.NO;
        }
        if (block instanceof class_2323 || block instanceof class_2349) {
            // 木门/栅栏门假定可开(执行层右键);铁门无红石打不开,按实体墙处理
            if (block == class_2246.field_9973) {
                return Ternary.NO;
            }
            return Ternary.YES;
        }
        if (block instanceof class_2577) {
            return Ternary.MAYBE;
        }
        if (block instanceof class_2488) {
            // 缓存 chunk 顶层的雪可能拿不到层数,留到位置精判
            return Ternary.MAYBE;
        }
        class_3610 fluidState = state.method_26227();
        if (!fluidState.method_15769()) {
            if (fluidState.method_15761() != 8) {
                return Ternary.NO; // 非满格流体(流动中)不可走
            }
            return Ternary.MAYBE;
        }
        if (block instanceof class_5546) {
            return Ternary.NO;
        }
        return state.method_26171(net.minecraft.class_2682.field_12294, net.minecraft.class_2338.field_10980, class_10.field_50) ? Ternary.YES : Ternary.NO;
    }

    /** MAYBE 的位置精判:地毯 / 雪层 / 满格流体。 */
    public static boolean canWalkThroughPosition(class_1922 view, ChunkLoadedTest loaded,
                                                 int x, int y, int z, class_2680 state) {
        class_2248 block = state.method_26204();

        if (block instanceof class_2577) {
            // 地毯是薄层,可走过的前提是地毯下面能站
            return canWalkOn(view, loaded, x, y - 1, z);
        }

        if (block instanceof class_2488) {
            // 未加载 chunk 拿不到层数,放行(否则雪原长途寻路直接瘫掉)
            if (!loaded.isLoaded(x, z)) {
                return true;
            }
            // 原版可通行判定是 <5 层;但 2 格高净空里 ≥3 层就挤不过去了
            if (state.method_11654(class_2488.field_11518) >= 3) {
                return false;
            }
            return canWalkOn(view, loaded, x, y - 1, z);
        }

        class_3610 fluidState = state.method_26227();
        if (!fluidState.method_15769()) {
            if (isFlowing(view, x, y, z, state)) {
                return false; // 水流会把人冲离路径
            }
            if (NavSettings.get().assumeWalkOnWater) {
                return false; // 水面行走语义下水柱不可穿
            }
            class_2680 up = view.method_8320(new class_2338(x, y + 1, z));
            if (!up.method_26227().method_15769() || up.method_26204() instanceof class_2553) {
                return false; // 上方还有流体/睡莲,穿过去等于潜水
            }
            return fluidState.method_15772() instanceof class_3621; // 只有水柱可游走
        }

        return state.method_26171(net.minecraft.class_2682.field_12294, net.minecraft.class_2338.field_10980, class_10.field_50);
    }

    // ==================== 完全无阻碍(可跳跃穿过) ====================

    /**
     * 比可穿行更严:不含需要右键的门/栅栏门、不含减速的
     * 藤蔓/梯子/蛛网、不含任何流体。用于跑酷与头顶净空检查。
     */
    public static Ternary fullyPassableBlockState(class_2680 state) {
        class_2248 block = state.method_26204();
        if (block instanceof class_2189) {
            return Ternary.YES;
        }
        if (block instanceof class_4770
                || block == class_2246.field_10589
                || block == class_2246.field_10343
                || block == class_2246.field_10597
                || block == class_2246.field_9983
                || block == class_2246.field_10302
                || block instanceof class_5800
                || block instanceof class_2323
                || block instanceof class_2349
                || block instanceof class_2488
                || !state.method_26227().method_15769()
                || block instanceof class_2533
                || block instanceof class_2334
                || block instanceof class_2484
                || block instanceof class_2480) {
            return Ternary.NO;
        }
        return state.method_26171(net.minecraft.class_2682.field_12294, net.minecraft.class_2338.field_10980, class_10.field_50) ? Ternary.YES : Ternary.NO;
    }

    public static boolean fullyPassable(CalculationContext context, int x, int y, int z) {
        return fullyPassable(context.get(x, y, z));
    }

    public static boolean fullyPassable(CalculationContext context, int x, int y, int z, class_2680 state) {
        return fullyPassable(state);
    }

    public static boolean fullyPassable(class_1922 level, class_2338 pos) {
        return fullyPassable(level.method_8320(pos));
    }

    public static boolean fullyPassable(class_2680 state) {
        return fullyPassableBlockState(state) == Ternary.YES;
    }

    // ==================== 可站立(能否作为脚下地面) ====================

    public static boolean canWalkOn(CalculationContext context, int x, int y, int z) {
        return canWalkOn(context.view, context.loadedTest, x, y, z, context.get(x, y, z));
    }

    public static boolean canWalkOn(CalculationContext context, int x, int y, int z, class_2680 state) {
        return canWalkOn(context.view, context.loadedTest, x, y, z, state);
    }

    /** 实时世界重载。 */
    public static boolean canWalkOn(class_1922 level, class_2338 pos) {
        return canWalkOn(level, ChunkLoadedTest.ALWAYS,
                pos.method_10263(), pos.method_10264(), pos.method_10260(), level.method_8320(pos));
    }

    public static boolean canWalkOn(class_1922 view, ChunkLoadedTest loaded, int x, int y, int z) {
        return canWalkOn(view, loaded, x, y, z, view.method_8320(new class_2338(x, y, z)));
    }

    public static boolean canWalkOn(class_1922 view, ChunkLoadedTest loaded,
                                    int x, int y, int z, class_2680 state) {
        Ternary result = canWalkOnBlockState(state);
        if (result == Ternary.YES) {
            return true;
        }
        if (result == Ternary.NO) {
            return false;
        }
        return canWalkOnPosition(view, loaded, x, y, z, state);
    }

    /** 三态预筛:只看 BlockState。 */
    public static Ternary canWalkOnBlockState(class_2680 state) {
        class_2248 block = state.method_26204();
        if (isBlockNormalCube(state) && block != class_2246.field_10092
                && block != class_2246.field_10422 && block != class_2246.field_21211) {
            return Ternary.YES;
        }
        if (block instanceof class_5800) {
            return Ternary.YES;
        }
        if (block == class_2246.field_9983 || (block == class_2246.field_10597 && NavSettings.get().allowVines)) {
            return Ternary.YES;
        }
        if (block == class_2246.field_10362 || block == class_2246.field_10194 || block == class_2246.field_10114) {
            return Ternary.YES;
        }
        if (block == class_2246.field_10443 || block == class_2246.field_10034 || block == class_2246.field_10380) {
            return Ternary.YES;
        }
        if (block == class_2246.field_10033 || block instanceof class_2506) {
            return Ternary.YES;
        }
        if (block instanceof class_2510) {
            return Ternary.YES;
        }
        if (isWater(state)) {
            return Ternary.MAYBE;
        }
        if (isLava(state) && NavSettings.get().assumeWalkOnLava) {
            return Ternary.MAYBE;
        }
        if (block instanceof class_2482) {
            if (!NavSettings.get().allowWalkOnBottomSlab) {
                // 只许站非下半台阶
                return state.method_11654(class_2482.field_11501) != class_2771.field_12681 ? Ternary.YES : Ternary.NO;
            }
            return Ternary.YES;
        }
        return Ternary.NO;
    }

    /**
     * MAYBE 的位置精判(水/岩浆)。水的"游泳位"语义:默认只能站在
     * 上方还有水的水格里(浮在水柱中);开水面行走则只能站在上方
     * 无水的水面上——两者按 XOR 互斥。
     */
    public static boolean canWalkOnPosition(class_1922 view, ChunkLoadedTest loaded,
                                            int x, int y, int z, class_2680 state) {
        if (isWater(state)) {
            class_2680 upState = view.method_8320(new class_2338(x, y + 1, z));
            class_2248 up = upState.method_26204();
            if (up == class_2246.field_10588 || up instanceof class_2577) {
                return true;
            }
            if (isFlowing(view, x, y, z, state) || upState.method_26227().method_15772() == class_3612.field_15909) {
                // 流水上唯一能站的情形:压在静水下面且未开水面行走
                return isWater(upState) && !NavSettings.get().assumeWalkOnWater;
            }
            return isWater(upState) ^ NavSettings.get().assumeWalkOnWater;
        }

        if (isLava(state) && !isFlowing(view, x, y, z, state) && NavSettings.get().assumeWalkOnLava) {
            return true;
        }

        return false; // 未识别的一律不站,宁可绕
    }

    /** 霜行者能否把该格冻成冰面(静水源且有附魔)。 */
    public static boolean canUseFrostWalker(CalculationContext context, class_2680 state) {
        return context.frostWalker != 0
                && state.method_26204() == class_2246.field_10382
                && state.method_11654(class_2404.field_11278) == 0;
    }

    /**
     * 若要站上/走过该格,它是否必须是实心的(霜行者判定用):
     * 梯子/藤蔓不算;流体上盖着上半台阶/顶部楼梯/关着的顶部活板门/
     * 脚手架/树叶等仍算有实心顶面。
     */
    public static boolean mustBeSolidToWalkOn(CalculationContext context, int x, int y, int z, class_2680 state) {
        class_2248 block = state.method_26204();
        if (block == class_2246.field_9983 || block == class_2246.field_10597) {
            return false;
        }
        if (!state.method_26227().method_15769()) {
            if (block instanceof class_2482) {
                if (state.method_11654(class_2482.field_11501) != class_2771.field_12681) {
                    return true;
                }
            } else if (block instanceof class_2510) {
                if (state.method_11654(class_2510.field_11572) == class_2760.field_12619) {
                    return true;
                }
                class_2778 shape = state.method_11654(class_2510.field_11565);
                if (shape == class_2778.field_12712 || shape == class_2778.field_12713) {
                    return true;
                }
            } else if (block instanceof class_2533) {
                if (!state.method_11654(class_2533.field_11631) && state.method_11654(class_2533.field_11625) == class_2760.field_12619) {
                    return true;
                }
            } else if (block == class_2246.field_16492) {
                return true;
            } else if (block instanceof class_2397) {
                return true;
            }
            if (context.assumeWalkOnWater) {
                return false;
            }
            if (context.getBlock(x, y + 1, z) instanceof class_2404) {
                return false;
            }
        }
        return true;
    }

    // ==================== 禁挖判定 ====================

    /**
     * 挖 (x,y,z) 是否被<b>物理上</b>禁止:世界边界外拒绝(内缩一格,边界外的方块
     * 没法贴放/挖到);冰(挖了变水搅乱路径)、被虫蚀方块,以及上方/四个
     * 水平邻格的液体与悬空落沙规则。保护性的硬禁挖(do_not_break 标签)不在
     * 这里——那是 {@link CalculationContext#breakCostMultiplierAt} 的事,
     * 硬禁挖的唯一真源是那个标签。
     */
    public static boolean avoidBreaking(CalculationContext context, int x, int y, int z, class_2680 state) {
        if (context.worldBorder != null
                && !(x > context.worldBorder.method_11976()
                        && x + 1 < context.worldBorder.method_11963()
                        && z > context.worldBorder.method_11958()
                        && z + 1 < context.worldBorder.method_11977())) {
            return true;
        }
        class_2248 b = state.method_26204();
        return b == class_2246.field_10295
                || b instanceof class_2384
                || avoidAdjacentBreaking(context, x, y + 1, z, true)
                || avoidAdjacentBreaking(context, x + 1, y, z, false)
                || avoidAdjacentBreaking(context, x - 1, y, z, false)
                || avoidAdjacentBreaking(context, x, y, z + 1, false)
                || avoidAdjacentBreaking(context, x, y, z - 1, false);
    }

    /**
     * 邻格 (x,y,z) 是否让"挖它旁边那格"变得危险。只查上方与四个
     * 水平向,不查下方。上方是落沙类不禁(整根沙柱的连锁挖掘成本
     * 已计入);上方是液体必禁。水平向:悬空的落沙类会被更新塌下
     * 来 → 禁;液体源爱水平漫延 → 禁;流动液体只要下方不是液体
     * (会向水平流)→ 禁。
     */
    public static boolean avoidAdjacentBreaking(CalculationContext context, int x, int y, int z, boolean directlyAbove) {
        class_2680 state = context.get(x, y, z);
        class_2248 block = state.method_26204();
        if (!directlyAbove
                && block instanceof class_2346
                && NavSettings.get().avoidUpdatingFallingBlocks
                && class_2346.method_10128(context.get(x, y - 1, z))) {
            return true;
        }
        // 只按纯液体方块判(含水方块可能有封闭底面,不算)
        if (block instanceof class_2404) {
            if (directlyAbove || NavSettings.get().strictLiquidCheck) {
                return true;
            }
            int level = state.method_11654(class_2404.field_11278);
            if (level == 0) {
                return true; // 源方块爱水平漫延
            }
            return !(context.getBlock(x, y - 1, z) instanceof class_2404);
        }
        return !state.method_26227().method_15769();
    }

    // ==================== 破坏成本 ====================

    public static double getMiningDurationTicks(CalculationContext context, int x, int y, int z, boolean includeFalling) {
        return getMiningDurationTicks(context, x, y, z, context.get(x, y, z), includeFalling);
    }

    /**
     * 挖穿该格的成本(tick)。本就可穿行 → 0;流体 → INF;
     * 禁挖 → INF;否则 1/速度 + 附加罚金,再乘上下文乘数。
     * {@code includeFalling} 时向上递归叠加整根落沙柱的成本。
     */
    public static double getMiningDurationTicks(CalculationContext context, int x, int y, int z,
                                                class_2680 state, boolean includeFalling) {
        if (!canWalkThrough(context, x, y, z, state)) {
            if (!state.method_26227().method_15769()) {
                return COST_INF;
            }
            double mult = context.breakCostMultiplierAt(x, y, z, state);
            if (mult >= COST_INF) {
                return COST_INF;
            }
            if (avoidBreaking(context, x, y, z, state)) {
                return COST_INF;
            }
            double strVsBlock = context.toolSet.getStrVsBlock(state);
            if (strVsBlock <= 0) {
                return COST_INF;
            }
            double result = 1 / strVsBlock;
            result += context.breakBlockAdditionalCost;
            result *= mult;
            if (includeFalling) {
                class_2680 above = context.get(x, y + 1, z);
                if (above.method_26204() instanceof class_2346) {
                    result += getMiningDurationTicks(context, x, y + 1, z, above, true);
                }
            }
            return result;
        }
        return 0; // 无需真挖,也就不必查上方落沙
    }

    // ==================== 放置相关 ====================

    /**
     * 该格是否可被放置动作替换掉:空气、单层雪(未加载 chunk 放行)、
     * 高草/大型蕨,及其余原版可替换方块。
     */
    public static boolean isReplaceable(int x, int y, int z, class_2680 state, ChunkLoadedTest loaded) {
        class_2248 block = state.method_26204();
        if (block instanceof class_2189) {
            return true;
        }
        if (block instanceof class_2488) {
            if (!loaded.isLoaded(x, z)) {
                return true;
            }
            return state.method_11654(class_2488.field_11518) == 1;
        }
        if (block == class_2246.field_10313 || block == class_2246.field_10214) {
            return true;
        }
        return state.method_45474();
    }

    public static boolean canPlaceAgainst(CalculationContext context, int x, int y, int z) {
        return canPlaceAgainst(context, x, y, z, context.get(x, y, z));
    }

    public static boolean canPlaceAgainst(CalculationContext context, int x, int y, int z, class_2680 state) {
        if (!placeableWithinBorder(context.worldBorder, x, z)) {
            return false;
        }
        return canPlaceAgainst(state);
    }

    public static boolean canPlaceAgainst(class_1922 level, class_2338 pos) {
        if (level instanceof net.minecraft.class_1937 live
                && !placeableWithinBorder(live.method_8621(), pos.method_10263(), pos.method_10260())) {
            return false;
        }
        return canPlaceAgainst(level.method_8320(pos));
    }

    /**
     * 贴面格是否离世界边界足够远:各向内缩一格——贴着边界的方块无法
     * 被右键选面。边界未知(null)按不限制。
     */
    public static boolean placeableWithinBorder(net.minecraft.class_2784 border,
                                                int x, int z) {
        if (border == null) {
            return true;
        }
        return x > border.method_11976() && x + 1 < border.method_11963()
                && z > border.method_11958() && z + 1 < border.method_11977();
    }

    /**
     * 能否瞄准该方块侧面中心作为放置贴面:完整实心方块或玻璃。
     * 技术上能贴、实际瞄不准的薄片方块(地毯之类)不算。
     */
    public static boolean canPlaceAgainst(class_2680 state) {
        return isBlockNormalCube(state)
                || state.method_26204() == class_2246.field_10033
                || state.method_26204() instanceof class_2506;
    }

    // ==================== 门 / 栅栏门通行 ====================

    /** 木门当下能否直接走过(玩家在门格里 → 不行)。 */
    public static boolean isDoorPassable(class_1922 level, class_2338 doorPos, class_2338 playerPos) {
        if (playerPos.equals(doorPos)) {
            return false;
        }
        class_2680 state = level.method_8320(doorPos);
        if (!(state.method_26204() instanceof class_2323)) {
            return true;
        }
        return isHorizontalBlockPassable(doorPos, state, playerPos, class_2323.field_10945);
    }

    /** 栅栏门当下能否走过(只看 OPEN)。 */
    public static boolean isGatePassable(class_1922 level, class_2338 gatePos, class_2338 playerPos) {
        if (playerPos.equals(gatePos)) {
            return false;
        }
        class_2680 state = level.method_8320(gatePos);
        if (!(state.method_26204() instanceof class_2349)) {
            return true;
        }
        return state.method_11654(class_2349.field_11026);
    }

    /**
     * 带朝向的门板通行判定:接近轴与门板朝向轴同向时,开着才能过;
     * 垂直时反而是关着才不挡路(门板收在格边)。
     */
    public static boolean isHorizontalBlockPassable(class_2338 blockPos, class_2680 blockState,
                                                    class_2338 playerPos, class_2746 propertyOpen) {
        if (playerPos.equals(blockPos)) {
            return false;
        }
        var facing = blockState.method_11654(class_2383.field_11177).method_10166();
        boolean open = blockState.method_11654(propertyOpen);

        net.minecraft.class_2350.class_2351 playerFacing;
        if (playerPos.method_10095().equals(blockPos) || playerPos.method_10072().equals(blockPos)) {
            playerFacing = net.minecraft.class_2350.class_2351.field_11051;
        } else if (playerPos.method_10078().equals(blockPos) || playerPos.method_10067().equals(blockPos)) {
            playerFacing = net.minecraft.class_2350.class_2351.field_11048;
        } else {
            return true;
        }
        return (facing == playerFacing) == open;
    }

    // ==================== 危险格 ====================

    /** 绝不能走进去的格:任何流体、岩浆块、仙人掌、浆果丛、火等。 */
    public static boolean avoidWalkingInto(class_2680 state) {
        class_2248 block = state.method_26204();
        return !state.method_26227().method_15769()
                || block == class_2246.field_10092
                || block == class_2246.field_10029
                || block == class_2246.field_16999
                || block instanceof class_4770
                || block == class_2246.field_10027
                || block == class_2246.field_10343
                || block == class_2246.field_10422;
    }

    // ==================== 台阶 / 流体基础判定 ====================

    /** 占据下半格的台阶。 */
    public static boolean isBottomSlab(class_2680 state) {
        return state.method_26204() instanceof class_2482
                && state.method_11654(class_2482.field_11501) == class_2771.field_12681;
    }

    /** 是否为水(含流动态)。 */
    public static boolean isWater(class_2680 state) {
        class_3611 f = state.method_26227().method_15772();
        return f == class_3612.field_15910 || f == class_3612.field_15909;
    }

    /** 是否为岩浆(含流动态)。 */
    public static boolean isLava(class_2680 state) {
        class_3611 f = state.method_26227().method_15772();
        return f == class_3612.field_15908 || f == class_3612.field_15907;
    }

    /** 是否为任意液体。 */
    public static boolean isLiquid(class_2680 state) {
        return !state.method_26227().method_15769();
    }

    /** 可能在流动:流体类且非满格。 */
    public static boolean possiblyFlowing(class_2680 state) {
        class_3610 fluidState = state.method_26227();
        return fluidState.method_15772() instanceof class_3609
                && fluidState.method_15761() != 8;
    }

    /**
     * 该格流体是否在流动:非满格即流动;满格源方块若四个水平邻格
     * 任一可能在流动(池边),也按流动处理。
     */
    public static boolean isFlowing(class_1922 view, int x, int y, int z, class_2680 state) {
        class_3610 fluidState = state.method_26227();
        if (!(fluidState.method_15772() instanceof class_3609)) {
            return false;
        }
        if (fluidState.method_15761() != 8) {
            return true;
        }
        return possiblyFlowing(view.method_8320(new class_2338(x + 1, y, z)))
                || possiblyFlowing(view.method_8320(new class_2338(x - 1, y, z)))
                || possiblyFlowing(view.method_8320(new class_2338(x, y, z + 1)))
                || possiblyFlowing(view.method_8320(new class_2338(x, y, z - 1)));
    }

    /**
     * 完整实心立方体判定:碰撞形状为满格,并排除一批形状异常/
     * 会动的方块(竹、活塞移动方块、脚手架、潜影盒、滴水石锥、
     * 紫水晶簇)。取形状抛异常时按 false。
     */
    public static boolean isBlockNormalCube(class_2680 state) {
        class_2248 block = state.method_26204();
        if (block instanceof class_2211
                || block instanceof class_2667
                || block instanceof class_3736
                || block instanceof class_2480
                || block instanceof class_5689
                || block instanceof class_5542) {
            return false;
        }
        try {
            return class_2248.method_9614(state.method_26220(null, null));
        } catch (Exception ignored) {
            // 拿不到碰撞形状的异类按非实心处理
        }
        return false;
    }

}
