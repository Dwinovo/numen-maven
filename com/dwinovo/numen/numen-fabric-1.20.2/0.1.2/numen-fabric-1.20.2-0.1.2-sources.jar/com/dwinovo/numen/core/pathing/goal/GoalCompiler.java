package com.dwinovo.numen.core.pathing.goal;

import com.dwinovo.numen.core.pathing.bridge.GoalAdapter;
import com.dwinovo.numen.core.pathing.calc.NavGoal;
import com.dwinovo.numen.core.pathing.goals.Goal;
import com.dwinovo.numen.core.pathing.util.BlockHelper;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.longs.LongSets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

/**
 * Compiles a task's INTENT into the full navigation contract. Each static
 * factory IS an intent — there is deliberately no intent enum, the method
 * names are the vocabulary — and each returns the three things the navigation
 * and its task must agree on, derived together so they can never drift:
 *
 * <ul>
 *   <li>{@link Compiled#goal()} — the search goal (which feet cells may end
 *       the path);</li>
 *   <li>{@link Compiled#sacred()} — the cells the route itself must leave
 *       untouched (may neither break nor bury: the table it travels to use,
 *       the ore its task will mine).</li>
 * </ul>
 *
 * <p>The load-bearing entry is {@link #block}: the replacement for the old
 * {@code resolveBlockGoal} fallback whose Euclidean {@code near(2.0)} sphere
 * admitted elevated cells (the geometry that let "place a scaffold, stand on
 * it" finish an approach) and marked nothing sacred (so a route could dig
 * through the very block it was travelling to).
 */
public final class GoalCompiler {

    private GoalCompiler() {}

    /**
     * The compiled navigation contract.
     *
     * @param goal           search goal — node-domain arrival
     * @param engineGoal     the SAME arrival semantics as a new-kernel
     *                       {@link Goal} — derived from {@code goal} through
     *                       {@link GoalAdapter}'s per-factory mapping table, so the
     *                       two goal domains can never drift apart
     * @param sacred         {@link class_2338#method_10063()} keys of cells the route must not
     *                       break or bury (the {@code CalculationContext} domain);
     *                       empty when the intent has no block objective
     */
    public record Compiled(NavGoal goal, Goal engineGoal, LongSet sacred) {
        /** engineGoal 从 goal 经映射表派生(既有调用方签名不变)。 */
        public Compiled(NavGoal goal, LongSet sacred) {
            this(goal, GoalAdapter.toEngineGoal(goal), sacred);
        }
    }

    /**
     * One mining stance: the ore (what becomes sacred), the stance BASE the feet
     * band hangs from (usually the ore itself, but a run's top block anchors one
     * lower — see {@code MineCompanionTask.coalesce}), and how far below that
     * base the feet may end ({@link NavGoal#mineColumn}).
     */

    /**
     * Use/open/work at a block (crafting table, chest, furnace, door): end
     * TOUCHING it ({@link NavGoal#getToBlock} — y-anchored, no elevated cell
     * satisfies), the target itself sacred, arrival = grounded within reach.
     */
    public static Compiled interact(class_2338 target) {
        class_2338 t = target.method_10062();
        return new Compiled(NavGoal.getToBlock(t), single(t));
    }

    /** Occupy exactly this cell. Nothing sacred. */
    public static Compiled standOn(class_2338 cell) {
        class_2338 c = cell.method_10062();
        return new Compiled(NavGoal.exact(c), LongSets.emptySet());
    }

    /** Stand orthogonally beside {@code target} (a placement stance): the
     *  target cell is sacred — the route may not scaffold into the cell the
     *  task is about to fill. */
    public static Compiled standAdjacent(class_2338 target) {
        class_2338 t = target.method_10062();
        return new Compiled(NavGoal.adjacent(t), single(t));
    }

    /**
     * Vicinity of a (usually moving) ground-dwelling point: horizontal radius
     * at the target's height ±1 ({@link NavGoal#nearGround} — the raw 3D sphere
     * is deliberately NOT used here). Nothing sacred.
     */
    public static Compiled near(class_2338 center, double radius) {
        class_2338 c = center.method_10062();
        return new Compiled(NavGoal.nearGround(c, radius), LongSets.emptySet());
    }

    /** The {@code resolveBlockGoal} replacement: a walkable cell is a place to
     *  stand, an occupied one is a block to get to (and not consume). */
    public static Compiled block(class_1937 level, class_2338 cell) {
        return block(BlockHelper.canWalkThrough(level, cell), cell);
    }

    /** Pure core of {@link #block(class_1937, class_2338)} (headless-testable). */
    public static Compiled block(boolean cellWalkable, class_2338 cell) {
        return cellWalkable ? standOn(cell) : interact(cell);
    }

    /**
     * A whole mining objective in one search: composite of per-ore stances
     * (plus a loose member per nearby drop, so the same walk collects them).
     *
     * <p>Target cells are deliberately NOT sacred — the route is allowed to chop a
     * target on the way past. A stance often sits inside the target's own column
     * (a tree trunk: "feet at/under the log" IS a log cell), so forbidding the
     * path from breaking targets makes every stance of an untouched trunk
     * unsatisfiable and the search burns its whole budget on a goal it can never
     * reach — then blacklists a perfectly minable block as "no path". An en-route
     * break loses nothing: the cell leaves knownOres on the next prune, its drop
     * is collected by the drop members, and progress counts inventory, not dig
     * events.
     */
    public static Compiled mineField(List<class_2338> ores, List<class_2338> drops) {
        List<NavGoal> members = new ArrayList<>(ores.size() + drops.size());
        for (class_2338 ore : ores) {
            members.add(NavGoal.mineStance(ore));
        }
        for (class_2338 drop : drops) {
            members.add(NavGoal.exact(drop));     // items, not blocks
        }
        return new Compiled(NavGoal.composite(members), LongSets.emptySet());
    }

    /**
     * Get beside ANY of these same-kind blocks (a "walk to the nearest X"
     * objective): composite of per-candidate {@link NavGoal#getToBlock}
     * members, EVERY candidate sacred — the route may neither break nor bury
     * the very blocks it is travelling to; whichever ends up cheapest wins.
     */
    public static Compiled anyOf(List<class_2338> candidates) {
        List<NavGoal> members = new ArrayList<>(candidates.size());
        LongSet sacred = new LongOpenHashSet(candidates.size());
        for (class_2338 c : candidates) {
            class_2338 t = c.method_10062();
            members.add(NavGoal.getToBlock(t));
            sacred.add(t.method_10063());
        }
        return new Compiled(NavGoal.composite(members), sacred);
    }

    private static LongSet single(class_2338 pos) {
        LongSet set = new LongOpenHashSet(1);
        set.add(pos.method_10063());
        return set;
    }
}
