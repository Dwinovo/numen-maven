package com.dwinovo.numen.core.pathing.moves.movements;

import com.dwinovo.numen.core.pathing.settings.ScaffoldMaterials;
import com.dwinovo.numen.core.pathing.settings.NavSettings;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.core.build.BuildValidity;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

/** Active construction material lookup used by path movements that place blocks. */
public final class BuildPlacementRegistry {

    public interface Provider {
        class_2680 desiredState(class_2338 placeAt);

        default boolean acceptsPlacement(class_2338 placeAt, class_2680 state) {
            class_2680 desired = desiredState(placeAt);
            return desired != null && BuildValidity.valid(state, desired, true);
        }
    }

    private static final Map<class_3222, Provider> PROVIDERS = new WeakHashMap<>();
    /** 施工期寻路放置过的格子回执(仅登记了 Provider 的玩家记录;任务逐 tick 领走)。 */
    private static final Map<class_3222, java.util.Set<class_2338>> SCAFFOLD = new WeakHashMap<>();

    private BuildPlacementRegistry() {}

    /** 寻路准备在该格放置(脚手架/垫柱/搭桥):给建造任务留回执,交付前清残料用。 */
    public static void recordScaffold(class_3222 player, class_2338 placeAt) {
        if (!PROVIDERS.containsKey(player)) {
            return;   // 无建造任务在册:挖矿等场景的搭桥不记账,防集合无界生长
        }
        SCAFFOLD.computeIfAbsent(player, k -> new java.util.LinkedHashSet<>()).add(placeAt.method_10062());
    }

    /** 领走该玩家累计的放置回执(领后清空)。 */
    public static java.util.Set<class_2338> drainScaffold(class_3222 player) {
        java.util.Set<class_2338> out = SCAFFOLD.remove(player);
        return out == null ? java.util.Set.of() : out;
    }

    public static void register(class_3222 player, Provider provider) {
        PROVIDERS.put(player, provider);
    }

    public static void unregister(class_3222 player, Provider provider) {
        if (PROVIDERS.get(player) == provider) {
            PROVIDERS.remove(player);
        }
    }


    static boolean hasTarget(class_3222 player, class_2338 placeAt) {
        Provider provider = PROVIDERS.get(player);
        return provider != null && provider.desiredState(placeAt) != null;
    }

    static boolean selectForLocation(class_3222 player, class_2338 placeAt, boolean select) {
        return selectForLocation(player, placeAt, null, player.method_36454(), player.method_36455(), select);
    }

    static boolean selectForLocation(class_3222 player, class_2338 placeAt, class_3965 hit,
                                     float yaw, float pitch, boolean select) {
        Provider provider = PROVIDERS.get(player);
        if (provider == null) {
            return false;
        }
        class_2680 desired = provider.desiredState(placeAt);
        if (desired == null) {
            return false;
        }
        if (selectMatching(player, select, stack -> wouldPlaceAccepted(player, stack, placeAt,
                hit, yaw, pitch, provider))) {
            return true;
        }
        if (selectMatching(player, select, stack -> wouldPlaceSameBlock(player, stack, desired,
                hit, yaw, pitch))) {
            return true;
        }
        return selectGenericThrowaway(player, hit, yaw, pitch, select);
    }

    private static boolean selectMatching(class_3222 player, boolean select, Predicate<class_1799> desired) {
        class_1661 inv = player.method_31548();
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && desired.test(stack)) {
                if (select) {
                    inv.field_7545 = i;
                }
                return true;
            }
        }
        class_1799 offhand = player.method_6079();
        if (!offhand.method_7960() && desired.test(offhand)) {
            // 建材在副手:选一个空/工具主手槽,让右键走副手放置(顺序 快捷栏→副手→背包)。
            for (int i = 0; i < 9; i++) {
                class_1799 stack = inv.method_5438(i);
                if (stack.method_7960()
                        || stack.method_7909() instanceof net.minecraft.class_1831
                        || stack.method_7909() instanceof net.minecraft.class_1820) {
                    if (select) {
                        inv.field_7545 = i;
                    }
                    return true;
                }
            }
        }
        if (NavSettings.get().allowInventory) {
            for (int i = 9; i < inv.field_7547.size(); i++) {
                class_1799 stack = inv.method_5438(i);
                if (!stack.method_7960() && desired.test(stack)) {
                    if (select) {
                        if (player instanceof NumenPlayer np) {
                            np.holdInHand(i);
                        } else {
                            class_1799 tmp = inv.method_5438(7);
                            inv.method_5447(7, stack);
                            inv.method_5447(i, tmp);
                            inv.field_7545 = 7;
                        }
                    }
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean wouldPlaceAccepted(class_3222 player, class_1799 stack, class_2338 placeAt,
                                              class_3965 hit, float yaw, float pitch,
                                              Provider provider) {
        if (hit == null) {
            if (!(stack.method_7909() instanceof class_1747 blockItem)) {
                return false;
            }
            class_2680 fallback = blockItem.method_7711().method_9564();
            return provider.acceptsPlacement(placeAt, fallback);
        }
        class_2680 state = predictedState(player, stack, hit, yaw, pitch, class_1268.field_5808);
        return state != null && provider.acceptsPlacement(placeAt, state);
    }

    private static boolean wouldPlaceSameBlock(class_3222 player, class_1799 stack, class_2680 desired,
                                               class_3965 hit, float yaw, float pitch) {
        if (!(stack.method_7909() instanceof class_1747 blockItem)) {
            return false;
        }
        if (hit == null) {
            return desired.method_26204() == blockItem.method_7711();
        }
        class_2680 state = predictedState(player, stack, hit, yaw, pitch, class_1268.field_5808);
        return state != null && state.method_26204() == desired.method_26204();
    }

    private static boolean selectGenericThrowaway(class_3222 player, class_3965 hit,
                                                  float yaw, float pitch, boolean select) {
        class_1661 inventory = player.method_31548();
        boolean allowInventory = NavSettings.get().allowInventory;
        for (class_1792 item : ScaffoldMaterials.of(player)) {
            for (int i = 0; i < 9; i++) {
                class_1799 stack = inventory.method_5438(i);
                if (!stack.method_7960() && stack.method_7909() == item
                        && wouldPlaceAny(player, stack, hit, yaw, pitch, class_1268.field_5808)) {
                    if (select) {
                        inventory.field_7545 = i;
                    }
                    return true;
                }
            }
            class_1799 offhand = player.method_6079();
            if (!offhand.method_7960() && offhand.method_7909() == item
                    && wouldPlaceAny(player, offhand, hit, yaw, pitch, class_1268.field_5810)) {
                for (int i = 0; i < 9; i++) {
                    class_1799 stack = inventory.method_5438(i);
                    if (stack.method_7960()
                            || stack.method_7909() instanceof net.minecraft.class_1831
                        || stack.method_7909() instanceof net.minecraft.class_1820) {
                        if (select) {
                            inventory.field_7545 = i;
                        }
                        return true;
                    }
                }
            }
            if (allowInventory) {
                for (int i = 9; i < 36; i++) {
                    class_1799 stack = inventory.method_5438(i);
                    if (!stack.method_7960() && stack.method_7909() == item
                            && wouldPlaceAny(player, stack, hit, yaw, pitch, class_1268.field_5808)) {
                        if (select) {
                            class_1799 tmp = inventory.method_5438(7);
                            inventory.method_5447(7, stack);
                            inventory.method_5447(i, tmp);
                            inventory.field_7545 = 7;
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean wouldPlaceAny(class_3222 player, class_1799 stack, class_3965 hit,
                                         float yaw, float pitch, class_1268 hand) {
        if (!(stack.method_7909() instanceof class_1747)) {
            return false;
        }
        return hit == null || predictedState(player, stack, hit, yaw, pitch, hand) != null;
    }

    private static class_2680 predictedState(class_3222 player, class_1799 stack, class_3965 hit,
                                             float yaw, float pitch, class_1268 hand) {
        if (!(stack.method_7909() instanceof class_1747 blockItem)) {
            return null;
        }
        float oldYaw = player.method_36454();
        float oldPitch = player.method_36455();
        try {
            player.method_36456(yaw);
            player.method_36457(pitch);
            class_1750 context = new class_1750(new class_1838(
                    player.method_37908(), player, hand, stack, hit) {});
            class_2680 state = blockItem.method_7711().method_9605(context);
            return state != null && context.method_7716() ? state : null;
        } catch (RuntimeException e) {
            return null;
        } finally {
            player.method_36456(oldYaw);
            player.method_36457(oldPitch);
        }
    }
}