package com.dwinovo.numen.core.scan;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2826;
import net.minecraft.class_3218;
import net.minecraft.class_4076;

/**
 * 读地形的两个原语:<b>扫一节</b>({@link #scanChunkSection})和<b>小盒里找最近</b>
 * ({@link #nearestBlock})。串成一次搜索是 {@link BlockSearch} 的事,这里只管怎么读。
 *
 * <h2>为什么不是逐格读</h2>
 * 朴素搜索是 {@code (2r+1)³} 次 {@code getBlockState}(r=12 就 ~15k 次)。扫一节改成先问
 * {@link class_2826#method_19523(Predicate)}——只看该节调色板的 2-10 项,没有目标就整节
 * 4096 格一次跳过。稀疏目标(矿)能快 50-200 倍。
 *
 * <p>{@link #nearestBlock} 仍是逐格读:它问的是"手边够得着的有没有",盒子只有十几格见方
 * 且必在加载区内,搭一次环序搜索的架子比直接读还贵。
 */
public final class BlockScanner {

    private BlockScanner() {}

    /**
     * The fully-loaded chunk at ({@code cx},{@code cz}), or {@code null} if it isn't loaded — a pure
     * cache read via {@link net.minecraft.class_3215#method_21730} that <b>never</b>
     * forces a load, generates, or bounces to the main thread. Every scan in this package reads terrain
     * through here: {@code getChunk} with a status would block the server thread on chunk I/O or
     * generation, and a scan is a perception query — it reports what is loaded and says so, it does not
     * make the world bigger to answer.
     */
    static class_2791 loadedChunk(class_1937 level, int cx, int cz) {
        return level instanceof class_3218 serverLevel
                ? serverLevel.method_14178().method_21730(cx, cz)
                : null;
    }

    /** One match: world position, its state, and Euclidean distance from the search centre. */
    public record Hit(class_2338 pos, class_2680 state, double distance) {}

    /**
     * 身边小盒范围内、离 {@code eye} 最近的满足 {@code match} 的方块;超出
     * {@code maxDist} 或没有则 null。同步逐格读,只适合以身体为中心的小半径
     * (必在加载区内)——远程找方块走 {@code BlockSearch} 的预算切片。
     *
     * <p>谓词带位置:有的判据要问方块实体(见 {@code CraftOps} 的行为探测),
     * 光有状态答不了。空气格不问谓词,直接跳过。
     */
    public static class_2338 nearestBlock(class_1937 level, class_2338 base, class_243 eye,
                                        int hr, int vr, double maxDist,
                                        java.util.function.BiPredicate<class_2338, class_2680> match) {
        class_2338 best = null;
        double bestD = maxDist * maxDist;
        for (class_2338 p : class_2338.method_10097(base.method_10069(-hr, -vr, -hr), base.method_10069(hr, vr, hr))) {
            class_2680 state = level.method_8320(p);
            if (state.method_26215() || !match.test(p, state)) {
                continue;
            }
            double d = eye.method_1025(class_243.method_24953(p));
            if (d < bestD) {
                bestD = d;
                best = p.method_10062();
            }
        }
        return best;
    }

    /**
     * 扫一节:已解析好的 chunk 里的一个 section,调色板短路 + 球面裁剪,命中追加进
     * {@code out}。全仓找方块最终都落到这里——{@link BlockSearch} 一个配额换一节,
     * {@link #scanRings} 一口气走完一串。公开是因为前者要按这个粒度计费。
     */
    public static void scanChunkSection(class_1937 level, class_2791 chunk,
                                        int chunkX, int sectionY, int chunkZ,
                                        class_2338 center, int radius, double radiusSq,
                                        Predicate<class_2680> filter,
                                        List<Hit> out) {
        int idx = level.method_31603(sectionY);
        if (idx < 0 || idx >= chunk.method_32890()) return;
        class_2826 section = chunk.method_38259(idx);
        if (section == null || section.method_38292()) return;
        // Palette short-circuit: skip all 4096 inner blocks when the
        // section's palette holds no target.
        if (!section.method_19523(filter)) return;
        scanSection(section, chunkX, sectionY, chunkZ, center, radius, radiusSq, filter, out);
    }

    private static void scanSection(class_2826 section,
                                    int chunkX, int sectionY, int chunkZ,
                                    class_2338 center, int radius, double radiusSq,
                                    Predicate<class_2680> filter,
                                    List<Hit> out) {
        int baseX = class_4076.method_18688(chunkX);
        int baseY = class_4076.method_18688(sectionY);
        int baseZ = class_4076.method_18688(chunkZ);
        for (int dx = 0; dx < 16; dx++) {
            int worldX = baseX + dx;
            int ddx = worldX - center.method_10263();
            if (ddx < -radius || ddx > radius) continue;
            for (int dy = 0; dy < 16; dy++) {
                int worldY = baseY + dy;
                int ddy = worldY - center.method_10264();
                if (ddy < -radius || ddy > radius) continue;
                for (int dz = 0; dz < 16; dz++) {
                    int worldZ = baseZ + dz;
                    int ddz = worldZ - center.method_10260();
                    if (ddz < -radius || ddz > radius) continue;
                    double distSq = (double) ddx * ddx + (double) ddy * ddy + (double) ddz * ddz;
                    if (distSq > radiusSq) continue;
                    class_2680 state = section.method_12254(dx, dy, dz);
                    if (!filter.test(state)) continue;
                    out.add(new Hit(new class_2338(worldX, worldY, worldZ), state, Math.sqrt(distSq)));
                }
            }
        }
    }
}
