package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.core.scan.BlockScanner;
import com.dwinovo.numen.core.scan.BlockSearch;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_7923;

/**
 * The {@code scan_blocks} implementation — the business half of
 * {@code ScanBlocksTool}. It is an async (budget-sliced) server job: the method
 * takes the live entity plus a reply {@link Consumer} and returns void — the
 * result arrives on a later tick through the callback.
 */
public final class ScanOps {

    private static final int MIN_RADIUS = 1;
    private static final int MAX_RADIUS = 192;
    private static final int MAX_RESULTS = 32;

    public void scanBlocks(
int radius,
List<String> block_ids,
            NumenPlayer self, Consumer<String> reply) {
        int r = class_3532.method_15340(radius, MIN_RADIUS, MAX_RADIUS);
        Set<class_2248> targets = ToolParse.parseBlocks(block_ids);
        if (targets.isEmpty()) {
            throw new IllegalArgumentException("no valid block_ids provided");
        }
        if (!(self.method_37908() instanceof class_3218 sl)) {
            throw new IllegalArgumentException("not on a server level");
        }
        class_2338 center = self.method_24515();
        BlockSearch.start(self.method_5667(), sl, center, r, MAX_RESULTS, targets,
                result -> reply.accept(buildResult(result, r, center)));
    }

    /**
     * What the scan actually covered, in the model's words — {@code null} when it
     * covered everything asked for. A hit list on its own can't distinguish "no
     * iron within 192 blocks" from "most of that sphere was never looked at", and
     * the model will read the first meaning into silence every time.
     */
    static String coverageNote(BlockSearch.ScanResult res) {
        List<String> notes = new ArrayList<>(2);
        if (res.deadlineHit()) {
            notes.add("time budget hit after " + res.columnsScanned() + "/" + res.columnsTotal()
                    + " chunk columns — what came back is the area nearest you; "
                    + "retry for fresh coverage or scan smaller");
        }
        if (res.columnsUnloaded() > 0) {
            notes.add(res.columnsUnloaded() + " of " + res.columnsTotal() + " chunk columns in this "
                    + "radius are not loaded, so they were not searched — blocks out there are "
                    + "UNKNOWN, not absent; walk that way and scan again to find out");
        }
        return notes.isEmpty() ? null : String.join("; ", notes);
    }

    private static String buildResult(BlockSearch.ScanResult res, int radius, class_2338 center) {
        List<BlockScanner.Hit> matches = res.matches();
        int limit = Math.min(matches.size(), MAX_RESULTS);
        JsonArray out = new JsonArray();
        for (int i = 0; i < limit; i++) {
            BlockScanner.Hit s = matches.get(i);
            JsonObject o = new JsonObject();
            o.addProperty("x", s.pos().method_10263());
            o.addProperty("y", s.pos().method_10264());
            o.addProperty("z", s.pos().method_10260());
            o.addProperty("block", class_7923.field_41175.method_10221(s.state().method_26204()).toString());
            o.addProperty("distance", s.distance());
            // Source vs flowing is THE decision bit for fluids: obsidian casting
            // and bucket-filling both demand a source cell.
            if (!s.state().method_26227().method_15769()) {
                o.addProperty("source", s.state().method_26227().method_15771());
            }
            out.add(o);
        }
        JsonObject root = new JsonObject();
        root.add("matches", out);
        // A count only when the walk actually covered the sphere. Cut short — proved its
        // quota, hit the deadline, skipped unloaded ground — whatever it saw is an artifact
        // of stopping, and a number in this slot gets read as "that is how much is there".
        if (res.coveredEverything()) {
            root.addProperty("total_in_radius", matches.size());
        }
        root.addProperty("truncated", matches.size() > MAX_RESULTS || !res.coveredEverything());
        root.addProperty("radius_searched", radius);
        String note = coverageNote(res);
        if (note != null) {
            root.addProperty("note", note);
        }
        JsonObject centerJson = new JsonObject();
        centerJson.addProperty("x", center.method_10263());
        centerJson.addProperty("y", center.method_10264());
        centerJson.addProperty("z", center.method_10260());
        root.add("center", centerJson);
        return root.toString();
    }

}
