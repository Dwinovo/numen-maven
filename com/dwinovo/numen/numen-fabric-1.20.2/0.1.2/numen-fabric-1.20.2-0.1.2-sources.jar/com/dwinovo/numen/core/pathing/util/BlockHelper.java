package com.dwinovo.numen.core.pathing.util;

import net.minecraft.class_1263;
import net.minecraft.class_1922;
import net.minecraft.class_2190;
import net.minecraft.class_2211;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2480;
import net.minecraft.class_2482;
import net.minecraft.class_2506;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2577;
import net.minecraft.class_265;
import net.minecraft.class_2667;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2771;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_3736;
import net.minecraft.class_4770;
import net.minecraft.class_5542;
import net.minecraft.class_5546;
import net.minecraft.class_5689;
import net.minecraft.class_5800;

/**
 * Stateless terrain predicates used by the movement primitives and the A*
 * search: decide
 * whether a block can be stood on, passed through, broken, or is a hazard —
 * without any entity instance, just a {@link class_1922} + {@link class_2338}.
 *
 * <h2>Coordinate convention</h2>
 * A "feet position" {@code p} is walkable as a standing spot when:
 * <ul>
 *   <li>{@code p} and {@code p.above()} are pass-through (air/non-colliding) —
 *       room for the 2-tall entity body, and</li>
 *   <li>{@code p.below()} is solid-walkable — something to stand on.</li>
 * </ul>
 */
public final class BlockHelper {

    private BlockHelper() {}

    private static final class_2350[] HORIZONTAL = {
            class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039};

    /**
     * Can the entity's body occupy this cell (no collision, not a fluid we
     * refuse to enter)? True for air, grass, flowers, etc.
     *
     * <p>Water is handled here, in the passability predicate itself, rather than
     * as a bolt-on swim move. Flowing
     * water is refused (the current shoves us off-path); still water is passable
     * ONLY as the SURFACE cell — i.e. nothing fluid directly above it — so the
     * move graph contains the water surface plane but never a submerged corridor.
     * Lava is never passable. This is what lets the generic traverse/ascend/
     * descend route across water with no dedicated swim edge.
     */
    public static boolean canWalkThrough(class_1922 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        class_2248 block = state.method_26204();
        class_3610 fluid = state.method_26227();
        if (!fluid.method_15769()) {
            if (!fluid.method_15767(class_3486.field_15517)) return false;       // lava etc. — never
            if (isFlowingWater(level, pos)) return false;        // current shoves us
            // Surface only: a fluid (or a lily pad) directly above means we'd be
            // submerged / capped here, not at a free surface.
            class_2680 up = level.method_8320(pos.method_10084());
            if (!up.method_26227().method_15769()) return false;
            return !up.method_27852(class_2246.field_10588);
        }
        // Explicit deny-list: blocks we must never path through.
        // Many have an EMPTY/partial collision shape (fire, cobweb, sweet-berry, powder
        // snow, open trapdoor, big dripleaf…) so the raw shape test below would wrongly
        // pass them; the explicit list is what stops the body walking into them.
        if (block instanceof class_4770
                || state.method_27852(class_2246.field_10343) || state.method_27852(class_2246.field_10027)
                || state.method_27852(class_2246.field_10302) || block instanceof class_2190
                || state.method_27852(class_2246.field_10422) || block instanceof class_2480
                || block instanceof class_2482 || block instanceof class_2533
                || state.method_27852(class_2246.field_21211) || state.method_27852(class_2246.field_10455)
                || state.method_27852(class_2246.field_16999) || state.method_27852(class_2246.field_28048)
                || block instanceof class_5542 || block instanceof class_5800
                || state.method_27852(class_2246.field_28682) || state.method_27852(class_2246.field_27879)
                || block instanceof class_5546) {
            return false;
        }
        // Wooden doors / fence gates are passable even when shut — the path
        // executor opens them by hand. Iron doors stay a hard
        // obstruction: no redstone, can't open. So they fall through to the
        // collision test below and read as solid.
        if (isOpenableDoor(state)) {
            return true;
        }
        // A thin carpet floor cover is always walkable over.
        if (block instanceof class_2577) {
            return true;
        }
        class_265 shape = state.method_26194(level, pos, class_3726.method_16194());
        return shape.method_1110();
    }

    /**
     * A wooden door or fence gate the body can open by hand — NOT an iron door
     * (needs redstone). The path treats these as passable (no breaking) and the
     * executor right-clicks them open when shut.
     */
    public static boolean isOpenableDoor(class_2680 state) {
        if (state.method_27852(class_2246.field_9973)) {
            return false;
        }
        return state.method_26204() instanceof class_2323
                || state.method_26204() instanceof class_2349;
    }

    /** Is this door/gate currently open (OPEN blockstate property true)? */
    public static boolean isDoorOpen(class_2680 state) {
        return state.method_28498(class_2741.field_12537)
                && state.method_11654(class_2741.field_12537);
    }

    /**
     * Can a body approaching the
     * door/gate at {@code doorPos} from the adjacent cell {@code fromPos} pass through it
     * AS IT CURRENTLY STANDS? A fence gate is passable iff open. A door is
     * orientation-aware: passable iff {@code (facingAxis == approachAxis) == open}
     * — so an open door perpendicular to the approach still BLOCKS (its panel swung across the
     * gap), and a closed door flush with the approach does not. The executor toggles (right-clicks)
     * any door/gate this reports as NOT passable, which both opens a blocking-closed one and
     * closes a blocking-open one. Non-door/gate blocks read as passable (not our concern).
     */
    public static boolean isDoorwayPassable(class_1922 level, class_2338 doorPos, class_2338 fromPos) {
        class_2680 state = level.method_8320(doorPos);
        class_2248 block = state.method_26204();
        if (block instanceof class_2349) {
            return state.method_11654(class_2741.field_12537);
        }
        if (!(block instanceof class_2323)) {
            return true;
        }
        if (fromPos.equals(doorPos)) {
            return false;
        }
        class_2350.class_2351 facing = state.method_11654(class_2383.field_11177).method_10166();
        boolean open = state.method_11654(class_2741.field_12537);
        class_2350.class_2351 approach;
        if (fromPos.method_10095().equals(doorPos) || fromPos.method_10072().equals(doorPos)) {
            approach = class_2350.class_2351.field_11051;
        } else if (fromPos.method_10078().equals(doorPos) || fromPos.method_10067().equals(doorPos)) {
            approach = class_2350.class_2351.field_11048;
        } else {
            return true;   // not cardinally adjacent (diagonal / wrong Y) → don't toggle
        }
        return (facing == approach) == open;
    }

    /** Is this cell water (source or flowing)? */
    public static boolean isWater(class_1922 level, class_2338 pos) {
        return level.method_8320(pos).method_26227()
                .method_15767(net.minecraft.class_3486.field_15517);
    }

    /**
     * Is this a FLOWING water cell?
     * A non-source level is flowing; a source block is "flowing" too when it
     * feeds a horizontal non-source neighbour (edge of a pool) — unsafe to
     * walk because the current there pushes you. Used to keep the
     * route on still water only.
     */
    public static boolean isFlowingWater(class_1922 level, class_2338 pos) {
        class_3610 fluid = level.method_8320(pos).method_26227();
        if (!fluid.method_15767(class_3486.field_15517)) return false;
        if (!fluid.method_15771()) return true;                 // amount < 8 → flowing
        for (class_2350 d : HORIZONTAL) {
            class_3610 n = level.method_8320(pos.method_10093(d)).method_26227();
            if (n.method_15767(class_3486.field_15517) && !n.method_15771()) return true;
        }
        return false;
    }

    /**
     * Can the entity stand on TOP of this block (i.e. is it a solid floor)?
     *
     * <p>Water: a water
     * cell is "walkable on" iff there is water directly ABOVE it — i.e. you
     * float at the surface, treading on the submerged column, never on the very
     * top (air-headed) cell. Combined with {@link #canWalkThrough}'s surface
     * rule, this pins the body to the water surface plane.
     */
    public static boolean canWalkOn(class_1922 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        class_3610 fluid = state.method_26227();
        if (!fluid.method_15769()) {
            if (!fluid.method_15767(class_3486.field_15517)) return false;   // lava is never a floor
            // Walk on water only where water is above (submerged → float here).
            return isWater(level, pos.method_10084());
        }
        if (state.method_26215()) return false;
        // Explicit allow-list: blocks that are NOT full collision
        // cubes but are still safe to stand on. The generic full-cube test below would
        // miss these (farmland/path are 15/16 tall, chests/ladders/azalea aren't cubes).
        if (state.method_27852(class_2246.field_10362) || state.method_27852(class_2246.field_10194) || state.method_27852(class_2246.field_10114)) return true;
        if (state.method_27852(class_2246.field_10034) || state.method_27852(class_2246.field_10380) || state.method_27852(class_2246.field_10443)) return true;
        if (state.method_27852(class_2246.field_10033) || state.method_26204() instanceof class_2506) return true;
        if (state.method_27852(class_2246.field_9983)) return true;
        if (state.method_26204() instanceof class_5800) return true;
        if (state.method_26204() instanceof class_2510) return true;
        if (state.method_26204() instanceof class_2482) {
            // ALL slabs are a floor. Standing
            // on a bottom slab is reconciled by playerFeet() returning the cell ABOVE it.
            return true;
        }
        // Magma / honey are full cubes but refused as floors (damage / stickiness).
        if (state.method_27852(class_2246.field_10092) || state.method_27852(class_2246.field_21211)) return false;
        // Everything else: a normal full collision cube.
        return state.method_26234(level, pos);
    }

    /**
     * The body's feet cell for pathing — the
     * position nudged up 0.1251 (so sinking on soul sand / farmland doesn't read a block
     * low) and, when that cell is a SLAB, taken as the cell ABOVE it. The slab adjustment
     * is what reconciles standing on a bottom slab (feet at slab.y+0.5) with the move graph,
     * where a move onto a slab targets the cell ABOVE the slab.
     */
    public static class_2338 playerFeet(class_1922 level, double x, double y, double z) {
        class_2338 f = class_2338.method_49637(x, y + 0.1251, z);
        if (level.method_8320(f).method_26204() instanceof class_2482) {
            return f.method_10084();
        }
        return f;
    }

    /** A slab occupying the bottom half of its cell. */
    public static boolean isBottomSlab(class_2680 state) {
        return state.method_26204() instanceof class_2482
                && state.method_11654(class_2482.field_11501) == class_2771.field_12681;
    }

    public static boolean isBottomSlab(class_1922 level, class_2338 pos) {
        return isBottomSlab(level.method_8320(pos));
    }

    /**
     * A "feet" cell is a valid standing spot: 2 cells of clearance above a
     * solid floor.
     */
    public static boolean isStandable(class_1922 level, class_2338 feet) {
        return canWalkOn(level, feet.method_10074())
                && canWalkThrough(level, feet)
                && canWalkThrough(level, feet.method_10084());
    }

    /**
     * Is this block a hazard the bot must never stand in / next to break?
     * Lava and fire are hard hazards; we keep it minimal for the MVP.
     */
    public static boolean isHazard(class_1922 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        class_3610 fluid = state.method_26227();
        if (!fluid.method_15769()) {
            // Lava is the dangerous fluid. Water we simply don't enter (above),
            // but it isn't a damage hazard.
            return fluid.method_15772().method_15774() == net.minecraft.class_1802.field_8187;
        }
        // The non-fluid hazard set — blocks we must never
        // path into (magma included: it damages on contact).
        return state.method_27852(class_2246.field_10092)
                || state.method_27852(class_2246.field_10029)
                || state.method_27852(class_2246.field_16999)
                || state.method_26204() instanceof class_4770
                || state.method_27852(class_2246.field_10027)
                || state.method_27852(class_2246.field_10343)
                || state.method_27852(class_2246.field_10422);
    }

    /**
     * A cell we shouldn't walk/sprint
     * INTO — ANY fluid (incl. water, unlike {@link #isHazard}) plus the same block set.
     * Used for "is it safe to keep moving into the cell ahead" checks (walk-while-break
     * suppressor, descend safeMode), where even water counts (the current shoves us).
     */
    public static boolean avoidWalkingInto(class_1922 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (!state.method_26227().method_15769()) return true;
        return state.method_27852(class_2246.field_10092)
                || state.method_27852(class_2246.field_10029)
                || state.method_27852(class_2246.field_16999)
                || state.method_26204() instanceof class_4770
                || state.method_27852(class_2246.field_10027)
                || state.method_27852(class_2246.field_10343)
                || state.method_27852(class_2246.field_10422);
    }

    /**
     * Can we aim at the given {@code face} of this block and place against it. The face must
     * be sturdy — the same face test vanilla uses to judge whether a block is supported —
     * so a full cube, glass, a TOP slab's top face, a stair's solid back, or soul sand's top
     * all qualify, while a bottom slab's top (the face sits inside the cell, a ray at the
     * boundary misses it) does not. Judged per shared face, not per block, so a half-height
     * platform is real support from above even though its sides are not.
     *
     * <p>A handful of behaviour-special blocks are refused outright regardless of face
     * sturdiness: bamboo and pointed dripstone snap, a moving piston is mid-teleport,
     * scaffolding shifts, shulker boxes animate their lid into the click, amethyst clusters
     * shatter — none is a face worth aiming a placement at. GUI blocks (crafting tables,
     * chests, hoppers) need no refusal here: placement always sneaks, and a sneaked click
     * places against the block instead of opening it.
     */
    public static boolean canPlaceAgainst(class_1922 level, class_2338 pos, class_2350 face) {
        class_2680 state = level.method_8320(pos);
        class_2248 b = state.method_26204();
        if (b instanceof class_2211 || b instanceof class_2667
                || b instanceof class_3736 || b instanceof class_2480
                || b instanceof class_5689 || b instanceof class_5542) {
            return false;
        }
        return state.method_26206(level, pos, face);
    }

    /**
     * The neighbour direction whose fluid would pour into {@code pos} if it
     * were broken — {@link class_2350#field_11036} or a horizontal, never {@code DOWN}
     * (vanilla fluids spread to the cardinals + down, so only an overhead or
     * sideways source can fill a cell you just emptied; a fluid below can't
     * flow up into it). Lava is returned in preference to water as the worse
     * hazard. Returns {@code null} when breaking releases no flow.
     *
     * <p>The single source of truth for "breaking this unleashes a fluid",
     * consulted by the A* break cost ({@link #breakWouldCreateFlow}) so
     * "safe to route through" and "safe to mine on purpose" never disagree.
     */
    public static class_2350 fluidReleasedByBreaking(class_1922 level, class_2338 pos) {
        class_2350 water = null;
        for (class_2350 dir : class_2350.values()) {
            if (dir == class_2350.field_11033) continue;
            class_3610 fluid = level.method_8320(pos.method_10093(dir)).method_26227();
            if (fluid.method_15769()) continue;
            if (fluid.method_15767(class_3486.field_15518)) return dir;   // worst hazard wins
            if (water == null) water = dir;
        }
        return water;
    }

    /**
     * Boolean form of {@link #fluidReleasedByBreaking} for the A* break cost:
     * would breaking {@code pos} expose the cell to an adjacent fluid that
     * then floods or lava-bathes the route?
     */
    public static boolean breakWouldCreateFlow(class_1922 level, class_2338 pos) {
        return fluidReleasedByBreaking(level, pos) != null;
    }

    /**
     * Is this block breakable at all? Bedrock / unbreakable (hardness < 0) are
     * never breakable; air is a no-op (return false — nothing to break).
     */
    public static boolean isBreakable(class_1922 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (state.method_26215()) return false;
        if (!state.method_26227().method_15769()) return false;
        float hardness = state.method_26214(asBlockGetterLevel(level), pos);
        return hardness >= 0.0f;
    }

    /**
     * {@code getDestroySpeed} takes a {@code BlockGetter}; this is just an
     * identity pass-through kept as a seam in case we need to adapt the
     * argument type per loader/version.
     */
    private static class_1922 asBlockGetterLevel(class_1922 level) {
        return level;
    }

    /**
     * Can {@code inv}'s tools actually HARVEST {@code state}'s drops — i.e. break it and get the
     * item, not just destroy it? True when the block drops without a tool, or ANY inventory slot
     * holds the correct tool. Mining a {@code requiresCorrectToolForDrops} block with the wrong
     * tool removes it for nothing, so the cost model vetoes it and the break/mine tools refuse it.
     * Single source of truth — paired with {@code switchToBestTool}, which can swap a backpack
     * tool into the hand. DELIBERATELY scans the WHOLE inventory, not just the
     * hotbar (a real player's quick-switch set): a companion can dig into its own pack, so the
     * gate + cost + execution all scan the whole inventory together.
     */
    public static boolean canHarvest(class_1263 inv, class_2680 state) {
        if (!state.method_29291()) {
            return true;
        }
        for (int i = 0; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_7951(state)) {
                return true;
            }
        }
        return false;
    }

    /** Convenience: full-block solid we are happy to place scaffolding against. */
    public static boolean isReplaceableForPlacement(class_1922 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        return state.method_26215() || state.method_45474();
    }

    /**
     * 命中 do_not_break 方块标签的方块:硬禁挖的唯一真源,任何开关
     * 也不解除。默认成员是设施类(床/门/活板门/栅栏门,见
     * ModBlockTagData);工作台/熔炉/箱子/陷阱箱等常规功能方块不在
     * 硬禁内,它们走 NavSettings.blocksToAvoidBreaking 软清单
     * (挖掘成本 ×10,无路可走仍会破坏)。数据包可往此标签追加任何要
     * 硬禁挖的方块;带方块实体的方块(漏斗/潜影盒/刷怪笼/信标等)默认
     * 与泥土一样可破坏、无惩罚,除非数据包把它们加进此标签。
     */
    public static boolean shouldAvoidBreaking(class_1922 level, class_2338 pos) {
        // 标签成员测试只读不可变 BlockState holder,off-thread 搜索可安全调用。
        class_2680 state = level.method_8320(pos);
        return state.method_26164(com.dwinovo.numen.core.init.InitTag.DO_NOT_BREAK);
    }

    /**
     * Would breaking {@code pos} drop a {@link class_2346} (sand / gravel /
     * anvil / concrete powder) sitting directly above it onto the bot? Refuse so
     * we never bury or suffocate ourselves.
     */
    public static boolean breakReleasesFallingBlock(class_1922 level, class_2338 pos) {
        return level.method_8320(pos.method_10084()).method_26204() instanceof class_2346;
    }
}
