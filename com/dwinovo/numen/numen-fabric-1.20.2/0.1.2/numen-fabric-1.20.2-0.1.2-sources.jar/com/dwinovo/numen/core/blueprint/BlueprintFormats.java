package com.dwinovo.numen.core.blueprint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2487;
import net.minecraft.class_2497;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/**
 * 社区图纸格式 → 原版结构 NBT 形态(size + palette + blocks)的转换器。
 * 转完塞回 {@link BlueprintStore} 的既有管线,旋转/液体过滤/格数上限/
 * 工具层全部共用,加载器对格式来源无感。
 *
 * <ul>
 *   <li>{@code .litematic}:多区域,调色板即原版形状的
 *       {Name, Properties} 复合标签,方块索引是<b>跨 long 连续位流</b>
 *       (与区块存储"每 long 取整不跨界"不同),YZX 序;</li>
 *   <li>{@code .schem}(v2/v3):调色板是
 *       {@code "ns:block[k=v]" → id} 映射,方块数据为 LEB128 varint 字节流,
 *       YZX 序(x 最快)。</li>
 * </ul>
 *
 * <p>两种格式都对区域全体积编码,空气占绝对大头——转换时按<b>稀疏语义</b>
 * 丢弃空气格(导入图纸的空气 = 缺省不触碰,不是"清场"指令;不然一栋
 * 40×20×40 的房子光空气就把 32k 格上限吃穿)。实体/容器内容物/计划刻忽略。
 */
final class BlueprintFormats {

    private BlueprintFormats() {}

    /**
     * 单个区域的<b>包围盒体积</b>上限(256³)。
     *
     * <p>这不是格数上限(那个在 {@code BlueprintStore.MAX_CELLS}),是遍历上限。区域尺寸
     * 直接来自文件,而文件是玩家目录里可以任意编辑、也可能下载到一半就断的东西:一个声明
     * 100000³ 的区域会让下面那个循环转上一万亿次——服务端不是崩,是<b>整个冻住</b>,而冻住
     * 比崩更难查(没有崩溃报告,只有"服务器没反应了")。
     *
     * <p>256³ 对真实图纸绰绰有余:量过的日式小屋是 40×23×45,骏马马厩是 52×35×54,
     * 都在这个数的百分之一以内。
     */
    private static final long MAX_REGION_VOLUME = 256L * 256L * 256L;

    // ------------------------------------------------------------------
    // .litematic
    // ------------------------------------------------------------------

    static class_2487 fromLitematic(class_2487 root) {
        class_2487 regions = root.method_10562("Regions");
        if (regions.method_33133()) {
            throw new IllegalArgumentException("litematic has no regions");
        }
        // 先归一化各区域包围盒,求整图最小角(blocks 坐标以它为原点)
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;
        class_2499 entities = new class_2499();
        List<class_2487> regionTags = new ArrayList<>();
        for (String key : regions.method_10541()) {
            class_2487 region = regions.method_10562(key);
            regionTags.add(region);
            int[] min = regionMin(region);
            int[] abs = regionAbsSize(region);
            minX = Math.min(minX, min[0]);
            minY = Math.min(minY, min[1]);
            minZ = Math.min(minZ, min[2]);
            maxX = Math.max(maxX, min[0] + abs[0] - 1);
            maxY = Math.max(maxY, min[1] + abs[1] - 1);
            maxZ = Math.max(maxZ, min[2] + abs[2] - 1);
        }

        class_2499 palette = new class_2499();
        class_2499 blocks = new class_2499();
        for (class_2487 region : regionTags) {
            int paletteBase = palette.size();
            class_2499 regionPalette = region.method_10554("BlockStatePalette", class_2520.field_33260);
            boolean[] isAir = new boolean[regionPalette.size()];
            for (int i = 0; i < regionPalette.size(); i++) {
                class_2487 entry = regionPalette.method_10602(i);
                isAir[i] = entry.method_10558("Name").endsWith("air");
                palette.add(entry.method_10553());
            }
            int[] min = regionMin(region);
            int[] abs = regionAbsSize(region);
            long[] packed = region.method_10565("BlockStates");
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(
                    Math.max(1, regionPalette.size() - 1)));
            // 方块实体数据(箱子里的东西、告示牌的字、旗帜花纹)按区域内坐标索引,
            // 出格时挂到对应的格上——不带它,社区图纸里的箱子告示牌全是空的
            Map<Long, class_2487> regionData = new HashMap<>();
            for (class_2520 t : region.method_10554("TileEntities", class_2520.field_33260)) {
                class_2487 be = ((class_2487) t).method_10553();
                long key = key3(be.method_10550("x"), be.method_10550("y"), be.method_10550("z"));
                be.method_10551("x");
                be.method_10551("y");
                be.method_10551("z");
                regionData.put(key, be);
            }
            for (class_2520 t : region.method_10554("Entities", class_2520.field_33260)) {
                class_2487 e = ((class_2487) t).method_10553();
                class_2499 at = e.method_10554("Pos", class_2520.field_33256);
                if (at.size() != 3) {
                    continue;
                }
                e.method_10551("Pos");
                entities.add(entityCell(at.method_10611(0) - minX, at.method_10611(1) - minY,
                        at.method_10611(2) - minZ, e));
            }
            long volume = (long) abs[0] * abs[1] * abs[2];
            if (volume > MAX_REGION_VOLUME) {
                throw new IllegalArgumentException("litematic region is " + abs[0] + "x" + abs[1]
                        + "x" + abs[2] + " — that is beyond anything buildable and usually means"
                        + " the file is corrupt or was downloaded incompletely");
            }
            for (long i = 0; i < volume; i++) {
                int idx = unpack(packed, bits, i);
                if (idx >= regionPalette.size() || isAir[idx]) {
                    continue;   // 稀疏语义:空气不入格
                }
                int x = (int) (i % abs[0]);
                int z = (int) ((i / abs[0]) % abs[2]);
                int y = (int) (i / ((long) abs[0] * abs[2]));
                blocks.add(cell(min[0] + x - minX, min[1] + y - minY, min[2] + z - minZ,
                        paletteBase + idx, regionData.get(key3(x, y, z))));
            }
        }
        return assemble(maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1, palette, blocks, entities);
    }

    /** 区域最小角:负尺寸表示向负方向延伸(min = pos + size + 1)。 */
    private static int[] regionMin(class_2487 region) {
        class_2487 pos = region.method_10562("Position");
        class_2487 size = region.method_10562("Size");
        return new int[]{
                pos.method_10550("x") + Math.min(0, size.method_10550("x") + 1),
                pos.method_10550("y") + Math.min(0, size.method_10550("y") + 1),
                pos.method_10550("z") + Math.min(0, size.method_10550("z") + 1)};
    }

    private static int[] regionAbsSize(class_2487 region) {
        class_2487 size = region.method_10562("Size");
        return new int[]{Math.abs(size.method_10550("x")), Math.abs(size.method_10550("y")),
                Math.abs(size.method_10550("z"))};
    }

    /** {@code .litematic} 的跨 long 连续位流取值。 */
    private static int unpack(long[] longs, int bits, long index) {
        long mask = (1L << bits) - 1;
        long startOffset = index * bits;
        int startArr = (int) (startOffset >> 6);
        int endArr = (int) ((startOffset + bits - 1) >> 6);
        int startBit = (int) (startOffset & 0x3F);
        if (startArr >= longs.length) {
            return 0;
        }
        if (startArr == endArr) {
            return (int) ((longs[startArr] >>> startBit) & mask);
        }
        int endOffset = 64 - startBit;
        long high = endArr < longs.length ? longs[endArr] : 0;
        return (int) (((longs[startArr] >>> startBit) | (high << endOffset)) & mask);
    }

    // ------------------------------------------------------------------
    // .schem(v2 根级 / v3 嵌套 Schematic.Blocks)
    // ------------------------------------------------------------------

    static class_2487 fromSchem(class_2487 root) {
        if (root.method_10573("Schematic", class_2520.field_33260)) {
            root = root.method_10562("Schematic");   // v3 外壳
        }
        class_2487 blocksHolder = root.method_10573("Blocks", class_2520.field_33260)
                ? root.method_10562("Blocks")        // v3:Palette/Data 收在 Blocks 里
                : root;                             // v2:平铺在根
        int width = root.method_10568("Width") & 0xFFFF;
        int height = root.method_10568("Height") & 0xFFFF;
        int length = root.method_10568("Length") & 0xFFFF;
        if (width == 0 || height == 0 || length == 0) {
            throw new IllegalArgumentException("schem has zero dimension");
        }
        if ((long) width * height * length > MAX_REGION_VOLUME) {
            throw new IllegalArgumentException("schem is " + width + "x" + height + "x" + length
                    + " — that is beyond anything buildable and usually means the file is corrupt"
                    + " or was downloaded incompletely");
        }
        // 方块实体数据:v3 在 Blocks.BlockEntities,v2 平铺在根
        Map<Long, class_2487> beData = new HashMap<>();
        class_2499 beList = blocksHolder.method_10573("BlockEntities", class_2520.field_33259)
                ? blocksHolder.method_10554("BlockEntities", class_2520.field_33260)
                : root.method_10554("BlockEntities", class_2520.field_33260);
        for (class_2520 t : beList) {
            class_2487 be = (class_2487) t;
            int[] at = be.method_10561("Pos");
            if (at.length != 3) {
                continue;
            }
            class_2487 data = be.method_10573("Data", class_2520.field_33260)
                    ? be.method_10562("Data").method_10553()   // v3
                    : be.method_10553();                      // v2:数据就在这一层
            data.method_10551("Pos");
            data.method_10551("Id");
            if (be.method_10573("Id", class_2520.field_33258)) {
                data.method_10582("id", be.method_10558("Id"));
            }
            beData.put(key3(at[0], at[1], at[2]), data);
        }
        class_2499 entities = new class_2499();
        for (class_2520 t : root.method_10554("Entities", class_2520.field_33260)) {
            class_2487 e = (class_2487) t;
            class_2499 at = e.method_10554("Pos", class_2520.field_33256);
            if (at.size() != 3) {
                continue;
            }
            class_2487 data = e.method_10573("Data", class_2520.field_33260)
                    ? e.method_10562("Data").method_10553()
                    : e.method_10553();
            data.method_10551("Pos");
            data.method_10551("Id");
            if (e.method_10573("Id", class_2520.field_33258)) {
                data.method_10582("id", e.method_10558("Id"));
            }
            entities.add(entityCell(at.method_10611(0), at.method_10611(1), at.method_10611(2), data));
        }
        class_2487 paletteMap = blocksHolder.method_10562("Palette");
        int maxId = -1;
        for (String key : paletteMap.method_10541()) {
            maxId = Math.max(maxId, paletteMap.method_10550(key));
        }
        class_2487[] byId = new class_2487[maxId + 1];
        boolean[] isAir = new boolean[maxId + 1];
        for (String key : paletteMap.method_10541()) {
            int id = paletteMap.method_10550(key);
            byId[id] = parseStateString(key);
            isAir[id] = byId[id].method_10558("Name").endsWith("air");
        }
        class_2499 palette = new class_2499();
        int[] remap = new int[maxId + 1];
        for (int id = 0; id <= maxId; id++) {
            remap[id] = palette.size();
            if (byId[id] != null) {
                palette.add(byId[id]);
            }
        }

        byte[] data = blocksHolder.method_10573("Data", class_2520.field_33257)
                ? blocksHolder.method_10547("Data")
                : blocksHolder.method_10547("BlockData");   // v2 字段名
        class_2499 blocks = new class_2499();
        int cursor = 0;
        long volume = (long) width * height * length;
        for (long i = 0; i < volume && cursor < data.length; i++) {
            // LEB128 varint
            int id = 0;
            int shift = 0;
            while (true) {
                byte b = data[cursor++];
                id |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) break;
                shift += 7;
            }
            if (id > maxId || byId[id] == null || isAir[id]) {
                continue;   // 稀疏语义:空气不入格
            }
            int x = (int) (i % width);
            int z = (int) ((i / width) % length);
            int y = (int) (i / ((long) width * length));
            blocks.add(cell(x, y, z, remap[id], beData.get(key3(x, y, z))));
        }
        return assemble(width, height, length, palette, blocks, entities);
    }

    /** {@code "ns:block[k=v,k2=v2]"} → 原版调色板复合标签 {Name, Properties}。
     *  纯文本解析,不碰注册表——合法性由后续 NbtUtils.readBlockState 裁决。 */
    private static class_2487 parseStateString(String s) {
        class_2487 out = new class_2487();
        int bracket = s.indexOf('[');
        if (bracket < 0) {
            out.method_10582("Name", s);
            return out;
        }
        out.method_10582("Name", s.substring(0, bracket));
        class_2487 props = new class_2487();
        String body = s.substring(bracket + 1, s.endsWith("]") ? s.length() - 1 : s.length());
        for (String pair : body.split(",")) {
            int eq = pair.indexOf('=');
            if (eq > 0) {
                props.method_10582(pair.substring(0, eq).trim(), pair.substring(eq + 1).trim());
            }
        }
        out.method_10566("Properties", props);
        return out;
    }

    // ------------------------------------------------------------------

    /** 三维坐标压成一个键——两种格式都要按坐标去认方块实体。 */
    private static long key3(int x, int y, int z) {
        return ((long) (x & 0xFFFFF) << 42) | ((long) (y & 0x1FFFFF) << 21) | (z & 0x1FFFFF);
    }

    private static class_2487 cell(int x, int y, int z, int stateIndex) {
        return cell(x, y, z, stateIndex, null);
    }

    private static class_2487 cell(int x, int y, int z, int stateIndex, class_2487 data) {
        class_2487 cell = new class_2487();
        class_2499 pos = new class_2499();
        pos.add(class_2497.method_23247(x));
        pos.add(class_2497.method_23247(y));
        pos.add(class_2497.method_23247(z));
        cell.method_10566("pos", pos);
        cell.method_10569("state", stateIndex);
        if (data != null && !data.method_33133()) {
            cell.method_10566("nbt", data);   // 原版结构格式里方块实体数据就挂在这个键上
        }
        return cell;
    }

    /**
     * 一只实体 → 原版结构格式的条目({@code pos} 双精度相对坐标 + {@code nbt})。
     *
     * <p>只收展示框、盔甲架、画这类"摆设":它们是建筑的一部分。活物不收——图纸里
     * 存着的牛马村民不是设计,照搬等于凭空造生物。
     */
    private static class_2487 entityCell(double x, double y, double z, class_2487 nbt) {
        class_2487 out = new class_2487();
        class_2499 pos = new class_2499();
        pos.add(net.minecraft.class_2489.method_23241(x));
        pos.add(net.minecraft.class_2489.method_23241(y));
        pos.add(net.minecraft.class_2489.method_23241(z));
        out.method_10566("pos", pos);
        class_2499 blockPos = new class_2499();
        blockPos.add(class_2497.method_23247((int) Math.floor(x)));
        blockPos.add(class_2497.method_23247((int) Math.floor(y)));
        blockPos.add(class_2497.method_23247((int) Math.floor(z)));
        out.method_10566("blockPos", blockPos);
        out.method_10566("nbt", nbt);
        return out;
    }

    private static class_2487 assemble(int sx, int sy, int sz, class_2499 palette, class_2499 blocks) {
        return assemble(sx, sy, sz, palette, blocks, new class_2499());
    }

    private static class_2487 assemble(int sx, int sy, int sz, class_2499 palette, class_2499 blocks,
                                        class_2499 entities) {
        class_2487 out = new class_2487();
        class_2499 size = new class_2499();
        size.add(class_2497.method_23247(sx));
        size.add(class_2497.method_23247(sy));
        size.add(class_2497.method_23247(sz));
        out.method_10566("size", size);
        out.method_10566("palette", palette);
        out.method_10566("blocks", blocks);
        out.method_10566("entities", entities);
        return out;
    }
}
