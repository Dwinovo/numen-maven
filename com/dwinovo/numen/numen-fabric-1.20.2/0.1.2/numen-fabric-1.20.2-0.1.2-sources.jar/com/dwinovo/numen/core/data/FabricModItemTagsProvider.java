package com.dwinovo.numen.core.data;

import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;

/**
 * Fabric-side item tag provider. Forwards to {@link ModItemTagData} so the
 * tag content lives in {@code common/} and stays loader-agnostic.
 */
public final class FabricModItemTagsProvider extends FabricTagProvider.ItemTagProvider {

    public FabricModItemTagsProvider(FabricDataOutput output,
                                     CompletableFuture<class_7225.class_7874> registries) {
        super(output, registries);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        ModItemTagData.addItemTags(key -> {
            var b = getOrCreateTagBuilder(key);
            // 与方块那侧同理:引用外部标签要跳过 Fabric 的 provider 归属校验
            return ModItemTagData.appender(v -> b.add(v), t -> b.forceAddTag(t));
        });
    }
}
