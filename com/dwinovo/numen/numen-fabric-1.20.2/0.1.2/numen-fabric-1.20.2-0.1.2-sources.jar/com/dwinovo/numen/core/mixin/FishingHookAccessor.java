package com.dwinovo.numen.core.mixin;

import net.minecraft.class_1536;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Read-only access to vanilla's private successful-bite countdown. */
@Mixin(class_1536.class)
public interface FishingHookAccessor {

    @Accessor("nibble")
    int numen$getNibble();
}
