package com.dwinovo.numen.core.pathing.cache;

import com.dwinovo.numen.core.pathing.util.BlockEntityAware;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_3610;
import net.minecraft.class_4076;

/**
 * A {@link class_1922} over a {@link LoadedChunks} snapshot — the search-side world view.
 * Loaded chunk → read its LIVE section palette; not in the snapshot (unloaded) → AIR
 * (an optimistic miss).
 *
 * <p><b>Caching is a single last-chunk pointer, not a per-cell memo.</b> A* expands locally, so consecutive block reads almost
 * always land in the same chunk — {@link #prev} short-circuits those to a direct palette
 * read with zero per-read allocation; only a chunk boundary costs one snapshot lookup.
 * A per-position {@code Long2ObjectOpenHashMap} memo (the previous design) instead balloons
 * to millions of entries over a multi-second search and repeatedly resizes, and the
 * resulting GC churn stop-the-worlds the (integrated) server thread — every entity stutters
 * in lockstep. The last-chunk cache has O(1) footprint and never allocates on the hot path.
 *
 * <p>Single-threaded per instance: one search runs on one worker, so the mutable
 * {@link #prev} needs no synchronisation.
 */
public final class CachedNavView implements class_1922, BlockEntityAware {

    private static final class_2680 AIR = class_2246.field_10124.method_9564();

    private final LoadedChunks loaded;
    private final class_1937 level;

    /** Last chunk read from — see class doc. Only ever holds a snapshot chunk (or null). */
    private class_2818 prev;

    public CachedNavView(LoadedChunks loaded, class_1937 level) {
        this.loaded = loaded;
        this.level = level;
    }

    @Override
    public class_2680 method_8320(class_2338 pos) {
        return read(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    /** Was the chunk containing block-column ({@code blockX},{@code blockZ}) captured in the
     *  snapshot? {@code false} means every read there was the optimistic AIR miss — prices
     *  computed from it are guesses, not measurements. */
    public boolean isLoaded(int blockX, int blockZ) {
        return loaded.at(class_4076.method_18675(blockX), class_4076.method_18675(blockZ)) != null;
    }

    private class_2680 read(int x, int y, int z) {
        if (y < level.method_31607() || y >= level.method_31607() + level.method_31605()) {
            return AIR;
        }
        int chunkX = class_4076.method_18675(x);
        int chunkZ = class_4076.method_18675(z);
        // Great cache locality: A* expands locally, so reads usually land in the same chunk as the previous one.
        class_2818 chunk = prev;
        if (chunk == null || chunk.method_12004().field_9181 != chunkX || chunk.method_12004().field_9180 != chunkZ) {
            chunk = loaded.at(chunkX, chunkZ);
            if (chunk != null) {
                prev = chunk;   // cache hits only; unloaded stays a cheap re-miss
            }
        }
        if (chunk == null) {
            return AIR;   // unloaded / outside the snapshot — optimistic miss → AIR
        }
        try {
            int idx = level.method_31602(y);
            class_2826[] sections = chunk.method_12006();
            if (idx < 0 || idx >= sections.length) {
                return AIR;
            }
            class_2826 section = sections[idx];
            return section.method_38292() ? AIR : section.method_12254(x & 15, y & 15, z & 15);
        } catch (RuntimeException race) {
            // An off-thread read raced a main-thread palette resize (rare). Yield AIR; the executor
            // re-costs against the live world and replans, so a one-off bad cell self-corrects.
            return AIR;
        }
    }

    @Override
    public class_3610 method_8316(class_2338 pos) {
        return method_8320(pos).method_26227();
    }

    @Override
    public boolean hasBlockEntity(class_2338 pos) {
        return loaded.hasBlockEntity(pos);   // from the main-thread snapshot — safe off-thread
    }

    @Override
    public class_2586 method_8321(class_2338 pos) {
        // Can't reconstruct a live block entity off-thread. The only search-path caller, the don't-grief
        // check, now goes through hasBlockEntity instead, so returning null here is safe.
        return null;
    }

    @Override
    public int method_31605() {
        return level.method_31605();
    }

    @Override
    public int method_31607() {
        return level.method_31607();
    }
}
