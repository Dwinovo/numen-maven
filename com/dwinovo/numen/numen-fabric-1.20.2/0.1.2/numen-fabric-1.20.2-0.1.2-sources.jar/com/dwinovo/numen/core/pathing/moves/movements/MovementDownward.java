package com.dwinovo.numen.core.pathing.moves.movements;
import com.dwinovo.numen.core.pathing.moves.AimGeometry;

import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import com.dwinovo.numen.core.pathing.moves.CalculationContext;
import com.dwinovo.numen.core.pathing.moves.Movement;
import com.dwinovo.numen.core.pathing.moves.MovementHelper;
import com.dwinovo.numen.core.pathing.moves.MovementState;
import com.dwinovo.numen.core.pathing.moves.MovementStatus;
import com.dwinovo.numen.core.pathing.moves.MutableMoveResult;

import static com.dwinovo.numen.core.pathing.moves.ActionCosts.COST_INF;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.FALL_N_BLOCKS_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.LADDER_DOWN_ONE_COST;

/** 原地向下挖:挖掉脚下方块落进下一格(或沿梯子/藤蔓下一格)。 */
public class MovementDownward extends Movement {

    /** 自由落体阶段计 tick(前 10 tick 不按键)。 */
    private int numTicks = 0;

    public MovementDownward(class_3222 player, class_2338 src, class_2338 dest) {
        super(player, src, dest, new class_2338[]{dest});
    }

    @Override
    public void reset() {
        super.reset();
        numTicks = 0;
    }

    /**
     * 成本。总开关关闭或下二格不可站则不可行;脚下是梯/藤按下爬价,
     * 否则落一格 + 挖脚下(脚下若是落沙,轮到执行时早已变空,不计沙链)。
     */
    public static double cost(CalculationContext context, int x, int y, int z) {
        if (!context.allowDownward) {
            return COST_INF;
        }
        if (!MovementHelper.canWalkOn(context, x, y - 2, z)) {
            return COST_INF;
        }
        class_2680 down = context.get(x, y - 1, z);
        class_2248 downBlock = down.method_26204();
        if (downBlock == class_2246.field_9983 || downBlock == class_2246.field_10597) {
            return LADDER_DOWN_ONE_COST;
        } else {
            return FALL_N_BLOCKS_COST[1]
                    + MovementHelper.getMiningDurationTicks(context, x, y - 1, z, down, false);
        }
    }

    @Override
    public double calculateCost(CalculationContext context, MutableMoveResult result) {
        return cost(context, src.method_10263(), src.method_10264(), src.method_10260());
    }

    @Override
    protected Set<class_2338> calculateValidPositions() {
        return Set.of(src, dest);
    }

    @Override
    public MovementState updateState(MovementState state) {
        super.updateState(state);
        if (state.getStatus() != MovementStatus.RUNNING) {
            return state;
        }

        class_2338 feet = feet(player);
        if (feet.equals(dest)) {
            return state.setStatus(MovementStatus.SUCCESS);
        } else if (!playerInValidPosition()) {
            return state.setStatus(MovementStatus.UNREACHABLE);
        }
        double diffX = player.method_23317() - (dest.method_10263() + 0.5);
        double diffZ = player.method_23321() - (dest.method_10260() + 0.5);
        double ab = Math.sqrt(diffX * diffX + diffZ * diffZ);

        if (numTicks++ < 10 && ab < 0.2) {
            return state; // 前 10 tick 且没漂出中心:自由落体,不碰按键
        }
        AimGeometry.moveTowards(player, state, positionsToBreak[0]);
        return state;
    }
}
