package com.dwinovo.numen.core.pathing.moves;

import com.dwinovo.numen.core.pathing.execute.AimProcessor;
import com.dwinovo.numen.core.pathing.execute.AimProcessor.Rotation;
import com.dwinovo.numen.core.pathing.settings.NavSettings;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4770;

/**
 * 行走朝向几何:瞄点求解、视线射线、朝向角与"朝方块走"的输入落地。
 * 此前混在 {@code MovementHelper} 的方块判定库里——但这一族回答的是
 * "眼睛该看哪、身体该朝哪"而不是"这一格能不能走",被执行层
 * ({@code ExecHarness}/{@code PathExecutor})、挖掘({@code BlockDigger})
 * 与建造演出跨包共用,单独成类。
 */
public final class AimGeometry {

    private AimGeometry() {}

    /** 方块中心点。 */
    public static class_243 blockCenter(class_2338 pos) {
        return new class_243(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
    }

    /**
     * 该格上眼睛能实际射到的第一个瞄点;全部被遮挡返回 null。
     * 判定次序:
     * <ol>
     *   <li>沿当前实际视角的射线已命中该格 → 保持视线,直接返回命中点
     *       (已注视时不再回中,避免无谓转头);</li>
     *   <li>碰撞形状中心与六面心逐一试射:每个候选点先算理想转角,再按
     *       视角步进量化出"本 tick 实际能转到的转角",沿该转角射线——
     *       命中该格才算可达(没转到位的 tick 不误判可视)。</li>
     * </ol>
     * 触及距离取 {@link NavSettings#blockReachDistance}。
     */
    public static class_243 reachableAimPoint(net.minecraft.class_3222 player, class_2338 pos) {
        var level = player.method_37908();
        class_243 eye = player.method_33571();
        double reach = blockReachDistance(player);
        var state = level.method_8320(pos);
        boolean fire = state.method_26204() instanceof class_4770;
        // 已注视捷径:沿当前视角的射线恰好命中该格才保持(严格等格)
        class_3965 looking = clipAlongRotation(player, player.method_36454(), player.method_36455(), reach);
        if (looking.method_17783() == class_239.class_240.field_1332 && looking.method_17777().equals(pos)) {
            return looking.method_17784();
        }
        // 首选取心:碰撞形状中点(无碰撞体退整格心);火取底面高度
        // (灭火看火的根部)。六面心按轮廓形状取(射线判定也是轮廓)。
        class_243 center = collisionCenter(level, pos, state);
        class_265 outline = state.method_26218(level, pos);
        if (outline.method_1110()) {
            outline = class_259.method_1077();
        }
        class_243[] aims = {
                center,
                shapePoint(pos, outline, 0.5, 0.0, 0.5),
                shapePoint(pos, outline, 0.5, 1.0, 0.5),
                shapePoint(pos, outline, 0.5, 0.5, 0.0),
                shapePoint(pos, outline, 0.5, 0.5, 1.0),
                shapePoint(pos, outline, 0.0, 0.5, 0.5),
                shapePoint(pos, outline, 1.0, 0.5, 0.5),
        };
        var aim = new AimProcessor();
        for (class_243 aimPoint : aims) {
            class_243 dir = aimPoint.method_1020(eye);
            if (dir.method_1027() < 1.0e-8) {
                continue;
            }
            // 本 tick 实际能转到的视角,沿它试射;可达则返回候选点本身
            // (调用方以候选点为视角目标,后续 tick 向它收敛)
            var stepped = aim.step(player.method_36454(), player.method_36455(),
                    yawTo(eye, aimPoint), pitchTo(eye, aimPoint));
            class_3965 res = clipAlongRotation(player, stepped.yaw(), stepped.pitch(), reach);
            if (hitsTarget(res, pos, fire)) {
                return aimPoint;
            }
        }
        return null;
    }

    /** 命中判定:命中该格;目标是火时命中其下方支撑格也算(火焰轮廓极薄)。 */
    private static boolean hitsTarget(class_3965 res, class_2338 pos, boolean fire) {
        if (res.method_17783() != class_239.class_240.field_1332) {
            return false;
        }
        return res.method_17777().equals(pos) || (fire && res.method_17777().equals(pos.method_10074()));
    }

    /** 碰撞形状中点;无碰撞体取整格心;火把 y 压到格底(看火的根部)。 */
    public static class_243 collisionCenter(net.minecraft.class_1937 level, class_2338 pos, class_2680 state) {
        class_265 shape = state.method_26220(level, pos);
        if (shape.method_1110()) {
            return new class_243(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
        }
        double x = (shape.method_1091(net.minecraft.class_2350.class_2351.field_11048) + shape.method_1105(net.minecraft.class_2350.class_2351.field_11048)) / 2;
        double y = (shape.method_1091(net.minecraft.class_2350.class_2351.field_11052) + shape.method_1105(net.minecraft.class_2350.class_2351.field_11052)) / 2;
        double z = (shape.method_1091(net.minecraft.class_2350.class_2351.field_11051) + shape.method_1105(net.minecraft.class_2350.class_2351.field_11051)) / 2;
        if (state.method_26204() instanceof class_4770) {
            y = 0;
        }
        return new class_243(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
    }

    /** 方块触及距离:创造 5.0,生存按设置(默认 4.5)。 */
    public static double blockReachDistance(net.minecraft.class_3222 player) {
        return player.method_7337() ? 5.0 : NavSettings.get().blockReachDistance;
    }

    /** 从眼位沿给定 yaw/pitch 的轮廓射线(不穿流体);方向向量按原版 float 三角。 */
    private static class_3965 clipAlongRotation(net.minecraft.class_3222 player,
                                                    float yaw, float pitch, double reach) {
        class_243 eye = player.method_33571();
        float f = pitch * ((float) Math.PI / 180F);
        float g = -yaw * ((float) Math.PI / 180F);
        float h = net.minecraft.class_3532.method_15362(g);
        float i = net.minecraft.class_3532.method_15374(g);
        float j = net.minecraft.class_3532.method_15362(f);
        float k = net.minecraft.class_3532.method_15374(f);
        class_243 dir = new class_243(i * j, -k, h * j);
        class_243 end = eye.method_1019(dir.method_1021(reach));
        return player.method_37908().method_17742(new net.minecraft.class_3959(
                eye, end, net.minecraft.class_3959.class_3960.field_17559,
                net.minecraft.class_3959.class_242.field_1348, player));
    }

    /** 方块碰撞形状上按比例取点(m 为各轴的 min↔max 插值系数)。 */
    static class_243 shapePoint(class_2338 pos, class_265 shape, double mx, double my, double mz) {
        double x = shape.method_1091(net.minecraft.class_2350.class_2351.field_11048) * mx
                + shape.method_1105(net.minecraft.class_2350.class_2351.field_11048) * (1 - mx);
        double y = shape.method_1091(net.minecraft.class_2350.class_2351.field_11052) * my
                + shape.method_1105(net.minecraft.class_2350.class_2351.field_11052) * (1 - my);
        double z = shape.method_1091(net.minecraft.class_2350.class_2351.field_11051) * mz
                + shape.method_1105(net.minecraft.class_2350.class_2351.field_11051) * (1 - mz);
        return new class_243(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
    }

    /** 从 from 看向 to 的 yaw(度,MC 朝向约定;用 Mth.atan2 多项式近似)。 */
    public static float yawTo(class_243 from, class_243 to) {
        double dx = from.field_1352 - to.field_1352;
        double dz = from.field_1350 - to.field_1350;
        return (float) Math.toDegrees(net.minecraft.class_3532.method_15349(dx, -dz));
    }

    /** 从 from 看向 to 的 pitch(度,向下为正;用 Mth.atan2 多项式近似)。 */
    public static float pitchTo(class_243 from, class_243 to) {
        double dx = from.field_1352 - to.field_1352;
        double dy = from.field_1351 - to.field_1351;
        double dz = from.field_1350 - to.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return (float) Math.toDegrees(net.minecraft.class_3532.method_15349(dy, horizontal));
    }

    /**
     * 朝目标方块走:yaw 对准方块中心、pitch 保持现状(不强制转头),
     * 并按住前进。
     */
    public static void moveTowards(class_1657 player, MovementState state, class_2338 pos) {
        float yaw = yawTo(player.method_33571(), blockCenter(pos));
        state.setTarget(new MovementState.MovementTarget(yaw, player.method_36455(), false));
        state.setInput(Input.MOVE_FORWARD, true);
    }
}
