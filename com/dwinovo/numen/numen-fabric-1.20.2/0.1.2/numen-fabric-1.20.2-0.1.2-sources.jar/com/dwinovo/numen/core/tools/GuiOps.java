package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.task.TaskResult;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3915;
import net.minecraft.class_7923;
import net.minecraft.class_8566;

/**
 * GUI tool implementations — the business half of {@code InspectGuiTool} and
 * {@code CloseGuiTool}: read the open container menu and close it.
 */
public final class GuiOps {

    public String inspectGui(NumenPlayer self) {
        class_1703 menu = self.field_7512;
        if (menu == null) {
            return TaskResult.fail("no GUI open.").toJson();
        }
        // With no block menu open, containerMenu IS your own InventoryMenu — which carries the 2x2
        // crafting grid. Surface it so the model can craft small recipes without a table.
        boolean ownInventory = menu == self.field_7498;
        StringBuilder container = new StringBuilder();
        StringBuilder mine = new StringBuilder();
        // Crafting grid (if any). Detect generically: a slot backed by a CraftingContainer IS a grid
        // cell (vanilla 2x2/3x3 AND modded NxM), the ResultSlot IS the output. We lay the cells out in
        // 2D with their click-able slot numbers so the model can drop the recipe ascii straight onto it
        // — no "row-major + stride + gaps" arithmetic, which is exactly where it kept misplacing.
        int gridW = 0, gridH = 0, resultIndex = -1;
        class_1735[] gridCells = null;   // indexed by position-in-container (row-major)
        for (int i = 0; i < menu.field_7761.size(); i++) {
            class_1735 slot = menu.field_7761.get(i);
            boolean playerSide = slot.field_7871 == self.method_31548();
            class_1799 it = slot.method_7677();
            if (slot instanceof class_1734) {
                resultIndex = slot.field_7874;
                continue;   // shown as part of the crafting-grid section, not the generic dump
            }
            if (slot.field_7871 instanceof class_8566 cc) {
                if (gridCells == null) {
                    gridW = cc.method_17398();
                    gridH = cc.method_17397();
                    gridCells = new class_1735[gridW * gridH];
                }
                int pos = slot.method_34266();
                if (pos >= 0 && pos < gridCells.length) {
                    gridCells[pos] = slot;
                }
                continue;
            }
            // Output-only = a non-empty machine slot that won't take its own item back (result slot).
            boolean output = !playerSide && !it.method_7960() && !slot.method_7680(it);
            String line = "  " + i + ": " + describe(it) + (output ? " [output]" : "") + "\n";
            if (playerSide) {
                if (!it.method_7960()) {
                    mine.append(line);   // only your filled slots — the items you can move in
                }
            } else {
                container.append(line);  // all container slots, empty included (placement targets)
            }
        }
        // Data slots = the menu's OTHER synced channel, parallel to the item slots: the ints a real
        // screen reads to draw progress / fuel / energy bars. Read them generically (no per-menu
        // special-casing) — meaning is GUI-specific, the model/skill interprets (e.g. a furnace's are
        // [litTime, litDuration, cookProgress, cookTotal], so cook% = cookProgress/cookTotal).
        String dataLine = "";
        List<class_3915> data = ((com.dwinovo.numen.mixin.MenuDataSlotsAccessor) (Object) menu).numen$dataSlots();
        if (!data.isEmpty()) {
            StringBuilder d = new StringBuilder("data values (machine state — progress/fuel/energy/…, "
                    + "meaning is GUI-specific): [");
            for (int i = 0; i < data.size(); i++) {
                if (i > 0) d.append(", ");
                d.append(data.get(i).method_17407());
            }
            dataLine = d.append("]\n").toString();
        }

        // Render the crafting grid as a 2D map of click-able slot numbers, so the recipe ascii from
        // lookup_recipe overlays cell-for-cell (a smaller recipe goes in the TOP-LEFT — same as here).
        String gridSection = "";
        if (gridCells != null) {
            StringBuilder g = new StringBuilder("crafting grid " + gridW + "x" + gridH
                    + " — put each recipe ingredient into the slot at the SAME position (a recipe "
                    + "smaller than the grid goes in the top-left); take the result from slot "
                    + resultIndex + ":\n");
            for (int r = 0; r < gridH; r++) {
                g.append("  ");
                for (int c = 0; c < gridW; c++) {
                    class_1735 cell = gridCells[r * gridW + c];
                    class_1799 it = cell == null ? class_1799.field_8037 : cell.method_7677();
                    int idx = cell == null ? -1 : cell.field_7874;
                    g.append("slot ").append(idx).append("=").append(describe(it));
                    if (c < gridW - 1) {
                        g.append("  |  ");
                    }
                }
                g.append("\n");
            }
            gridSection = g.toString();
        }

        String header = ownInventory
                ? "GUI: InventoryMenu (YOUR own inventory — includes the 2x2 crafting grid below)\n"
                : "GUI: " + menu.getClass().getSimpleName() + "\n";
        return TaskResult.ok(header
                + gridSection
                + "container slots:\n" + (container.length() == 0 ? "  (none)\n" : container)
                + "your inventory (non-empty):\n" + (mine.length() == 0 ? "  (empty)\n" : mine)
                + "cursor: " + describe(menu.method_34255()) + "\n"
                + dataLine
                + "tip: transfer {from} (no `to`) routes a whole stack to the other section; add `to`"
                + " + `count` for an exact move into a specific slot.").toJson();
    }

    private static String describe(class_1799 stack) {
        return stack.method_7960()
                ? "-"
                : class_7923.field_41178.method_10221(stack.method_7909()).method_12832() + " x" + stack.method_7947();
    }

    public String closeGui(NumenPlayer self) {
        class_1703 menu = self.field_7512;
        if (menu == null || menu == self.field_7498) {
            // The InventoryMenu (your own 2x2 grid + inventory) is always open — nothing to close.
            // If you left items in the 2x2 crafting grid, transfer them back out.
            return TaskResult.ok("no block GUI was open (your own inventory menu is always available).").toJson();
        }
        self.method_7346();
        return TaskResult.ok("closed the GUI.").toJson();
    }
}
