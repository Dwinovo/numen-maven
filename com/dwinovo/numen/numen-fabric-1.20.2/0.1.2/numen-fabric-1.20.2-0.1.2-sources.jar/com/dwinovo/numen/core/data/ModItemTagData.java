package com.dwinovo.numen.core.data;

import com.dwinovo.numen.core.init.InitTag;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_6862;

/**
 * Single source of truth for every item tag numen-core emits. A
 * {@link TagAppenderProvider} abstraction lets the Fabric and NeoForge data
 * providers feed their own native builder here, so adding a new tag entry edits
 * one place and both loaders pick it up.
 *
 * <h2>Adding a new tag</h2>
 * <ol>
 *   <li>Declare the {@link class_6862} in {@link InitTag}.</li>
 *   <li>Add a {@code tags.tag(InitTag.X).add(Items.Y)} block in
 *       {@link #addItemTags}.</li>
 *   <li>Re-run {@code ./gradlew :fabric:runDatagen :neoforge:runData}.</li>
 * </ol>
 */
public final class ModItemTagData {

    private ModItemTagData() {}

    /**
     * Loader-agnostic adapter: each loader's tag provider implements this to
     * return an {@link Appender} for a given key. The only MC appender with a
     * {@code add(T)} sink is {@code protected}, and the public
     * {@code TagsProvider.TagAppender} only takes {@code ResourceKey}s, so common
     * defines its own neutral sink and each loader wraps its native builder via
     * {@link #appender}.
     */
    @FunctionalInterface
    public interface TagAppenderProvider<T> {
        Appender<T> tag(class_6862<T> key);
    }

    /**
     * Minimal fluent sink — the {@code .add(T)} chaining the tag lists use, plus
     * {@code .addTag} for referencing another tag ({@code #minecraft:banners} and
     * friends). Naming a vanilla tag beats copying its current members: the
     * members change between versions, the tag's meaning does not.
     */
    public interface Appender<T> {
        Appender<T> add(T value);

        Appender<T> addTag(class_6862<T> tag);
    }

    /** Adapt a native MC tag builder to an {@link Appender}; loaders pass explicit
     *  lambdas (not method refs) to dodge the {@code add(T)} vs {@code add(T...)}
     *  overload ambiguity. */
    public static <T> Appender<T> appender(Consumer<T> add, Consumer<class_6862<T>> addTag) {
        return new Appender<>() {
            @Override
            public Appender<T> add(T value) {
                add.accept(value);
                return this;
            }

            @Override
            public Appender<T> addTag(class_6862<T> tag) {
                addTag.accept(tag);
                return this;
            }
        };
    }

    /** Foods that may be used to feed/heal a companion (vanilla foods only, no mod cross-deps). */
    public static void addItemTags(TagAppenderProvider<class_1792> tags) {
        tags.tag(InitTag.TAME_FOODS)
                .add(class_1802.field_8279)
                .add(class_1802.field_8512)
                .add(class_1802.field_8229)
                .add(class_1802.field_8179)
                .add(class_1802.field_8176)
                .add(class_1802.field_8544)
                .add(class_1802.field_8373)
                .add(class_1802.field_8347)
                .add(class_1802.field_8261)
                .add(class_1802.field_8752)
                .add(class_1802.field_8509)
                .add(class_1802.field_8423)
                .add(class_1802.field_28659)
                .add(class_1802.field_8463)
                .add(class_1802.field_8071)
                .add(class_1802.field_20417)
                .add(class_1802.field_8497)
                .add(class_1802.field_8208)
                .add(class_1802.field_8741)
                .add(class_1802.field_8567)
                .add(class_1802.field_8186)
                .add(class_1802.field_8308)
                .add(class_1802.field_16998);

        // Cheap, common blocks the pathfinder may expend as scaffolding —
        // never the player's valuables. Packs can extend this tag freely.
        tags.tag(InitTag.SCAFFOLDS)
                .add(class_1802.field_20412)
                .add(class_1802.field_8831)
                .add(class_1802.field_29025)
                .add(class_1802.field_20391)
                .add(class_1802.field_8328)
                .add(class_1802.field_20407)
                .add(class_1802.field_20401)
                .add(class_1802.field_20394)
                .add(class_1802.field_27021)
                .add(class_1802.field_28866)
                // Dirt-family variants players actually hand the companion ("here,
                // 128 dirt") — a stack of coarse dirt must count as scaffolding,
                // or hasScaffold=false silently disables every pillar/bridge move.
                .add(class_1802.field_8460)
                .add(class_1802.field_28655)
                .add(class_1802.field_8382)
                .add(class_1802.field_37537)
                .add(class_1802.field_20392)
                .add(class_1802.field_8270)
                .add(class_1802.field_8610)
                .add(class_1802.field_27020)
                // 各维度手边最多的那种:去了下界/末地,主世界那批可能一块都没带。
                .add(class_1802.field_23843)
                .add(class_1802.field_22000)
                .add(class_1802.field_21999)
                .add(class_1802.field_20399)
                .add(class_1802.field_8246);
        // 沙和砂砾故意不在其中:重力方块垫在半空会直接落下去,柱子搭不起来。
    }
}
