package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.data.ClientNumenInventory;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: a companion's 36 main backpack slots, answering
 * {@link RequestInventoryPayload}. {@code loaded=false} means the body is asleep
 * in unloaded chunks (or not the requester's) — no contents. Dropped into
 * {@link ClientNumenInventory} for the Items tab to render read-only.
 */
public record NumenInventoryPayload(UUID uuid, boolean loaded, List<class_1799> items,
                                    List<class_1799> craft, int foodLevel, float saturation)
        implements class_8710 {

    public static final class_9154<NumenInventoryPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "numen_inventory"));

    public static final class_9139<class_9129, NumenInventoryPayload> STREAM_CODEC =
            class_9139.method_58025(
                    class_4844.field_48453, NumenInventoryPayload::uuid,
                    class_9135.field_48547, NumenInventoryPayload::loaded,
                    class_1799.field_49269, NumenInventoryPayload::items,
                    class_1799.field_49269, NumenInventoryPayload::craft,
                    class_9135.field_48550, NumenInventoryPayload::foodLevel,
                    class_9135.field_48552, NumenInventoryPayload::saturation,
                    NumenInventoryPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client main thread. */
    public static void handle(NumenInventoryPayload p) {
        ClientNumenInventory.update(p.uuid(), new ClientNumenInventory.Snapshot(
                p.loaded(), p.items(), p.craft(), p.foodLevel(), p.saturation(), System.currentTimeMillis()));
    }
}
