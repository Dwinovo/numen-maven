package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.path.ClientPathViz;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: the companion's current pathfinding plan, for the in-world
 * path overlay (Baritone's {@code PathRenderer}, ported to our server-authored
 * model). Baritone renders client-side from its own {@code PathingBehavior};
 * our path lives on the server, so the body pushes it to the owner whenever it
 * (re)plans a segment, and pushes an EMPTY one (all lists empty, no goal) to
 * clear the overlay when the path ends.
 *
 * <ul>
 *   <li>{@code nodes} — the path positions (feet cells); drawn as a red poly-line.</li>
 *   <li>{@code toBreak} — blocks the path will dig; drawn as red boxes.</li>
 *   <li>{@code toPlace} — scaffold blocks the path will place; drawn as green boxes.</li>
 *   <li>{@code goal} — the goal cell; drawn as a green box (absent while clearing).</li>
 * </ul>
 */
public record PathVizPayload(UUID companion,
                             class_2960 dimension,
                             List<class_2338> nodes,
                             List<class_2338> toBreak,
                             List<class_2338> toPlace,
                             List<class_2338> targets) implements class_8710 {

    /** Cap per list — paths are trimmed well below this; defends against absurd input. */
    public static final int MAX = 512;

    public static final class_9154<PathVizPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "path_viz"));

    public static final class_9139<class_9129, PathVizPayload> STREAM_CODEC =
            class_9139.method_58025(
                    class_4844.field_48453, PathVizPayload::companion,
                    class_2960.field_48267, PathVizPayload::dimension,
                    class_2338.field_48404.method_56433(class_9135.method_58000(MAX)), PathVizPayload::nodes,
                    class_2338.field_48404.method_56433(class_9135.method_58000(MAX)), PathVizPayload::toBreak,
                    class_2338.field_48404.method_56433(class_9135.method_58000(MAX)), PathVizPayload::toPlace,
                    class_2338.field_48404.method_56433(class_9135.method_58000(MAX)), PathVizPayload::targets,
                    PathVizPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(PathVizPayload p) {
        ClientPathViz.accept(p);
    }
}
