package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.Companions;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client → Server: the owner asked to summon a companion by name from the panel's
 * "+" button. Mirrors the {@code /numen player summon} command — summon is
 * idempotent per (owner, name), so re-summoning an existing name just wakes it.
 */
public record SummonRequestPayload(String name) implements class_8710 {

    public static final int MAX_NAME = 32;

    public static final class_9154<SummonRequestPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "summon_request"));

    public static final class_9139<class_9129, SummonRequestPayload> STREAM_CODEC =
            class_9139.method_56434(class_9135.method_56364(MAX_NAME), SummonRequestPayload::name,
                    SummonRequestPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Server main thread. */
    public static void handle(SummonRequestPayload p, class_3222 owner) {
        String name = p.name() == null ? "" : p.name().trim();
        if (name.isEmpty() || name.length() > MAX_NAME) return;
        class_3218 level = (class_3218) owner.method_37908();
        Companions.summon(level.method_8503(), owner.method_5667(), name, level, owner.method_19538());
        Companions.syncRosterToOwner(level.method_8503(), owner);   // push the new roster to the owner
    }
}
