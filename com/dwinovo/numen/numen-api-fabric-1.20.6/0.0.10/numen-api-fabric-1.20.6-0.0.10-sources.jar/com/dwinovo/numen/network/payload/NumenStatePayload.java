package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: a companion's 36 main backpack slots. Sent both as the answer to
 * {@link RequestStatePayload} (the Items tab asking) and unprompted whenever her
 * inventory actually changes, so the agent loop can state what she carries without
 * spending a turn on {@code get_self_status}. {@code loaded=false} means the body is
 * asleep in unloaded chunks (or not the requester's) — no contents.
 *
 * <p>{@code selectedSlot} and {@code offhand} ride along rather than being read off the
 * client-side entity: vanilla only syncs equipment for entities the client is tracking,
 * so once she walks out of view the hands would go blank while the backpack (pushed from
 * the server) stayed readable. Two fields buy one answer that is the same everywhere.
 *
 * <h2>为什么这里装的不只是背包</h2>
 * 饱食度、选中槽、副手早就在里面了 —— 它一直是<b>这具身体此刻的样子</b>,只是原来叫背包。
 * 身上的效果同理:模型每一轮都要读它才知道自己中没中毒、有没有抗性,而这类东西<b>一进对话
 * 历史就永远不会过期</b>,只能每次现挂。同一条通道、同一份快照,不必为每样状态另开一路。
 * 骑乘同理:她坐没坐在船上决定了"再点一次船"是不是废话、goto 会驾船还是走路,
 * 模型必须实时看见。{@code vehicleType} 空串 = 没骑任何东西,{@code vehicleId} 相应为 -1。
 */
public record NumenStatePayload(UUID uuid, boolean loaded, List<class_1799> items,
                                List<class_1799> craft, int foodLevel, float saturation,
                                int selectedSlot, class_1799 offhand,
                                List<class_1293> effects,
                                String vehicleType, int vehicleId)
        implements class_8710 {

    public static final class_9154<NumenStatePayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "numen_state"));

    /** 手写而不是 {@code composite}:后者最多拼 6 个分量,这里有九个。 */
    public static final class_9139<class_9129, NumenStatePayload> STREAM_CODEC =
            class_9139.method_56437(NumenStatePayload::write, NumenStatePayload::read);

    private static void write(class_9129 buf, NumenStatePayload p) {
        class_4844.field_48453.encode(buf, p.uuid());
        class_9135.field_48547.encode(buf, p.loaded());
        class_1799.field_49269.encode(buf, p.items());
        class_1799.field_49269.encode(buf, p.craft());
        class_9135.field_48550.encode(buf, p.foodLevel());
        class_9135.field_48552.encode(buf, p.saturation());
        class_9135.field_48550.encode(buf, p.selectedSlot());
        class_1799.field_49268.encode(buf, p.offhand());
        class_1293.field_49207.method_56433(class_9135.method_56363()).encode(buf, p.effects());
        class_9135.field_48554.encode(buf, p.vehicleType());
        class_9135.field_48550.encode(buf, p.vehicleId());
    }

    private static NumenStatePayload read(class_9129 buf) {
        UUID uuid = class_4844.field_48453.decode(buf);
        boolean loaded = class_9135.field_48547.decode(buf);
        List<class_1799> items = class_1799.field_49269.decode(buf);
        List<class_1799> craft = class_1799.field_49269.decode(buf);
        int foodLevel = class_9135.field_48550.decode(buf);
        float saturation = class_9135.field_48552.decode(buf);
        int selectedSlot = class_9135.field_48550.decode(buf);
        class_1799 offhand = class_1799.field_49268.decode(buf);
        List<class_1293> effects =
                class_1293.field_49207.method_56433(class_9135.method_56363()).decode(buf);
        String vehicleType = class_9135.field_48554.decode(buf);
        int vehicleId = class_9135.field_48550.decode(buf);
        return new NumenStatePayload(uuid, loaded, items, craft, foodLevel, saturation,
                selectedSlot, offhand, effects, vehicleType, vehicleId);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client main thread. */
    public static void handle(NumenStatePayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.state.accept(p);
    }
}
