package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Server → Client: one companion's live pathing state for debug overlay
 * rendering. Sent periodically (a few times a second) to owners who toggled
 * debug mode; the client draws it as world-space lines/boxes every frame, so
 * no particle spam is involved. Positions travel as {@code BlockPos#asLong}.
 *
 * <p>Categories: the current path (walked segment onward), the planned next
 * segment, the in-flight search's best partial path, blocks the route will
 * break / place / squeeze through, goal marker boxes, and goal columns
 * (an x/z-only goal rendered as a vertical line; y in the packed long is 0).
 */
public record PathDebugPayload(UUID companionId,
                               List<Long> currentPath, List<Long> nextPath, List<Long> bestPath,
                               List<Long> toBreak, List<Long> toPlace, List<Long> toWalkInto,
                               List<Long> goalBoxes, List<Long> goalColumns)
        implements class_8710 {

    public static final class_9154<PathDebugPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "path_debug"));

    public static final class_9139<class_9129, PathDebugPayload> STREAM_CODEC =
            class_9139.method_56437(PathDebugPayload::write, PathDebugPayload::read);

    private static void write(class_9129 buf, PathDebugPayload p) {
        buf.method_10797(p.companionId);
        writeLongs(buf, p.currentPath);
        writeLongs(buf, p.nextPath);
        writeLongs(buf, p.bestPath);
        writeLongs(buf, p.toBreak);
        writeLongs(buf, p.toPlace);
        writeLongs(buf, p.toWalkInto);
        writeLongs(buf, p.goalBoxes);
        writeLongs(buf, p.goalColumns);
    }

    private static PathDebugPayload read(class_9129 buf) {
        return new PathDebugPayload(buf.method_10790(),
                readLongs(buf), readLongs(buf), readLongs(buf),
                readLongs(buf), readLongs(buf), readLongs(buf),
                readLongs(buf), readLongs(buf));
    }

    private static void writeLongs(class_9129 buf, List<Long> list) {
        buf.method_10804(list.size());
        for (long v : list) {
            buf.method_52974(v);
        }
    }

    private static List<Long> readLongs(class_9129 buf) {
        int n = buf.method_10816();
        List<Long> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(buf.readLong());
        }
        return list;
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler (client main thread): stash for the frame renderer. */
    public static void handle(PathDebugPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.pathDebug.accept(p);
    }
}
