package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.CompanionRegistry;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.Wire;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * Client → Server:编辑卡给一只<b>已创建</b>同伴换皮肤(或清空回原版默认)。
 *
 * <p>皮肤的真源是注册表({@link CompanionRegistry.Entry#withSkin}),spawn 时注入
 * GameProfile——所以换肤 = 改注册表 + 原地回收身体(存盘→离场→按注册表重建,
 * {@link Companions#dormant}/{@link Companions#respawn} 现成一对,背包/位置/在做的活
 * 全走既有持久化通道回来)。客户端只认 Mojang 签过名的 textures,连皮肤格式校验
 * 都不用自己写。休眠/死亡的身体只改注册表,下次重建自然生效。
 */
public record ChangeSkinPayload(UUID uuid, String skinValue, String skinSig)
        implements class_8710 {

    public static final class_9154<ChangeSkinPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "change_skin"));

    public static final class_9139<ByteBuf, ChangeSkinPayload> STREAM_CODEC =
            class_9139.method_56436(
                    class_4844.field_48453, ChangeSkinPayload::uuid,
                    Wire.TO_SERVER.text(), ChangeSkinPayload::skinValue,
                    Wire.TO_SERVER.text(), ChangeSkinPayload::skinSig,
                    ChangeSkinPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static void handle(ChangeSkinPayload p, class_3222 owner) {
        MinecraftServer server = ((class_3218) owner.method_37908()).method_8503();
        if (server == null || p.uuid() == null) return;
        CompanionRegistry reg = CompanionRegistry.get(server);
        CompanionRegistry.Entry entry = reg.find(p.uuid());
        if (entry == null || !owner.method_5667().equals(entry.owner())) {
            return;   // 不存在或不是他的
        }
        reg.put(p.uuid(), entry.withSkin(p.skinValue(), p.skinSig()));
        NumenPlayer body = NumenPlayer.findByUuid(server, p.uuid());
        if (body != null) {
            // 活体立即生效:存盘离场再按注册表重建。同一 tick 内先移后加同一 UUID,
            // 与死亡复活流用的是同一对出入口。
            Companions.dormant(server, body);
            Companions.respawn(server, p.uuid());
        }
    }
}
