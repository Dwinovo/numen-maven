package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.permission.ConsentAnswer;
import com.dwinovo.numen.permission.ConsentDesk;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client → Server:主人在答复框上选的那一项;拒绝可以带一句附言。
 *
 * <h2>信任模型</h2>
 * 与 {@link RunProgramPayload} 同一条:目标必须是同伴(跨维度查找),发送者必须是它的主人。
 * 认主人、对请求号都在 {@link ConsentDesk#reply}(与 {@code /numen consent} 命令同一个入口),这里只转交。
 *
 * @param companion 哪只同伴
 * @param id        答的是哪一条请求
 * @param decision  允许 / 允许并记住 / 拒绝
 * @param note      附言,只有拒绝带;空串 = 没说
 */
public record ConsentReplyPayload(UUID companion, long id, ConsentAnswer.Decision decision, String note)
        implements class_8710 {

    public static final int MAX_NOTE_LENGTH = 512;

    public static final class_9154<ConsentReplyPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "consent_reply"));

    public static final class_9139<ByteBuf, ConsentReplyPayload> STREAM_CODEC =
            class_9139.method_56905(
                    class_4844.field_48453, ConsentReplyPayload::companion,
                    class_9135.field_48551, ConsentReplyPayload::id,
                    class_9135.method_56375(i -> ConsentAnswer.Decision.values()[i], Enum::ordinal),
                    ConsentReplyPayload::decision,
                    class_9135.method_56364(MAX_NOTE_LENGTH), ConsentReplyPayload::note,
                    ConsentReplyPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Handler invoked on the server main thread. */
    public static void handle(ConsentReplyPayload p, class_3222 player) {
        NumenPlayer companion = NumenPlayer.findByUuid(player.method_37908().method_8503(), p.companion());
        if (companion == null) {
            Constants.LOG.debug("[numen-net] consent_reply for unknown companion {}", p.companion());
            return;
        }
        if (p.decision() != ConsentAnswer.Decision.DENY && !p.note().isBlank()) {
            Constants.LOG.warn("[numen-net] ✗ consent_reply rejected from {}: a note only goes with a deny",
                    player.method_5477().getString());
            return;
        }
        switch (ConsentDesk.reply(player, companion, p.id(), p.decision(), p.note())) {
            case NOT_OWNER -> Constants.LOG.warn("[numen-net] ✗ consent_reply rejected from {}: not the owner",
                    player.method_5477().getString());
            case NOT_PENDING -> Constants.LOG.info("[numen-net] consent_reply #{} for {} no longer pending",
                    p.id(), p.companion());
            case ANSWERED -> { }
        }
    }
}
