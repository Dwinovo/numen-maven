package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.NumenNetwork;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client → Server: "show me this companion's backpack." Other players' full
 * inventory isn't synced to clients (only equipment is), so the read-only Items
 * tab fetches it on demand. Answered with one {@link NumenStatePayload}.
 *
 * <p>Only the owner of a LOADED companion gets the contents; otherwise the reply
 * is {@code loaded=false} (asleep / not yours — no inventory oracle).
 */
public record RequestStatePayload(UUID uuid) implements class_8710 {

    /** The 36 main backpack slots (hotbar + storage); equipment is already client-synced. */
    public static final int MAIN_SLOTS = 36;

    public static final class_9154<RequestStatePayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "request_state"));

    public static final class_9139<ByteBuf, RequestStatePayload> STREAM_CODEC =
            class_9139.method_56434(class_4844.field_48453, RequestStatePayload::uuid,
                    RequestStatePayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Server main thread. */
    public static void handle(RequestStatePayload p, class_3222 player) {
        NumenPlayer numen = NumenPlayer.findByUuid(player.method_37908().method_8503(), p.uuid());
        if (numen == null || !numen.isOwnedByPlayer(player.method_5667())) {
            NumenNetwork.sendToPlayer(player, absent(p.uuid()));
            return;
        }
        NumenNetwork.sendToPlayer(player, snapshot(numen));
    }

    /** 身体不在(睡在未加载区块 / 不是你的):没有内容可给。 */
    public static NumenStatePayload absent(java.util.UUID uuid) {
        return new NumenStatePayload(uuid, false, List.of(), List.of(), 0, 0f,
                0, class_1799.field_8037, List.of(), "", -1, "");
    }

    /**
     * 这具身体此刻带着什么。应答面板的请求和背包变化时的主动推送共用这一份——两条路给出
     * 不同的快照就等于两个真源。
     */
    public static NumenStatePayload snapshot(NumenPlayer numen) {
        class_1661 inv = numen.method_31548();
        List<class_1799> items = new ArrayList<>(MAIN_SLOTS);
        for (int i = 0; i < MAIN_SLOTS; i++) {
            items.add(inv.method_5438(i).method_7972());
        }
        // The 2×2 crafting menu (vanilla InventoryMenu layout): slot 0 = result, slots 1-4 = grid.
        // Packed as [grid0, grid1, grid2, grid3, result] for the Items tab to mirror.
        List<class_1799> craft = new ArrayList<>(5);
        for (int i = 1; i <= 4; i++) craft.add(numen.field_7498.method_7611(i).method_7677().method_7972());
        craft.add(numen.field_7498.method_7611(0).method_7677().method_7972());
        // 效果照抄一份:MobEffectInstance 是可变的(每 tick 自减),直接引用会让客户端读到
        // 一个还在动的对象。
        List<net.minecraft.class_1293> effects = new ArrayList<>();
        for (var live : numen.method_6026()) {
            effects.add(new net.minecraft.class_1293(live));
        }
        // 骑乘随身照:类型按注册路径报,id 给 use entity 直接可用的实体号
        net.minecraft.class_1297 vehicle = numen.method_5854();
        String vehicleType = vehicle == null ? ""
                : net.minecraft.class_7923.field_41177
                        .method_10221(vehicle.method_5864()).method_12832();
        return new NumenStatePayload(numen.method_5667(), true, items, craft,
                numen.method_7344().method_7586(), numen.method_7344().method_7589(),
                inv.field_7545, numen.method_6079().method_7972(), effects,
                vehicleType, vehicle == null ? -1 : vehicle.method_5628(),
                com.dwinovo.numen.api.NumenPlugins.bodyStateFragments(numen));
    }
}
