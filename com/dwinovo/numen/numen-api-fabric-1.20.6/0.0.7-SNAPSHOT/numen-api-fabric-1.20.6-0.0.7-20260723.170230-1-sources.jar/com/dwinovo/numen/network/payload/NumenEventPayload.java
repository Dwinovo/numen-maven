package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: an asynchronous WORLD EVENT for a companion's brain (dimension change, a hazard,
 * task wind-down, …). The server ships a ready-made {@code <event>} XML string; the client-side
 * INBOX decides consumption timing by the brain's state at arrival (mid-turn → next boundary;
 * background task running → immediate turn; fully idle → wait for the next turn). {@code principal}
 * marks "a live human is speaking" (bridge mods relaying danmaku / QQ messages): those open a turn
 * even from full idle, same privilege as the owner. Plain world events leave it false — their
 * timing is the inbox's business, not the producer's.
 */
public record NumenEventPayload(UUID entityUuid, String xml, boolean principal) implements class_8710 {

    public static final class_9154<NumenEventPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "numen_event"));

    public static final class_9139<class_9129, NumenEventPayload> STREAM_CODEC =
            class_9139.method_56436(
                    class_4844.field_48453, NumenEventPayload::entityUuid,
                    class_9135.field_48554, NumenEventPayload::xml,
                    class_9135.field_48547, NumenEventPayload::principal,
                    NumenEventPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenEventPayload p) {
        AgentLoopRegistry.get(p.entityUuid()).ifPresent(loop -> loop.pushEvent(p.xml(), p.principal()));
    }
}
