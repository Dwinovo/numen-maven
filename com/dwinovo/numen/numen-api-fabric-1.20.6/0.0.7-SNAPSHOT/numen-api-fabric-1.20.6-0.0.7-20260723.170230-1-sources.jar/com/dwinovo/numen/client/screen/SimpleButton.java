package com.dwinovo.numen.client.screen;

import com.dwinovo.numen.client.ui.RoundRect;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/**
 * The Numen button, drawn procedurally from the CURRENT theme (no baked sprite, so a
 * theme switch recolours it): a rounded card — idle = field tone, hover = lifted toward
 * white, disabled = sunk toward the ground. {@link #primary()} paints it in the theme's
 * CTA colour for the one action a form wants you to take.
 *
 * <p>{@link #icon(class_2960)} swaps the text label for a WHITE-template sprite
 * tinted with the label colour — icon buttons stay theme-aware too. Pair icons with a
 * vanilla {@code setTooltip} so the meaning is one hover away.
 */
public final class SimpleButton extends class_4185 {

    private class_2960 icon;
    private boolean primary;
    private boolean danger;

    public SimpleButton(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 onPress) {
        super(x, y, width, height, message, onPress,
                defaultNarrationSupplier -> defaultNarrationSupplier.get());
    }

    /** Draw a centered, theme-tinted WHITE icon sprite instead of the text label. */
    public SimpleButton icon(class_2960 icon) {
        this.icon = icon;
        return this;
    }

    /** CTA styling (amber fill) — the one action a form wants you to take. */
    public SimpleButton primary() {
        this.primary = true;
        return this;
    }

    /** Destructive styling (fail-red fill) — for the confirm card's Delete. */
    public SimpleButton danger() {
        this.danger = true;
        return this;
    }

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        UiTheme t = UiTheme.current();
        int x = method_46426(), y = method_46427(), w = method_25368(), h = method_25364();
        boolean hovered = field_22763 && method_25367();

        int base = danger ? t.fail() : primary ? t.cta() : t.field();
        int fill = !field_22763 ? UiTheme.mix(base, t.ground(), 0.55f)
                : hovered ? UiTheme.mix(base, 0xFFFFFFFF, 0.18f)
                : base;
        int border = !field_22763 ? UiTheme.mix(t.border(), t.ground(), 0.45f) : t.border();
        RoundRect.card(g, x, y, x + w, y + h, 5, fill, border);

        // danger 的深红底上深棕字不可读——用 onBand 奶油浅色(五套预设的 fail 都是深红系)。
        int labelColor = !field_22763 ? UiTheme.mix(t.textDim(), t.ground(), 0.3f)
                : danger ? t.onBand()
                : primary ? t.onCta()
                : t.text();

        if (icon != null) {   // white template sprite, multiplied by the label colour
            int s = Math.min(w, h) >= 16 ? 11 : 9;
            g.method_51422(((labelColor >> 16) & 0xFF) / 255f, ((labelColor >> 8) & 0xFF) / 255f,
                    (labelColor & 0xFF) / 255f, 1f);
            g.method_52706(icon, x + (w - s) / 2, y + (h - s) / 2, s, s);
            g.method_51422(1f, 1f, 1f, 1f);
            return;
        }

        class_327 font = class_310.method_1551().field_1772;
        int tw = font.method_27525(method_25369());
        Nb.text(g, font, method_25369(), x + (w - tw) / 2, y + (h - 8) / 2, labelColor);   // flat, coloured
    }
}
