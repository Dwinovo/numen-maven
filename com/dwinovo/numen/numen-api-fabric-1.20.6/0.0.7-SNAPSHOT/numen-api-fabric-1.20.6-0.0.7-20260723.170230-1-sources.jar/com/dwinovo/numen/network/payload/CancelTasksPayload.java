package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.NumenPlayer;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Client-to-server payload: "the owner pressed Stop — cancel everything my
 * entity is doing". Sent by {@code EntityAgentLoop.abort()} alongside the
 * client-side turn teardown, so the interrupt stops the <em>body</em> (the
 * running task: walking, mining, placing), not just the model conversation.
 *
 * <h2>Trust model</h2>
 * Owner check only — no distance check, deliberately: the owner must be able
 * to stop a companion that has wandered far away. Cancelling is the one action
 * that is always safe to allow from anywhere.
 *
 * <p>The server-side {@code CANCELLED} results this produces are shipped back
 * via {@link TaskResultPayload} as usual; the client agent loop has already
 * synthesized "interrupted by owner" results for those tool-call ids and drops
 * the real ones as late arrivals. This payload's job is purely the body stop.
 */
public record CancelTasksPayload(UUID entityUuid) implements class_8710 {

    public static final class_9154<CancelTasksPayload> TYPE = new class_9154<>(
            new class_2960(Constants.MOD_ID, "cancel_tasks"));

    public static final class_9139<class_9129, CancelTasksPayload> STREAM_CODEC =
            class_9139.method_56434(
                    class_4844.field_48453, CancelTasksPayload::entityUuid,
                    CancelTasksPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Handler invoked on the server main thread. */
    public static void handle(CancelTasksPayload p, class_3222 player) {
        // Cross-dimension lookup: the owner must be able to stop a companion
        // that has wandered into another dimension or out of view distance.
        NumenPlayer numen = NumenPlayer.findByUuid(player.method_37908().method_8503(), p.entityUuid());
        if (numen == null) {
            Constants.LOG.debug("[numen-net] cancel_tasks for unknown entity {}", p.entityUuid());
            return;
        }
        if (!numen.isOwnedByPlayer(player.method_5667())) {
            Constants.LOG.warn("[numen-net] ✗ cancel_tasks rejected from {}: not the owner",
                    player.method_5477().getString());
            return;
        }
        com.dwinovo.numen.task.CompanionTickDispatcher.cancelFor(numen);
        Constants.LOG.info("[numen-net] ✓ cancel_tasks on entity {} for {}",
                p.entityUuid(), player.method_5477().getString());
    }
}
