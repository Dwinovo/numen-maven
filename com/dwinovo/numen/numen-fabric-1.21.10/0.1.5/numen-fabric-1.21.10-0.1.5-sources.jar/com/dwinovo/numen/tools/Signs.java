package com.dwinovo.numen.tools;

import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.sdk.Call;
import com.dwinovo.numen.api.sdk.Doc;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2625;
import net.minecraft.class_8242;

/** 告示牌上的字:{@code numen.scan.block} 读出来、{@code numen.use.sign} 写完读回来用的是同一份读法。 */
public final class Signs {

    private Signs() {}

    /** 一块告示牌的字。 */
    @Doc("The text on a sign.")
    public record Text(@Doc("The four front lines, top to bottom.") List<String> front,
                       @Doc("The four back lines.") List<String> back,
                       @Doc("Waxed: its text can no longer be edited.") boolean waxed) {}

    /** 这一格的告示牌;不是告示牌当场说,并指怎么找。 */
    public static class_2625 at(NumenPlayer her, class_2338 pos) {
        if (her.method_51469().method_8321(pos) instanceof class_2625 sign) {
            return sign;
        }
        throw new ApiError(ErrorKind.NOT_FOUND, "there is no sign at " + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260(),
                Call.of("numen.scan.blocks", "#minecraft:all_signs"));
    }

    public static Text read(class_2625 sign) {
        return new Text(lines(sign.method_49853()), lines(sign.method_49854()), sign.method_49855());
    }

    /** 一面的四行字。 */
    public static List<String> lines(class_8242 text) {
        List<String> out = new ArrayList<>();
        for (class_2561 line : text.method_49877(false)) {
            out.add(line.getString());
        }
        return out;
    }
}
