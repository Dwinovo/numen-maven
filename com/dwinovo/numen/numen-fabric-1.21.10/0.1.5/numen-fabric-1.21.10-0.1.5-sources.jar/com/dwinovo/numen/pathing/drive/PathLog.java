package com.dwinovo.numen.pathing.drive;

import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2259;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_7923;
import com.dwinovo.numen.api.entity.Controls;
import com.dwinovo.numen.api.entity.Mouse;
import com.dwinovo.numen.pathing.plan.Edit;
import com.dwinovo.numen.pathing.plan.Maneuver;
import com.dwinovo.numen.pathing.plan.MoveKind;
import com.dwinovo.numen.pathing.search.Pending;
import com.dwinovo.numen.pathing.search.Route;
import com.dwinovo.numen.pathing.search.SearchResult;
import com.dwinovo.numen.pathing.search.Searches;
import com.dwinovo.numen.pathing.spec.RouteSpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 寻路的日志:一行一件事,前缀 {@code [numen-path]},接着是谁(身体名加 UUID 前六位),再是事件与事实——坐标、方块 id(带状态)、
 * 数字都写齐。直接写进 slf4j 的 {@code NumenPathing} 这一个记录器,开多少由宿主的日志配置定:
 * <ul>
 *   <li>INFO——结局与被叫停、每一次搜索与规划的结论、重搜、一步走不下去、卡住、计划内的坠落与落地、倒水接坠落与收水、
 *       动手被拒、下载具、不在推进;</li>
 *   <li>DEBUG——出发、派搜索、路线上的每一步、每一步开始、每一下成功的挖与放与开关门、换目标、暂停、身体换手上的东西;</li>
 *   <li>WARN——主线程上寻路一刻用的时间超过 {@link #MAIN_THREAD_WARN_NANOS}。</li>
 * </ul>
 * 事件只在发生时记一次,不逐刻刷。
 *
 * <p>没有做成宿主实现的端口:宿主对日志的要求只是"进服务器日志、能按级别与记录器开关",slf4j 加宿主自己的日志配置
 * 本来就是这个出口,原版与加载器都经它记;端口只会让每个宿主(连同 GameTest 的假玩家夹具)多写一份转发。
 */
public final class PathLog {

    private static final Logger LOG = LoggerFactory.getLogger("NumenPathing");
    private static final String PREFIX = "[numen-path] ";

    /**
     * 主线程上一次导航一刻里寻路做的活(拷快照、组成本模型、复核前提、按键与转头)超过这么多纳秒,就记 WARN。
     * 依据:原版每刻 50 毫秒,这是它的十分之一,一刻里别的实体与区块还要用剩下的;实测拷一次快照 0.1–1 毫秒,复核一步只判
     * 一次前提(搜索展开一个节点要判二十来次、共几到二十来微秒,docs/adr/pathing/0019-lookup-table-nodes.md),平常远在它之下。按墙钟计,不随 {@code /tick rate} 变:刻速调高时一刻的预算变小,
     * 服务器跟不上是刻速的事;这里只标出寻路自己在主线程上做了重活的那几刻。
     */
    static final long MAIN_THREAD_WARN_NANOS = 5_000_000L;

    private PathLog() {}

    public static void info(String format, Object... args) {
        LOG.info(PREFIX + format, args);
    }

    public static void debug(String format, Object... args) {
        if (LOG.isDebugEnabled()) {
            LOG.debug(PREFIX + format, args);
        }
    }

    public static void warn(String format, Object... args) {
        LOG.warn(PREFIX + format, args);
    }

    /** DEBUG 开着:拼一行要花点工夫的(整条路线)先问它。 */
    public static boolean debugging() {
        return LOG.isDebugEnabled();
    }

    /** 主线程上一次做完的寻路活 {@code what} 用了 {@code nanos}:超过 {@link #MAIN_THREAD_WARN_NANOS} 记 WARN。 */
    public static void mainThread(String who, String what, long nanos) {
        if (nanos > MAIN_THREAD_WARN_NANOS) {
            warn("{} 主线程上{}用了 {}(阈值 {})", who, what, ms(nanos), ms(MAIN_THREAD_WARN_NANOS));
        }
    }

    // ==================== 事实的写法 ====================

    /** 谁:身体名,加 UUID 前六位(同名的身体分得开)。 */
    public static String who(class_3222 body) {
        return body.method_5820() + "#" + body.method_5845().substring(0, 6);
    }

    /** 一格:{@code x,y,z}。 */
    public static String pos(class_2338 pos) {
        return pos == null ? "-" : pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
    }

    /** 身体的精确位置,两位小数。 */
    public static String at(class_243 v) {
        return String.format(Locale.ROOT, "%.2f,%.2f,%.2f", v.field_1352, v.field_1351, v.field_1350);
    }

    /** 方块:注册名,有状态时连同状态,与 {@code /setblock} 的写法相同。 */
    public static String block(class_2680 state) {
        return class_2259.method_9685(state);
    }

    /** 纳秒写成毫秒,一位小数。 */
    public static String ms(long nanos) {
        return String.format(Locale.ROOT, "%.1fms", nanos / 1.0e6);
    }

    /**
     * 一次搜索慢在哪的几个读数,分得清是谁:线程 CPU 时间与墙钟之比(远小于 100% 是抢 CPU 或等锁)、跑的期间 JIT 编译与回收停顿的毫秒
     * (JIT 大是冷启动)、每节点微秒;两者都正常而每节点仍慢,是地形或实现。池线程数与机器核数一并写出。
     */
    public static String load(Pending<?> done, int expanded) {
        String cpu = done.cpuNanos() < 0 ? "不可用"
                : String.format(Locale.ROOT, "%.0f%%", 100.0 * done.cpuNanos() / Math.max(1, done.ranNanos()));
        String jit = done.jitMillis() < 0 ? "不可用" : "+" + done.jitMillis() + "ms";
        String perNode = expanded <= 0 ? "-" : String.format(Locale.ROOT, "%.0fμs", done.ranNanos() / 1.0e3 / expanded);
        return String.format(Locale.ROOT, "CPU/墙钟 %s JIT %s GC +%dms 每节点 %s 池 %d 线程/%d 核", cpu, jit, done.gcMillis(), perNode,
                Searches.poolSize(), Runtime.getRuntime().availableProcessors());
    }

    /** 纳秒写成秒,一位小数。 */
    public static String seconds(long nanos) {
        return String.format(Locale.ROOT, "%.1fs", nanos / 1.0e9);
    }

    /** 一个数,一位小数。 */
    public static String num(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    /** 规格的要点:挖不挖、放不放、要问的格算不算能走,与出厂值不同的上限与开关。 */
    public static String spec(RouteSpec spec) {
        StringBuilder out = new StringBuilder("dig=").append(spec.dig()).append(" place=").append(spec.place())
                .append(" consent=").append(spec.consent() ? num(spec.consentMultiplier()) : "false");
        out.append(" maxFallDamage=").append(spec.maxFallDamage());
        if (spec.budgeted()) {
            out.append(" alterBudget=").append(spec.alterBudget());
        }
        if (spec.parkour()) {
            out.append(" parkour");
        }
        return out.toString();
    }

    /** 一条路线的要点:几步、各种走法几步、总代价、改几格、起终点,有水下的加上几段、最长憋几刻、最少还剩几刻。 */
    public static String route(Route route) {
        String dives = "";
        double held = 0;
        double left = Double.POSITIVE_INFINITY;
        List<Route.Dive> under = route.dives();
        for (Route.Dive dive : under) {
            held = Math.max(held, dive.held());
            left = Math.min(left, dive.left());
        }
        if (!under.isEmpty()) {
            dives = " 水下 " + under.size() + " 段 最长憋 " + num(held) + " 刻 最少还剩 " + num(left) + " 刻";
        }
        return steps(route) + dives;
    }

    private static String steps(Route route) {
        Map<MoveKind, Integer> kinds = new EnumMap<>(MoveKind.class);
        for (Route.Leg leg : route.legs()) {
            kinds.merge(leg.maneuver().kind(), 1, Integer::sum);
        }
        StringBuilder out = new StringBuilder().append(route.legs().size()).append(" 步 [");
        boolean first = true;
        for (Map.Entry<MoveKind, Integer> e : kinds.entrySet()) {
            out.append(first ? "" : " ").append(e.getKey()).append('×').append(e.getValue());
            first = false;
        }
        return out.append("] 代价 ").append(num(route.cost())).append(" 改 ").append(route.alterations())
                .append(" 格 ").append(pos(route.start())).append("→").append(pos(route.end())).toString();
    }

    /** 路线上的每一步:走法与落点,排障时还原她走的是哪条路。 */
    public static String legs(Route route) {
        StringBuilder out = new StringBuilder(pos(route.start()));
        for (Route.Leg leg : route.legs()) {
            Maneuver m = leg.maneuver();
            out.append(' ').append(m.kind()).append('>').append(pos(m.to()));
        }
        return out.toString();
    }

    /** 一步:走法、起落点。 */
    public static String step(Maneuver m) {
        return m.kind() + " " + pos(m.from()) + "→" + pos(m.to());
    }

    /** 搜索里离目标最近的节点上朝目标的一步被拒:哪种走法、从哪个节点、卡在哪一格、哪条前提。 */
    public static String blocking(SearchResult.Blocking b) {
        return b.move() + " 从 " + pos(b.from()) + " 卡在 " + pos(b.fails().cell()) + " 前提=" + b.fails().reason();
    }

    /** 一步走不下去:哪种走法、哪一格、什么方块、哪条前提或执行里出的事。 */
    public static String blockage(Blockage b) {
        return b.move() + " 卡在 " + pos(b.cell()) + " " + block(b.block()) + " "
                + (b.reason() != null ? "前提=" + b.reason() : "执行=" + b.hitch());
    }

    /** 一趟里按原因分的重规划次数,如 "往前核不成立 2 一步超时 1";一次也没有为 "-"。 */
    public static String replans(Journal journal) {
        StringBuilder out = new StringBuilder();
        journal.replans().forEach((why, n) -> out.append(out.isEmpty() ? "" : " ").append(why.label).append(' ').append(n));
        return out.isEmpty() ? "-" : out.toString();
    }

    /** 身体此刻的状态:精确位置、在地上还是空中、泡没泡水、眼睛在不在水里、氧气、血量。 */
    public static String body(class_3222 body) {
        return "身体 " + at(body.method_73189()) + (body.method_24828() ? " 地上" : " 空中") + (body.method_5799() ? " 水里" : "")
                + (body.method_5777(net.minecraft.class_3486.field_15517) ? " 眼在水里" : "")
                + " 氧气 " + body.method_5669() + "/" + body.method_5748() + " 血 " + num(body.method_6032());
    }

    /**
     * 身体的手此刻的样子:按着的键、主手拿的、准星落着的东西、鼠标正在挖哪一格与进度、控制器正在做哪件改动
     * ({@code working},没有为 null)。"不在推进"时她手上在干什么,看这一段。
     */
    public static String hands(class_3222 body, Controls keys, Mouse mouse, Edit working) {
        StringBuilder pressed = new StringBuilder();
        for (Controls.Key key : Controls.Key.values()) {
            if (keys.held(key)) {
                pressed.append(pressed.isEmpty() ? "" : "+").append(key);
            }
        }
        class_2338 digging = mouse.pressing();
        return "按键 " + (pressed.isEmpty() ? "-" : pressed) + " 主手 " + stack(body.method_6047()) + " 准星 " + crosshair(body, mouse.pick())
                + " 鼠标 " + (digging == null ? "没在挖" : "挖 " + pos(digging) + " 进度 " + num(mouse.progress()))
                + " 在做 " + (working == null ? "-" : edit(working));
    }

    private static String stack(class_1799 stack) {
        return stack.method_7960() ? "空手" : class_7923.field_41178.method_10221(stack.method_7909()) + "×" + stack.method_7947();
    }

    private static String crosshair(class_3222 body, class_239 hit) {
        return switch (hit) {
            case class_3965 block when block.method_17783() == class_239.class_240.field_1332 -> "方块 " + pos(block.method_17777()) + " "
                    + block(body.method_51469().method_8320(block.method_17777())) + " 面 " + block.method_17780();
            case class_3966 entity -> "实体 " + class_7923.field_41177.method_10221(entity.method_17782().method_5864());
            default -> "空";
        };
    }

    /** 一件改动:做什么、哪一格、原来是什么。 */
    private static String edit(Edit edit) {
        return switch (edit) {
            case Edit.Dig dig -> "挖 " + pos(dig.pos()) + " " + block(dig.state());
            case Edit.Place place -> "放 " + pos(place.pos()) + " " + class_7923.field_41175.method_10221(place.block());
            case Edit.Door door -> "开关 " + pos(door.pos()) + " " + block(door.state());
            case Edit.Catch caught -> "倒水 " + pos(caught.pos());
        };
    }
}
