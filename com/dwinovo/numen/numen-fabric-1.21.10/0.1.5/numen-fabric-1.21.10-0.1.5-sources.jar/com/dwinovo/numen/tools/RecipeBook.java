package com.dwinovo.numen.tools;

import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.knowledge.RecipePage;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.BiPredicate;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1874;
import net.minecraft.class_3218;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_3975;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8059;
import net.minecraft.class_8786;

/**
 * 配方书:原版配方表里每一种配方类型的配方,像 JEI 的一页({@code numen.inv.recipes}、{@code numen.inv.uses})。读法只靠原版的
 * {@link class_1860} 接口,所以任何模组的配方类型都读得到:认识的几种(合成、烧炼、切石、锻造)有完整描述,其余给出类型、输入与产物。
 * 合成配方的事实(装得下的最小的格、照她背着的还缺什么)与合成时查的同一处读({@link CraftOps})。
 */
public final class RecipeBook {

    /** 一次交回的配方条数上限:答复要装进脚本与大模型的上下文;超出的条数在 {@link RecipePage#omitted} 里如实说。 */
    public static final int MAX_RECIPES = 40;

    /** "any[...]" 一类料最多把几种东西列出来,其余记一个数。 */
    private static final int MAX_LISTED_ITEMS = 8;

    private RecipeBook() {}

    /** 做这样东西的每一条配方,每个类别;找不到就是空表(它靠挖或交易得来,不是做出来的)。 */
    public static RecipePage recipesFor(class_1792 target, NumenPlayer self) {
        return collect(self, (recipe, result) -> result.method_7909() == target);
    }

    /** 拿这样东西当输入的每一条配方:标签展开后的输入里有它(锻造看三个槽认不认它)。 */
    public static RecipePage usesOf(class_1792 input, NumenPlayer self) {
        class_1799 probe = new class_1799(input);
        return collect(self, (recipe, result) -> takes(recipe, probe));
    }

    /**
     * 配方类型的名字,即 {@link com.dwinovo.numen.api.knowledge.Recipe#category}:登记了的是它在注册表里的名字;模组也可以不登记
     * (比如用 {@code RecipeType.simple} 造出、没进注册表),那就是类型自己报的名字,{@code simple} 造的类型报的就是它的 id。
     */
    public static String categoryOf(class_1860<?> recipe) {
        net.minecraft.class_2960 key = class_7923.field_41188.method_10221(recipe.method_17716());
        return key != null ? key.toString() : recipe.method_17716().toString();
    }

    /**
     * 在合成格里做的配方:类型是原版的合成。模组机器的配方也可以实现 {@code CraftingRecipe}(类型是它自己的),那不是在合成格里做的,
     * 照别的类型只给类型、输入与产物。配方书描述合成配方与 {@code numen.inv.craft} 认合成配方,都问这一处。
     */
    static boolean isCrafting(class_1860<?> recipe) {
        return recipe instanceof class_3955 && recipe.method_17716() == class_3956.field_17545;
    }

    static boolean takes(class_1860<?> recipe, class_1799 stack) {
        if (recipe instanceof class_8059 sm) {
            return sm.method_64722().map(i -> i.method_8093(stack)).orElse(false) || sm.method_64723().method_8093(stack) || sm.method_64724().map(i -> i.method_8093(stack)).orElse(false);
        }
        for (class_1856 ing : recipe.method_61671().method_64675()) {
            if (ing.method_8093(stack)) {
                return true;
            }
        }
        return false;
    }

    private static RecipePage collect(NumenPlayer self, BiPredicate<class_1860<?>, class_1799> wanted) {
        class_3218 level = self.method_51469();
        return collect(level.method_64577().method_8126(), level.method_30349(), wanted,
                (holder, recipe, result) -> CraftOps.recipe(holder, recipe, result, self));
    }

    /** 合成配方的那一行:装得下的格、还缺什么要看她背着什么,所以由调用方给。 */
    interface CraftingRow {
        com.dwinovo.numen.api.knowledge.Recipe of(class_8786<?> holder, class_3955 recipe, class_1799 result);
    }

    /** 从这些配方里挑出 {@code wanted} 要的,每条描述成一行;一条坏配方只丢它自己。 */
    static RecipePage collect(Iterable<? extends class_8786<?>> holders, class_7225.class_7874 registries,
                         BiPredicate<class_1860<?>, class_1799> wanted, CraftingRow crafting) {
        List<com.dwinovo.numen.api.knowledge.Recipe> described = new ArrayList<>();
        List<com.dwinovo.numen.api.knowledge.Recipe> skeletons = new ArrayList<>();
        for (class_8786<?> holder : holders) {
            // 每条配方自成一格:整合包里一条坏配方(产出为 null、输入表为 null)只丢它自己,绝不让它杀掉整个查询。见 RecipeProbe。
            try {
                class_1860<?> r = holder.comp_1933();
                class_1799 result = RecipeProbe.displayedResult(r, registries);
                // 合成里产出依赖输入的配方(烟花、镶零件的装备)静态描述答不了;锻造配方在原版里一律标 special,不是这个意思
                if ((isCrafting(r) && r.method_8118()) || result.method_7960()
                        || !RecipeProbe.usableIngredients(r) || !wanted.test(r, result)) {
                    continue;
                }
                if (r instanceof class_3955 cr && isCrafting(r)) {
                    // 不可摆放、输入清单为空的(产出依赖输入的特殊配方)静态描述答不了
                    if (cr.method_61671().method_61687() || cr.method_61671().method_64675().isEmpty()) {
                        continue;
                    }
                    described.add(crafting.of(holder, cr, result));
                } else if (r instanceof class_1874 cook) {
                    described.add(row(holder, r, result, List.of(describeIngredient(cook.method_64720())),
                            Optional.of(cook.method_8167())));
                } else if (r instanceof class_3975 sc) {
                    described.add(row(holder, r, result, List.of(describeIngredient(sc.method_64720())),
                            Optional.empty()));
                } else if (r instanceof class_8059) {
                    described.add(row(holder, r, result, List.of(), Optional.empty()));
                } else {
                    skeletons.add(row(holder, r, result, r.method_61671().method_64675().stream()
                            .map(RecipeBook::describeIngredient).toList(), Optional.empty()));
                }
            } catch (RuntimeException broken) {
                com.dwinovo.numen.Constants.LOG.debug(
                        "[numen-recipe] 配方 {} 坏了,跳过: {}", holder.comp_1932(), broken.toString());
            }
        }
        described.addAll(skeletons);
        int omitted = Math.max(0, described.size() - MAX_RECIPES);
        return new RecipePage(described.subList(0, described.size() - omitted),
                omitted == 0 ? Optional.empty() : Optional.of(omitted));
    }

    /** 不在合成格里做的一条配方(合成配方的那一行由 {@link CraftOps#recipe} 出)。 */
    private static com.dwinovo.numen.api.knowledge.Recipe row(class_8786<?> holder, class_1860<?> recipe, class_1799 result,
                                                          List<String> ingredients, Optional<Integer> ticks) {
        return new com.dwinovo.numen.api.knowledge.Recipe(Optional.of(holder.comp_1932().method_29177().toString()), categoryOf(recipe),
                Optional.empty(), class_7923.field_41178.method_10221(result.method_7909()).toString(), result.method_7947(),
                List.of(), ingredients, List.of(), Optional.empty(), Optional.empty(), ticks, List.of());
    }

    /**
     * 一样料的叫法:单一物品就是它;一类有共同后缀的写成 {@code planks(any)};不然把每一种都列出来(超过 {@link #MAX_LISTED_ITEMS}
     * 种只列前几种、记下还有几种)——免得一类料把模型引到某一种具体的东西上。合成缺料时说缺什么用的是同一套叫法。
     */
    static String describeIngredient(class_1856 ing) {
        List<String> paths = ing.method_8105()   // 1.21.2+: Stream<Holder<Item>>
                .map(h -> class_7923.field_41178.method_10221(h.comp_349()).method_12832())
                .distinct()
                .toList();
        if (paths.isEmpty()) {
            return "?";
        }
        if (paths.size() == 1) {
            return paths.get(0);
        }
        String suffix = commonSuffixToken(paths);
        if (suffix != null) {
            return suffix + "(any)";
        }
        if (paths.size() > MAX_LISTED_ITEMS) {
            return "any[" + String.join("/", paths.subList(0, MAX_LISTED_ITEMS)) + "/+"
                    + (paths.size() - MAX_LISTED_ITEMS) + " more]";
        }
        return "any[" + String.join("/", paths) + "]";
    }

    private static String commonSuffixToken(List<String> paths) {
        String token = null;
        for (String p : paths) {
            int u = p.lastIndexOf('_');
            String t = u < 0 ? p : p.substring(u + 1);
            if (token == null) {
                token = t;
            } else if (!token.equals(t)) {
                return null;
            }
        }
        return token;
    }
}
