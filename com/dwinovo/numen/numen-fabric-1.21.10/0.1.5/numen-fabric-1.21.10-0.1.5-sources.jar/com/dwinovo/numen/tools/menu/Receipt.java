package com.dwinovo.numen.tools.menu;

import com.dwinovo.numen.api.entity.BodyDelta;
import com.dwinovo.numen.api.entity.NumenPlayer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

/**
 * 在开着的界面里做一件事前后,她身上和界面里变了什么:背包与经验、血量({@link BodyDelta},点一下、挖、打的回执用的是同一份)和界面
 * 自己那一边的格子(附魔台里的剑上了附魔、青金石少了几块、铁砧的结果格换了名字——这些不在她的背包里,{@link BodyDelta} 看不到)。
 * 只报事实,不下结论:成没成由各界面读回来的结果说。
 */
final class Receipt {

    private final BodyDelta body;
    private final class_1703 menu;
    private final List<String> slots;

    private Receipt(NumenPlayer her) {
        this.body = BodyDelta.open(her);
        this.menu = her.field_7512;
        this.slots = windowSlots(her);
    }

    /** 此刻拍一张。 */
    static Receipt open(NumenPlayer her) {
        return new Receipt(her);
    }

    /** 从拍照到现在,每一条是一件真发生的事;都没变是空表。 */
    List<String> changes(NumenPlayer her) {
        List<String> facts = new ArrayList<>(body.changes(her));
        if (her.field_7512 == menu) {
            List<String> now = windowSlots(her);
            for (int i = 0; i < slots.size(); i++) {
                if (!slots.get(i).equals(now.get(i))) {
                    facts.add("window slot " + i + ": " + slots.get(i) + " -> " + now.get(i));
                }
            }
        }
        return facts;
    }

    /** 界面里不属于她背包的每一格,写成一行。 */
    private static List<String> windowSlots(NumenPlayer her) {
        List<String> out = new ArrayList<>();
        for (class_1735 slot : her.field_7512.field_7761) {
            out.add(slot.field_7871 == her.method_31548() ? "" : stack(slot.method_7677()));
        }
        return out;
    }

    /** 一叠东西写成一行:{@code minecraft:diamond_sword (named X; sharpness 2)};空的是 {@code empty}。 */
    static String stack(class_1799 stack) {
        if (stack.method_7960()) {
            return "empty";
        }
        List<String> details = new ArrayList<>();
        if (stack.method_57826(class_9334.field_49631)) {
            details.add("named " + stack.method_7964().getString());
        }
        enchantments(stack.method_58694(class_9334.field_49633), details);
        enchantments(stack.method_58694(class_9334.field_49643), details);
        return class_7923.field_41178.method_10221(stack.method_7909()) + (stack.method_7947() > 1 ? " x" + stack.method_7947() : "")
                + (details.isEmpty() ? "" : " (" + String.join("; ", details) + ")");
    }

    private static void enchantments(class_9304 enchantments, List<String> into) {
        if (enchantments == null) {
            return;
        }
        for (class_6880<class_1887> each : enchantments.method_57534()) {
            into.add(each.method_40230().map(key -> key.method_29177().method_12832()).orElse("?") + " " + enchantments.method_57536(each));
        }
    }
}
