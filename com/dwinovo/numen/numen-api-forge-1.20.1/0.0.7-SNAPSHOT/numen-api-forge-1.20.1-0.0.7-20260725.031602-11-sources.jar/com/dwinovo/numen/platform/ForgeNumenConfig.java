package com.dwinovo.numen.platform;

import com.dwinovo.numen.platform.services.INumenConfig;
import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Forge implementation of {@link INumenConfig}. Backed by a
 * {@link ForgeConfigSpec} that Forge serialises as TOML under
 * {@code <gameDir>/config/numen-common.toml}. Editable in-game via Forge's
 * built-in config screen (Mods → Numen → Config).
 *
 * <h2>Registration timing</h2>
 * The static {@link #SPEC} is constructed during class load (just data — no
 * I/O), so it's safe to reference from the Mod constructor. {@code NumenMod}
 * registers the spec via {@code ModLoadingContext.registerConfig(...)}; Forge
 * loads / writes the TOML when the world loads.
 *
 * <p>This is a straight port of the NeoForge {@code ModConfigSpec} variant —
 * Forge's {@code ForgeConfigSpec} exposes the identical builder API, only the
 * class name differs.
 */
public final class ForgeNumenConfig implements INumenConfig {

    public static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> BASE_URL;
    public static final ForgeConfigSpec.ConfigValue<String> MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> PROVIDER;
    public static final ForgeConfigSpec.ConfigValue<String> PROXY;
    public static final ForgeConfigSpec.ConfigValue<String> REASONING_EFFORT;
    public static final ForgeConfigSpec.ConfigValue<String> SYSTEM_PROMPT;
    public static final ForgeConfigSpec.ConfigValue<String> STT_PROVIDER;
    public static final ForgeConfigSpec.ConfigValue<String> STT_API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> STT_BASE_URL;
    public static final ForgeConfigSpec.ConfigValue<String> STT_MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> STT_MICROPHONE;
    public static final ForgeConfigSpec SPEC;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("OpenAI / OpenAI-compatible API settings.").push("openai");

        API_KEY = b.comment("API key (sk-...) sent as the bearer token. Required.")
                .define("api_key", "");
        BASE_URL = b.comment("Base URL override. Leave empty for OpenAI's default endpoint.",
                "Examples: https://api.deepseek.com, http://localhost:11434 (Ollama)")
                .define("base_url", "");
        MODEL = b.comment("Model id sent as the `model` field. Backend-defined.")
                .define("model", "gpt-5-2-mini");
        PROVIDER = b.comment("Wire-format adapter AND default base URL selector.",
                "openai      → api.openai.com/v1 (default; also generic OpenAI-compat fallback)",
                "deepseek    → api.deepseek.com/beta (preserves reasoning_content for V4 thinking)",
                "moonshot    → api.moonshot.ai/v1 (Kimi; fill_reasoning_content safety net)",
                "  (alias: kimi)",
                "minimax     → api.minimax.io/v1",
                "volcengine  → ark.cn-beijing.volces.com/api/v3 (Doubao)",
                "  (aliases: doubao, ark)",
                "dashscope   → dashscope.aliyuncs.com/compatible-mode/v1 (Alibaba Qwen / Tongyi)",
                "  (aliases: qwen, tongyi, aliyun)",
                "Override 'base_url' below to use a different host (proxy / region split).")
                .define("provider", "openai");
        PROXY = b.comment("Optional HTTP proxy for LLM calls as host:port (empty = direct).")
                .define("proxy", "");
        REASONING_EFFORT = b.comment(
                "Reasoning / deep-thinking effort for reasoning-capable models.",
                "auto (default; send nothing, let the backend decide) | low | medium | high.",
                "When not 'auto', the OpenAI-dialect 'reasoning_effort' request parameter is sent.")
                .define("reasoning_effort", "auto");

        b.pop();
        b.comment("Behaviour tuning.").push("agent");
        // Deliberately short. The planning behaviour (use todowrite for
        // multi-step tasks, load_skill to fetch detailed workflows) emerges
        // entirely from those tools' own descriptions plus the runtime-injected
        // <available_skills> XML block — adding rules here just dilutes
        // attention. Mirrors opencode's default.txt minimalist style.
        SYSTEM_PROMPT = b.comment("System prompt prepended to every conversation.")
                .define("system_prompt",
                        "You are Numen, a Minecraft entity controlled by the player who owns you.\n"
                                + "Use the tools provided to act in the world; output text only to talk to your owner.");
        b.pop();

        b.comment("Voice input (STT) — global, one microphone / one transcription service.").push("stt");
        STT_PROVIDER = b.comment("Provider preset (whisper-http adapter).",
                "siliconflow | openai | groq | custom (fill base_url + model yourself)")
                .define("provider", "siliconflow");
        STT_API_KEY = b.comment("Voice-input service API key (bearer). Empty = voice input off.")
                .define("api_key", "");
        STT_BASE_URL = b.comment("Base URL override. Empty = provider preset default.")
                .define("base_url", "");
        STT_MODEL = b.comment("Transcription model id (e.g. whisper-1, FunAudioLLM/SenseVoiceSmall).")
                .define("model", "FunAudioLLM/SenseVoiceSmall");
        STT_MICROPHONE = b.comment("Input device name; empty = first available microphone.")
                .define("microphone", "");
        b.pop();

        SPEC = b.build();
    }

    /** Default constructor used by {@code ServiceLoader}. */
    public ForgeNumenConfig() {}

    @Override
    public String getApiKey() {
        return safe(API_KEY);
    }

    @Override
    public String getBaseUrl() {
        return safe(BASE_URL);
    }

    @Override
    public String getModel() {
        return safe(MODEL);
    }

    @Override
    public String getSystemPrompt() {
        return safe(SYSTEM_PROMPT);
    }

    @Override
    public String getProvider() {
        String s = safe(PROVIDER);
        return s.isEmpty() ? "openai" : s;
    }

    @Override
    public String getProxy() {
        return safe(PROXY);
    }

    @Override
    public String getReasoningEffort() {
        String s = safe(REASONING_EFFORT);
        return s.isEmpty() ? "auto" : s;
    }

    @Override
    public String getSttProvider() {
        String s = safe(STT_PROVIDER);
        return s.isEmpty() ? "siliconflow" : s;
    }

    @Override
    public String getSttApiKey() {
        return safe(STT_API_KEY);
    }

    @Override
    public String getSttBaseUrl() {
        return safe(STT_BASE_URL);
    }

    @Override
    public String getSttModel() {
        return safe(STT_MODEL);
    }

    @Override
    public String getSttMicrophone() {
        return safe(STT_MICROPHONE);
    }

    // ---- mutations ----

    @Override
    public void setApiKey(String value) {
        API_KEY.set(value == null ? "" : value);
    }

    @Override
    public void setBaseUrl(String value) {
        BASE_URL.set(value == null ? "" : value);
    }

    @Override
    public void setModel(String value) {
        MODEL.set(value == null ? "" : value);
    }

    @Override
    public void setProvider(String value) {
        PROVIDER.set(value == null ? "openai" : value);
    }

    @Override
    public void setProxy(String value) {
        PROXY.set(value == null ? "" : value);
    }

    @Override
    public void setReasoningEffort(String value) {
        REASONING_EFFORT.set(value == null ? "auto" : value);
    }

    @Override
    public void setSystemPrompt(String value) {
        SYSTEM_PROMPT.set(value == null ? "" : value);
    }

    @Override
    public void setSttProvider(String value) {
        STT_PROVIDER.set(value == null || value.isBlank() ? "siliconflow" : value);
    }

    @Override
    public void setSttApiKey(String value) {
        STT_API_KEY.set(value == null ? "" : value);
    }

    @Override
    public void setSttBaseUrl(String value) {
        STT_BASE_URL.set(value == null ? "" : value);
    }

    @Override
    public void setSttModel(String value) {
        STT_MODEL.set(value == null ? "" : value);
    }

    @Override
    public void setSttMicrophone(String value) {
        STT_MICROPHONE.set(value == null ? "" : value);
    }

    /**
     * Flush the in-memory config to disk. The setters above only mutate the
     * loaded NightConfig in memory — {@link ForgeConfigSpec.ConfigValue#set}'s
     * own javadoc states it does NOT write to disk; call
     * {@link ForgeConfigSpec#save()} eventually. Without this explicit save an
     * in-game settings change is lost on shutdown.
     *
     * <p>Guarded by {@link ForgeConfigSpec#isLoaded()}: {@code save()} throws if
     * the spec hasn't been bound to a config file yet.
     */
    @Override
    public void save() {
        if (SPEC.isLoaded()) {
            SPEC.save();
        }
        com.dwinovo.numen.Constants.LOG.info(
                "[numen-config] saved (api_key length={}, provider={}, model={})",
                safe(API_KEY).length(), safe(PROVIDER), safe(MODEL));
    }

    /**
     * Guard against the (rare) corner case where a config value is read before
     * the spec is fully bound — returns the empty string instead of letting an
     * exception escape into the LLM call site.
     */
    private static String safe(ForgeConfigSpec.ConfigValue<String> v) {
        try {
            String s = v.get();
            return s == null ? "" : s;
        } catch (IllegalStateException ex) {
            return "";
        }
    }
}
