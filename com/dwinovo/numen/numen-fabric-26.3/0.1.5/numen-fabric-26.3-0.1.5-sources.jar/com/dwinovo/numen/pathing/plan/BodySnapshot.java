package com.dwinovo.numen.pathing.plan;

import java.util.List;
import java.util.Objects;

import com.dwinovo.numen.api.entity.DigTime;
import com.dwinovo.numen.pathing.world.BodyStats;

import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.HayBlock;
import net.minecraft.world.level.block.HoneyBlock;
import net.minecraft.world.level.block.PointedDripstoneBlock;
import net.minecraft.world.level.block.PowderSnowBlock;
import net.minecraft.world.level.block.SlimeBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SpeleothemThickness;

/**
 * 身体快照:规划要知道的身体的一切,由宿主在派发那一刻从真实的身体上抄下来。规划与执行复核读同一份形状,搜索线程只读。
 *
 * <p>摔掉几点血、摔落上限、能不能疾跑、能不能动方块这几条规则只写在这里,规格只能在其上收紧;憋气的本钱与规则在
 * {@link Breath}。
 *
 * @param stats                   第 0 层用的物理量(尺寸、迈步、起跳、交互距离、细雪托不托得住)
 * @param gameMode                游戏模式:创造模式瞬间挖掉、不摔伤;冒险与旁观模式动不了方块
 * @param health                  当前血量
 * @param safeFallDistance        属性 {@code safe_fall_distance}:摔这么高以内不掉血(原版 3)
 * @param fallDamageMultiplier    属性 {@code fall_damage_multiplier}(原版 1)
 * @param foodLevel               饱食度:原版高于 6 才能疾跑
 * @param waterMovementEfficiency 属性 {@code water_movement_efficiency}:0 是原版水里的步速,1 与陆上一样快
 * @param inventory               主背包 36 格的副本,下标就是槽位;挑工具看全背包
 * @param mining                  挖掘速度相关的属性与效果
 * @param breath                  氧气、水下呼吸附魔与效果、海龟壳:能憋多久
 * @param mobility                身上已有的移动方式:许不许飞、在不在飞、滑翔物、烟花
 */
public record BodySnapshot(BodyStats stats, GameType gameMode, float health, double safeFallDistance,
                           double fallDamageMultiplier, int foodLevel, double waterMovementEfficiency,
                           List<ItemStack> inventory, DigTime.Mining mining, Breath breath, Mobility mobility) {

    /** 摔完至少要留下的血量(三颗心):按血量推摔落上限时不把她摔到只剩一口气。 */
    static final float HEALTH_RESERVE = 6.0F;

    public BodySnapshot {
        Objects.requireNonNull(stats, "stats");
        Objects.requireNonNull(gameMode, "gameMode");
        Objects.requireNonNull(mining, "mining");
        Objects.requireNonNull(breath, "breath");
        Objects.requireNonNull(mobility, "mobility");
        inventory = inventory.stream().map(ItemStack::copy).toList();
    }

    /** 同一份快照,这一趟只走({@link Mobility#afoot}):走法集与起点都按没有飞行能力的身体算。 */
    public BodySnapshot afoot() {
        return new BodySnapshot(stats, gameMode, health, safeFallDistance, fallDamageMultiplier, foodLevel,
                waterMovementEfficiency, inventory, mining, breath, mobility.afoot());
    }

    public boolean creative() {
        return gameMode.isCreative();
    }

    /** 背包里有一桶水:摔不起的坠落可以倒水接住。 */
    public boolean carriesWaterBucket() {
        for (ItemStack stack : inventory) {
            if (stack.is(Items.WATER_BUCKET)) {
                return true;
            }
        }
        return false;
    }

    /** 能不能挖、能不能放:冒险与旁观模式不能(原版 {@code GameType.isBlockPlacingRestricted})。 */
    public boolean mayEdit() {
        return !gameMode.isBlockPlacingRestricted();
    }

    /** 能不能疾跑:饱食度高于 6,或能飞的创造模式(原版 {@code LocalPlayer.hasEnoughFoodToStartSprinting})。 */
    public boolean canSprint() {
        return foodLevel > 6 || creative();
    }

    /**
     * 从 {@code height} 格高处落到 {@code onto} 上掉几点血。全模块只在这里回答:坠落的定价与摔不摔得起都读它。
     *
     * <p>照原版:落地时原版对脚下那块调 {@code Block.fallOn},默认把落差按方块的 {@code fallDistanceReduction}(床、层架菌
     * 是 0.5,别的方块是 0)减掉再交给 {@code causeFallDamage}(倍率 1);下面几种方块覆写了它,改的是交过去的落差或倍率——
     * <ul>
     *   <li>朝上的滴水石锥尖({@code PointedDripstoneBlock}:{@code tip_direction=up} 且 {@code thickness=tip}):落差加 2、
     *       倍率 2,落差过 1 格就疼;锥身、朝下的锥与别的粗细按默认;</li>
     *   <li>干草块({@code HayBlock})、蜂蜜块({@code HoneyBlock}):倍率 0.2;</li>
     *   <li>黏液块({@code SlimeBlock}):不按潜行时倍率 0——寻路计划的落地都不按潜行;</li>
     *   <li>细雪({@code PowderSnowBlock}):不调 {@code causeFallDamage},不疼。只有细雪托得住的身体才落得到它上面。</li>
     * </ul>
     * 之后照原版 {@code LivingEntity.calculateFallDamage}:落差减去安全高度、乘以方块给的倍率(这两步按原版的 float 算)、
     * 再乘属性 {@code fall_damage_multiplier},向上取整;不到 1 点不掉血。创造模式不摔伤({@code Player.causeFallDamage}
     * 在能飞时直接返回)。护甲附魔与抗性效果的减伤不算。
     */
    public int fallDamage(double height, BlockState onto) {
        if (creative() || onto.getBlock() instanceof PowderSnowBlock) {
            return 0;
        }
        float distance = (float) height;
        float multiplier = 1.0F;
        switch (onto.getBlock()) {
            case PointedDripstoneBlock dripstone when onto.getValue(PointedDripstoneBlock.TIP_DIRECTION) == Direction.UP
                    && onto.getValue(PointedDripstoneBlock.THICKNESS) == SpeleothemThickness.TIP -> {
                distance += 2.0F;
                multiplier = 2.0F;
            }
            case HayBlock hay -> multiplier = 0.2F;
            case HoneyBlock honey -> multiplier = 0.2F;
            case SlimeBlock slime -> multiplier = 0.0F;
            default -> distance *= 1.0F - onto.getBlock().getFallDistanceReduction();
        }
        float over = distance - (float) safeFallDistance;
        return Math.max(0, Mth.ceil((double) (over * multiplier) * fallDamageMultiplier));
    }

    /**
     * 摔掉 {@code damage} 点血受不受得起:不疼的都行,疼的只到摔完还留 {@link #HEALTH_RESERVE} 点血为止。
     * 这是全模块唯一的摔落上限;路线规格愿意承受的摔伤只能比它更紧({@link CostModel#bearsFall})。
     */
    public boolean bears(int damage) {
        return damage <= 0 || health - damage >= HEALTH_RESERVE;
    }

    /**
     * 落在硬地(倍率 1 的方块)上,摔伤不超过 {@code accepted} 点、又受得起({@link #bears})的最大落差,由 {@link #fallDamage}
     * 的公式反推;不会摔伤的身体(创造模式、{@code fall_damage_multiplier} 为 0)不限,为正无穷。落点方块减轻摔伤的,落差还能更高,
     * 这里不管(估价把这样的落点另算)。
     */
    public double maxDrop(int accepted) {
        if (creative() || fallDamageMultiplier <= 0) {
            return Double.POSITIVE_INFINITY;
        }
        int damage = Math.max(0, Math.min(accepted, (int) Math.floor(health - HEALTH_RESERVE)));
        return safeFallDistance + damage / fallDamageMultiplier;
    }
}
