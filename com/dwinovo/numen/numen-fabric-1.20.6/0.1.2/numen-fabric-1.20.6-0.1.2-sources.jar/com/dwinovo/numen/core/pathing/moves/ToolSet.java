package com.dwinovo.numen.core.pathing.moves;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1294;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_6862;
import net.minecraft.class_9362;
import com.dwinovo.numen.core.pathing.settings.NavSettings;

/**
 * 快捷栏工具评估:对任意方块给出"最优工具挖掘速度"(1/挖掘tick数)
 * 与最优槽位。结果按 Block 缓存,一次成本计算全程复用。
 *
 * <p>线程模型:构造在主线程,构造时把快捷栏九格逐格 copy、当前选中
 * 槽位、药水修正与全部相关设置取样为 final 字段;此后所有查询只读
 * 快照,worker 线程可安全调用,不会活读玩家背包或全局设置。
 */
public class ToolSet {

    /** 每种方块 → 最优工具挖掘速度的缓存。 */
    private final Map<class_2248, Double> breakStrengthCache;

    /** 缓存缺失时的计算函数(构造时折入药水修正,避免逐次判断)。 */
    private final Function<class_2248, Double> backendCalculation;

    /** 构造时逐格 copy 的快捷栏九格。 */
    private final class_1799[] hotbar;

    /** 构造时的手持槽位(autoTool 关闭的成本口径用)。 */
    private final int selectedSlot;

    /** true 时功能方块保护乘数失效(强制破坏语义)。 */
    private final boolean ignoreBreakingProtection;

    // 构造时取样的设置(计算中途改设置不影响本次搜索)
    private final boolean autoTool;
    private final boolean useSwordToMine;
    private final boolean itemSaver;
    private final int itemSaverThreshold;
    private final List<class_2248> blocksToAvoidBreaking;
    private final double avoidBreakingMultiplier;

    public ToolSet(class_3222 player) {
        this(player, false);
    }

    public ToolSet(class_3222 player, boolean ignoreBreakingProtection) {
        this(snapshotHotbar(player), player.method_31548().field_7545, ignoreBreakingProtection,
                NavSettings.get().considerPotionEffects ? potionAmplifier(player) : 1.0);
    }

    /**
     * 快照直构(线程安全冒烟测试与自备快照的调用方用):调用方给出
     * 快捷栏九格(应为不再被改写的副本)、选中槽位与药水修正倍率。
     */
    public ToolSet(class_1799[] hotbarSnapshot, int selectedSlot,
                   boolean ignoreBreakingProtection, double potionAmplifier) {
        this.breakStrengthCache = new HashMap<>();
        this.hotbar = hotbarSnapshot.clone();
        this.selectedSlot = selectedSlot;
        this.ignoreBreakingProtection = ignoreBreakingProtection;

        NavSettings settings = NavSettings.get();
        this.autoTool = settings.autoTool;
        this.useSwordToMine = settings.useSwordToMine;
        this.itemSaver = settings.itemSaver;
        this.itemSaverThreshold = settings.itemSaverThreshold;
        this.blocksToAvoidBreaking = List.copyOf(settings.blocksToAvoidBreaking());
        this.avoidBreakingMultiplier = settings.avoidBreakingMultiplier;

        if (potionAmplifier != 1.0) {
            Function<Double, Double> amplify = x -> potionAmplifier * x;
            backendCalculation = amplify.compose(this::getBestDestructionTime);
        } else {
            backendCalculation = this::getBestDestructionTime;
        }
    }

    /** 快捷栏九格逐格 copy(主线程调用;worker 之后只读副本)。 */
    private static class_1799[] snapshotHotbar(class_3222 player) {
        class_1799[] hotbar = new class_1799[9];
        for (int i = 0; i < 9; i++) {
            hotbar[i] = player.method_31548().method_5438(i).method_7972();
        }
        return hotbar;
    }

    /**
     * 用快捷栏最优工具挖该方块的速度(1/挖掘tick数)。
     * 不可破坏时为负值。
     */
    public double getStrVsBlock(class_2680 state) {
        return breakStrengthCache.computeIfAbsent(state.method_26204(), backendCalculation);
    }

    /**
     * 材质廉价度序:按材质物品标签(木板/圆石/铁锭…)从廉到贵排序,
     * 命中哪个标签就返回其序号;不命中任何标签返回 -1(工具本体不在
     * 材质标签里,通常恒 -1,平速时先遇到的槽位保持胜出)。
     */
    private static final List<class_6862<class_1792>> MATERIAL_TAGS_PRIORITY = List.of(
            materialTag("wooden_tool_materials"),
            materialTag("stone_tool_materials"),
            materialTag("iron_tool_materials"),
            materialTag("gold_tool_materials"),
            materialTag("diamond_tool_materials"),
            materialTag("netherite_tool_materials")
    );

    private static class_6862<class_1792> materialTag(String name) {
        return class_6862.method_40092(net.minecraft.class_7924.field_41197,
                new net.minecraft.class_2960(name));
    }

    private static int getMaterialCost(class_1799 itemStack) {
        for (int i = 0; i < MATERIAL_TAGS_PRIORITY.size(); i++) {
            if (itemStack.method_31573(MATERIAL_TAGS_PRIORITY.get(i))) {
                return i;
            }
        }
        return -1;
    }

    /** 是否属于武器类物品(剑/斧/三叉戟/重锤)。 */
    private static boolean isWeapon(class_1799 itemStack) {
        class_1792 item = itemStack.method_7909();
        return item instanceof class_1829 || item instanceof class_1743
                || item instanceof class_1835 || item instanceof class_9362;
    }

    /** 该物品是否带精准采集附魔。 */
    public boolean hasSilkTouch(class_1799 stack) {
        // 本代直接查附魔等级,无 Holder 键集。
        return class_1890.method_8225(class_1893.field_9099, stack) > 0;
    }

    public int getBestSlot(class_2248 b, boolean preferSilkTouch) {
        return getBestSlot(b, preferSilkTouch, false);
    }

    /**
     * 快捷栏 9 格中挖该方块的最优槽位(基于构造时的快照)。速度最高
     * 者胜;平速时优先更廉价材质,{@code preferSilkTouch} 时优先精准
     * 采集。autoTool 关闭且用于成本计算时直接返回构造时的手持槽
     * (让路径成本反映真实会用的那件工具)。
     */
    public int getBestSlot(class_2248 b, boolean preferSilkTouch, boolean pathingCalculation) {
        if (!autoTool && pathingCalculation) {
            return selectedSlot;
        }

        int best = 0;
        double highestSpeed = Double.NEGATIVE_INFINITY;
        int lowestCost = Integer.MIN_VALUE;
        boolean bestSilkTouch = false;
        class_2680 blockState = b.method_9564();
        for (int i = 0; i < 9; i++) {
            class_1799 itemStack = hotbar[i];
            if (!useSwordToMine && isWeapon(itemStack)) {
                continue;
            }
            if (itemSaver
                    && itemStack.method_7919() + itemSaverThreshold >= itemStack.method_7936()
                    && itemStack.method_7936() > 1) {
                continue;
            }
            double speed = calculateSpeedVsBlock(itemStack, blockState);
            boolean silkTouch = hasSilkTouch(itemStack);
            if (speed > highestSpeed) {
                highestSpeed = speed;
                best = i;
                lowestCost = getMaterialCost(itemStack);
                bestSilkTouch = silkTouch;
            } else if (speed == highestSpeed) {
                int cost = getMaterialCost(itemStack);
                if ((cost < lowestCost && (silkTouch || !bestSilkTouch))
                        || (preferSilkTouch && !bestSilkTouch && silkTouch)) {
                    highestSpeed = speed;
                    best = i;
                    lowestCost = cost;
                    bestSilkTouch = silkTouch;
                }
            }
        }
        return best;
    }

    /** 用最优槽位工具挖该方块的速度(已乘保护方块修正)。 */
    private double getBestDestructionTime(class_2248 b) {
        class_1799 stack = hotbar[getBestSlot(b, false, true)];
        return calculateSpeedVsBlock(stack, b.method_9564()) * avoidanceMultiplier(b);
    }

    /**
     * 受保护功能方块(工作台/熔炉/箱子等)速度乘 0.1,
     * 即挖掘成本 ×10;强制破坏语义下失效。
     */
    private double avoidanceMultiplier(class_2248 b) {
        if (ignoreBreakingProtection) {
            return 1;
        }
        return blocksToAvoidBreaking.contains(b) ? avoidBreakingMultiplier : 1;
    }

    /**
     * 用指定物品挖指定方块的速度(1/挖掘tick数)。
     * hardness&lt;0(基岩类)返回 -1 表示不可破坏。
     * speed&gt;1 时叠加效率附魔的挖掘效率加成;除以 hardness 后,
     * 正确工具(或不需要正确工具)除以 30,错误工具除以 100。
     */
    public static double calculateSpeedVsBlock(class_1799 item, class_2680 state) {
        float hardness;
        try {
            hardness = state.method_26214(null, null);
        } catch (NullPointerException npe) {
            // 取不到硬度的异类方块按不可破坏处理
            return -1;
        }
        if (hardness < 0) {
            return -1;
        }

        float speed = item.method_7924(state);
        if (speed > 1) {
            // 本代效率加成走经典公式 level²+1(1.21 的 MINING_EFFICIENCY
            // 属性效果对效率附魔的 calculate(level) 就是这条曲线)。
            int eff = class_1890.method_8225(class_1893.field_9131, item);
            if (eff > 0) {
                speed += eff * eff + 1;
            }
        }

        speed /= hardness;
        if (!state.method_29291() || (!item.method_7960() && item.method_7951(state))) {
            return speed / 30;
        } else {
            return speed / 100;
        }
    }

    /** 急迫 / 挖掘疲劳药水对挖掘速度的修正倍率(构造时在主线程取样)。 */
    private static double potionAmplifier(class_3222 player) {
        double speed = 1;
        if (player.method_6059(class_1294.field_5917)) {
            speed *= 1 + (player.method_6112(class_1294.field_5917).method_5578() + 1) * 0.2;
        }
        if (player.method_6059(class_1294.field_5901)) {
            switch (player.method_6112(class_1294.field_5901).method_5578()) {
                case 0:
                    speed *= 0.3;
                    break;
                case 1:
                    speed *= 0.09;
                    break;
                case 2:
                    speed *= 0.0027; // 原版就是 0.0027,不是 0.027
                    break;
                default:
                    speed *= 0.00081;
                    break;
            }
        }
        return speed;
    }
}
