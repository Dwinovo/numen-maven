package com.dwinovo.numen.init;

import com.dwinovo.numen.Constants;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

/**
 * Catalogue of the datapack tags the Numen tool pack declares. The
 * pathfinder and the loader-side data generators both reference the constants
 * here so the key's identifier exists in one place only — rename or repath in
 * this file and every consumer follows. These are Numen's tags (namespace
 * {@code numen}), not Numen API's: pathfinding scaffolding is a
 * tool-pack concern. Which blocks the body may break is not a tag — that is
 * the permission layer's rule table ({@code com.dwinovo.numen.api.permission}).
 *
 * <h2>Why not derive at runtime</h2>
 * Tags are referenced from pathfinder hot paths where a fresh
 * {@code new ResourceLocation(...)} per call would allocate. Caching
 * the {@link class_6862} as a {@code static final} field amortises that cost
 * and gives the JIT a constant pool reference.
 */
public final class InitTag {

    /**
     * Foods that may be used to feed/heal a companion. Datapack-driven so server
     * admins can extend the list without code changes — see
     * {@code data/numen/tags/items/tame_foods.json}.
     */
    public static final class_6862<class_1792> TAME_FOODS = item("tame_foods");

    /**
     * The factory throwaway list: blocks a walk is willing to spend — bridging gaps,
     * stepping up, and pillaring — when its description names no {@code materials}
     * (reflexes always use it).
     * Datapack-driven so packs can add their own cheap blocks — see
     * {@code data/numen/tags/items/throwaway.json}.
     */
    public static final class_6862<class_1792> THROWAWAY = item("throwaway");

    private InitTag() {}

    /** 模型写标签用的前缀:{@code #minecraft:beds} 指"床这一类",而不是某一种颜色的床。 */
    public static final String TAG_PREFIX = "#";

    /**
     * 把 {@code #ns:path} 解成一个标签键;不是这个形式、或者 id 不合法,返回 {@code null}
     * (调用方接着按具体 id 试)。
     *
     * <p>让工具参数收标签,是因为"一类方块"这件事我们枚举不完:床有 16 色、石头有一族、
     * 模组还会加。标签是 Minecraft 自己表达"一类"的方式,而且整合包能扩。
     */
    public static <T> class_6862<T> parseRef(net.minecraft.class_5321<
            ? extends net.minecraft.class_2378<T>> registry, String raw) {
        if (raw == null || !raw.startsWith(TAG_PREFIX)) {
            return null;
        }
        class_2960 id = class_2960.method_12829(raw.substring(TAG_PREFIX.length()).trim());
        return id == null ? null : class_6862.method_40092(registry, id);
    }

    private static class_6862<class_1792> item(String name) {
        return class_6862.method_40092(class_7924.field_41197,
                new class_2960(Constants.MOD_ID, name));
    }

}
