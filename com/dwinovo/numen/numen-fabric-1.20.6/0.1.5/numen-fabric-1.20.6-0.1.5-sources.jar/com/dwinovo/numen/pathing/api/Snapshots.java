package com.dwinovo.numen.pathing.api;

import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1656;
import net.minecraft.class_1770;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_3222;
import net.minecraft.class_4050;
import net.minecraft.class_5134;
import net.minecraft.class_5635;
import net.minecraft.class_6880;
import net.minecraft.class_9284;
import net.minecraft.class_9334;
import com.dwinovo.numen.api.entity.BodyEnchantments;
import com.dwinovo.numen.api.entity.DigTime;
import com.dwinovo.numen.pathing.plan.BodySnapshot;
import com.dwinovo.numen.pathing.plan.Breath;
import com.dwinovo.numen.pathing.plan.Mobility;
import com.dwinovo.numen.pathing.world.BodyStats;
import com.dwinovo.numen.pathing.world.Kinematics;

/**
 * 从一具真实的身体上抄下规划要的身体快照,原版口径只此一处:尺寸取原版的姿势尺寸,迈步、起跳、重力、交互距离、
 * 摔落取同名属性,潜行、水下移动、挖掘速度里本代由附魔直接起作用的几项按 {@link BodyEnchantments} 换成属性的值,细雪托不托得住
 * 照原版看脚上的皮靴,冰霜行者看靴子的附魔,游戏模式、血量、饱食度、主背包照抄;氧气、水下呼吸附魔、水下呼吸类效果还剩几刻、
 * 头上是不是海龟壳照抄,原版永远不扣氧
 * 的(能在水下呼吸、无敌)记成效果无穷。
 *
 * <p>只在世界所在的线程上调用;抄出来的快照可以交给搜索线程。
 */
public final class Snapshots {

    private Snapshots() {}

    public static BodySnapshot of(class_3222 body) {
        BodyStats stats = stats(body);
        DigTime.Mining mining = DigTime.Mining.of(body);
        List<class_1799> inventory = List.copyOf(body.method_31548().field_7547);
        return new BodySnapshot(stats, body.field_13974.method_14257(), body.method_6032(),
                body.method_45325(class_5134.field_49079),
                body.method_45325(class_5134.field_49077), body.method_7344().method_7586(),
                BodyEnchantments.waterMovementEfficiency(body), inventory, mining, breath(body), mobility(body));
    }

    /**
     * 憋气的本钱。水下呼吸类效果照原版 {@code MobEffectUtil.hasWaterBreathing} 认水下呼吸与潮涌能量两种,取剩得久的;
     * 能在水下呼吸的实体({@code canBreatheUnderwater})与无敌的玩家原版不扣氧({@code LivingEntity.baseTick}),记成无穷。
     * 规划之外要问"此刻憋得住吗"的(Numen 的换气本能)也读这一份。
     */
    public static Breath breath(class_3222 body) {
        double shield = body.method_6094() || body.method_31549().field_7480 ? Double.POSITIVE_INFINITY
                : Math.max(remaining(body, class_1294.field_5923), remaining(body, class_1294.field_5927));
        return new Breath(body.method_5669(), body.method_5748(), BodyEnchantments.oxygenBonus(body),
                shield, body.method_6118(class_1304.field_6169).method_31574(class_1802.field_8090));
    }

    /**
     * 身上已有的移动方式:许不许飞、在不在飞、飞行速度照能力({@link class_1656});滑翔物看胸甲位——1.21.1 是没坏的鞘翅
     * ({@code ElytraItem.isFlyEnabled}),还能用多少点耐久是离坏掉前剩的;烟花数是背包与副手里的火箭总数。谁能飞、谁能滑翔只在这里判。
     */
    public static Mobility mobility(class_3222 body) {
        class_1656 abilities = body.method_31549();
        class_1799 chest = body.method_6118(class_1304.field_6174);
        int gliderLife = chest.method_31574(class_1802.field_8833) && class_1770.method_7804(chest)
                ? chest.method_7936() - chest.method_7919() - 1 : 0;
        int fireworks = 0;
        int burn = Integer.MAX_VALUE;
        for (class_1799 stack : rockets(body)) {
            fireworks += stack.method_7947();
            burn = Math.min(burn, ROCKET_BURN * flightDuration(stack));
        }
        return new Mobility(abilities.field_7478, flying(body), abilities.method_7252(), gliderLife, fireworks,
                fireworks == 0 ? 0 : burn);
    }

    /** 背包与副手里的烟花火箭,各一叠。 */
    private static List<class_1799> rockets(class_3222 body) {
        List<class_1799> out = new java.util.ArrayList<>();
        for (class_1799 stack : body.method_31548().field_7547) {
            if (stack.method_31574(class_1802.field_8639)) {
                out.add(stack);
            }
        }
        if (body.method_6079().method_31574(class_1802.field_8639)) {
            out.add(body.method_6079());
        }
        return out;
    }

    /** 烟花飞行时长({@code Fireworks.flightDuration}):每多一级多推十刻。 */
    private static int flightDuration(class_1799 stack) {
        class_9284 fireworks = stack.method_57824(class_9334.field_49616);
        return fireworks == null ? 1 : Math.max(1, fireworks.comp_2391());
    }

    /** 一级飞行时长的烟花保底推多少刻({@code FireworkRocketEntity} 的寿命:{@code 10 × 时长 + 最多 11 的随机})。 */
    private static final int ROCKET_BURN = 10;

    /** 身体此刻在不在飞(创造飞行):快照里的 {@link Mobility#flying} 与执行时每刻问的是这一处。 */
    public static boolean flying(class_3222 body) {
        return body.method_31549().field_7479;
    }

    /** 在水里游一格要几刻:规划给水里一步定价用的同一个数({@link Kinematics#wadeTicksPerBlock})。 */
    public static double swimTicksPerBlock(class_3222 body) {
        return Kinematics.wadeTicksPerBlock(stats(body), BodyEnchantments.waterMovementEfficiency(body));
    }

    /** 这个效果还剩几刻;没有为 0,不限时为无穷。 */
    private static double remaining(class_3222 body, class_6880<class_1291> effect) {
        class_1293 instance = body.method_6112(effect);
        if (instance == null) {
            return 0;
        }
        return instance.method_48559() ? Double.POSITIVE_INFINITY : instance.method_5584();
    }

    /** 第 0 层要的那几项物理量:尺寸、迈步、起跳、重力、交互距离、细雪与冰霜行者。 */
    public static BodyStats stats(class_3222 body) {
        return new BodyStats(body.method_18377(class_4050.field_18076),
                body.method_49476(), body.method_45325(class_5134.field_23728), body.method_56989(), walkingSpeed(body),
                BodyEnchantments.sneakingSpeed(body),
                body.method_55754(), class_5635.method_32355(body), frostWalker(body));
    }

    /** 平走的移动速度:属性值去掉此刻疾跑加上的那一份(疾跑的倍数在 {@code Kinematics} 里按疾跑算)。 */
    private static double walkingSpeed(class_3222 body) {
        double value = body.method_45325(class_5134.field_23719);
        return body.method_5624() ? value / Kinematics.SPRINT_MULTIPLIER : value;
    }

    /** 脚上的靴子带冰霜行者。 */
    private static boolean frostWalker(class_3222 body) {
        return class_1890.method_8225(class_1893.field_9122, body.method_6118(class_1304.field_6166)) > 0;
    }
}
