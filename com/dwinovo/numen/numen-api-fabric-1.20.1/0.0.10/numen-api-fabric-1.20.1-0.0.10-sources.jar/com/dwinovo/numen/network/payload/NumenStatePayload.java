package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: a companion's 36 main backpack slots. Sent both as the answer to
 * {@link RequestStatePayload} (the Items tab asking) and unprompted whenever her
 * inventory actually changes, so the agent loop can state what she carries without
 * spending a turn on {@code get_self_status}. {@code loaded=false} means the body is
 * asleep in unloaded chunks (or not the requester's) — no contents.
 *
 * <p>{@code selectedSlot} and {@code offhand} ride along rather than being read off the
 * client-side entity: vanilla only syncs equipment for entities the client is tracking,
 * so once she walks out of view the hands would go blank while the backpack (pushed from
 * the server) stayed readable. Two fields buy one answer that is the same everywhere.
 *
 * <h2>为什么这里装的不只是背包</h2>
 * 饱食度、选中槽、副手早就在里面了 —— 它一直是<b>这具身体此刻的样子</b>,只是原来叫背包。
 * 身上的效果同理:模型每一轮都要读它才知道自己中没中毒、有没有抗性,而这类东西<b>一进对话
 * 历史就永远不会过期</b>,只能每次现挂。同一条通道、同一份快照,不必为每样状态另开一路。
 * 骑乘同理:她坐没坐在船上决定了"再点一次船"是不是废话、goto 会驾船还是走路,
 * 模型必须实时看见。{@code vehicleType} 空串 = 没骑任何东西,{@code vehicleId} 相应为 -1。
 */
public record NumenStatePayload(UUID uuid, boolean loaded, List<class_1799> items,
                                List<class_1799> craft, int foodLevel, float saturation,
                                int selectedSlot, class_1799 offhand,
                                List<class_1293> effects,
                                String vehicleType, int vehicleId)
        implements NumenPayload {

    public static final class_2960 ID =
            new class_2960(Constants.MOD_ID, "numen_state");

    /** 物品清单的护栏:36 主格 + 2×2 合成栏,64 远超实际上限,防的是恶意长度。 */
    private static final int MAX_ITEMS = 64;
    private static final int MAX_EFFECTS = 64;

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(uuid);
        buf.writeBoolean(loaded);
        writeItems(buf, items);
        writeItems(buf, craft);
        buf.method_10804(foodLevel);
        buf.writeFloat(saturation);
        buf.method_10804(selectedSlot);
        buf.method_10793(offhand);
        // 效果按 NBT 走:1.20.1 没有 MobEffectInstance 的流编解码器,save/load 是它的原生序列化
        int en = Math.min(effects.size(), MAX_EFFECTS);
        buf.method_10804(en);
        for (int i = 0; i < en; i++) {
            buf.method_10794(effects.get(i).method_5582(new class_2487()));
        }
        buf.method_10814(vehicleType);
        buf.method_10804(vehicleId);
    }

    public static NumenStatePayload read(class_2540 buf) {
        UUID uuid = buf.method_10790();
        boolean loaded = buf.readBoolean();
        List<class_1799> items = readItems(buf);
        List<class_1799> craft = readItems(buf);
        int foodLevel = buf.method_10816();
        float saturation = buf.readFloat();
        int selectedSlot = buf.method_10816();
        class_1799 offhand = buf.method_10819();
        int en = Math.min(buf.method_10816(), MAX_EFFECTS);
        List<class_1293> effects = new ArrayList<>(en);
        for (int i = 0; i < en; i++) {
            class_2487 tag = buf.method_10798();
            class_1293 e = tag == null ? null : class_1293.method_5583(tag);
            if (e != null) {
                effects.add(e);
            }
        }
        String vehicleType = buf.method_19772();
        int vehicleId = buf.method_10816();
        return new NumenStatePayload(uuid, loaded, items, craft, foodLevel, saturation,
                selectedSlot, offhand, effects, vehicleType, vehicleId);
    }

    private static void writeItems(class_2540 buf, List<class_1799> list) {
        int n = Math.min(list.size(), MAX_ITEMS);
        buf.method_10804(n);
        for (int i = 0; i < n; i++) {
            buf.method_10793(list.get(i));
        }
    }

    private static List<class_1799> readItems(class_2540 buf) {
        int n = Math.min(buf.method_10816(), MAX_ITEMS);
        List<class_1799> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(buf.method_10819());
        }
        return list;
    }

    /** Client main thread. */
    public static void handle(NumenStatePayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.state.accept(p);
    }
}
