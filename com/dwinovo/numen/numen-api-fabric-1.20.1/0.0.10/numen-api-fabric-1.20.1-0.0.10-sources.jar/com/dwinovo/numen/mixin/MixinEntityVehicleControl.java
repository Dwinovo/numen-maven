package com.dwinovo.numen.mixin;

import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 载具的服务端权威开关。原版把"谁驱动这个载具"交给控制乘客的客户端:船的
 * {@code tick} 在控制者不是本地实例时每刻 {@code setDeltaMovement(ZERO)},
 * 等一个客户端移动包——而同伴没有客户端,那个包永远不来,船就冻死在原地。
 * 控制乘客是同伴时判服务端为权威,原版的浮力、摩擦、移动整条物理链在服务端
 * 活过来,骑乘生物(马)的 {@code travelRidden} 同理。与 Carpet 假玩家的
 * EntityMixin 同一做法。
 */
@Mixin(class_1297.class)
public abstract class MixinEntityVehicleControl {

    @Shadow
    public abstract class_1309 getControllingPassenger();

    @Inject(method = "isControlledByLocalInstance", at = @At("HEAD"), cancellable = true)
    private void numen$serverDrivesCompanionVehicles(CallbackInfoReturnable<Boolean> cir) {
        if (getControllingPassenger() instanceof NumenPlayer) {
            cir.setReturnValue(!((class_1297) (Object) this).method_37908().method_8608());
        }
    }
}
