package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.CompanionSpeech;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.NumenPayload;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Client → Server:同伴的大脑开始/结束输出(回合进行中或语音在播)。
 * 纯姿态信号——身体据此在说话期间注视主人(闲时链消费),不承载任何
 * 逻辑状态,丢了漂了都无害。只在状态翻转时发,不逐 tick 刷。
 */
public record SpeakingStatePayload(UUID entityUuid, boolean speaking) implements NumenPayload {

    public static final class_2960 ID =
            new class_2960(Constants.MOD_ID, "speaking_state");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.writeBoolean(speaking);
    }

    public static SpeakingStatePayload read(class_2540 buf) {
        return new SpeakingStatePayload(buf.method_10790(), buf.readBoolean());
    }

    /** Server main thread. 只认主人本人发来的状态。 */
    public static void handle(SpeakingStatePayload p, class_3222 sender) {
        var companion = com.dwinovo.numen.entity.NumenPlayer.findByUuid(
                sender.method_37908().method_8503(), p.entityUuid());
        if (companion == null || !companion.isOwnedByPlayer(sender.method_5667())) return;
        CompanionSpeech.setSpeaking(p.entityUuid(), p.speaking());
    }
}
