package com.dwinovo.numen.client.chat;

import com.dwinovo.numen.client.NumenKeys;
import com.dwinovo.numen.client.agent.KnownSkins;
import com.dwinovo.numen.client.agent.NumenRoster;
import com.dwinovo.numen.client.hud.TalkHint;
import com.dwinovo.numen.client.screen.Nb;
import com.dwinovo.numen.client.screen.UiTheme;
import com.dwinovo.numen.client.ui.Anim;
import com.dwinovo.numen.client.ui.RoundRect;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_7532;

/**
 * 同伴转盘:抽奖转盘的操作模型——顶槽固定(金环 + 指针 ▼),滚轮转动
 * 整个轮盘把人送进顶槽,点击别处的头像沿最短路径转过去,点击顶槽头像
 * 确认,松开轮盘键也确认(对讲机手感),Esc 放弃不改选。悬浮任意头像
 * 在光标旁浮名字;确认关盘后准星下方闪一行「按 [键] 对话 · 按住 [键]
 * 说话」教学下一步。
 *
 * <p>动效:旋转角走欠阻尼弹簧(拨过去带一丝回弹,拨盘手感),顶槽
 * 住客的尺寸用帧率无关指数趋近柔滑放大,呼吸是慢周期浮点正弦叠在
 * pose 缩放上;开盘 170ms 从圆心 easeOutCubic 弹出。
 */
public class CompanionWheelScreen extends class_437 {

    private static final int AVATAR = 26;             // 基础头像尺寸(px)
    private static final float SELECTED_PX = 7f;      // 顶槽住客的目标增量(px)
    private static final float APPROACH_RATE = 16f;   // 尺寸趋近速率
    private static final float BREATH_AMP = 0.035f;   // 呼吸振幅(缩放比)
    private static final long BREATH_PERIOD_MS = 2600;
    private static final long OPEN_MS = 170;          // 开盘弹出时长
    private static final float SPRING_K = 260f;       // 旋转弹簧刚度
    private static final float SPRING_DAMP = 0.78f;   // 阻尼比(<1:一丝回弹)
    private static final long FLASH_MS = 3200;        // 关盘教学提示时长

    private final List<NumenRoster.Entry> entries;
    private final float[] sizePx;
    private final long openedAtMs = System.currentTimeMillis();
    private long lastFrameNanos = System.nanoTime();

    /** 顶槽目标(entries 下标);旋转角朝它的席位角趋近。 */
    private int index;
    /** 轮盘当前旋转角(度)与角速度——欠阻尼弹簧驱动。 */
    private float rotDeg;
    private float rotVel;

    public CompanionWheelScreen() {
        super(class_2561.method_43470("Numen companion wheel"));
        this.entries = NumenRoster.instance().entries();
        this.index = 0;
        var current = SelectedCompanion.get();
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).uuid().equals(current)) {
                this.index = i;
                break;
            }
        }
        this.rotDeg = targetRotFor(index);   // 开盘即对位,不空转
        this.sizePx = new float[entries.size()];
        for (int i = 0; i < sizePx.length; i++) {
            sizePx[i] = i == index ? AVATAR + SELECTED_PX : AVATAR;
        }
    }

    private static boolean physicallyDown(long window, class_304 k) {
        if (k.method_1415()) {
            return false;
        }
        class_3675.class_306 key = class_3675.method_15981(k.method_1428());
        if (key.method_1442() == class_3675.class_307.field_1672) {
            return GLFW.glfwGetMouseButton(window, key.method_1444()) == GLFW.GLFW_PRESS;
        }
        return class_3675.method_15987(window, key.method_1444());
    }

    /**
     * 移动放行的唯一通路(由 {@code MixinKeyboardInput} 在原版采样之后
     * 调用,两个加载器同一个点):开屏期间按键系统被闸,采出来的移动
     * 意图全是零——这里按 GLFW 物理按键状态原样重建,奔跑不为选人断步,
     * 开盘前就按住的 W 也无缝接上。不碰 {@code KeyMapping} 状态,键位
     * 冲突类模组无感。鼠标视角仍锁定(被转盘征用),武器轮盘式取舍。
     */
    public static void feedMovement(net.minecraft.class_744 input,
                                    float sneakingSpeedMultiplier) {
        class_310 mc = class_310.method_1551();
        long window = mc.method_22683().method_4490();
        boolean up = physicallyDown(window, mc.field_1690.field_1894);
        boolean down = physicallyDown(window, mc.field_1690.field_1881);
        boolean left = physicallyDown(window, mc.field_1690.field_1913);
        boolean right = physicallyDown(window, mc.field_1690.field_1849);
        input.field_3910 = up;
        input.field_3909 = down;
        input.field_3908 = left;
        input.field_3906 = right;
        input.field_3905 = (up ? 1f : 0f) - (down ? 1f : 0f);
        input.field_3907 = (left ? 1f : 0f) - (right ? 1f : 0f);
        input.field_3904 = physicallyDown(window, mc.field_1690.field_1903);
        input.field_3903 = physicallyDown(window, mc.field_1690.field_1832);
        if (input.field_3903) {
            input.field_3905 *= sneakingSpeedMultiplier;
            input.field_3907 *= sneakingSpeedMultiplier;
        }
    }

    private float step() {
        return 360f / entries.size();
    }

    /** 让 i 号坐进顶槽所需的旋转角。 */
    private float targetRotFor(int i) {
        return -i * step();
    }

    private int radius() {
        return class_3532.method_15340(Math.min(this.field_22789, this.field_22790) / 5, 56, 104);
    }

    /** i 号此刻的方位角(弧度,顶槽为 -90°)。 */
    private double slotAngle(int i) {
        return Math.toRadians(-90 + i * step() + rotDeg);
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partialTicks) {
        // 崩溃护栏:轮盘渲染出错直接关盘,不带走游戏
        if (!com.dwinovo.numen.client.ui.SafeUi.run("wheel-render",
                () -> renderInner(g, mouseX, mouseY))) {
            method_25419();
        }
    }

    private void renderInner(class_332 g, int mouseX, int mouseY) {
        if (entries.isEmpty()) {
            method_25419();
            return;
        }
        long nowMs = System.currentTimeMillis();
        long nowNanos = System.nanoTime();
        float dt = Math.min((nowNanos - lastFrameNanos) / 1.0e9f, 0.05f);
        lastFrameNanos = nowNanos;
        float open = Anim.easeOutCubic((nowMs - openedAtMs) / (float) OPEN_MS);

        // 旋转角:欠阻尼弹簧追目标——拨过去,末端一丝回弹
        float target = rotDeg + wrapDeg(targetRotFor(index) - rotDeg);
        float acc = SPRING_K * (target - rotDeg)
                - 2f * (float) Math.sqrt(SPRING_K) * SPRING_DAMP * rotVel;
        rotVel += acc * dt;
        rotDeg += rotVel * dt;
        if (Math.abs(target - rotDeg) < 0.05f && Math.abs(rotVel) < 0.5f) {
            rotDeg = target;
            rotVel = 0f;
        }

        g.method_25294(0, 0, this.field_22789, this.field_22790, (int) (0x48 * open) << 24);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        int r = radius();
        float rNow = r * open;
        UiTheme th = UiTheme.current();

        // 顶槽底座:固定的金环 + 指针 ▼(先画,头像转进来压在上面)
        int topX = cx;
        int topY = cy - Math.round(rNow);
        int ringHalf = AVATAR / 2 + 5;
        RoundRect.fill(g, topX - ringHalf, topY - ringHalf, topX + ringHalf, topY + ringHalf, 5,
                th.cta());
        Nb.text(g, this.field_22793, "▼", topX - this.field_22793.method_1727("▼") / 2,
                topY - ringHalf - 12, th.cta());

        int hovered = -1;
        for (int i = 0; i < entries.size(); i++) {
            boolean atTop = i == index;
            sizePx[i] = Anim.approach(sizePx[i], atTop ? AVATAR + SELECTED_PX : AVATAR,
                    APPROACH_RATE, dt);

            double ang = slotAngle(i);
            float ax = cx + (float) (Math.cos(ang) * rNow);
            float ay = cy + (float) (Math.sin(ang) * rNow);
            if (hitAvatar(mouseX, mouseY, ax, ay)) {
                hovered = i;
            }

            float breath = atTop
                    ? 1f + BREATH_AMP * (0.5f + 0.5f * (float) Math.sin(
                            nowMs % BREATH_PERIOD_MS / (double) BREATH_PERIOD_MS * Math.PI * 2))
                    : 1f;
            float scale = sizePx[i] / AVATAR * breath * open;

            g.method_51448().method_22903();
            g.method_51448().method_46416(ax, ay, 0);
            g.method_51448().method_22905(scale, scale, 1f);
            int half = AVATAR / 2;
            if (!atTop) {
                RoundRect.fill(g, -half - 2, -half - 2, half + 2, half + 2, 4, th.border());
            }
            class_7532.method_44443(g, KnownSkins.of(entries.get(i).uuid()),
                    -half, -half, AVATAR);
            g.method_51448().method_22909();
        }

        if (open > 0.4f) {
            // 顶槽名牌:当前选中 xxx
            String label = "当前选中  " + entries.get(index).name();
            int tw = this.field_22793.method_1727(label);
            int nx = cx - tw / 2;
            int ny = cy - r - 46;
            RoundRect.card(g, nx - 10, ny - 6, nx + tw + 10, ny + 14, 4, th.aiFill(), th.border());
            Nb.text(g, this.field_22793, label, nx, ny, th.text());

            String hint = "滚轮转盘 · 点击送到顶槽 · 点顶槽或松开确认 · Esc 取消";
            Nb.text(g, this.field_22793, hint, cx - this.field_22793.method_1727(hint) / 2, cy + r + 30, 0xB0FFFFFF);
        }

        // 悬浮名字:光标旁小字(顶槽住客的名字已在名牌上,不重复)
        if (hovered >= 0 && hovered != index) {
            String name = entries.get(hovered).name();
            Nb.text(g, this.field_22793, name, mouseX + 10, mouseY - 4, 0xE0FFFFFF);
        }
    }

    private boolean hitAvatar(double mx, double my, float ax, float ay) {
        int half = AVATAR / 2 + 3;
        return mx >= ax - half && mx <= ax + half && my >= ay - half && my <= ay + half;
    }

    private static float wrapDeg(float a) {
        while (a > 180f) a -= 360f;
        while (a < -180f) a += 360f;
        return a;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollY) {   // 1.20.1: single scroll delta
        if (!entries.isEmpty()) {
            int n = entries.size();
            index = ((index + (scrollY < 0 ? 1 : -1)) % n + n) % n;
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button != 0 || entries.isEmpty()) {
            return super.method_25402(mouseX, mouseY, button);
        }
        // 命中检测与渲染同一套席位坐标
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        float rNow = radius() * Anim.easeOutCubic(
                (System.currentTimeMillis() - openedAtMs) / (float) OPEN_MS);
        for (int i = 0; i < entries.size(); i++) {
            double ang = slotAngle(i);
            float ax = cx + (float) (Math.cos(ang) * rNow);
            float ay = cy + (float) (Math.sin(ang) * rNow);
            if (hitAvatar(mouseX, mouseY, ax, ay)) {
                if (i == index) {
                    confirm();      // 点顶槽住客:确认关盘
                } else {
                    index = i;      // 点别处:最短路径转过去(弹簧自己追)
                }
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        // 按住开、松开定:轮盘键抬起即确认(对讲机手感)
        if (NumenKeys.COMPANION_WHEEL.method_1417(keyCode, scanCode) && !entries.isEmpty()) {
            confirm();
            return true;
        }
        return super.method_16803(keyCode, scanCode, modifiers);
    }

    private void confirm() {
        NumenRoster.Entry chosen = entries.get(index);
        SelectedCompanion.set(chosen.uuid());
        // 关盘教学:下一步怎么跟它说话
        TalkHint.flash("已选中 " + chosen.name()
                + " · 按 [" + NumenKeys.TALK_COMPANION.method_16007().getString()
                + "] 对话 · 按住 [" + NumenKeys.QUICK_VOICE.method_16007().getString()
                + "] 说话", FLASH_MS);
        method_25419();
    }

    @Override
    public void method_25420(class_332 g) {
        // 刻意留空:不要菜单模糊(render 里自画一层轻压暗)
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
