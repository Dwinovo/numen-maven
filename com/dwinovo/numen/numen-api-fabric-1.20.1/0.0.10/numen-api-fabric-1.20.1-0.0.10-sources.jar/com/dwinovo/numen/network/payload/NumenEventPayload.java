package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: 一条进同伴输入队列的条目。
 *
 * <p>它就是 {@code EventQueue.Entry} 的线上形状——四个字段一个不少:
 *
 * <ul>
 *   <li>{@code entryType} —— 查类型表(拼给模型的样子、进不进聊天流、打断时清不清)。
 *       第三方内容包注册了新类型,这条通道不用改;</li>
 *   <li>{@code ts} —— <b>事发的真实时刻</b>,不是收到的时刻。主人离线期间攒下的事
 *       补发时,少了它她会把三小时前的事当成刚发生的;</li>
 *   <li>{@code urgent} —— 她不知道就会做错事。到了队列会立刻带走攒的一切开一轮
 *       (除非队列锁着)。</li>
 * </ul>
 *
 * <p>消费时机<b>不由发送方决定</b>:队列按自己的规则(急件 / 攒够条数 / 攒够时长)
 * 说了算。
 */
public record NumenEventPayload(UUID entityUuid, String entryType, String text, long ts, boolean urgent)
        implements NumenPayload {

    public static final class_2960 ID =
            new class_2960(Constants.MOD_ID, "numen_event");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_10788(entryType, 64);
        buf.method_10814(text);
        buf.method_10791(ts);
        buf.writeBoolean(urgent);
    }

    public static NumenEventPayload read(class_2540 buf) {
        return new NumenEventPayload(buf.method_10790(), buf.method_10800(64), buf.method_19772(),
                buf.method_10792(), buf.readBoolean());
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenEventPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.event.accept(p);
    }
}
