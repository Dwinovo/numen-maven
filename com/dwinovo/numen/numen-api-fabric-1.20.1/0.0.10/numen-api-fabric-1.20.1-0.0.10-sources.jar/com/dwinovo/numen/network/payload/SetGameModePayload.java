package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.NumenPayload;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * Client → Server:编辑卡把一只<b>已创建</b>同伴的游戏模式切到生存/创造。
 * 权限门与召唤同一道({@link Companions#applyGameMode}):创造要主人有
 * gamemode 权限或本人在创造。改完立刻重推名册,编辑卡的模式格按新真相显示。
 */
public record SetGameModePayload(UUID uuid, boolean creative) implements NumenPayload {

    public static final class_2960 ID =
            new class_2960(Constants.MOD_ID, "set_game_mode");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(uuid);
        buf.writeBoolean(creative);
    }

    public static SetGameModePayload read(class_2540 buf) {
        return new SetGameModePayload(buf.method_10790(), buf.readBoolean());
    }

    public static void handle(SetGameModePayload p, class_3222 owner) {
        MinecraftServer server = ((class_3218) owner.method_37908()).method_8503();
        if (server == null || p.uuid() == null) return;
        NumenPlayer body = NumenPlayer.findByUuid(server, p.uuid());
        if (body == null || !body.isOwnedByPlayer(owner.method_5667())) {
            return;   // 不在场(休眠/死亡)或不是他的:模式住在活体上,没有活体没有可改的
        }
        Companions.applyGameMode(owner, body, p.creative());
        Companions.syncRosterToOwner(server, owner);
    }
}
