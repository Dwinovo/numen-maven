package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: ask the receiving owner's client to perform a local UI action.
 * The {@code /numen} command tree lives entirely on the server now (so it
 * doesn't collide with the client-side command dispatcher), but a couple of its
 * verbs — opening the settings GUI, clearing the conversation loops — are
 * inherently client-local. The server command just fires this packet at the
 * caller and their client does the rest.
 */
public record ClientUiActionPayload(Action action) implements NumenPayload {

    public enum Action { OPEN_SETTINGS, RESET_LOOPS, DEBUG_TEXT_ON, DEBUG_TEXT_OFF }

    public static final class_2960 ID =
            new class_2960(Constants.MOD_ID, "client_ui_action");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10804(action.ordinal());
    }

    public static ClientUiActionPayload read(class_2540 buf) {
        return new ClientUiActionPayload(Action.values()[buf.method_10816()]);
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(ClientUiActionPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.uiAction.accept(p);
    }
}
