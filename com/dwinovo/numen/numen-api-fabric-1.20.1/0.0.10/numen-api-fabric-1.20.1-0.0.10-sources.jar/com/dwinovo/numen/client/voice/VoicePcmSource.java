package com.dwinovo.numen.client.voice;

import com.dwinovo.numen.Constants;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_4234;

/**
 * "数据不来自 ogg 资源"的声音实例:取数被换成 {@link #openStream()}
 * 返回的内存 PCM 流。换法按 loader 分家(见
 * {@code com.dwinovo.numen.platform.services.IVoiceSoundFactory}):
 * Fabric 由 fabric 模块的 {@code MixinSoundEngine} 在 {@code SoundEngine.play}
 * 的流式取数处认这个接口;NeoForge 由子类覆写其补丁提供的官方
 * {@code SoundInstance.getStream} 钩子。两个 common 实现:
 * {@link EntityVoiceSound}(挂实体的 3D 空间音源)与
 * {@link VoicePreviewSound}(设置界面试听的 2D 就地播放)。
 */
public interface VoicePcmSource {

    /** 共用的 sounds.json 占位声音事件(见 {@link EntityVoiceSound} 的说明)。 */
    class_2960 SOUND_LOCATION =
            new class_2960(Constants.MOD_ID, "companion_voice");
    class_3414 SOUND_EVENT = class_3414.method_47908(SOUND_LOCATION);

    /** 这句语音的数据源——语义对应更高 MC 版本 {@code SoundInstance#getStream} 官方钩子。 */
    CompletableFuture<class_4234> openStream();
}
