package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: a companion has respawned at the owner's side after dying — both the same-session
 * timed recovery and the at-login recovery for a companion that died while the owner was away. Carries
 * the {@code cause} so the brain always learns WHY it died, even when a logout wiped the client's
 * in-memory death state. The owner's {@link com.dwinovo.numen.client.agent.EntityAgentLoop} is created
 * if needed and reawakened with a death {@code <event>}.
 */
public record NumenRespawnPayload(UUID entityUuid, String cause) implements NumenPayload {

    public static final class_2960 ID =
            new class_2960(Constants.MOD_ID, "numen_respawn");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_10814(cause);
    }

    public static NumenRespawnPayload read(class_2540 buf) {
        return new NumenRespawnPayload(buf.method_10790(), buf.method_19772());
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that).
     *  getOrCreate (not get): after a logout the loop may not exist yet — make it so the death event lands. */
    public static void handle(NumenRespawnPayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.respawn.accept(p);
    }
}
