package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.CompanionRegistry;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.NumenPayload;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * Client → Server: the owner asked to permanently delete a companion from the panel (rail ✕ → confirm).
 * Like a death — the live body drops its whole inventory at its feet — then it's dismissed for good
 * (registry entry removed, won't return on login). A dormant (unloaded) companion has no body to drop
 * from, so it's just forgotten (its orphaned {@code .dat} keeps the items but nothing respawns it).
 */
public record DismissRequestPayload(UUID uuid) implements NumenPayload {

    public static final class_2960 ID =
            new class_2960(Constants.MOD_ID, "dismiss_request");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(uuid);
    }

    public static DismissRequestPayload read(class_2540 buf) {
        return new DismissRequestPayload(buf.method_10790());
    }

    /** Server main thread. */
    public static void handle(DismissRequestPayload p, class_3222 owner) {
        MinecraftServer server = ((class_3218) owner.method_37908()).method_8503();
        if (server == null || p.uuid() == null) return;

        NumenPlayer body = NumenPlayer.findByUuid(server, p.uuid());
        if (body != null) {
            if (!body.isOwnedByPlayer(owner.method_5667())) return;   // not the caller's companion
            body.method_31548().method_7388();                        // death-style: drop everything at its feet
            Companions.dismiss(server, body);                     // despawn + forget (no respawn)
        } else {
            // 休眠 / 没加载——先按注册表验归属,再除名。走 Companions.forget 而不是直接
            // reg.remove:除名和通知客户端是同一件事的两半,分开写迟早漏一半。
            CompanionRegistry.Entry e = CompanionRegistry.get(server).find(p.uuid());
            if (e == null || !e.owner().equals(owner.method_5667())) return;
            Companions.forget(server, owner.method_5667(), java.util.List.of(p.uuid()));
        }
    }
}
