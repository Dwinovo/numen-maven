package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.platform.Services;
import com.dwinovo.numen.network.NumenPayload;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Client → Server: "show me this companion's backpack." Other players' full
 * inventory isn't synced to clients (only equipment is), so the read-only Items
 * tab fetches it on demand. Answered with one {@link NumenInventoryPayload}.
 *
 * <p>Only the owner of a LOADED companion gets the contents; otherwise the reply
 * is {@code loaded=false} (asleep / not yours — no inventory oracle).
 */
public record RequestInventoryPayload(UUID uuid) implements NumenPayload {

    /** The 36 main backpack slots (hotbar + storage); equipment is already client-synced. */
    public static final int MAIN_SLOTS = 36;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "request_inventory");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(uuid);
    }

    public static RequestInventoryPayload read(class_2540 buf) {
        return new RequestInventoryPayload(buf.method_10790());
    }

    /** Server main thread. */
    public static void handle(RequestInventoryPayload p, class_3222 player) {
        NumenPlayer numen = NumenPlayer.findByUuid(player.method_37908().method_8503(), p.uuid());
        if (numen == null || !numen.isOwnedByPlayer(player.method_5667())) {
            Services.NETWORK.sendToPlayer(player,
                    new NumenInventoryPayload(p.uuid(), false, List.of(), List.of(), 0, 0f));
            return;
        }
        class_1661 inv = numen.method_31548();
        List<class_1799> items = new ArrayList<>(MAIN_SLOTS);
        for (int i = 0; i < MAIN_SLOTS; i++) {
            items.add(inv.method_5438(i).method_7972());
        }
        // The 2×2 crafting menu (vanilla InventoryMenu layout): slot 0 = result, slots 1-4 = grid.
        // Packed as [grid0, grid1, grid2, grid3, result] for the Items tab to mirror.
        List<class_1799> craft = new ArrayList<>(5);
        for (int i = 1; i <= 4; i++) craft.add(numen.field_7498.method_7611(i).method_7677().method_7972());
        craft.add(numen.field_7498.method_7611(0).method_7677().method_7972());
        Services.NETWORK.sendToPlayer(player, new NumenInventoryPayload(p.uuid(), true, items, craft,
                numen.method_7344().method_7586(), numen.method_7344().method_7589()));
    }
}
