package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.NumenRoster;
import com.dwinovo.numen.network.NumenPayload;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: the roster of companions this player owns (UUID + name).
 * Pushed on owner login (after their dormant companions respawn) and right after
 * a fresh summon, so the client's {@link NumenRoster} panel always reflects the truth.
 */
public record CompanionListPayload(List<Entry> companions) implements NumenPayload {

    /** Cap defends against absurd input; nobody owns hundreds of companions. */
    public static final int MAX = 64;

    /** One companion's roster line. */
    public record Entry(UUID uuid, String name) {}

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "companion_list");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        int n = Math.min(companions.size(), MAX);
        buf.method_10804(n);
        for (int i = 0; i < n; i++) {
            Entry e = companions.get(i);
            buf.method_10797(e.uuid());
            buf.method_10788(e.name(), 256);
        }
    }

    public static CompanionListPayload read(class_2540 buf) {
        int n = Math.min(buf.method_10816(), MAX);
        List<Entry> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(new Entry(buf.method_10790(), buf.method_10800(256)));
        }
        return new CompanionListPayload(list);
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(CompanionListPayload p) {
        java.util.List<NumenRoster.Entry> snapshot = new java.util.ArrayList<>();
        for (Entry e : p.companions()) {
            snapshot.add(new NumenRoster.Entry(e.uuid(), e.name()));
        }
        NumenRoster.instance().replaceAll(snapshot);
    }
}
