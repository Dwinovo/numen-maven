package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;
import com.dwinovo.numen.entity.CompanionRegistry;
import com.dwinovo.numen.entity.Companions;
import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.UUID;

/**
 * Client → Server: the owner asked to permanently delete a companion from the panel (rail ✕ → confirm).
 * This side only checks the companion is the caller's; what dismissal does is {@link Companions#dismiss}.
 */
public record DismissRequestPayload(UUID uuid) implements NumenPayload {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "dismiss_request");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(uuid);
    }

    public static DismissRequestPayload read(class_2540 buf) {
        return new DismissRequestPayload(buf.method_10790());
    }

    /** Server main thread. */
    public static void handle(DismissRequestPayload p, class_3222 owner) {
        MinecraftServer server = ((class_3218) owner.method_37908()).method_8503();
        if (server == null || p.uuid() == null) return;

        // 活体看身体上的主人;休眠 / 没加载的看注册表
        NumenPlayer body = NumenPlayer.findByUuid(server, p.uuid());
        boolean callers;
        if (body != null) {
            callers = body.isOwnedByPlayer(owner.method_5667());
        } else {
            CompanionRegistry.Entry e = CompanionRegistry.get(server).find(p.uuid());
            callers = e != null && e.owner().equals(owner.method_5667());
        }
        if (!callers) return;
        Companions.dismiss(server, owner.method_5667(), List.of(p.uuid()));
    }
}
