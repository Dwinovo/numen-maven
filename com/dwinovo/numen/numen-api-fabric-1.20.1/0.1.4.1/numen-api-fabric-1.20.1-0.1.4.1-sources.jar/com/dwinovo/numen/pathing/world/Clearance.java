package com.dwinovo.numen.pathing.world;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_4050;

/**
 * 净空:身体以某个姿势、脚在某个高度站在一列上,它的碰撞盒(宽 {@link BodyStats#width()},站立或潜行的高)和周围方块的
 * 碰撞箱有没有交叠。头顶是楼梯、活板门、半砖时就按它们真实的碰撞箱判,没有"楼梯可穿"这类分类。
 *
 * <p>交叠的口径照原版:身体的盒先向内收 {@code 1e-7}({@code Player.canPlayerFitWithinBlocksAndEntitiesWhen} 同样收),
 * 贴着的面不算撞上。碰撞箱最高伸到 1.5 格(栅栏、墙),所以脚下那一格也要看。
 */
public final class Clearance {

    /** 原版判"身体放不放得下"时把身体的盒向内收的量。落脚、迈步判脚底与碰撞箱交不交叠用同一个量。 */
    static final double DEFLATE = 1.0E-7;

    private Clearance() {}

    /** 身体以 {@code pose} 站在 {@code (x, z)} 这一列、脚在 {@code feetY} 时放不放得下。 */
    public static boolean fits(class_1922 level, BodyStats body, class_4050 pose, int x, double feetY, int z) {
        return free(level, body, box(body, pose, x + 0.5, feetY, z + 0.5), feetY);
    }

    /**
     * 身体以 {@code pose} 站在 {@code (x, z)} 这一列、脚在 {@code feetY} 时,碰撞箱与它交叠的那些格,自下而上;放得下时为空。
     * 规划要挖开或打开哪几格才站得进去,问的就是这里。
     */
    public static List<class_2338> blockers(class_1922 level, BodyStats body, class_4050 pose, int x, double feetY, int z) {
        return blockers(level, body, pose, x, feetY, z, 0, 0);
    }

    /**
     * 身体以 {@code pose}、脚一直在 {@code feetY},从 {@code (x, z)} 这一列的中心直走到 {@code (x + dx, z + dz)} 那一列的中心,
     * 途中碰撞箱与它交叠的那些格,自下而上。关着的门只占格边,身体站在门格中心碰不到它,走过格边时才撞上——找挡路的门、
     * 要挖开的格问的是这里。走的是斜线时取两端身体盒的包络,比身体真实扫过的范围略大。
     */
    public static List<class_2338> blockers(class_1922 level, BodyStats body, class_4050 pose, int x, double feetY, int z,
                                          int dx, int dz) {
        class_238 swept = box(body, pose, x + 0.5, feetY, z + 0.5).method_991(box(body, pose, x + dx + 0.5, feetY, z + dz + 0.5));
        List<class_2338> out = new ArrayList<>();
        visit(level, body, swept, feetY, pos -> {
            out.add(pos.method_10062());
            return true;
        });
        out.sort((a, b) -> Integer.compare(a.method_10264(), b.method_10264()));
        return out;
    }

    /**
     * 身体以 {@code pose}、脚在 {@code feetY} 时占到的最高一格(碰撞盒的顶在这一格里)。最低一格就是脚所在的格
     * {@link Footing#cellOf}。身体经过哪几格、碰到哪几格,都按这两头数。
     */
    public static int topCell(BodyStats body, class_4050 pose, double feetY) {
        return class_3532.method_15357(feetY + body.height(pose) - DEFLATE);
    }

    /** 身体以 {@code pose} 站在 {@code (x, z)} 这一列、脚在 {@code feetY} 时占着 {@code cell} 这一格。 */
    public static boolean occupies(BodyStats body, class_4050 pose, int x, double feetY, int z, class_2338 cell) {
        return cell.method_10263() == x && cell.method_10260() == z && cell.method_10264() >= Footing.cellOf(feetY)
                && cell.method_10264() <= topCell(body, pose, feetY);
    }

    /**
     * {@code state} 整块实心:碰撞箱正好是整格,不随世界或身体变。身体哪一部分都进不了这样一格,要进去只能先挖掉它。
     */
    public static boolean solid(class_2680 state) {
        return Boxes.whole(state);
    }

    /** 身体以 {@code pose}、脚底中心在 {@code (cx, feetY, cz)} 时的碰撞盒。 */
    static class_238 box(BodyStats body, class_4050 pose, double cx, double feetY, double cz) {
        double half = body.width() / 2;
        return new class_238(cx - half, feetY, cz - half, cx + half, feetY + body.height(pose), cz + half);
    }

    /**
     * 这个盒子与方块碰撞箱有没有交叠。{@code feetY} 是这具身体的脚高,碰撞箱随身体变化的方块按它回答。
     */
    static boolean free(class_1922 level, BodyStats stats, class_238 body, double feetY) {
        return !visit(level, stats, body, feetY, pos -> false);
    }

    /** 与盒子交叠的格逐个交给 {@code hit};它答 false 就停下。有交叠返回 true。 */
    private static boolean visit(class_1922 level, BodyStats stats, class_238 body, double feetY, Predicate<class_2338> hit) {
        class_238 inner = body.method_1011(DEFLATE);
        int x0 = class_3532.method_15357(inner.field_1323);
        int x1 = class_3532.method_15357(inner.field_1320);
        int z0 = class_3532.method_15357(inner.field_1321);
        int z1 = class_3532.method_15357(inner.field_1324);
        // 下面一格的碰撞箱可能高出它自己(栅栏、墙到 1.5)
        int y0 = class_3532.method_15357(inner.field_1322) - 1;
        int y1 = class_3532.method_15357(inner.field_1325);
        class_2338.class_2339 pos = new class_2338.class_2339();
        boolean any = false;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = y0; y <= y1; y++) {
                    for (class_238 box : Boxes.at(level, stats, x, y, z, level.method_8320(pos.method_10103(x, y, z)), feetY)) {
                        if (inner.method_1003(box.field_1323 + x, box.field_1322 + y, box.field_1321 + z,
                                box.field_1320 + x, box.field_1325 + y, box.field_1324 + z)) {
                            any = true;
                            if (!hit.test(pos)) {
                                return true;
                            }
                            break;
                        }
                    }
                }
            }
        }
        return any;
    }
}
