package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;
import com.dwinovo.numen.network.Wire;
import com.dwinovo.numen.program.ModuleSet;
import com.dwinovo.numen.program.NetworkTransport;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Client-to-server payload: the answer to a {@link ClientCallPayload}, the call's result in the shape every API call
 * returns ({@code ApiReply}). When the function changed her modules (a {@code numen.module.save}), the client's new
 * module list rides along as {@code modules}, so the program that is still running sees the new text the next time it
 * uses the module and the client stays the only source of truth. A result can be as long as what the function read
 * (a module's code) and the new module texts ride along, so the payload is {@link Wire.Fragmentable}.
 */
public record ClientCallResultPayload(UUID entityUuid, String callId, String replyJson, Optional<ModuleSet> modules)
        implements NumenPayload, Wire.Fragmentable {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "client_call_result");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        Wire.writeText(buf, callId);
        Wire.writeText(buf, replyJson);
        buf.method_37435(modules, (b, set) -> set.write(b));
    }

    public static ClientCallResultPayload read(class_2540 buf) {
        return new ClientCallResultPayload(buf.method_10790(), Wire.readText(buf), Wire.readText(buf),
                buf.method_37436(ModuleSet::read));
    }

    /** 编码后的字节数。 */
    public int size() {
        return Wire.size(this);
    }

    /** Handler invoked on the server main thread. */
    public static void handle(ClientCallResultPayload p, class_3222 player) {
        NetworkTransport.INSTANCE.answered(player.method_5667(), p);
    }
}
