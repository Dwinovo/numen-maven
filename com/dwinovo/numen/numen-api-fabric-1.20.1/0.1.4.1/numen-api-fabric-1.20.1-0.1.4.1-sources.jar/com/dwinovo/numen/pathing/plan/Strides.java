package com.dwinovo.numen.pathing.plan;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_4050;
import com.dwinovo.numen.pathing.world.BodyStats;
import com.dwinovo.numen.pathing.world.Clearance;
import com.dwinovo.numen.pathing.world.Semantics;
import com.dwinovo.numen.pathing.world.Semantics.Kind;

/** 几种走法共用的小事:身体要腾出的格、泡没泡在水里、脚下的步速、每格走多久。 */
final class Strides {

    private Strides() {}

    /** 身体脚在 {@code feetY} 站在 {@code to} 那一列时挡着它的格,自下而上。 */
    static List<class_2338> at(class_1922 level, BodyStats body, class_2338 to, double feetY) {
        return Clearance.blockers(level, body, class_4050.field_18076, to.method_10263(), feetY, to.method_10260());
    }

    /** 身体脚在 {@code feetY},从 {@code from} 那一列朝 {@code heading} 走进相邻一列,途中挡着它的格,自下而上。 */
    static List<class_2338> across(class_1922 level, BodyStats body, class_2338 from, Heading heading, double feetY) {
        return Clearance.blockers(level, body, class_4050.field_18076, from.method_10263(), feetY, from.method_10260(), heading.dx(), heading.dz());
    }

    /** 几份挡路的格合起来,去重后自下而上。 */
    @SafeVarargs
    static List<class_2338> union(List<class_2338>... lists) {
        List<class_2338> out = new ArrayList<>();
        for (List<class_2338> list : lists) {
            for (class_2338 cell : list) {
                if (!out.contains(cell)) {
                    out.add(cell);
                }
            }
        }
        out.sort(Comparator.comparingInt(class_2338::method_10264));
        return out;
    }

    /** 脚所在的这一格有液体(水、岩浆、含水的方块):站在里面跳不起来。 */
    static boolean feetInFluid(class_1922 level, class_2338 feet) {
        return !level.method_8316(feet).method_15769();
    }

    /** 水:静的与流动的。 */
    private static final java.util.EnumSet<Kind> WATERS = java.util.EnumSet.of(Kind.WATER, Kind.FLOWING_WATER);

    /** 脚所在的这一格泡在水里。 */
    static boolean inWater(class_1922 level, class_2338 feet) {
        return Semantics.isAny(level, feet, WATERS);
    }

    /** 起步与落点两处脚下步速系数的平均:各管半程。 */
    static double speedFactor(class_1922 level, class_2338 from, double fromFeet, class_2338 to, double toFeet) {
        return (Semantics.speedFactor(level, from.method_10263(), fromFeet, from.method_10260())
                + Semantics.speedFactor(level, to.method_10263(), toFeet, to.method_10260())) / 2;
    }

    /** 这一步每走一格要几刻:在水里按水里的步速;否则潜行、疾跑或平走,再按脚下的步速系数放慢。 */
    static double pace(CostModel model, Maneuver m) {
        if (m.wading()) {
            return model.waterStep();
        }
        double pace = m.sneak() ? ActionCosts.SNEAK_ONE_BLOCK
                : m.sprint() ? ActionCosts.SPRINT_ONE_BLOCK : ActionCosts.WALK_ONE_BLOCK;
        return pace / m.speedFactor();
    }

    /** 起跳的价钱:起跳升一格的耗时,加规格的起跳罚分。 */
    static double jump(CostModel model) {
        return ActionCosts.JUMP_ONE_BLOCK + model.spec().jumpPenalty();
    }

    /**
     * 身体从 {@code drop} 高处落到 {@code support}(落定后脚踩的那一格)上摔掉几点血:站着落地、没落进水里,才照身体快照按落差与
     * 那一格算({@link BodySnapshot#fallDamage});落进水里、攀着、浮着不摔。
     *
     * <p>脚踩的那一格是托住脚的碰撞箱所在的格(第 0 层 {@code Footing.supportY})。原版结算摔伤看的是脚底往下 0.2 格处那一格
     * ({@code Entity.getOnPosLegacy}),两者只在托脚的是不到 0.2 格厚的薄片(地毯、一层雪、中继器)时不同:那时原版看的是薄片底下那一块。
     */
    static int fallDamage(CostModel model, class_1922 level, Stance landing, class_2338 support, double drop, boolean wading) {
        if (!landing.grounded() || wading || support == null) {
            return 0;
        }
        return model.body().fallDamage(drop, level.method_8320(support));
    }

    /** 从 {@code drop} 高处落到这个落点的耗时:下落,至少要走回列中心那一截。 */
    static double landing(Maneuver m) {
        return Math.max(ActionCosts.fall(m.drop()), ActionCosts.CENTER_AFTER_FALL);
    }

    /** 落地摔疼的折价:掉的血按 {@link ActionCosts#FALL_DAMAGE_PER_POINT} 折成刻。 */
    static double bruise(Maneuver m) {
        return m.fallDamage() * ActionCosts.FALL_DAMAGE_PER_POINT;
    }

    /**
     * 身体以 {@code start} 待在 {@code from}、走到 {@code to} 以 {@code landing} 待着,这一步里眼睛换不换得了气:起步或落定时
     * 眼睛(列中心、脚高加站立眼高)换不了气({@link Semantics#breathless}),整步都按憋着气算——半截在水里的那一步也算进憋气,
     * 宁可多算。
     */
    static boolean submerged(class_1922 level, BodyStats body, class_2338 from, Stance start, class_2338 to, Stance landing) {
        double eye = body.eyeHeight(class_4050.field_18076);
        return Semantics.breathless(level, from.method_10263() + 0.5, start.feetY() + eye, from.method_10260() + 0.5)
                || Semantics.breathless(level, to.method_10263() + 0.5, landing.feetY() + eye, to.method_10260() + 0.5);
    }
}
