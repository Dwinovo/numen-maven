package com.dwinovo.numen.pathing.plan;

import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2756;
import net.minecraft.class_2784;
import net.minecraft.class_3610;
import net.minecraft.class_4076;
import com.dwinovo.numen.pathing.world.Recall;
import com.dwinovo.numen.pathing.world.Semantics;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

/**
 * 做了一些改动之后的世界:把改动叠在一个只读视图上,自己也是只读视图。一件改动让世界变成什么样只写在这里——挖掉的格
 * 只剩它原来含着的液体,放下的格是那种方块的默认状态,开关过的门连同另一半一起翻转。
 *
 * <p>规划一步时,草稿在它上面叠这一步设想的改动;搜索展开一个节点时,在快照上叠"走到这个节点的那一步"做过的改动,
 * 下一步的前提看到的就是身体此刻真正面对的世界。叠在另一份改动之上时,把那份的改动抄过来、直接读它底下的视图:
 * 前提函数每一步要读几百格,读一格只经一层。
 */
public class EditedView implements WorldView, Recall.Source {

    private final WorldView base;
    /** 改过的格;一件改动都没有时不建表(规划一步时大多数草稿一件也不改)。 */
    private Long2ObjectOpenHashMap<class_2680> changed;

    EditedView(WorldView base) {
        if (base instanceof EditedView under) {
            this.base = under.base;
            if (under.changed != null) {
                this.changed = new Long2ObjectOpenHashMap<>(under.changed);
            }
        } else {
            this.base = base;
        }
    }

    /** {@code base} 做完 {@code edits} 之后的样子;没有改动就是 {@code base} 本身。 */
    public static WorldView after(WorldView base, List<Edit> edits) {
        if (edits.isEmpty()) {
            return base;
        }
        EditedView view = new EditedView(base);
        for (Edit edit : edits) {
            if (edit instanceof Edit.Dig dig) {
                view.dig(dig.pos());
            } else if (edit instanceof Edit.Place place) {
                view.place(place.pos(), place.block());
            } else if (edit instanceof Edit.Door door) {
                view.toggle(door.pos());
            } else if (edit instanceof Edit.Catch caught) {
                // 倒下的水在这一步里就收回了
            }
        }
        return view;
    }

    // ==================== 改动 ====================

    /** 挖掉:只剩这一格原来含着的液体。 */
    void dig(class_2338 pos) {
        set(pos, method_8320(pos).method_26227().method_15759());
    }

    /** 放下一块 {@code block}。 */
    void place(class_2338 pos, class_2248 block) {
        set(pos, block.method_9564());
    }

    /** 倒一桶水:这一格成了水源。 */
    void pour(class_2338 pos) {
        set(pos, class_2246.field_10382.method_9564());
    }

    /** 开关一扇门;门的另一半照原版一起翻转。 */
    void toggle(class_2338 pos) {
        class_2680 state = method_8320(pos);
        set(pos, Semantics.toggled(state));
        if (state.method_26204() instanceof class_2323) {
            class_2338 other = state.method_11654(class_2323.field_10946) == class_2756.field_12607 ? pos.method_10084() : pos.method_10074();
            class_2680 half = method_8320(other);
            if (half.method_27852(state.method_26204())) {
                set(other, Semantics.toggled(half));
            }
        }
    }

    private void set(class_2338 pos, class_2680 state) {
        if (changed == null) {
            changed = new Long2ObjectOpenHashMap<>(4);
        }
        changed.put(pos.method_10063(), state);
    }

    /** 一件改动都没叠时,就是底下那份视图:照它交出记事本;叠了改动的世界不记。 */
    @Override
    public Recall recall() {
        return changed == null && base instanceof Recall.Source source ? source.recall() : null;
    }

    /** 这一格改过。 */
    boolean changed(class_2338 pos) {
        return changed != null && changed.containsKey(pos.method_10063());
    }

    // ==================== 视图 ====================

    @Override
    public class_2680 method_8320(class_2338 pos) {
        if (changed == null) {
            return base.method_8320(pos);
        }
        class_2680 state = changed.get(pos.method_10063());
        return state != null ? state : base.method_8320(pos);
    }

    /** 这一段里改过哪一格,就不敢说整段是空气;没改过的照底下的视图答。 */
    @Override
    public boolean airSection(int x, int y, int z) {
        if (changed != null) {
            long section = class_4076.method_18685(class_4076.method_18675(x), class_4076.method_18675(y),
                    class_4076.method_18675(z));
            for (long cell : changed.keySet()) {
                if (class_4076.method_18691(cell) == section) {
                    return false;
                }
            }
        }
        return base.airSection(x, y, z);
    }

    @Override
    public class_3610 method_8316(class_2338 pos) {
        return method_8320(pos).method_26227();
    }

    @Override
    public class_2586 method_8321(class_2338 pos) {
        return changed(pos) ? null : base.method_8321(pos);
    }

    @Override
    public int method_31605() {
        return base.method_31605();
    }

    @Override
    public int method_31607() {
        return base.method_31607();
    }

    @Override
    public class_2784 border() {
        return base.border();
    }

    @Override
    public boolean ultraWarm() {
        return base.ultraWarm();
    }
}
