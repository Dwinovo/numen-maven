package com.dwinovo.numen.pathing.world;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;

/**
 * 贴面:往一格里放方块时,可以点哪些邻格的哪一面。照原版,点得中的面都能贴——准星点中的是方块的轮廓
 * ({@code getShape},不是碰撞箱),所以台阶、楼梯、栅栏、活板门、玻璃板、火把……只要有轮廓就有面可点,流体、空气没有。
 * 点中的邻格自己若可以被顶替(高草、单层雪),方块会落进那一格而不是要放的格,那一面就不算。放下去的方块要不要支撑、
 * 会不会立刻掉下来,由原版放置规则决定,不在这里判。
 *
 * <p>点在哪:面朝要放的格那一侧,轮廓在这个方向上的最外一层里面积最大的那块面的中心。下半砖的顶面在 0.5 高,
 * 就点在 0.5 高;规划与执行都从这里取这个点。
 */
public final class Faces {

    private Faces() {}

    /** 放方块时点的那一下:点 {@code clicked} 这一格的 {@code side} 面上的 {@code point}。 */
    public record Face(class_2338 clicked, class_2350 side, class_243 point) {}

    /**
     * 眼睛在 {@code eye}、交互距离 {@code range} 时,往 {@code target} 放 {@code placing} 点得中的那个面:能贴的面由
     * {@link #against} 给,点在 {@link #hitPoint};眼睛要在那个面朝外的一侧,射线({@link Sight})第一下碰上它,够得着,放下去
     * 落在 {@code target}。一个都点不中为 null。优先点下面那一格的顶面。规划判"站在这里放得下"与执行时瞄哪一点问的都是它。
     */
    public static Face inSight(class_1922 level, class_243 eye, double range, class_2338 target, class_2248 placing) {
        List<class_2350> sides = new ArrayList<>(against(level, target, placing));
        sides.sort((a, b) -> Boolean.compare(b == class_2350.field_11033, a == class_2350.field_11033));
        for (class_2350 dir : sides) {
            class_2338 clicked = target.method_10093(dir);
            class_2350 side = dir.method_10153();
            class_243 onFace = hitPoint(level, target, dir);
            class_243 point = Sight.inset(onFace, side);
            if (!Sight.facing(eye, onFace, side) || onFace.method_1022(eye) >= range) {
                continue;
            }
            if (!target.equals(Replaceable.landing(level, clicked, side, placing))) {
                continue;
            }
            if (Sight.trace(level, eye, point, clicked).clear(side)) {
                return new Face(clicked, side, point);
            }
        }
        return null;
    }

    /**
     * 往 {@code target} 放 {@code placing} 时,可以点的邻格所在的方向(从 {@code target} 看过去)。点的是那个邻格朝向
     * {@code target} 的那一面,即方向的反向。
     */
    public static Set<class_2350> against(class_1922 level, class_2338 target, class_2248 placing) {
        EnumSet<class_2350> out = EnumSet.noneOf(class_2350.class);
        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbor = target.method_10093(dir);
            class_2680 state = level.method_8320(neighbor);
            if (!state.method_26218(level, neighbor).method_1110() && !Replaceable.replaceableBy(state, placing)) {
                out.add(dir);
            }
        }
        return out;
    }

    /**
     * 要往 {@code target} 放、点 {@code dir} 方向那个邻格时,准星该落的点(绝对坐标)。
     *
     * @throws IllegalArgumentException 那个邻格没有轮廓,点不中
     */
    public static class_243 hitPoint(class_1922 level, class_2338 target, class_2350 dir) {
        return point(level, target.method_10093(dir), dir.method_10153());
    }

    /**
     * 点 {@code block} 这一格的 {@code face} 面时准星该落的点(绝对坐标):轮廓在这个方向上的最外一层里面积最大的那块面的中心。
     * 放方块时点邻格的那一面、用一格方块时点它自己的一面,都从这里取。
     *
     * @throws IllegalArgumentException 那一格没有轮廓,点不中
     */
    public static class_243 point(class_1922 level, class_2338 block, class_2350 face) {
        class_265 shape = level.method_8320(block).method_26218(level, block);
        if (shape.method_1110()) {
            throw new IllegalArgumentException(block + " 没有轮廓,点不中");
        }
        class_2350.class_2351 axis = face.method_10166();
        boolean positive = face.method_10171() == class_2350.class_2352.field_11056;
        double plane = positive ? shape.method_1105(axis) : shape.method_1091(axis);
        class_238 best = null;
        double bestArea = -1;
        for (class_238 box : shape.method_1090()) {
            double edge = positive ? box.method_990(axis) : box.method_1001(axis);
            if (edge != plane) {
                continue;
            }
            double area = faceArea(box, axis);
            if (area > bestArea) {
                best = box;
                bestArea = area;
            }
        }
        class_243 center = best.method_1005();
        class_243 onFace = switch (axis) {
            case field_11048 -> new class_243(plane, center.field_1351, center.field_1350);
            case field_11052 -> new class_243(center.field_1352, plane, center.field_1350);
            case field_11051 -> new class_243(center.field_1352, center.field_1351, plane);
        };
        return onFace.method_1031(block.method_10263(), block.method_10264(), block.method_10260());
    }

    private static double faceArea(class_238 box, class_2350.class_2351 axis) {
        return switch (axis) {
            case field_11048 -> box.method_17940() * box.method_17941();
            case field_11052 -> box.method_17939() * box.method_17941();
            case field_11051 -> box.method_17939() * box.method_17940();
        };
    }
}
