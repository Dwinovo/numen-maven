package com.dwinovo.numen.pathing.world;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

/**
 * 视线:从眼睛到一格方块某一面上的一点,中间隔着什么。"看不看得见那一格"只在这里判——搜索在快照上调它(用一格方块的站位、
 * 挖一格时挡着几格),执行在活世界上调它(到达复核、挖放与按键的瞄点)。
 *
 * <p>口径照原版准星拾取({@code BlockGetter.clip},{@code ClipContext.Block.OUTLINE},不看流体):沿射线逐格,按方块轮廓
 * (连同交互轮廓的覆写)算碰没碰上。与原版的 clip 只差一处:碰上别的格之后不停,一直数到目标,把挡着的格分成两种——
 * <ul>
 *   <li><b>软遮挡</b>({@link #soft}):往里放一块别种方块时原版会直接顶掉的格(第 0 层 {@link Replaceable#displaced}:草、高草、
 *       蕨、枯灌木、单层雪、没长满的藤蔓……)。一下就掉、清掉它不算改建;清不清归用那一格的一方(挖掘执行清掉它,纯按键点到的就是它);</li>
 *   <li><b>硬遮挡</b>:其余有轮廓的格,要挖开才看得见。</li>
 * </ul>
 */
public final class Sight {

    /** 瞄面上的点时往面里收这么多:射线不贴着棱,从面朝外那一侧射过来才碰得上这一面。 */
    public static final double INSET = 0.02;
    /** 射线打到瞄点之后再往前伸这么多,保证穿进那一面。 */
    private static final double THROUGH = 0.1;

    private Sight() {}

    /**
     * 一次视线:从眼睛朝 {@code point} 射过去的结果。
     *
     * @param point   瞄点
     * @param reached 射线碰上了目标那一格的轮廓
     * @param face    碰上的是目标的哪一面;没碰上为 null
     * @param hard    路上挡着的硬遮挡,按先后
     * @param soft    路上挡着的软遮挡,按先后
     */
    public record Trace(class_243 point, boolean reached, class_2350 face, List<class_2338> hard, List<class_2338> soft) {

        /** 第一下就碰上目标:准星对过去就落在它上面。给了 {@code side} 时还得是那一面。 */
        public boolean clear(class_2350 side) {
            return clearable(side) && soft.isEmpty();
        }

        /** 只隔着软遮挡:清掉它们就看得见。给了 {@code side} 时碰上的还得是那一面。 */
        public boolean clearable(class_2350 side) {
            return reached && hard.isEmpty() && (side == null || face == side);
        }
    }

    /** 软遮挡:挡在视线上、用之前一下清掉就行的格。判据只在这里:往里放一块别种方块时原版会直接顶掉它。 */
    public static boolean soft(class_2680 state) {
        return Replaceable.displaced(state);
    }

    /**
     * 从 {@code eye} 朝 {@code point} 射一条视线,数到 {@code target} 为止:碰没碰上它、碰上的是哪一面、路上隔着哪些格。
     * 射线打到瞄点再往前伸一点,穿进那一面。
     */
    public static Trace trace(class_1922 level, class_243 eye, class_243 point, class_2338 target) {
        class_243 through = point.method_1019(point.method_1020(eye).method_1029().method_1021(THROUGH));
        List<class_2338> hard = new ArrayList<>();
        List<class_2338> soft = new ArrayList<>();
        class_3965 hit = class_1922.method_17744(eye, through, level, (view, pos) -> {
            class_2680 state = view.method_8320(pos);
            class_265 shape = state.method_26218(view, pos);
            class_3965 on = view.method_17745(eye, through, pos, shape, state);
            if (on == null) {
                return null;
            }
            if (pos.equals(target)) {
                return on;
            }
            (soft(state) ? soft : hard).add(pos.method_10062());
            return null;
        }, view -> null);
        return new Trace(point, hit != null, hit == null ? null : hit.method_17780(), List.copyOf(hard),
                List.copyOf(soft));
    }

    /**
     * 从 {@code eye} 挖 {@code target} 时朝哪一点看:朝 {@code points} 里的每一点各打一条视线,路上挡着的格(硬的、软的)都
     * {@code clears} 的那些里,取硬遮挡最少的那一条;一条都没有为 null——看得见它的每一处都隔着清不掉的格。挖一格时给站位定价
     * (瞄点是 {@link #faces})与挖的时候先清哪一格(瞄点是身体够得着的那几点)都按这一条挑。
     */
    public static Trace dig(class_1922 level, class_243 eye, class_2338 target, List<class_243> points, Predicate<class_2338> clears) {
        Trace best = null;
        for (class_243 point : points) {
            Trace trace = trace(level, eye, point, target);
            if ((best == null || trace.hard().size() < best.hard().size())
                    && trace.hard().stream().allMatch(clears) && trace.soft().stream().allMatch(clears)) {
                best = trace;
            }
        }
        return best;
    }

    /** {@code target} 朝着 {@code eye} 的各面上的瞄点({@link Faces#point} 往面里收 {@link #INSET})。 */
    public static List<class_243> faces(class_1922 level, class_243 eye, class_2338 target) {
        List<class_243> out = new ArrayList<>(3);
        for (class_2350 side : class_2350.values()) {
            class_243 onFace = Faces.point(level, target, side);
            if (facing(eye, onFace, side)) {
                out.add(inset(onFace, side));
            }
        }
        return out;
    }

    /** 用一格方块时点它 {@code side} 面的那一点:面上的瞄点({@link Faces#point})往面里收 {@link #INSET}。 */
    public static class_243 aim(class_1922 level, class_2338 target, class_2350 side) {
        return inset(Faces.point(level, target, side), side);
    }

    /** 面上的点往面里收 {@link #INSET}。 */
    public static class_243 inset(class_243 onFace, class_2350 side) {
        return onFace.method_1020(class_243.method_24954(side.method_10163()).method_1021(INSET));
    }

    /** 眼睛在这个面朝外的一侧:从这里看得到这一面。 */
    public static boolean facing(class_243 eye, class_243 onFace, class_2350 side) {
        class_243 normal = class_243.method_24954(side.method_10163());
        return eye.method_1020(onFace).method_1026(normal) > 1.0E-4;
    }

    /** 这一格有没有可点的轮廓:空气、流体没有,点不中。 */
    public static boolean clickable(class_1922 level, class_2338 pos) {
        return !level.method_8320(pos).method_26218(level, pos).method_1110();
    }

    /**
     * {@code target} 的 {@code side} 面敞不敞开:面前那一格不是整块的硬遮挡,视线过得去。整块的硬方块贴着的面从哪儿都看不见,
     * 不必再打射线。
     */
    public static boolean open(class_1922 level, class_2338 target, class_2350 side) {
        class_2338 front = target.method_10093(side);
        class_2680 state = level.method_8320(front);
        return soft(state) || !class_2248.method_9614(state.method_26218(level, front));
    }

    /**
     * 从 {@code eye} 用 {@code target} 的 {@code side} 面:这一面敞开({@link #open})、面朝着眼睛、面上的点在交互距离
     * {@code reach} 以内、视线上没有硬遮挡、碰上的就是这一面——这样交出这一次的视线(可能还隔着软遮挡);否则为 null。
     * 面前贴着整块硬方块的面不算,哪怕从一道细缝里斜着看得到它:那样的线差半个鼠标像素就落到别的方块上。
     */
    public static Trace use(class_1922 level, class_243 eye, double reach, class_2338 target, class_2350 side) {
        if (!open(level, target, side)) {
            return null;
        }
        class_243 onFace = Faces.point(level, target, side);
        if (!facing(eye, onFace, side) || onFace.method_1022(eye) >= reach) {
            return null;
        }
        Trace trace = trace(level, eye, inset(onFace, side), target);
        return trace.clearable(side) ? trace : null;
    }
}
