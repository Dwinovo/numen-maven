package com.dwinovo.numen.pathing.world;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2488;
import net.minecraft.class_2541;
import net.minecraft.class_2680;
import net.minecraft.class_5777;
import net.minecraft.class_7130;
import net.minecraft.class_8237;

/**
 * 放置时方块真正落在哪一格,照原版 {@code BlockPlaceContext}:点中的那一格本身可以被顶替(高草、单层雪、藤蔓……),方块就落
 * 进点中的那一格;否则落进点中那一面前面的一格,那一格也得可以被顶替,不然放不下。规划要问许可、记账的是这一格,
 * 执行时以真实落点为准。
 *
 * <p>"可以被顶替"是原版 {@code BlockState.canBeReplaced(BlockPlaceContext)} 对"放一个与它不同种的方块"的回答。那个方法要一个
 * 带 {@code Level} 的放置上下文,搜索用的只读视图给不出,所以这里按同一套规则直接回答:默认看方块的 replaceable 属性
 * (空气、流体、草、花、火……);原版 1.21.1 里对"放别的方块"答得和属性不一样的,是雪层(只有一层时)、藤蔓(五个面
 * 没长满时)、发光地衣与幽匿脉络(总是)、瓶子草作物(从不)。放的与这一格同种时原版是叠放(加一层雪、合成双层半砖),
 * 这一格没有空出来给新方块,答不能。
 */
public final class Replaceable {

    private Replaceable() {}

    /** 拿着 {@code placing} 这种方块往 {@code state} 所在的格里放,原来的方块能不能被直接顶替。 */
    public static boolean replaceableBy(class_2680 state, class_2248 placing) {
        return state.method_26204() != placing && displaced(state);
    }

    /**
     * 往这一格里放一块与它不同种的方块时,它会被直接顶掉:草、高草、蕨、枯灌木、只有一层的雪、没长满的藤蔓、发光地衣……
     * 花不在里面——原版的花不可替换,放方块时顶不掉它。
     */
    public static boolean displaced(class_2680 state) {
        class_2248 block = state.method_26204();
        if (block instanceof class_2488) {
            return state.method_11654(class_2488.field_11518) == 1;
        }
        if (block instanceof class_2541) {
            return class_2541.field_11697.values().stream().filter(state::method_11654).count()
                    < class_2541.field_11697.size();
        }
        if (block instanceof class_5777 || block instanceof class_7130) {
            return true;
        }
        if (block instanceof class_8237) {
            return false;
        }
        return state.method_45474();
    }

    /**
     * 拿着 {@code placing} 点 {@code clicked} 这一格的 {@code face} 面,方块真正落在哪一格;放不下返回 null。
     */
    public static class_2338 landing(class_1922 level, class_2338 clicked, class_2350 face, class_2248 placing) {
        if (replaceableBy(level.method_8320(clicked), placing)) {
            return clicked;
        }
        class_2338 front = clicked.method_10093(face);
        return replaceableBy(level.method_8320(front), placing) ? front : null;
    }
}
