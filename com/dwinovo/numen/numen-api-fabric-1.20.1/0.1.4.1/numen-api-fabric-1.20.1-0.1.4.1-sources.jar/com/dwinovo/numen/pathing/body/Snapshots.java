package com.dwinovo.numen.pathing.body;

import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_3222;
import net.minecraft.class_4050;
import net.minecraft.class_5635;
import com.dwinovo.numen.pathing.plan.BodySnapshot;
import com.dwinovo.numen.pathing.plan.Breath;
import com.dwinovo.numen.pathing.world.BodyStats;

/**
 * 从一具真实的身体上抄下规划要的身体快照,原版口径只此一处:尺寸取原版的姿势尺寸,迈步取迈步高度,起跳、重力、交互距离见
 * {@link BodyCompat};这一代的原版没有摔落、水下移动、挖掘速度的属性,摔落的安全高度按跳跃提升效果算,水下移动按深海探索者附魔算,
 * 挖掘速度的水下系数按水下速掘附魔算。细雪托不托得住照原版看脚上的皮靴,冰霜行者看靴子的附魔,游戏模式、血量、饱食度、
 * 主背包照抄;氧气、水下呼吸附魔、水下呼吸类效果还剩几刻、头上是不是海龟壳照抄,原版永远不扣氧
 * 的(能在水下呼吸、无敌)记成效果无穷。
 *
 * <p>只在世界所在的线程上调用;抄出来的快照可以交给搜索线程。
 */
public final class Snapshots {

    private Snapshots() {}

    public static BodySnapshot of(class_3222 body) {
        BodyStats stats = stats(body);
        // 这一代没有挖掘效率、方块破坏速度属性:效率只来自工具自己的效率附魔(DigTime 按工具算),破坏速度恒为 1
        BodySnapshot.Mining mining = new BodySnapshot.Mining(0, 1.0,
                class_1890.method_8200(body) ? 1.0 : 0.2,
                class_1292.method_5576(body) ? class_1292.method_5575(body) : -1,
                body.method_6059(class_1294.field_5901) ? body.method_6112(class_1294.field_5901).method_5578() : -1);
        List<class_1799> inventory = List.copyOf(body.method_31548().field_7547);
        class_1293 jump = body.method_6112(class_1294.field_5913);
        return new BodySnapshot(stats, body.field_13974.method_14257(), body.method_6032(),
                3.0 + (jump == null ? 0 : jump.method_5578() + 1),
                1.0, body.method_7344().method_7586(),
                Math.min(3, class_1890.method_8232(body)) / 3.0, inventory, mining, breath(body));
    }

    /**
     * 憋气的本钱。水下呼吸类效果照原版 {@code MobEffectUtil.hasWaterBreathing} 认水下呼吸与潮涌能量两种,取剩得久的;
     * 能在水下呼吸的实体({@code canBreatheUnderwater})与无敌的玩家原版不扣氧({@code LivingEntity.baseTick}),记成无穷。
     */
    private static Breath breath(class_3222 body) {
        double shield = body.method_6094() || body.method_31549().field_7480 ? Double.POSITIVE_INFINITY
                : Math.max(remaining(body, class_1294.field_5923), remaining(body, class_1294.field_5927));
        return new Breath(body.method_5669(), body.method_5748(), class_1890.method_8211(body),
                shield, body.method_6118(class_1304.field_6169).method_31574(class_1802.field_8090));
    }

    /** 这个效果还剩几刻;没有为 0,不限时为无穷。 */
    private static double remaining(class_3222 body, class_1291 effect) {
        class_1293 instance = body.method_6112(effect);
        if (instance == null) {
            return 0;
        }
        return instance.method_48559() ? Double.POSITIVE_INFINITY : instance.method_5584();
    }

    /** 第 0 层要的那几项物理量:尺寸、眼高、迈步、起跳、重力、交互距离、细雪与冰霜行者。 */
    public static BodyStats stats(class_3222 body) {
        return new BodyStats(body.method_18377(class_4050.field_18076), body.method_18377(class_4050.field_18081),
                body.method_18381(class_4050.field_18076), body.method_18381(class_4050.field_18081),
                body.method_49476(), BodyCompat.JUMP_STRENGTH, BodyCompat.gravity(body),
                BodyCompat.blockReach(body), class_5635.method_32355(body), frostWalker(body));
    }

    /** 脚上的靴子带冰霜行者。 */
    private static boolean frostWalker(class_3222 body) {
        return class_1890.method_8225(class_1893.field_9122,
                body.method_6118(class_1304.field_6166)) > 0;
    }
}
