package com.dwinovo.numen.pathing.drive;

import com.dwinovo.numen.pathing.body.Aim;
import com.dwinovo.numen.pathing.body.BodyCompat;
import com.dwinovo.numen.pathing.body.Controls;
import com.dwinovo.numen.pathing.body.Controls.Key;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * 朝一个水平的点走:停在那儿、不减速地穿过去,或压着速度走过去。停下时身体朝着那一点,每刻在"按前进、松开、按后退"
 * 三者里挑一个:照原版的移动与摩擦往后推算这一刻按下它、之后一直松着,身体最后停在哪,挑停得离那一点最近的;身体在空中
 * 时连同落地前的那几刻一起推算。
 *
 * <p>推算用原版的量:地上每刻的加速度是移动速度属性乘 {@code 0.216 / 方块摩擦³},速度每刻乘方块摩擦乘 0.91;空中加速度
 * 0.02(疾跑 0.026),速度每刻乘 0.91。
 *
 * <p>只在脚踏实地时转身;腾空时不回身,按身体此刻朝着的方向前进或后退来修正——空中转过身去,落地就是背对着路。
 */
final class Steering {

    /** 原版方块默认摩擦。 */
    private static final double DEFAULT_FRICTION = 0.6;
    private static final double AIR_FRICTION = 0.91;
    /** 原版速度小于它就归零。 */
    private static final double REST = 0.003;
    /** 推算的最长刻数。 */
    private static final int HORIZON = 80;
    /** 离目标点这么近、速度这么小就算停住了。 */
    static final double AT = 0.05;

    private Steering() {}

    /** 不减速地朝 {@code (x, z)} 走。 */
    static void pass(class_3222 body, Controls keys, double x, double z) {
        if (body.method_24828()) {
            Aim.faceToward(body, x, z);
        }
        keys.press(Key.FORWARD);
        keys.release(Key.BACK);
    }

    /**
     * 朝 {@code (x, z)} 走,沿那个方向的速度不超过 {@code speed}(格每刻):低于它就按前进,否则松开。走出边沿时用它压住
     * 冲出去的速度,离地之后再由 {@link #stop} 在空中修正落点。
     */
    static void approach(class_3222 body, Controls keys, double x, double z, double speed) {
        Aim.faceToward(body, x, z);
        double yaw = Math.toRadians(body.method_36454());
        class_243 motion = body.method_18798();
        double along = motion.field_1352 * -Math.sin(yaw) + motion.field_1350 * Math.cos(yaw);
        keys.release(Key.BACK);
        keys.set(Key.FORWARD, along < speed);
    }

    /** 按住前进的下一刻,身体沿它此刻朝着的方向会挪多远:原版先把这一刻的输入加速度加进速度,再移动。 */
    static double nextStride(class_3222 body) {
        double yaw = Math.toRadians(body.method_36454());
        class_243 motion = body.method_18798();
        double along = motion.field_1352 * -Math.sin(yaw) + motion.field_1350 * Math.cos(yaw);
        return along + (body.method_24828() ? groundAccel(body) : (body.method_5624() ? 0.026 : 0.02) * 0.98);
    }

    /**
     * 停在 {@code (x, z)};身体在空中时落在脚高 {@code landingY}。
     *
     * @return 已经停在那一点上
     */
    static boolean stop(class_3222 body, Controls keys, double x, double z, double landingY) {
        double dx = x - body.method_23317();
        double dz = z - body.method_23321();
        double distance = Math.sqrt(dx * dx + dz * dz);
        class_243 motion = body.method_18798();
        double speed = Math.sqrt(motion.field_1352 * motion.field_1352 + motion.field_1350 * motion.field_1350);
        keys.release(Key.FORWARD);
        keys.release(Key.BACK);
        if (distance < AT && speed < REST * 10) {
            return true;
        }
        // 只在地上转身;腾空时不回身,沿身体此刻朝着的方向按前进后退修正
        if (distance >= AT && body.method_24828()) {
            Aim.faceToward(body, x, z);
        }
        double yaw = Math.toRadians(body.method_36454());
        double fx = -Math.sin(yaw);
        double fz = Math.cos(yaw);
        double ahead = dx * fx + dz * fz;
        double along = motion.field_1352 * fx + motion.field_1350 * fz;
        int airLeft = body.method_24828() ? 0 : ticksToLand(body.method_23318(), motion.field_1351, landingY, BodyCompat.gravity(body));
        double groundAccel = groundAccel(body);
        double groundFriction = friction(body) * 0.91;
        double airAccel = (body.method_5624() ? 0.026 : 0.02) * 0.98;
        double best = Double.POSITIVE_INFINITY;
        int choice = 0;
        for (int action : new int[] {1, 0, -1}) {
            double rest = simulate(along, airLeft, action, groundAccel, groundFriction, airAccel);
            double miss = Math.abs(rest - ahead);
            if (miss < best - 1.0E-4) {
                best = miss;
                choice = action;
            }
        }
        if (choice > 0) {
            keys.press(Key.FORWARD);
        } else if (choice < 0) {
            keys.press(Key.BACK);
        }
        return false;
    }

    /**
     * 这一刻按 {@code action}(1 前进、0 松开、-1 后退)、之后一直松着,身体沿直线还会走多远才停住:先在空中飞完
     * {@code airLeft} 刻(在地上为 0),再在地上滑到停。
     */
    private static double simulate(double along, int airLeft, int action,
                                   double groundAccel, double groundFriction, double airAccel) {
        double pos = 0;
        double m = along;
        for (int t = 0; t < HORIZON; t++) {
            int input = t == 0 ? action : 0;
            if (t < airLeft) {
                m += airAccel * input;
                pos += m;
                m *= AIR_FRICTION;
            } else {
                m += groundAccel * input;
                pos += m;
                m *= groundFriction;
                if (Math.abs(m) < REST) {
                    break;
                }
            }
        }
        return pos;
    }

    /** 从脚高 {@code y}、竖直速度 {@code vy} 落到 {@code landingY} 要几刻(原版先移动,再减重力乘 0.98)。 */
    private static int ticksToLand(double y, double vy, double landingY, double gravity) {
        int ticks = 0;
        while (y > landingY && ticks < HORIZON) {
            y += vy;
            vy = (vy - gravity) * 0.98;
            ticks++;
        }
        return Math.max(ticks, 1);
    }

    /** 地上按前进一刻加的速度:原版 {@code getFrictionInfluencedSpeed} 乘输入的 0.98。 */
    private static double groundAccel(class_3222 body) {
        double f = friction(body);
        return body.method_6029() * (0.21600002 / (f * f * f)) * 0.98;
    }

    /** 脚下影响移动的那一格的摩擦(原版看脚下半格处)。 */
    private static double friction(class_3222 body) {
        class_2338 below = class_2338.method_49637(body.method_23317(), body.method_23318() - 0.5000001, body.method_23321());
        float friction = body.method_37908().method_8320(below).method_26204().method_9499();
        return friction > 0 ? friction : DEFAULT_FRICTION;
    }
}
