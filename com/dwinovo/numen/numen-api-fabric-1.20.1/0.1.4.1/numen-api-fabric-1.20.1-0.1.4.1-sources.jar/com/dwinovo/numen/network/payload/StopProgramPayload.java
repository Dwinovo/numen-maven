package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.OwnedBody;
import com.dwinovo.numen.network.Wire;
import com.dwinovo.numen.program.ServerPrograms;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Client-to-server payload: "stop the program I sent". Two ways to stop, both the client's call because they are about
 * the client's side of things — the owner spoke, the stop button, an external brain took over, the connection is
 * closing:
 * <ul>
 *   <li>{@code cutOff = false}: stop between calls with {@code why} as the reason (the owner spoke, an urgent event the
 *       client synthesised); the call in flight finishes first, a body job it waits for keeps running;</li>
 *   <li>{@code cutOff = true}: the turn is cut off, the program stops at once; {@code stopBody} says whether the body
 *       job was stopped too ({@link CancelTasksPayload} does that), so the receipt tells the truth about it.</li>
 * </ul>
 * Urgent events the server emits itself it judges itself, with the same rule ({@code EventQueue.isUrgent}); they never
 * come through here. Only the owner's program, and only the one named by {@code programId}, is touched.
 */
public record StopProgramPayload(UUID entityUuid, String programId, boolean cutOff, boolean stopBody, String why)
        implements NumenPayload {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "stop_program");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        Wire.writeText(buf, programId);
        buf.writeBoolean(cutOff);
        buf.writeBoolean(stopBody);
        Wire.writeText(buf, why);
    }

    public static StopProgramPayload read(class_2540 buf) {
        return new StopProgramPayload(buf.method_10790(),
                Wire.readText(buf),
                buf.readBoolean(),
                buf.readBoolean(),
                Wire.readText(buf));
    }

    /** Handler invoked on the server main thread. */
    public static void handle(StopProgramPayload p, class_3222 player) {
        NumenPlayer companion = NumenPlayer.findByUuid(player.method_37908().method_8503(), p.entityUuid());
        if (companion == null || !companion.isOwnedByPlayer(player.method_5667())) {
            Constants.LOG.debug("[numen-net] stop_program for {} ignored: not the sender's companion", p.entityUuid());
            return;
        }
        if (p.cutOff()) {
            ServerPrograms.cutOff(p.entityUuid(), p.programId(), p.stopBody());
        } else {
            ServerPrograms.interrupt(p.entityUuid(), p.programId(), p.why());
        }
    }
}
