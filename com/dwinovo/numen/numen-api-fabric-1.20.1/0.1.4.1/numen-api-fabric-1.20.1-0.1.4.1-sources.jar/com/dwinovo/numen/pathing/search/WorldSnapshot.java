package com.dwinovo.numen.pathing.search;

import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2841;
import net.minecraft.class_3610;
import net.minecraft.class_4076;
import net.minecraft.class_5539;

/**
 * 搜索视图:派发搜索时在世界所在的线程上拷贝一块区域里已加载区块的方块段,工作线程只读这份拷贝,不碰活世界。
 * 拷贝的是每个非空区段的方块调色板({@code PalettedContainer.copy}),全空的区段记为空气;世界边界与建筑高度一并抄下。
 * 区域是以一个区块为中心、边长 {@code 2·radius+1} 的正方形,没加载的区块留空,{@link #isLoaded} 答否。
 *
 * <p>拷贝之后只读,不再变;多个线程同时读是安全的。方块实体不拷,读出来都是 null——一格有没有方块实体是方块状态的事,
 * 里面装着什么只在世界所在的线程上读。
 */
public final class WorldSnapshot implements SearchView {

    private static final class_2680 AIR = class_2246.field_10124.method_9564();

    /** 一个区块的方块段从哪来:给出那个区块的全部区段,没加载为 null。只在世界所在的线程上调用。 */
    @FunctionalInterface
    public interface Sections {
        class_2826[] of(int chunkX, int chunkZ);
    }

    private final int minChunkX;
    private final int minChunkZ;
    private final int side;
    /** [区块][区段]:区块没加载为 null,区段全空为 null。 */
    private final class_2841<class_2680>[][] chunks;
    private final int minBuildHeight;
    private final int height;
    private final int minSection;
    private final class_2784 border;
    private final boolean ultraWarm;

    @SuppressWarnings("unchecked")
    private WorldSnapshot(class_5539 heights, class_2784 border, boolean ultraWarm, Sections source,
                          int centerX, int centerZ, int radius) {
        this.minChunkX = centerX - radius;
        this.minChunkZ = centerZ - radius;
        this.side = 2 * radius + 1;
        this.chunks = new class_2841[side * side][];
        this.minBuildHeight = heights.method_31607();
        this.height = heights.method_31605();
        this.minSection = heights.method_32891();
        this.border = copy(border);
        this.ultraWarm = ultraWarm;
        for (int i = 0; i < side; i++) {
            for (int j = 0; j < side; j++) {
                class_2826[] sections = source.of(minChunkX + i, minChunkZ + j);
                if (sections == null) {
                    continue;
                }
                class_2841<class_2680>[] states = new class_2841[sections.length];
                for (int s = 0; s < sections.length; s++) {
                    if (sections[s] != null && !sections[s].method_38292()) {
                        states[s] = sections[s].method_12265().method_39957();
                    }
                }
                chunks[i * side + j] = states;
            }
        }
    }

    /** 派发一次搜索时拷贝的半径(区块数):以起点所在区块为中心,边长 13 个区块,约两百格见方。 */
    public static final int SEARCH_RADIUS = 6;

    /** 为从 {@code start} 出发的一次搜索拷贝快照:以它所在的区块为中心、{@link #SEARCH_RADIUS} 为半径。必须在世界所在的线程上调用。 */
    public static WorldSnapshot around(class_1937 level, class_2338 start) {
        return capture(level, class_4076.method_18675(start.method_10263()), class_4076.method_18675(start.method_10260()),
                SEARCH_RADIUS);
    }

    /**
     * 拷贝 {@code level} 里以区块 {@code (centerX, centerZ)} 为中心、半径 {@code radius} 个区块的已加载区块。必须在
     * {@code level} 所在的线程上调用;不加载任何区块。
     */
    public static WorldSnapshot capture(class_1937 level, int centerX, int centerZ, int radius) {
        return capture(level, level.method_8621(), level.method_8597().comp_644(), (cx, cz) -> {
            class_2818 chunk = level.method_8398().method_21730(cx, cz);
            return chunk == null ? null : chunk.method_12006();
        }, centerX, centerZ, radius);
    }

    /** 同上,方块段、建筑高度、世界边界与维度倒不倒得出水由调用方给出。 */
    public static WorldSnapshot capture(class_5539 heights, class_2784 border, boolean ultraWarm,
                                        Sections source, int centerX, int centerZ, int radius) {
        if (radius < 0) {
            throw new IllegalArgumentException("半径不能为负:" + radius);
        }
        return new WorldSnapshot(heights, border, ultraWarm, source, centerX, centerZ, radius);
    }

    /** 世界边界抄一份静止的:正在缩放的边界按此刻的大小。 */
    private static class_2784 copy(class_2784 live) {
        class_2784 copy = new class_2784();
        copy.method_11978(live.method_11964(), live.method_11980());
        copy.method_11969(live.method_11965());
        return copy;
    }

    private class_2841<class_2680>[] chunk(int x, int z) {
        int i = class_4076.method_18675(x) - minChunkX;
        int j = class_4076.method_18675(z) - minChunkZ;
        if (i < 0 || j < 0 || i >= side || j >= side) {
            return null;
        }
        return chunks[i * side + j];
    }

    @Override
    public boolean isLoaded(int x, int z) {
        return chunk(x, z) != null;
    }

    @Override
    public class_2680 method_8320(class_2338 pos) {
        class_2841<class_2680>[] states = chunk(pos.method_10263(), pos.method_10260());
        if (states == null) {
            return AIR;
        }
        int index = class_4076.method_18675(pos.method_10264()) - minSection;
        if (index < 0 || index >= states.length || states[index] == null) {
            return AIR;
        }
        return states[index].method_12321(pos.method_10263() & 15, pos.method_10264() & 15, pos.method_10260() & 15);
    }

    /** 没加载的区块、全空的区段(拷贝时记为空)、建筑高度之外,读出来都是空气。 */
    @Override
    public boolean airSection(int x, int y, int z) {
        class_2841<class_2680>[] states = chunk(x, z);
        if (states == null) {
            return true;
        }
        int index = class_4076.method_18675(y) - minSection;
        return index < 0 || index >= states.length || states[index] == null;
    }

    @Override
    public class_3610 method_8316(class_2338 pos) {
        return method_8320(pos).method_26227();
    }

    @Override
    public class_2586 method_8321(class_2338 pos) {
        return null;
    }

    @Override
    public int method_31605() {
        return height;
    }

    @Override
    public int method_31607() {
        return minBuildHeight;
    }

    @Override
    public class_2784 border() {
        return border;
    }

    @Override
    public boolean ultraWarm() {
        return ultraWarm;
    }
}
