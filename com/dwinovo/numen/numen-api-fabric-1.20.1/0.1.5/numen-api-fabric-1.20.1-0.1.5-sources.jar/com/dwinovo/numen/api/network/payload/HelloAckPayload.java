package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.network.NumenPayload;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.network.ClientPayloadSink;

/**
 * Server → Client: 收下了 {@link HelloPayload}(协议对得上)——这位玩家能不能改服务器上的配置(模型档案与 key、外部大脑……,
 * 见 {@code Authority}),以及他是不是这台服务器的房主(他的"我的"就是服务器目录那一份,见 {@code Homes#isHost})。
 * 只发给协议对得上的客户端,格式随协议走。
 */
public record HelloAckPayload(boolean admin, boolean host) implements NumenPayload {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "hello_ack");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.writeBoolean(admin);
        buf.writeBoolean(host);
    }

    public static HelloAckPayload read(class_2540 buf) {
        return new HelloAckPayload(buf.readBoolean(), buf.readBoolean());
    }

    /** Client main thread. */
    public static void handle(HelloAckPayload p) {
        ClientPayloadSink.helloAck.accept(p);
    }
}
