package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.network.NumenPayload;
import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.network.Wire;
import com.dwinovo.numen.api.program.NetworkTransport;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Client-to-server payload: the answer to a {@link ClientCallPayload}, the call's result in the shape every API call
 * returns ({@code ApiReply}). A result can be as long as what the function read on the client, so the payload is
 * {@link Wire.Fragmentable}.
 */
public record ClientCallResultPayload(UUID entityUuid, String callId, String replyJson)
        implements NumenPayload, Wire.Fragmentable {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "client_call_result");

    /** 编码后的字节数。 */
    public int size() {
        return Wire.size(this);
    }

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        Wire.writeText(buf, callId);
        Wire.writeText(buf, replyJson);
    }

    public static ClientCallResultPayload read(class_2540 buf) {
        return new ClientCallResultPayload(buf.method_10790(), Wire.readText(buf), Wire.readText(buf));
    }

    /** Handler invoked on the server main thread. */
    public static void handle(ClientCallResultPayload p, class_3222 player) {
        NetworkTransport.INSTANCE.answered(player.method_5667(), p);
    }
}
