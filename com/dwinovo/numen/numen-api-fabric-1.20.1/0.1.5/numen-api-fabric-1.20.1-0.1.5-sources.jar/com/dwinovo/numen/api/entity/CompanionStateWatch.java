package com.dwinovo.numen.api.entity;

import com.dwinovo.numen.api.brain.Presence;
import com.dwinovo.numen.api.network.payload.NumenStatePayload;
import com.dwinovo.numen.api.network.payload.RequestStatePayload;
import com.dwinovo.numen.api.network.NumenNetwork;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * 同伴身上的状态一变就推一份给主人的客户端,让 agent 循环不必花一整轮
 * {@code status_self} 去重新发现自己带着什么、身上有什么效果。
 *
 * <h2>为什么非推不可</h2>
 * 渲染那块提示词的代码在<b>客户端</b>,而 companion 的 36 格从不同步给客户端——原版只同步
 * 装备槽,背包是每个玩家的私有数据。客户端手上根本没有背包可遍历,而构造请求是同步的,
 * 不能现场等一个网络往返。所以只能由服务端把它推过去,让客户端的缓存始终是新鲜的。
 *
 * <h2>为什么要检测变化</h2>
 * 省的不是提示词 token(那块每次请求都得带,它从不进历史),是<b>包和序列化</b>。不检测就得
 * 每 tick 推一个,20 包/秒/同伴,每包 36 个 {@code ItemStack};而客户端只在发请求那一刻读一次,
 * 她十秒不说话,那 200 个包里 199 个白发。服务器上同伴一多就更明显。
 *
 * <h2>为什么是自己遍历,不挂原版监听器</h2>
 * 原版的 {@code ContainerListener} 确实白送一份算好的 diff,但它要跟着菜单换(广播的只有
 * 当前菜单,开箱子就换了)、要按 {@code Slot.container} 挡掉箱子自己的格子、还要信
 * {@code getContainerSlot()} 的下标口径。一趟 41 格的遍历省掉这一整串前提,代价是每 tick
 * 多读四十来次——在一个 50ms 的 tick 预算里看不见。
 *
 * <h2>只认"什么物品、几个"</h2>
 * 耐久、附魔、其它组件一概不进比较。否则她每挥一镐都算变了。模型读的是"我有什么、几个",
 * 要精确到槽位和附魔时才用 {@code gui view}。
 *
 * <h2>效果同理:只认"有哪些、几级"</h2>
 * <b>剩余时间不进比较</b> —— 它每 tick 都在减,拿它当变化判据就是每 tick 推一个包。
 * 时长照发,由客户端按收到的时刻自己往下扣:效果是确定性的倒计时,推算出来的秒数和真值
 * 一致,而重推只发生在"多了一种、少了一种、升了级"这三件真事上。
 *
 * <h2>身体状态片段一并算</h2>
 * 身体状态片段(打头的 {@code <worn>} 与插件经 {@code NumenApi.contributeBodyState} 读的那段)也是身体此刻的样子,
 * 在这里和背包一起检查:整段字符串和上次不同才推。所以片段里不能有每 tick 都在变的值。
 */
public final class CompanionStateWatch {

    /** 最小推送间隔(tick)。她连续捡东西时压成一波,模型下一轮才读,晚半秒无感。 */
    private static final int MIN_INTERVAL_TICKS = 10;
    private static final class_1792[] EMPTY_ITEMS = new class_1792[0];
    private static final int[] EMPTY_COUNTS = new int[0];

    private static final Map<UUID, CompanionStateWatch> WATCHES = new HashMap<>();

    static {
        // 谁持有谁自己报到:这张表是世界作用域的,不作废会跟着进下一个存档。
        com.dwinovo.numen.api.platform.ServerLifecycle.onStopped(CompanionStateWatch::dropAll);
    }

    /** 每格上次见到的物品与数量。{@link class_1792} 是注册表单例,比引用就够——不必算哈希,
     *  也就没有"把数量塞进低位、模组把堆叠上限调过 65535 就溢出"这种雷。 */
    private class_1792[] lastItem = EMPTY_ITEMS;
    private int[] lastCount = EMPTY_COUNTS;
    private int lastSelected = -1;
    /** 上次见到的效果:每条编码成"效果 + 等级",不含剩余时间。 */
    private java.util.Set<String> lastEffects = java.util.Set.of();
    /** 上次见到的载具实体 id;-1 = 没骑。上下船是模型必须实时知道的身体事实。 */
    private int lastVehicleId = -1;
    /** 上次见到的身体状态片段(拼好的整段);空串 = 一段都没有。 */
    private String lastBodyState = "";
    private long lastSentTick;
    private boolean everSent;

    // 包内可见:单测直接验"片段相同不推、变了推"。
    CompanionStateWatch() {}

    /** 每服务端 tick、每个同伴调一次(见 {@code CompanionTickDispatcher})。 */
    public static void tick(NumenPlayer companion, long serverTick) {
        WATCHES.computeIfAbsent(companion.method_5667(), ignored -> new CompanionStateWatch())
                .tickOne(companion, serverTick);
    }

    /** 同伴离场(休眠/死亡/关服):丢掉它的镜像。 */
    public static void forget(UUID companionUuid) {
        WATCHES.remove(companionUuid);
    }

    /** 关服 / 换存档:世界作用域的进程内状态一律作废。 */
    public static void dropAll() {
        WATCHES.clear();
    }

    private void tickOne(NumenPlayer companion, long serverTick) {
        // 主人不在线、或他没有报到过的客户端(收不到我们的包)就直接走,而且<b>不碰镜像</b>:走一趟把变化吃掉的话,
        // 他回来时镜像已经是最新的,再也检测不出那段时间发生过什么,她的背包就一直是他离线前那份。
        class_3222 owner = companion.resolveOwnerPlayer();
        if (owner == null || !Presence.hasClient(owner.method_5667())) {
            return;
        }
        // 节流先行:没到间隔连遍历都省了。只对"已经推过一次"成立——第一次必须放行,
        // 她一登场就该有一份快照。
        if (everSent && serverTick - lastSentTick < MIN_INTERVAL_TICKS) {
            return;
        }
        // 各趟都要走:短路的话背包变了就不再看别的,镜像会漏掉同一波里的其余变化。
        boolean invChanged = changedSince(companion.method_31548());
        boolean effectsChanged = effectsChangedSince(companion);
        boolean vehicleChanged = vehicleChangedSince(companion);
        boolean bodyStateChanged = bodyStateChangedSince(
                com.dwinovo.numen.api.NumenPlugins.bodyStateFragments(companion));
        if (!invChanged && !effectsChanged && !vehicleChanged && !bodyStateChanged) {
            return;
        }
        lastSentTick = serverTick;
        boolean first = !everSent;
        everSent = true;
        NumenStatePayload payload = RequestStatePayload.snapshot(companion);
        NumenNetwork.sendToPlayer(owner, payload);
        // 一次推送一行。链路是"服务端推 → 客户端缓存 → 渲染进请求",出问题时得能一眼看出
        // 断在哪一节;只记开始不记结果的日志已经害过我们一次。
        com.dwinovo.numen.api.Constants.LOG.info(
                "[numen-state] {} → {} 种物品 / {} 格, 主手 {}, 副手 {}, 效果 {}{}{}{}",
                companion.method_5477().getString(), kinds(payload), usedSlots(payload),
                slotName(payload.selectedSlot(), payload.items()), name(payload.offhand()),
                payload.effects().size(),
                !payload.vehicle().isEmpty() ? ", 骑 " + payload.vehicle() : "",
                payload.bodyState().isEmpty() ? "" : ", 插件片段 " + payload.bodyState().length() + " 字符",
                first ? " (首次)" : "");
    }

    /** 一趟遍历:顺便把镜像更新到最新。返回"有没有模型在乎的变化"。 */
    private boolean changedSince(class_1661 inv) {
        int size = inv.method_5439();
        if (lastItem.length != size) {
            lastItem = new class_1792[size];   // 全 null,首格全部算变化
            lastCount = new int[size];
        }
        boolean changed = false;
        for (int i = 0; i < size; i++) {
            class_1799 stack = inv.method_5438(i);
            // 空栈的 getItem() 是 AIR、getCount() 是 0,和"这一格没东西"天然一致。
            if (lastItem[i] != stack.method_7909() || lastCount[i] != stack.method_7947()) {
                lastItem[i] = stack.method_7909();
                lastCount[i] = stack.method_7947();
                changed = true;   // 不 break:整趟走完,镜像才是完整的
            }
        }
        // 换手不动任何格子的内容,但块里的 holding 会变——所以选中槽自成一处状态。
        if (inv.field_7545 != lastSelected) {
            lastSelected = inv.field_7545;
            changed = true;
        }
        return changed;
    }


    /** 一趟遍历:更新效果镜像,返回"有没有多一种、少一种、或者升了级"。 */
    private boolean effectsChangedSince(NumenPlayer companion) {
        java.util.Set<String> now = new java.util.HashSet<>();
        for (var effect : companion.method_6026()) {
            // 1.20.1: getEffect() 直接给 MobEffect(不是 Holder),id 走注册表反查
            var key = net.minecraft.class_7923.field_41174
                    .method_10221(effect.method_5579());
            now.add((key == null ? "unknown" : key.toString()) + '@' + effect.method_5578());
        }
        if (now.equals(lastEffects)) {
            return false;
        }
        lastEffects = now;
        return true;
    }

    /** 插件片段这一趟拼出来的整段和上次比,顺便把镜像更新到最新。返回"有没有变"。 */
    boolean bodyStateChangedSince(String now) {
        if (now.equals(lastBodyState)) {
            return false;
        }
        lastBodyState = now;
        return true;
    }

    /** 上没上/下没下载具。比实体 id 就够:换了一条船也是一次上下船。 */
    private boolean vehicleChangedSince(NumenPlayer companion) {
        var vehicle = companion.method_5854();
        int nowId = vehicle == null ? -1 : vehicle.method_5628();
        if (nowId == lastVehicleId) {
            return false;
        }
        lastVehicleId = nowId;
        return true;
    }

    private static int kinds(NumenStatePayload p) {
        return (int) p.items().stream().filter(s -> !s.method_7960())
                .map(class_1799::method_7909).distinct().count();
    }

    private static int usedSlots(NumenStatePayload p) {
        return (int) p.items().stream().filter(s -> !s.method_7960()).count();
    }

    private static String slotName(int selected, java.util.List<class_1799> items) {
        return selected < 0 || selected >= items.size() ? "空手" : name(items.get(selected));
    }

    private static String name(class_1799 stack) {
        return stack.method_7960() ? "空手"
                : net.minecraft.class_7923.field_41178
                        .method_10221(stack.method_7909()).method_12832();
    }
}
