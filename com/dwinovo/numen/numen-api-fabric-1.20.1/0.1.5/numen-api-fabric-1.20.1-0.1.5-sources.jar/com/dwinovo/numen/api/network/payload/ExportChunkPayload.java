package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.network.NumenPayload;
import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.network.ClientPayloadSink;
import com.dwinovo.numen.api.network.Wire;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: 主人要求导出的一只同伴的记忆(zip)的一段。整包按段依次下行({@code Exports} 每刻至多一段),每段都装得进一个包;
 * 客户端按序收齐再存成文件({@code MemoryFiles}),总大小不设上限。
 *
 * @param index 这是第几段,从 0 起
 * @param total 一共几段
 */
public record ExportChunkPayload(UUID companion, String companionName, int index, int total, byte[] bytes)
        implements NumenPayload {

    /** 一段最多多少字节:远小于一个下行包的上限,留足包头。 */
    public static final int SEGMENT_BYTES = 64 * 1024;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "export_chunk");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(companion);
        Wire.writeText(buf, companionName);
        buf.method_10804(index);
        buf.method_10804(total);
        buf.method_10813(bytes);
    }

    public static ExportChunkPayload read(class_2540 buf) {
        return new ExportChunkPayload(buf.method_10790(), Wire.readText(buf), buf.method_10816(), buf.method_10816(), buf.method_10803(SEGMENT_BYTES));
    }

    /** Client main thread. */
    public static void handle(ExportChunkPayload p) {
        ClientPayloadSink.export.accept(p);
    }
}
