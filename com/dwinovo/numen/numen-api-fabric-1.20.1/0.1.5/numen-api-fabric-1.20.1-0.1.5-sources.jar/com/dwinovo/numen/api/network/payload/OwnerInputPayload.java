package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.network.NumenPayload;
import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.brain.OwnerInput;
import com.dwinovo.numen.api.brain.OwnerInputs;
import com.dwinovo.numen.api.network.Wire;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Client → Server: 主人做的一件事({@link OwnerInput}),JSON 一条。在网络线程上读懂、验过形状就投进这位玩家的信箱,
 * 主线程每刻取几条处理({@link OwnerInputs});读不懂的丢弃——上行的东西不可信。
 */
public record OwnerInputPayload(String json) implements NumenPayload {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "owner_input");

    public static OwnerInputPayload of(OwnerInput input) {
        return new OwnerInputPayload(input.toJson().toString());
    }

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        Wire.writeText(buf, json);
    }

    public static OwnerInputPayload read(class_2540 buf) {
        return new OwnerInputPayload(Wire.readText(buf));
    }

    /** Handler invoked on the network thread (or the server thread where the loader has no other). */
    public static void handle(OwnerInputPayload p, class_3222 player) {
        OwnerInput input = read(p.json());
        if (input == null) {
            Constants.LOG.warn("[numen-net] dropped an unreadable owner input from {}", player.method_5667());
            return;
        }
        OwnerInputs.offer(player.method_5667(), input);
    }

    static OwnerInput read(String json) {
        try {
            JsonElement el = JsonParser.parseString(json);
            return el instanceof JsonObject o ? OwnerInput.fromJson(o) : null;
        } catch (RuntimeException unreadable) {
            return null;
        }
    }
}
