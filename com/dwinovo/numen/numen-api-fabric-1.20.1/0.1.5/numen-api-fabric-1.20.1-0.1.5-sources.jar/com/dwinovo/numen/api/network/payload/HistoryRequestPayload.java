package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.network.NumenPayload;
import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.brain.Replies;
import com.dwinovo.numen.api.network.Wire;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Client → Server: 面板要一页历史。{@code cursor} 是上一页带回来的游标(原样带回,空串 = 最新一页)。答复是
 * {@link HistoryPagePayload},带着同一个 {@code requestId}。
 */
public record HistoryRequestPayload(long requestId, String conversation, String cursor, int limit)
        implements NumenPayload {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "history_request");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10791(requestId);
        Wire.writeText(buf, conversation);
        Wire.writeText(buf, cursor);
        buf.method_10804(limit);
    }

    public static HistoryRequestPayload read(class_2540 buf) {
        return new HistoryRequestPayload(buf.method_10792(), Wire.readText(buf), Wire.readText(buf), buf.method_10816());
    }

    /** Handler invoked on the server main thread; the page is computed on the companions' write lanes. */
    public static void handle(HistoryRequestPayload p, class_3222 player) {
        Replies.history(player, p.requestId(), p.conversation(), p.cursor(), p.limit());
    }
}
