package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.path.ClientPathViz;
import com.dwinovo.numen.network.NumenPayload;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: the companion's current pathfinding plan, for the in-world
 * path overlay. The path is computed and owned on the server (the client has
 * no planner state of its own to render from), so the body pushes the plan to
 * the owner whenever it (re)plans a segment, and pushes an EMPTY one (all
 * lists empty) to clear the overlay when the path ends.
 *
 * <ul>
 *   <li>{@code nodes} — the path positions (feet cells); drawn as a red poly-line.</li>
 *   <li>{@code toBreak} — blocks the path will dig; drawn as red boxes.</li>
 *   <li>{@code toPlace} — scaffold blocks the path will place; drawn as green boxes.</li>
 *   <li>{@code targets} — the goal cell(s); drawn as green boxes.</li>
 * </ul>
 */
public record PathVizPayload(UUID companion,
                             class_2960 dimension,
                             List<class_2338> nodes,
                             List<class_2338> toBreak,
                             List<class_2338> toPlace,
                             List<class_2338> targets) implements NumenPayload {

    /** Cap per list — paths are trimmed well below this; defends against absurd input. */
    public static final int MAX = 512;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "path_viz");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(companion);
        buf.method_10812(dimension);
        writeList(buf, nodes);
        writeList(buf, toBreak);
        writeList(buf, toPlace);
        writeList(buf, targets);
    }

    public static PathVizPayload read(class_2540 buf) {
        UUID companion = buf.method_10790();
        class_2960 dimension = buf.method_10810();
        return new PathVizPayload(companion, dimension,
                readList(buf), readList(buf), readList(buf), readList(buf));
    }

    private static void writeList(class_2540 buf, List<class_2338> list) {
        int n = Math.min(list.size(), MAX);
        buf.method_10804(n);
        for (int i = 0; i < n; i++) {
            buf.method_10807(list.get(i));
        }
    }

    private static List<class_2338> readList(class_2540 buf) {
        int n = Math.min(buf.method_10816(), MAX);
        List<class_2338> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(buf.method_10811());
        }
        return list;
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(PathVizPayload p) {
        ClientPathViz.accept(p);
    }
}
