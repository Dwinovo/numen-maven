package com.dwinovo.numen.entity;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.util.Set;
import java.util.UUID;

/**
 * Spawns and despawns companion {@link NumenPlayer} bodies through the vanilla
 * player-join path — entirely public API, no loader-specific construction needed
 * (the only fake piece is {@link FakeConnection}, which is common).
 *
 * <p>{@link net.minecraft.class_3324#method_14570} adds the body
 * to the player list (→ chunk loading for free) and to the level, but does NOT
 * load a hand-built fake player's {@code .dat} (that path is tied to the real
 * login flow) — so {@link #spawn} restores position / inventory / owner from disk
 * explicitly afterwards.
 * {@link net.minecraft.class_3324#method_14611} saves that data back and
 * removes the body — so despawn is a clean, persisted dormancy.
 */
@com.dwinovo.numen.api.Internal
public final class CompanionFactory {

    private CompanionFactory() {}

    /**
     * Bring a companion into the world. On first creation pass a {@code pos}
     * (the spawn location, e.g. beside the owner); on a respawn from dormancy
     * pass {@code null} to keep the position restored from its {@code .dat}.
     */
    public static NumenPlayer spawn(MinecraftServer server, UUID companionUuid, String name,
                                     UUID ownerUuid, class_3218 level, class_243 pos) {
        GameProfile profile = new GameProfile(companionUuid, name);
        // 借来的正版皮肤(Mojang 签名的 textures,注册表持久化)注入档案——客户端只认
        // 签过名的皮肤数据;没有则回落原版默认皮肤(按 UUID 哈希抽取)。
        CompanionRegistry.Entry reg = CompanionRegistry.get(server).find(companionUuid);
        if (reg != null && !reg.skinValue().isEmpty()) {
            profile.getProperties().put("textures", new com.mojang.authlib.properties.Property(
                    "textures", reg.skinValue(), reg.skinSig().isEmpty() ? null : reg.skinSig()));
        }
        NumenPlayer player = new NumenPlayer(server, level, profile);
        FakeConnection connection = new FakeConnection();
        // 1.20.1: placeNewPlayer is 2-arg (no CommonListenerCookie — pre-configuration-phase).
        server.method_3760().method_14570(connection, player);
        // placeNewPlayer does NOT load a hand-built fake player's .dat, so restore
        // it ourselves: position, inventory, health, owner from
        // disk. Without this a respawned companion spawns at 0,0,0 with no items.
        loadPlayerData(server, player);
        // Companions are always survival, whatever the world's default game type — their whole design
        // (gather/drops, real combat, recoverable death) is survival-shaped, and placeNewPlayer would
        // otherwise hand a creative world's body instabuild (no block drops, breaks auto_mine). Forced
        // here after the .dat restore so a stale saved game type can't override it.
        player.method_7336(class_1934.field_9215);
        // First spawn has no .dat to restore the owner from; set it explicitly.
        if (player.getOwnerUuid() == null) {
            player.setOwnerUuid(ownerUuid);
        }
        // An explicit pos (fresh summon) overrides the restored position; a respawn
        // from dormancy passes null to keep exactly what the .dat restored.
        if (pos != null) {
            player.method_48105(level, pos.field_1352, pos.field_1351, pos.field_1350, Set.of(), player.method_36454(), player.method_36455());
        }
        return player;
    }

    /**
     * Restore a fake player's saved state from its playerdata {@code .dat}
     * ({@link net.minecraft.class_3324#loadPlayerData} +
     * {@link net.minecraft.class_1297#method_5651}). {@code placeNewPlayer}
     * skips this for hand-constructed players, so we invoke the same load
     * ourselves. No-op on first summon (no file yet).
     */
    private static void loadPlayerData(MinecraftServer server, NumenPlayer player) {
        // 1.20.4: PlayerList.load(player) returns a nullable CompoundTag (predates both the
        // Optional wrapper and the ValueInput IO refactor). It already applies the tag to the
        // player internally and returns it; re-applying via Entity.load(CompoundTag) is a no-op-safe
        // belt-and-braces restore of position/inventory for a hand-built fake player.
        net.minecraft.class_2487 tag = server.method_3760().method_14600(player);
        if (tag != null) {
            player.method_5651(tag);
        }
    }

    /** Save the companion's data and remove it from the world (dormancy). */
    public static void despawn(MinecraftServer server, NumenPlayer player) {
        // Tell tool packs the body is leaving so they can finalize their own
        // per-companion work (e.g. clear a mining crack overlay) instead of leaving
        // it orphaned once the body drops out of the tick loop's player list.
        CompanionLifecycle.fireRemove(player);
        server.method_3760().method_14611(player);
    }
}
