package com.dwinovo.numen.plugins;

import com.dwinovo.numen.ModJar;
import com.dwinovo.numen.plugins.ysm.Ysm;
import com.dwinovo.numen.plugins.ysm.YsmHost;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;

import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * 本加载器内嵌了哪些联动、各自要谁——以及加载器替它们做的那几件事。
 *
 * <p>清单在这里,不做扫描:内嵌联动是<b>闭合集合</b>,数量由我们自己定;扫描是给开放
 * 集合用的。列在一处,"现在内嵌了哪些、各自要谁"一眼答得完。闸门本身三个加载器共用,
 * 见 {@link Gate}。
 *
 * <p>只有 YSM 与 Litematica:车万女仆等没有 Fabric 版,这里装不上它们,联动也就无从谈起。
 *
 * <h2>联动的类型只许出现在嵌套类里</h2>
 * 本类自己的方法(含 lambda 编译出来的合成方法)一个都不能提联动的类型:校验器为了核对
 * 参数类型会把它们提前加载,而开发运行(datagen、runClient)里联动不在类路径上——
 * compileOnly——提前加载就是 {@code ClassNotFoundException},整个模组入口跟着炸。
 * 各联动的接线放进各自的嵌套类,闸门开了才碰到它。
 */
public final class Builtin {

    private Builtin() {}

    public static void registerAll() {
        Gate gate = new Gate(FabricLoader.getInstance()::isModLoaded, ModJar::find);
        gate.open("yes_steve_model", "ysm", content -> () -> YsmOnFabric.install(content));
        gate.openClientMod(LitematicaOnFabric.TARGET_MOD, "litematica", content -> () -> LitematicaOnFabric.install(content));
        gate.openClientMod("jei", "jei", () -> JeiOnFabric::install);
    }

    /** JEI 联动要加载器答的一件事:流体成分在 Fabric 上是 {@code IJeiFluidIngredient},数量以 81000 为一桶(碎片),换成毫桶。 */
    private static final class JeiOnFabric implements com.dwinovo.numen.plugins.jei.JeiHost {
        static void install() {
            com.dwinovo.numen.plugins.jei.NumenJei.install(new JeiOnFabric());
        }

        @Override
        public long milliBuckets(Object fluid) {
            return ((mezz.jei.api.fabric.ingredients.fluids.IJeiFluidIngredient) fluid).getAmount() * 1000
                    / net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants.BUCKET;
        }
    }

    /** YSM 联动只写原版;它要的加载器专属的两件事,Fabric 的答案在这里。 */
    private static final class YsmOnFabric implements YsmHost {
        static void install(Path content) {
            com.dwinovo.numen.plugins.ysm.NumenYsm.install(new YsmOnFabric(), content);
        }

        @Override
        public void onServerTick(Consumer<MinecraftServer> listener) {
            ServerTickEvents.END_SERVER_TICK.register(listener::accept);
        }

        @Override
        public Ysm.Storage storage() {
            return Ysm.Storage.FABRIC;
        }
    }

    /** Litematica 联动不需要加载器替它做什么事:函数都在主人的客户端上跑,经 Numen API 的同一条反向请求。 */
    private static final class LitematicaOnFabric {
        static final String TARGET_MOD = "litematica";

        static void install(Path content) {
            com.dwinovo.numen.plugins.litematica.NumenLitematica.install(TARGET_MOD, content);
        }
    }
}
