package com.dwinovo.numen.tools.menu;

import com.dwinovo.numen.api.entity.BodyDelta;
import com.dwinovo.numen.api.entity.NumenPlayer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1772;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * 在开着的界面里做一件事前后,她身上和界面里变了什么:背包与经验、血量({@link BodyDelta},点一下、挖、打的回执用的是同一份)和界面
 * 自己那一边的格子(附魔台里的剑上了附魔、青金石少了几块、铁砧的结果格换了名字——这些不在她的背包里,{@link BodyDelta} 看不到)。
 * 只报事实,不下结论:成没成由各界面读回来的结果说。
 */
final class Receipt {

    private final BodyDelta body;
    private final class_1703 menu;
    private final List<String> slots;

    private Receipt(NumenPlayer her) {
        this.body = BodyDelta.open(her);
        this.menu = her.field_7512;
        this.slots = windowSlots(her);
    }

    /** 此刻拍一张。 */
    static Receipt open(NumenPlayer her) {
        return new Receipt(her);
    }

    /** 从拍照到现在,每一条是一件真发生的事;都没变是空表。 */
    List<String> changes(NumenPlayer her) {
        List<String> facts = new ArrayList<>(body.changes(her));
        if (her.field_7512 == menu) {
            List<String> now = windowSlots(her);
            for (int i = 0; i < slots.size(); i++) {
                if (!slots.get(i).equals(now.get(i))) {
                    facts.add("window slot " + i + ": " + slots.get(i) + " -> " + now.get(i));
                }
            }
        }
        return facts;
    }

    /** 界面里不属于她背包的每一格,写成一行。 */
    private static List<String> windowSlots(NumenPlayer her) {
        List<String> out = new ArrayList<>();
        for (class_1735 slot : her.field_7512.field_7761) {
            out.add(slot.field_7871 == her.method_31548() ? "" : stack(slot.method_7677()));
        }
        return out;
    }

    /** 一叠东西写成一行:{@code minecraft:diamond_sword (named X; sharpness 2)};空的是 {@code empty}。 */
    static String stack(class_1799 stack) {
        if (stack.method_7960()) {
            return "empty";
        }
        List<String> details = new ArrayList<>();
        if (stack.method_7938()) {
            details.add("named " + stack.method_7964().getString());
        }
        enchantments(class_1890.method_22445(stack.method_7921()), details);
        enchantments(class_1890.method_22445(class_1772.method_7806(stack)), details);
        return class_7923.field_41178.method_10221(stack.method_7909()) + (stack.method_7947() > 1 ? " x" + stack.method_7947() : "")
                + (details.isEmpty() ? "" : " (" + String.join("; ", details) + ")");
    }

    private static void enchantments(Map<class_1887, Integer> enchantments, List<String> into) {
        enchantments.forEach((each, level) -> {
            var key = class_7923.field_41176.method_10221(each);
            into.add((key == null ? "?" : key.method_12832()) + " " + level);
        });
    }
}
