package com.dwinovo.numen.mixin;

import com.dwinovo.numen.mixin.inject.BlockItemAccessor;
import com.dwinovo.numen.mixin.inject.CraftingMenuAccessor;
import com.dwinovo.numen.mixin.inject.FishingHookAccessor;
import com.dwinovo.numen.mixin.inject.ItemEntityAccessor;
import com.dwinovo.numen.mixin.inject.MenuDataSlotsAccessor;
import com.dwinovo.numen.platform.IVanillaAccess;
import java.util.List;
import net.minecraft.class_1536;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1731;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3915;
import net.minecraft.class_8566;

/**
 * {@link IVanillaAccess} 的模组实现,全部经 {@code mixin.inject} 包的 Mixin 访问器。
 * Mixin 配置的包是下一层的 {@code mixin.inject},这里不是 Mixin 声明的包,可以被 ServiceLoader 正常加载。
 */
public final class VanillaAccessImpl implements IVanillaAccess {

    @Override
    public int biteCountdown(class_1536 hook) {
        return ((FishingHookAccessor) (Object) hook).numen$getNibble();
    }

    @Override
    public int pickupDelay(class_1542 item) {
        return ((ItemEntityAccessor) item).numen$getPickupDelay();
    }

    @Override
    public List<class_3915> syncedDataSlots(class_1703 menu) {
        return ((MenuDataSlotsAccessor) (Object) menu).numen$dataSlots();
    }

    @Override
    public void recomputeCraftingResult(class_1703 menu, class_1937 level, class_1657 player,
                                        class_8566 grid, class_1731 result) {
        CraftingMenuAccessor.numen$recompute(menu, level, player, grid, result);
    }

    @Override
    public class_2680 placementState(class_1747 item, class_1750 context) {
        return ((BlockItemAccessor) item).numen$placementState(context);
    }
}
