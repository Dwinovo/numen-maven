package com.dwinovo.numen.pathing.drive;

import java.util.function.Function;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import com.dwinovo.numen.api.entity.Mouse;
import com.dwinovo.numen.pathing.drive.Blockage.Hitch;
import com.dwinovo.numen.pathing.plan.Edit;

/**
 * 开关门的子控制器:任何一种走法、任何一步要穿过门(木门、栅栏门、活板门),都由它开或关。转过去看门身上看得见的一点,
 * 准星落上了就右键一下——不按潜行,门才会响应——门翻过来就做完了。门的另一半由原版一起翻,变了的格都记进实际账。
 */
final class DoorOpener {

    private DoorOpener() {}

    /** 这扇门已经从规划时的样子翻过来了。 */
    static boolean opened(Edit.Door door, class_2680 now) {
        return now.method_27852(door.state().method_26204()) && now.method_28498(class_2741.field_12537)
                && now.method_11654(class_2741.field_12537) != door.state().method_11654(class_2741.field_12537);
    }

    /** @param unseen 门看不见、准星还没落上时交给调用方计数 */
    static Beat tick(Rig rig, Edit.Door door, Function<Hitch, Beat> unseen) {
        class_2338 pos = door.pos();
        class_243 point = rig.look.point(pos);
        if (point == null) {
            return unseen.apply(Hitch.OCCLUDED);
        }
        rig.look.at(point);
        if (rig.mouse.on(pos) == null) {
            return unseen.apply(Hitch.OCCLUDED);
        }
        boolean sneaking = rig.entity.method_5715();
        rig.entity.method_5660(false);
        Mouse.Use use = rig.use();
        rig.entity.method_5660(sneaking);
        if (use instanceof Mouse.Use.Pressed pressed && (!pressed.changes().isEmpty())) {
            rig.ledger.used(pressed.changes());
            if (PathLog.debugging()) {
                PathLog.debug("{} 开关门 {}", rig.who, Work.changes(pressed));
            }
            return Beat.WORKED;
        } else if (use instanceof Mouse.Use.Refused refused) {
            return Work.refused(rig, "开关门", refused.pos(), refused.reason());
        } else if (use instanceof Mouse.Use.Pressed pressed) {
            return Beat.IDLE;
        } else {
            Mouse.Use.Waiting waiting = (Mouse.Use.Waiting) use;
            return Beat.IDLE;
        }
    }
}
