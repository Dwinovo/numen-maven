package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client:某个同伴的头顶气泡状态(见 {@link SpeechBubblePayload}
 * 的上行说明)。收到的客户端不一定是主人——附近路过的玩家同样收到,
 * 同伴说话路人也听得见。
 */
public record SpeechBubbleSyncPayload(UUID entityUuid, byte kind, String text) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "speech_bubble_sync");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_52997(kind);
        buf.method_10788(text, SpeechBubblePayload.MAX_TEXT);
    }

    public static SpeechBubbleSyncPayload read(class_2540 buf) {
        return new SpeechBubbleSyncPayload(buf.method_10790(), buf.readByte(),
                buf.method_10800(SpeechBubblePayload.MAX_TEXT));
    }

    /** Client main thread. */
    public static void handle(SpeechBubbleSyncPayload p) {
        com.dwinovo.numen.client.hud.SpeechBubbles.apply(p.entityUuid(), p.kind(), p.text());
    }
}
