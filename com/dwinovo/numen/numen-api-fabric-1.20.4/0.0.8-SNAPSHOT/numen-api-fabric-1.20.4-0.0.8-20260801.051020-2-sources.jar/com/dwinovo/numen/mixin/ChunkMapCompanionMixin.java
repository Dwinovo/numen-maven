package com.dwinovo.numen.mixin;

import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_3222;
import net.minecraft.class_3898;
import net.minecraft.class_8603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Take companion fake players OUT of the client chunk-tracking / loading machinery.
 *
 * <p>A companion {@link NumenPlayer} is a real {@link class_3222} subclass, so vanilla treats it
 * as a viewing client: it computes and sends per-chunk load/unload packets to it every move
 * ({@code updateChunkTracking}) and, via {@code updatePlayerStatus} → {@code DistanceManager.addPlayer},
 * keeps a full simulation-distance sphere of chunks loaded around it. For a fake player with no real
 * client both are wrong — the packets go nowhere, and the sphere makes every companion a heavyweight,
 * uncontrolled, moving chunk-loader (the source of the server-scale cost and the chunk-save freeze).
 *
 * <p>This mixin makes {@code ChunkMap} treat a companion as a non-viewing player:
 * <ul>
 *   <li>{@code skipPlayer → true}: stops the wasted client tracking AND the player loading ticket.
 *       The loading is added back, but bounded and self-cleaning, by
 *       {@link com.dwinovo.numen.entity.CompanionChunkLoader}.</li>
 *   <li>{@code applyChunkTrackingView → cancel}: skips the chunk load/unload packet sends that
 *       would otherwise run on every move (and on join, from {@code updatePlayerStatus}) for a
 *       client that isn't there. The view is pinned to {@code EMPTY} first so the diff against the
 *       next view stays empty instead of replaying every chunk once tracking resumes.</li>
 * </ul>
 * The companion still ticks (players tick from the player list regardless) and is still tracked as an
 * entity, so real players nearby continue to see it.
 *
 * <p>Behavioural note: because a companion no longer counts as a player in {@code DistanceManager}, its
 * loading-pad chunks are not "near a player" for {@code NaturalSpawner} — hostile mobs won't naturally
 * spawn around a companion working far from any real player. This is consistent with the bounded-pad
 * intent (a companion is a lightweight loader, not a full player); tasks that rely on mobs spawning near
 * a remote companion (e.g. combat/farming away from the owner) will behave differently.
 */
@Mixin(class_3898.class)
public abstract class ChunkMapCompanionMixin {

    @Inject(method = "skipPlayer", at = @At("HEAD"), cancellable = true)
    private void numen$skipCompanionAsViewer(class_3222 player, CallbackInfoReturnable<Boolean> cir) {
        if (player instanceof NumenPlayer) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "applyChunkTrackingView", at = @At("HEAD"), cancellable = true)
    private void numen$suppressCompanionChunkPackets(class_3222 player, class_8603 view, CallbackInfo ci) {
        if (player instanceof NumenPlayer) {
            player.method_52373(class_8603.field_44986);
            ci.cancel();
        }
    }
}
