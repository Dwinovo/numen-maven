package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.data.ClientNumenInventory;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: a companion's 36 main backpack slots, answering
 * {@link RequestInventoryPayload}. {@code loaded=false} means the body is asleep
 * in unloaded chunks (or not the requester's) — no contents. Dropped into
 * {@link ClientNumenInventory} for the Items tab to render read-only.
 */
public record NumenInventoryPayload(UUID uuid, boolean loaded, List<class_1799> items,
                                    List<class_1799> craft, int foodLevel, float saturation)
        implements class_8710 {

    /** Cap defends against absurd input. */
    public static final int MAX_ITEMS = 256;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "numen_inventory");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10797(uuid);
        buf.method_52964(loaded);
        writeItems(buf, items);
        writeItems(buf, craft);
        buf.method_10804(foodLevel);
        buf.method_52941(saturation);
    }

    public static NumenInventoryPayload read(class_2540 buf) {
        UUID uuid = buf.method_10790();
        boolean loaded = buf.readBoolean();
        List<class_1799> items = readItems(buf);
        List<class_1799> craft = readItems(buf);
        int foodLevel = buf.method_10816();
        float saturation = buf.readFloat();
        return new NumenInventoryPayload(uuid, loaded, items, craft, foodLevel, saturation);
    }

    // FriendlyByteBuf#writeItem / #readItem already encode empty stacks (a leading present-flag),
    // so this is the 1.20.4 equivalent of ItemStack.OPTIONAL_LIST_STREAM_CODEC.
    private static void writeItems(class_2540 buf, List<class_1799> list) {
        int n = Math.min(list.size(), MAX_ITEMS);
        buf.method_10804(n);
        for (int i = 0; i < n; i++) {
            buf.method_10793(list.get(i));
        }
    }

    private static List<class_1799> readItems(class_2540 buf) {
        int n = Math.min(buf.method_10816(), MAX_ITEMS);
        List<class_1799> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(buf.method_10819());
        }
        return list;
    }

    /** Client main thread. */
    public static void handle(NumenInventoryPayload p) {
        ClientNumenInventory.update(p.uuid(), new ClientNumenInventory.Snapshot(
                p.loaded(), p.items(), p.craft(), p.foodLevel(), p.saturation(), System.currentTimeMillis()));
    }
}
