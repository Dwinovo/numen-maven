package com.dwinovo.numen.mixin;

import com.dwinovo.numen.entity.FakeConnection;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_8609;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Drop every outbound packet aimed at a companion {@link FakeConnection}, at the
 * <em>packet-listener</em> level — one layer above {@link FakeConnection#method_10743}.
 *
 * <h2>Why this is needed on top of {@code FakeConnection.send} being a no-op</h2>
 * NeoForge inserts its custom-payload channel validation
 * ({@code NetworkRegistry.checkPacket}) <em>inside</em>
 * {@link class_8609#method_14364}, which runs <strong>before</strong> the
 * call reaches {@link class_2535#method_10743}. So a companion's no-op {@code Connection.send}
 * never gets the chance to discard a modded clientbound payload — the validation throws
 * first:
 * <pre>UnsupportedOperationException: Payload &lt;mod:foo&gt; may not be sent to the client!</pre>
 * A fake player never negotiated any custom channels (it skips the configuration phase),
 * so the channel set is empty and <em>any</em> mod custom payload trips the check and
 * crashes the server tick. This happens for any mod that pushes a clientbound payload at
 * the body — an item's {@code use()} opening a screen (chiikawa's music box), a menu's
 * per-tick {@code broadcastChanges} (AE2 terminals), etc.
 *
 * <p>Cancelling at {@code HEAD} of the 1-arg {@code send(Packet)} short-circuits before
 * the (2-arg) overload that carries {@code checkPacket} is ever reached. It is a strict
 * superset of what {@link FakeConnection#method_10743} already did (drop on the floor — there is
 * no client), so there is no behavioural regression: vanilla position/chunk/keep-alive
 * packets were already discarded.
 *
 * <p>Common (all environments): the integrated server hits this path in singleplayer too,
 * so it must NOT be a {@code server}-only (dedicated) mixin.
 */
@Mixin(class_8609.class)
public abstract class MixinServerCommonPacketListener {

    @Shadow
    @Final
    protected class_2535 connection;

    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void numen$dropOutboundForFakeConnection(class_2596<?> packet, CallbackInfo ci) {
        if (this.connection instanceof FakeConnection) {
            ci.cancel();
        }
    }
}
