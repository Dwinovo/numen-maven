package com.dwinovo.numen.entity;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Persistent index of every companion that exists, keyed by companion UUID.
 * The companion BODY (inventory, position, owner) persists for free as a vanilla
 * player {@code .dat}, but vanilla never enumerates the {@code playerdata/}
 * folder for players that aren't logging in — so without this index we couldn't
 * know which companions to recreate, or who owns them, while they sit dormant.
 *
 * <p>World-saved on the overworld data storage (one file, all owners' companions).
 * The {@code dimension}/{@code pos} are a respawn hint (which level to construct
 * the body in); the {@code .dat} carries the authoritative restored state.
 */
@com.dwinovo.numen.api.Internal
public final class CompanionRegistry extends class_18 {

    /** One companion's catalog entry. {@code diedAt > 0} = dead, awaiting a respawn-at-owner (the death
     *  state is persisted here so it SURVIVES a logout during the respawn window — see Companions). */
    public record Entry(String name, UUID owner, class_5321<class_1937> dimension, class_2338 pos,
                        String deathCause, long diedAt) {
        /** A live companion (not dead). */
        public Entry(String name, UUID owner, class_5321<class_1937> dimension, class_2338 pos) {
            this(name, owner, dimension, pos, "", 0L);
        }

        static final Codec<Entry> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("name").forGetter(Entry::name),
                class_4844.field_41525.fieldOf("owner").forGetter(Entry::owner),
                class_5321.method_39154(class_7924.field_41223).fieldOf("dimension").forGetter(Entry::dimension),
                class_2338.field_25064.fieldOf("pos").forGetter(Entry::pos),
                Codec.STRING.optionalFieldOf("deathCause", "").forGetter(Entry::deathCause),
                Codec.LONG.optionalFieldOf("diedAt", 0L).forGetter(Entry::diedAt)
        ).apply(i, Entry::new));
    }

    private static final Codec<CompanionRegistry> CODEC =
            Codec.unboundedMap(class_4844.field_41525, Entry.CODEC)
                    .xmap(CompanionRegistry::new, d -> d.entries)
                    .fieldOf("companions").codec();

    // 1.21.4 predates the codec-based SavedDataType; register with the old SavedData.Factory
    // (Supplier + deserializer + DataFixType) and drive (de)serialization through CODEC ourselves.
    private static final class_18.class_8645<CompanionRegistry> FACTORY = new class_18.class_8645<>(
            CompanionRegistry::new, CompanionRegistry::load,
            net.minecraft.class_4284.field_45082);

    // 1.20.4 SavedData: save/load take only the CompoundTag (the HolderLookup.Provider param is 1.20.5+).
    @Override
    public class_2487 method_75(class_2487 tag) {
        CODEC.encodeStart(class_2509.field_11560, this).result()
                .ifPresent(t -> { if (t instanceof class_2487 c) tag.method_10543(c); });
        return tag;
    }

    private static CompanionRegistry load(class_2487 tag) {
        return CODEC.parse(class_2509.field_11560, tag).result().orElseGet(CompanionRegistry::new);
    }

    private final Map<UUID, Entry> entries;

    private CompanionRegistry() {
        this.entries = new HashMap<>();
    }

    private CompanionRegistry(Map<UUID, Entry> entries) {
        this.entries = new HashMap<>(entries);
    }

    public static CompanionRegistry get(MinecraftServer server) {
        return server.method_30002().method_17983().method_17924(FACTORY, "numen_companions");
    }

    /** Add or update a companion's catalog entry. */
    public void put(UUID companionUuid, Entry entry) {
        entries.put(companionUuid, entry);
        method_80();
    }

    public Entry find(UUID companionUuid) {
        return entries.get(companionUuid);
    }

    public void remove(UUID companionUuid) {
        if (entries.remove(companionUuid) != null) method_80();
    }

    /** Every companion owned by {@code ownerUuid} (UUID + entry). */
    public List<Map.Entry<UUID, Entry>> ownedBy(UUID ownerUuid) {
        List<Map.Entry<UUID, Entry>> out = new ArrayList<>();
        for (Map.Entry<UUID, Entry> e : entries.entrySet()) {
            if (e.getValue().owner().equals(ownerUuid)) out.add(e);
        }
        return out;
    }

    /** Every companion currently dead and awaiting respawn (persisted, survives a logout). */
    public List<Map.Entry<UUID, Entry>> pendingDead() {
        List<Map.Entry<UUID, Entry>> out = new ArrayList<>();
        for (Map.Entry<UUID, Entry> e : entries.entrySet()) {
            if (e.getValue().diedAt() > 0L) out.add(e);
        }
        return out;
    }

    /** Mark a companion dead (records the cause + game-time, persisted for the respawn timer). */
    public void markDead(UUID uuid, String cause, long diedAt) {
        Entry e = entries.get(uuid);
        if (e == null) return;
        entries.put(uuid, new Entry(e.name(), e.owner(), e.dimension(), e.pos(), cause, diedAt));
        method_80();
    }

    /** Clear the death state (called when the body is respawned). */
    public void markAlive(UUID uuid) {
        Entry e = entries.get(uuid);
        if (e == null || e.diedAt() == 0L) return;
        entries.put(uuid, new Entry(e.name(), e.owner(), e.dimension(), e.pos()));
        method_80();
    }
}
