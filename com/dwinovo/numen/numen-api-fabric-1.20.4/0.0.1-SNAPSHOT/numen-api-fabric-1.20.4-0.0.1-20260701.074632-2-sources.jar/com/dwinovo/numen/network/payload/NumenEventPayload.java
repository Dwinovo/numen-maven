package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: an asynchronous WORLD EVENT for a companion's brain (dimension change, a hazard,
 * …). The server detects the event (edge-triggered) and ships a ready-made {@code <event>} XML string;
 * the client loop queues it like an owner prompt and splices it in at a protocol-valid boundary.
 * {@code urgent} wakes an idle brain to react now; otherwise it rides along on the next owner-driven turn.
 */
public record NumenEventPayload(UUID entityUuid, String xml, boolean urgent) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "numen_event");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_10814(xml);
        buf.method_52964(urgent);
    }

    public static NumenEventPayload read(class_2540 buf) {
        return new NumenEventPayload(buf.method_10790(), buf.method_19772(), buf.readBoolean());
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenEventPayload p) {
        AgentLoopRegistry.get(p.entityUuid()).ifPresent(loop -> loop.injectEvent(p.xml(), p.urgent()));
    }
}
