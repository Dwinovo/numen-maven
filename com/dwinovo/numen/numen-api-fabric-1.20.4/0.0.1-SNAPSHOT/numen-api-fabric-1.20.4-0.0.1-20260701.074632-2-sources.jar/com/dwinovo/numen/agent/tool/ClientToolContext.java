package com.dwinovo.numen.agent.tool;

import java.util.UUID;
import net.minecraft.class_1309;
import net.minecraft.class_742;

/**
 * Per-turn context handed to local tools. Carries the "anchor" body for the
 * agent — the companion's client-side {@link class_742} the loop
 * drives, plus its stable {@code getUUID()}. Perception tools call
 * {@link #anchor()} to get the perspective centre.
 *
 * <p>The body may be {@code null} when it's unloaded out of view distance;
 * perception tools must check and surface a clean failure rather than NPE.
 */
@com.dwinovo.numen.api.Internal
public record ClientToolContext(class_742 entity, UUID entityUuid) {

    /** The body's own perspective is the scan centre / inventory anchor. */
    public class_1309 anchor() {
        return entity;
    }
}
