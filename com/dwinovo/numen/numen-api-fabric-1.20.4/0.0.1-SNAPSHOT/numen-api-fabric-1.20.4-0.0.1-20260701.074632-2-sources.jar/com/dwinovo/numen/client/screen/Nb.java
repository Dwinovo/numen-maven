package com.dwinovo.numen.client.screen;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5251;

/**
 * Shared BlockFrame ("neobrutalist") drawing helpers for the Numen GUI.
 *
 * <p>Text is always drawn FLAT (no drop shadow) with the colour baked into the
 * {@link net.minecraft.class_2583} — on this build the shadowless text path
 * ignores the colour param (renders black), and a shadow on dark text over a light
 * ground smudges. Baking into the Style gives crisp, coloured, flat text.
 */
public final class Nb {

    private Nb() {}

    /** A flat, coloured text Component (colour in the Style). */
    public static class_2561 colored(String s, int color) {
        return class_2561.method_43470(s).method_27694(st -> st.method_27703(class_5251.method_27717(color & 0xFFFFFF)));
    }

    public static void text(class_332 g, class_327 font, String s, int x, int y, int color) {
        g.method_51439(font, colored(s, color), x, y, -1, false);
    }

    public static void text(class_332 g, class_327 font, class_2561 c, int x, int y, int color) {
        g.method_51439(font, c.method_27661().method_27694(st -> st.method_27703(class_5251.method_27717(color & 0xFFFFFF))), x, y, -1, false);
    }

    /** Square thick border = four filled edge rects (no rounded corners). */
    public static void border(class_332 g, int x, int y, int w, int h, int t, int color) {
        g.method_25294(x, y, x + w, y + t, color);
        g.method_25294(x, y + h - t, x + w, y + h, color);
        g.method_25294(x, y, x + t, y + h, color);
        g.method_25294(x + w - t, y, x + w, y + h, color);
    }
}
