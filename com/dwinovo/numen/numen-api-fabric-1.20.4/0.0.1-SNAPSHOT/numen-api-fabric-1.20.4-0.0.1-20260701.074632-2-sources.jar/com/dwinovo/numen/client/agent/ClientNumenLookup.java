package com.dwinovo.numen.client.agent;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_742;

/**
 * Resolve a companion's <strong>client-side body</strong> by its stable
 * {@link UUID}. The companion is a server-side fake {@code ServerPlayer}; on a
 * tracking client it materialises as a {@link class_742}
 * ({@code RemotePlayer}) in the loaded entity list, exactly like any other
 * player. So "find the companion" is "find the player entity with this UUID."
 *
 * <h2>Why UUID, not network id</h2>
 * The vanilla network {@code entity.getId()} (int) is a per-session handle that
 * changes whenever the entity is recreated (most notably on cross-dimension
 * travel). The client agent loop is therefore keyed by UUID and resolves the
 * current body through here, surviving the int-id churn of a Nether/End trip.
 * See {@link AgentLoopRegistry}.
 *
 * <p>{@code ClientLevel} exposes no public by-UUID lookup, so we scan the
 * loaded entities. Callers (chat GUI, agent loop) hit this infrequently — per
 * prompt / per tool round-trip, never per tick — so the linear scan is fine.
 *
 * <h2>Threading</h2>
 * Client main thread only.
 */
public final class ClientNumenLookup {

    private ClientNumenLookup() {}

    /** The currently-loaded companion body with this UUID, or {@code null}. */
    public static class_742 resolve(UUID uuid) {
        if (uuid == null) return null;
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return null;
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e instanceof class_742 p && uuid.equals(p.method_5667())) {
                return p;
            }
        }
        return null;
    }
}
