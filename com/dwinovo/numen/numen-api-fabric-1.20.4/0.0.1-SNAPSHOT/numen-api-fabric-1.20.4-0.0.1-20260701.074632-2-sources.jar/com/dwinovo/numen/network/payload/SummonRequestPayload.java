package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.Companions;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

/**
 * Client → Server: the owner asked to summon a companion by name from the panel's
 * "+" button. Mirrors the {@code /numen player summon} command — summon is
 * idempotent per (owner, name), so re-summoning an existing name just wakes it.
 */
public record SummonRequestPayload(String name) implements class_8710 {

    public static final int MAX_NAME = 32;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "summon_request");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10788(name, MAX_NAME);
    }

    public static SummonRequestPayload read(class_2540 buf) {
        return new SummonRequestPayload(buf.method_10800(MAX_NAME));
    }

    /** Server main thread. */
    public static void handle(SummonRequestPayload p, class_3222 owner) {
        String name = p.name() == null ? "" : p.name().trim();
        if (name.isEmpty() || name.length() > MAX_NAME) return;
        class_3218 level = (class_3218) owner.method_37908();
        Companions.summon(level.method_8503(), owner.method_5667(), name, level, owner.method_19538());
        Companions.syncRosterToOwner(level.method_8503(), owner);   // push the new roster to the owner
    }
}
