package com.dwinovo.numen.client.screen;

import com.dwinovo.numen.agent.llm.NumenLlmClient;
import com.dwinovo.numen.data.ModLanguageData;
import com.dwinovo.numen.platform.Services;
import com.dwinovo.numen.platform.services.INumenConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

/**
 * Standalone global-settings screen (provider / API key / model / base URL),
 * reached from the {@code /numen} OPEN_SETTINGS verb. The {@link NumenScreen}
 * Settings tab embeds the same controls; both share {@link LlmProviders} +
 * {@link ProviderDropdown}, so the provider is picked from a dropdown rather than
 * a button grid.
 */
public final class SettingsScreen extends class_437 {

    private static final int CONTENT_WIDTH = 300;
    private static final int CONTENT_HEIGHT = 190;
    private static final int LABEL_H = 11;
    private static final int FIELD_GAP = 37;

    private static final int TXT_MUTED = 0xFFAAAAAA;
    private static final int OK = 0xFF74D17A;

    private final class_437 parent;

    private ProviderDropdown provider;
    private class_342 apiKeyInput;
    private class_342 modelInput;
    private class_342 baseUrlInput;
    private long savedFlashUntil;

    private int left, top;

    public SettingsScreen(class_437 parent) {
        super(class_2561.method_43471(ModLanguageData.Keys.GUI_SETTINGS_TITLE));
        this.parent = parent;
    }

    public static void open(class_437 parent) {
        class_310.method_1551().method_1507(new SettingsScreen(parent));
    }

    @Override
    protected void method_25426() {
        method_37067();
        this.left = (this.field_22789 - CONTENT_WIDTH) / 2;
        this.top = (this.field_22790 - CONTENT_HEIGHT) / 2;
        INumenConfig cfg = Services.CONFIG;

        int y = top + 10;
        provider = new ProviderDropdown(cfg.getProvider(), false);
        provider.setBounds(left, y + LABEL_H, CONTENT_WIDTH, 18);

        int y2 = y + FIELD_GAP;
        apiKeyInput = field(left, y2 + LABEL_H, 512, cfg.getApiKey());
        int y3 = y2 + FIELD_GAP;
        modelInput = field(left, y3 + LABEL_H, 128, cfg.getModel());
        int y4 = y3 + FIELD_GAP;
        baseUrlInput = field(left, y4 + LABEL_H, 256, cfg.getBaseUrl());

        int footerY = top + CONTENT_HEIGHT - 18;
        int btnW = 60;
        int rightX = left + CONTENT_WIDTH - btnW;
        method_37063(new SimpleButton(rightX - btnW - 4, footerY, btnW, 18,
                class_2561.method_43471(ModLanguageData.Keys.GUI_SETTINGS_CANCEL), b -> method_25419()));
        method_37063(new SimpleButton(rightX, footerY, btnW, 18,
                class_2561.method_43471(ModLanguageData.Keys.GUI_SETTINGS_SAVE), b -> onSave()));
    }

    private class_342 field(int x, int y, int max, String value) {
        class_342 e = new class_342(field_22793, x, y, CONTENT_WIDTH, 18, class_2561.method_43470(""));
        e.method_1880(max);
        e.method_1852(value == null ? "" : value);
        method_37063(e);
        return e;
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partial) {
        super.method_25394(g, mouseX, mouseY, partial);
        g.method_27534(field_22793, method_25440(), this.field_22789 / 2, top - 6, 0xFFFFFFFF);

        LlmProviders.Option opt = LlmProviders.byId(provider.selectedId());
        modelInput.method_47404(class_2561.method_43470(opt.defaultModel()));
        baseUrlInput.method_47404(class_2561.method_43470(opt.defaultBaseUrl()));

        int y = top + 10;
        g.method_27535(field_22793, class_2561.method_43471(ModLanguageData.Keys.GUI_SETTINGS_PROVIDER), left, y, TXT_MUTED);
        g.method_27535(field_22793, class_2561.method_43471(ModLanguageData.Keys.GUI_SETTINGS_API_KEY), left, y + FIELD_GAP, TXT_MUTED);
        g.method_27535(field_22793, class_2561.method_43471(ModLanguageData.Keys.GUI_SETTINGS_MODEL), left, y + FIELD_GAP * 2, TXT_MUTED);
        g.method_27535(field_22793, class_2561.method_43471(ModLanguageData.Keys.GUI_SETTINGS_BASE_URL), left, y + FIELD_GAP * 3, TXT_MUTED);

        if (savedFlashUntil > System.currentTimeMillis()) {
            g.method_27535(field_22793, class_2561.method_43470("✔ saved"), left, top + CONTENT_HEIGHT - 14, OK);
        }
        provider.render(g, field_22793, mouseX, mouseY);   // last → open list overlays the fields
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && provider != null && provider.mouseClicked(mouseX, mouseY)) {
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private void onSave() {
        INumenConfig cfg = Services.CONFIG;
        cfg.setProvider(provider.selectedId());
        cfg.setApiKey(apiKeyInput.method_1882());
        cfg.setModel(modelInput.method_1882());
        cfg.setBaseUrl(baseUrlInput.method_1882());
        cfg.save();
        NumenLlmClient.reset();
        savedFlashUntil = System.currentTimeMillis() + 1500;
    }

    @Override
    public void method_25419() {
        if (parent != null) {
            this.field_22787.method_1507(parent);
        } else {
            super.method_25419();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
