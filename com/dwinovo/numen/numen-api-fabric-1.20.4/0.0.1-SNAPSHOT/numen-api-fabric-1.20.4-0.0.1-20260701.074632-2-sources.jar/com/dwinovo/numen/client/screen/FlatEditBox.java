package com.dwinovo.numen.client.screen;

import com.dwinovo.numen.Constants;
import java.util.function.BiFunction;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_5481;

/**
 * A borderless {@link class_342} that paints its text WITHOUT the vanilla drop shadow,
 * and draws the caret as a thin fill bar instead of the shadowed {@code "_"}, to match
 * the flat Cottage UI.
 *
 * <p>Vanilla hardcodes the shadow in {@code renderWidget} and (before 1.21.6) exposes
 * no toggle; {@code Style.withShadowColor} is 1.21.5-only — so neither lever is portable
 * to older targets. Rather than a fragile {@code @Redirect} mixin or access-wideners,
 * this REUSES all of EditBox's input/state machinery and only re-does the paint, through
 * PUBLIC getters ({@link #method_1882()} / {@link #method_1881()} / {@link #method_1859()}
 * / {@link #method_25370()} / geometry). The horizontal scroll offset and blink phase — the
 * only state without getters — are tracked here. Geometry matches vanilla's borderless
 * branch exactly: text at {@code (getX(), getY())}. Assumes {@code setBordered(false)}.
 */
public class FlatEditBox extends class_342 {

    /** Cottage-style caret sprite (brown-capped amber bar, HyperFrames pixel art, native 3x10). */
    private static final class_2960 CARET = new class_2960(Constants.MOD_ID, "caret");
    private static final int CARET_W = 3, CARET_H = 10;
    private static final int SELECT_COLOR = 0x804E7480;   // translucent reply-teal
    private static final long BLINK_MS = 300L;

    private final class_327 font;
    private int color = 0xE0E0E0;                          // captured from setTextColor
    private class_2561 hint;                                // captured from setHint
    private BiFunction<String, Integer, class_5481> fmt =
            (s, off) -> class_5481.method_30747(s, class_2583.field_24360);
    private long focusTime;
    private int scroll;                                    // our own displayPos (left scroll offset)

    public FlatEditBox(class_327 font, int x, int y, int w, int h, class_2561 msg) {
        super(font, x, y, w, h, msg);
        this.font = font;
    }

    @Override public void method_1868(int c) { super.method_1868(c); this.color = c; }
    @Override public void method_47404(class_2561 c) { super.method_47404(c); this.hint = c; }
    @Override public void method_1854(BiFunction<String, Integer, class_5481> f) {
        super.method_1854(f);
        this.fmt = f;
    }
    @Override public void method_25365(boolean f) {
        super.method_25365(f);
        if (f) this.focusTime = System.currentTimeMillis();
    }

    @Override
    public void method_48579(class_332 g, int mouseX, int mouseY, float partial) {
        if (!method_1885()) return;

        String value = method_1882();
        int innerW = method_1859();
        int textX = method_46426();                               // borderless: no +4 inset
        int textY = method_46427();                               // borderless: top-aligned (matches vanilla)
        int cursor = method_1881();

        // Empty: draw the hint (placeholder) FIRST, then the caret ON TOP — both inside this
        // widget pass, so the placeholder can't be painted over the caret the way a separate,
        // later screen-side draw did. The hint shows even when focused (the chat input is
        // focus-by-default); its colour comes from the hint Component's own Style.
        if (value.isEmpty()) {
            if (hint != null) g.method_51439(font, hint, textX, textY, color, false);
            caret(g, textX, textY);
            return;
        }

        // Keep the caret inside the visible window — our stand-in for vanilla's private
        // displayPos, recomputed/persisted so the text scrolls but doesn't jump.
        scroll = class_3532.method_15340(scroll, 0, value.length());
        if (cursor < scroll) scroll = cursor;
        while (scroll < cursor && font.method_1727(value.substring(scroll, cursor)) > innerW) scroll++;
        String visible = font.method_27523(value.substring(scroll), innerW);
        int visEnd = scroll + visible.length();

        // Selection box — highlightPos is private, so derive the range from getHighlighted().
        String hl = method_1866();
        if (!hl.isEmpty()) {
            int len = hl.length();
            int a, b;
            if (cursor - len >= 0 && value.substring(cursor - len, cursor).equals(hl)) { a = cursor - len; b = cursor; }
            else { a = cursor; b = Math.min(value.length(), cursor + len); }
            int va = class_3532.method_15340(a, scroll, visEnd), vb = class_3532.method_15340(b, scroll, visEnd);
            if (vb > va) {
                int hx1 = textX + font.method_1727(value.substring(scroll, va));
                int hx2 = textX + font.method_1727(value.substring(scroll, vb));
                g.method_25294(hx1, textY - 1, hx2, textY + 9, SELECT_COLOR);
            }
        }

        // The text, through the box's formatter, drawn flat (dropShadow = false).
        if (!visible.isEmpty()) {
            g.method_51430(font, fmt.apply(visible, scroll), textX, textY, color, false);
        }

        // Caret on top of the text.
        if (cursor >= scroll && cursor <= visEnd) {
            caret(g, textX + font.method_1727(value.substring(scroll, cursor)), textY);
        }
    }

    /** The Cottage pixel-art caret sprite (no "_" glyph → no shadow), blinking on focus, drawn LAST
     *  so it sits on top of the text/placeholder; centred on column x, native 3x10 (crisp, no scale). */
    private void caret(class_332 g, int x, int textY) {
        if (method_25370() && ((System.currentTimeMillis() - focusTime) / BLINK_MS) % 2 == 0) {
            g.method_52706(CARET, x - 1, textY - 1, CARET_W, CARET_H);
        }
    }
}
