package com.dwinovo.numen.entity;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8791;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * The companion body: a server-side fake {@link class_3222}. Replaces the old
 * custom {@code NumenEntity} Mob so the companion is a first-class player —
 * native interaction/combat code paths (universal mod compatibility), its own
 * player inventory, and free chunk loading + playerdata persistence by virtue of
 * being a list-resident player.
 *
 * <h2>Identity &amp; ownership</h2>
 * Created by {@link CompanionFactory} with a stable per-companion UUID (carried
 * in the {@link GameProfile}); the enumerable index lives in
 * {@link CompanionRegistry}. Unlike the Mob, a fake player cannot carry custom
 * {@code SynchedEntityData}, so the owner is a plain server-side field persisted
 * to the companion's own playerdata {@code .dat} via
 * {@link #method_5652}. Owner checks are UUID comparisons — never
 * vanilla {@code isOwnedBy} (which resolves through a level and breaks across
 * dimensions).
 */
public final class NumenPlayer extends class_3222 {

    private static final String NBT_KEY_OWNER = "NumenOwner";

    /** Owner's player UUID. Null only transiently before the first assignment. */
    private UUID ownerUuid;

    /** Latched once we've handled this body's death, so the post-death routine runs exactly once. */
    private boolean deathHandled;

    public NumenPlayer(MinecraftServer server, class_3218 level, GameProfile profile,
                        class_8791 clientInformation) {
        super(server, level, profile, clientInformation);
    }

    /** The loaded companion body with this UUID, or {@code null} if not spawned. */
    public static NumenPlayer findByUuid(MinecraftServer server, UUID uuid) {
        return server.method_3760().method_14602(uuid) instanceof NumenPlayer ap ? ap : null;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public void setOwnerUuid(UUID ownerUuid) {
        this.ownerUuid = ownerUuid;
    }

    /** Cross-dimension safe owner check — UUID comparison, not level-scoped lookup. */
    public boolean isOwnedByPlayer(UUID playerUuid) {
        return ownerUuid != null && ownerUuid.equals(playerUuid);
    }

    /** The owner as an online player, server-wide; null when offline. */
    public class_3222 resolveOwnerPlayer() {
        return ownerUuid == null ? null : method_37908().method_8503().method_3760().method_14602(ownerUuid);
    }


    /** True if {@code item} sits anywhere in the inventory (hotbar/main/offhand all count). */
    public boolean ensureInInventory(class_1792 item) {
        var inv = method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_31574(item)) return true;
        }
        return false;
    }

    /**
     * Hold the item in inventory slot {@code slot} in the main hand the way a real player
     * does — a hotbar slot is simply SELECTED (number-key); a main-inventory slot is SWAPPED
     * into the currently selected hotbar slot (item-conserving). This is the only correct way
     * to "switch to hand": calling {@code setItemInHand(MAIN_HAND, stack)} overwrites the held
     * item (losing it) and aliases ONE {@link net.minecraft.class_1799} across two
     * slots, which corrupts the inventory once the stack is consumed. No-op for {@code slot < 0}.
     */
    public void holdInHand(int slot) {
        if (slot < 0) {
            return;
        }
        var inv = method_31548();
        if (net.minecraft.class_1661.method_7380(slot)) {
            inv.field_7545 = slot;
            return;
        }
        int selected = inv.field_7545;
        net.minecraft.class_1799 held = inv.method_5438(selected);
        inv.method_5447(selected, inv.method_5438(slot));
        inv.method_5447(slot, held);
    }

    // ---- server tick (Carpet's EntityPlayerMPFake trick) ----

    /**
     * Drive the body's own movement physics. A real {@link class_3222} runs
     * {@code travel} (against {@code zza}/{@code xxa}), food, air and pose inside
     * {@link #method_14226()}, which the network layer invokes via
     * {@code connection.tick()}. A fake player's connection is a no-op, so
     * {@code doTick()} never fires and the body would only ever turn (a direct
     * {@code setYRot} write) without walking. The entity system already calls
     * {@code super.tick()} (menus / container / position sync), so we add the
     * missing {@code doTick()} movement pass here — exactly as Carpet's
     * {@code EntityPlayerMPFake.tick()} does. Every 10 ticks we resync the
     * connection position and let chunk loading follow the body so it never
     * walks out of its loaded area.
     */
    @Override
    public void method_5773() {
        // A fake player isn't auto-removed on death (no client to send a respawn packet), so it would
        // sit at 0 HP forever. Detect death once, hand off to the recoverable-death routine (stop the
        // brain, schedule a respawn at the owner), and skip the normal movement/AI tick for this corpse.
        if (!deathHandled && (method_6032() <= 0.0f || method_29504())) {
            deathHandled = true;
            Companions.onDeath(this);
            return;
        }
        if (method_37908() instanceof class_3218 sl && sl.method_8510() % 10 == 0) {
            this.field_13987.method_14372();
            sl.method_14178().method_14096(this);
        }
        super.method_5773();
        try {
            this.method_14226();
        } catch (Exception ignored) {
            // mirrors Carpet — fake-connection internals can NPE on edge cases
        }
    }

    @Override
    public void method_5652(class_2487 output) {
        super.method_5652(output);
        if (ownerUuid != null) {
            output.method_25927(NBT_KEY_OWNER, ownerUuid);   // 1.21.4: no CompoundTag.store(Codec)
        }
    }

    @Override
    public void method_5749(class_2487 input) {
        super.method_5749(input);
        if (input.method_25928(NBT_KEY_OWNER)) this.ownerUuid = input.method_25926(NBT_KEY_OWNER);
    }
}
