package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.data.ClientNumenLocations;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: answer to {@link LocateNumenPayload}. One snapshot per
 * requested UUID — position, dimension and HP for owned + loaded companions,
 * {@code found=false} otherwise. The client drops them into
 * {@link ClientNumenLocations} for the roster panel / vitals strip to read.
 */
public record NumenLocationsPayload(List<Snapshot> snapshots) implements class_8710 {

    /**
     * Wire shape of one located (or not) companion. {@code loaded=false} with
     * {@code found=true} means "asleep in unloaded chunks at its last known
     * position" — position/dimension are valid, vitals are not.
     */
    public record Snapshot(UUID uuid, boolean found, boolean loaded,
                           double x, double y, double z,
                           String dimension, float hp, float maxHp) {

        public static Snapshot notFound(UUID uuid) {
            return new Snapshot(uuid, false, false, 0, 0, 0, "", 0, 0);
        }

        /** A live, ticking companion. */
        public static Snapshot live(UUID uuid, double x, double y, double z,
                                    String dimension, float hp, float maxHp) {
            return new Snapshot(uuid, true, true, x, y, z, dimension, hp, maxHp);
        }

        /** Unloaded — last known position from the persistent index. */
        public static Snapshot lastSeen(UUID uuid, double x, double y, double z, String dimension) {
            return new Snapshot(uuid, true, false, x, y, z, dimension, 0, 0);
        }

        void write(class_2540 buf) {
            buf.method_10797(uuid);
            buf.method_52964(found);
            buf.method_52964(loaded);
            buf.method_52940(x);
            buf.method_52940(y);
            buf.method_52940(z);
            buf.method_10788(dimension, 256);
            buf.method_52941(hp);
            buf.method_52941(maxHp);
        }

        static Snapshot read(class_2540 buf) {
            return new Snapshot(
                    buf.method_10790(),
                    buf.readBoolean(), buf.readBoolean(),
                    buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.method_10800(256),
                    buf.readFloat(), buf.readFloat());
        }
    }

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "numen_locations");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        int n = Math.min(snapshots.size(), LocateNumenPayload.MAX_UUIDS);
        buf.method_10804(n);
        for (int i = 0; i < n; i++) {
            snapshots.get(i).write(buf);
        }
    }

    public static NumenLocationsPayload read(class_2540 buf) {
        int n = Math.min(buf.method_10816(), LocateNumenPayload.MAX_UUIDS);
        List<Snapshot> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(Snapshot.read(buf));
        }
        return new NumenLocationsPayload(list);
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenLocationsPayload p) {
        long now = System.currentTimeMillis();
        for (Snapshot s : p.snapshots()) {
            ClientNumenLocations.update(s.uuid(), new ClientNumenLocations.Snapshot(
                    s.found(), s.loaded(), s.x(), s.y(), s.z(), s.dimension(), s.hp(), s.maxHp(), now));
        }
    }
}
