package com.dwinovo.numen.permission;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_18;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2756;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4284;
import net.minecraft.class_4844;

/**
 * 每维度一份:玩家放过方块的格子,和是谁放的。{@code placed}、{@code self_placed} 信号的来源,也是"这东西是谁的"这个概念在
 * 全仓唯一的落点。
 *
 * <p>记:放的人只在 {@link #placedBy} 一处认——谁放的就记谁,真玩家、同伴都一样,双格方块连它带出来的另一半一起记。
 * 经物品落位的({@code BlockItem.place} 返回处的 mixin)与建造照图直写的都走它。这里只记事实,"算不算别人的东西"
 * 由信号对着要动手的同伴判。
 * 查:格子已是空气视为无记号并顺手清掉——不另挂方块变化钩子,谁挖的都一样。
 *
 * <p>线程:按区块存"格子 → 放的人",每份发布后不再改,改就整个换一份(写时复制,经
 * {@link ConcurrentHashMap#compute}),寻路工作线程无锁读。
 */
public final class PlacedBlocks extends class_18 {

    /**
     * 放下这一格的玩家:{@code id} 认人,{@code name} 是放的那一刻的名字(主人看的"xxx 放的";查不到名字为空串)。
     * 记下放的人之前的存档里的格子不知道是谁放的,是 {@link #UNKNOWN}。
     */
    public record Placer(UUID id, String name) {

        public static final Placer UNKNOWN = new Placer(new UUID(0L, 0L), "");

        /** 说得出是谁:有名字。 */
        public boolean known() {
            return !name.isEmpty();
        }
    }

    /** 同一个人放的格子存成一组。 */
    private record PlacerCells(UUID id, String name, List<Long> cells) {
        static final Codec<PlacerCells> CODEC = RecordCodecBuilder.create(i -> i.group(
                class_4844.field_25122.fieldOf("id").forGetter(PlacerCells::id),
                Codec.STRING.fieldOf("name").forGetter(PlacerCells::name),
                Codec.LONG.listOf().fieldOf("cells").forGetter(PlacerCells::cells)
        ).apply(i, PlacerCells::new));
    }

    /**
     * {@code cells}:不知道是谁放的格子(记下放的人之前的存档);{@code placers}:按放的人分组的格子。
     */
    private static final Codec<PlacedBlocks> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.LONG.listOf().optionalFieldOf("cells", List.of()).forGetter(PlacedBlocks::unknownCells),
            PlacerCells.CODEC.listOf().optionalFieldOf("placers", List.of()).forGetter(PlacedBlocks::placerCells)
    ).apply(i, PlacedBlocks::new));

    // 1.20.4 has SavedData.Factory but not yet the HolderLookup-aware save/load; CODEC (de)serialisation is ours.
    private static final class_18.class_8645<PlacedBlocks> FACTORY = new class_18.class_8645<>(
            PlacedBlocks::new, PlacedBlocks::load, class_4284.field_45082);

    /** {@link class_1923#method_37232} → 该区块内玩家放过的格子({@link class_2338#method_10063})与放的人;值发布后不改。 */
    private final ConcurrentHashMap<Long, Long2ObjectMap<Placer>> byChunk = new ConcurrentHashMap<>();

    public PlacedBlocks() {
    }

    private PlacedBlocks(List<Long> unknown, List<PlacerCells> groups) {
        for (long cell : unknown) {
            put(cell, Placer.UNKNOWN);
        }
        for (PlacerCells group : groups) {
            Placer placer = new Placer(group.id(), group.name());
            for (long cell : group.cells()) {
                put(cell, placer);
            }
        }
    }

    public static PlacedBlocks of(class_3218 level) {
        return level.method_17983().method_17924(FACTORY, "numen_placed");
    }

    static PlacedBlocks load(class_2487 tag) {
        return CODEC.parse(class_2509.field_11560, tag).result().orElseGet(PlacedBlocks::new);
    }

    @Override
    public class_2487 method_75(class_2487 tag) {
        CODEC.encodeStart(class_2509.field_11560, this).result()
                .ifPresent(t -> { if (t instanceof class_2487 c) tag.method_10543(c); });
        return tag;
    }

    /**
     * {@code by} 在 {@code pos} 放下了方块(主线程):记下这一格和放的人,双格方块连它带出来的另一半(门上半、床头)。
     * 放的人只在这里认,名字取放的那一刻的。
     */
    public static void placedBy(class_3218 level, class_2338 pos, class_3222 by) {
        PlacedBlocks placed = of(level);
        Placer placer = new Placer(by.method_5667(), by.method_7334().getName());
        placed.record(pos, placer);
        class_2338 other = otherHalfOf(pos, level.method_8320(pos));
        if (other != null && !level.method_8320(other).method_26215()) {
            placed.record(other, placer);
        }
    }

    /**
     * 双格方块的主半(门的下半、床脚)带出来的另一半在哪;不是双格方块的主半为 null。放置记录、建造判"放一扇门
     * 还要清哪一格"与画设计时"门盖掉哪两格"共用这一处。
     */
    public static class_2338 otherHalfOf(class_2338 pos, class_2680 state) {
        if (state == null) {
            return null;
        }
        if (state.method_28498(class_2741.field_12483)
                && state.method_11654(class_2741.field_12483) == class_2742.field_12557
                && state.method_28498(class_2741.field_12481)) {
            return pos.method_10093(state.method_11654(class_2741.field_12481));
        }
        if (state.method_28498(class_2741.field_12533)
                && state.method_11654(class_2741.field_12533) == class_2756.field_12607) {
            return pos.method_10084();
        }
        return null;
    }

    /** 记一格和放它的人(主线程)。 */
    public void record(class_2338 pos, Placer placer) {
        put(pos.method_10063(), placer);
        method_80();
    }

    /** 抹掉一格的记号。 */
    public void forget(class_2338 pos) {
        long cell = pos.method_10063();
        byChunk.computeIfPresent(chunkKey(pos), (k, old) -> {
            if (!old.containsKey(cell)) {
                return old;
            }
            if (old.size() == 1) {
                return null;
            }
            Long2ObjectOpenHashMap<Placer> next = new Long2ObjectOpenHashMap<>(old);
            next.remove(cell);
            return next;
        });
        method_80();
    }

    /**
     * 这一格是玩家放的吗。{@code now} 是调用方读到的这一格此刻的状态:已是空气就当没有记号,
     * 并顺手把记号清掉。任何线程可调。
     */
    public boolean isPlaced(class_2338 pos, class_2680 now) {
        return placerAt(pos, now) != null;
    }

    /**
     * 放这一格的人;不是玩家放的是 null(已是空气同 {@link #isPlaced},顺手清掉)。不知道是谁放的是
     * {@link Placer#UNKNOWN}。任何线程可调。
     */
    public Placer placerAt(class_2338 pos, class_2680 now) {
        Long2ObjectMap<Placer> cells = byChunk.get(chunkKey(pos));
        Placer placer = cells == null ? null : cells.get(pos.method_10063());
        if (placer == null) {
            return null;
        }
        if (now.method_26215()) {
            forget(pos);
            return null;
        }
        return placer;
    }

    /**
     * {@code center} 周围 {@code radius} 格(切比雪夫)内有没有别人放的方块(含自身)。
     *
     * @param notBy 这个人放的不算(要动手的同伴自己);null = 谁放的都算
     */
    public boolean anyPlacedWithin(class_2338 center, int radius, class_1922 view, UUID notBy) {
        class_2338.class_2339 cursor = new class_2338.class_2339();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    cursor.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    Long2ObjectMap<Placer> cells = byChunk.get(class_1923.method_37232(cursor));
                    if (cells == null || !cells.containsKey(cursor.method_10063())) {
                        continue;
                    }
                    Placer placer = placerAt(cursor.method_10062(), view.method_8320(cursor));
                    if (placer != null && !placer.id().equals(notBy)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** 记着的格子总数(测试与调试用)。 */
    public int size() {
        int n = 0;
        for (Long2ObjectMap<Placer> s : byChunk.values()) {
            n += s.size();
        }
        return n;
    }

    private void put(long cell, Placer placer) {
        byChunk.compute(class_1923.method_37232(class_2338.method_10092(cell)), (k, old) -> {
            Long2ObjectOpenHashMap<Placer> next = old == null ? new Long2ObjectOpenHashMap<>()
                    : new Long2ObjectOpenHashMap<>(old);
            next.put(cell, placer);
            return next;
        });
    }

    private List<Long> unknownCells() {
        List<Long> out = new ArrayList<>();
        for (Long2ObjectMap<Placer> cells : byChunk.values()) {
            for (Long2ObjectMap.Entry<Placer> e : cells.long2ObjectEntrySet()) {
                if (e.getValue().equals(Placer.UNKNOWN)) {
                    out.add(e.getLongKey());
                }
            }
        }
        return out;
    }

    private List<PlacerCells> placerCells() {
        Map<Placer, List<Long>> groups = new LinkedHashMap<>();
        for (Long2ObjectMap<Placer> cells : byChunk.values()) {
            for (Long2ObjectMap.Entry<Placer> e : cells.long2ObjectEntrySet()) {
                if (!e.getValue().equals(Placer.UNKNOWN)) {
                    groups.computeIfAbsent(e.getValue(), k -> new ArrayList<>()).add(e.getLongKey());
                }
            }
        }
        List<PlacerCells> out = new ArrayList<>();
        groups.forEach((placer, cells) -> out.add(new PlacerCells(placer.id(), placer.name(), cells)));
        return out;
    }

    private static long chunkKey(class_2338 pos) {
        return class_1923.method_37232(pos);
    }
}
