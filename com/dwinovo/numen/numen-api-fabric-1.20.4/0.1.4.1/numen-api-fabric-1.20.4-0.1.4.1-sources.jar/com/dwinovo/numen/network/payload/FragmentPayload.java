package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.Fragments;
import com.dwinovo.numen.network.Wire;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * 一条超过单包上限的消息({@link Wire.Fragmentable})的一片:消息号、第几片、共几片,第 0 片再带上原包的种类,其余是编码后字节
 * 的一段。两个方向各有自己的通道 id,加载器都按"一个 id 一个方向"登记。怎么切、怎么拼、拼多大见 {@link Fragments}。
 *
 * <p>{@code id} 是这一片所在方向的通道 id({@link #TO_SERVER_ID}、{@link #TO_CLIENT_ID}),跟着片走,所以一个记录类服务两个方向。
 *
 * @param message 这条消息的号:同一条消息的片都是它
 * @param inner   原包的种类,只有第 0 片带
 * @param chunk   原包编码后字节的一段:除最后一片外都正好是 {@link Fragments#chunkBytes}
 */
public record FragmentPayload(class_2960 id, int message, int index, int count,
                              Optional<class_2960> inner, byte[] chunk) implements class_8710 {

    public static final class_2960 TO_SERVER_ID = new class_2960(Constants.MOD_ID, "fragment_to_server");
    public static final class_2960 TO_CLIENT_ID = new class_2960(Constants.MOD_ID, "fragment_to_client");

    /** 这个方向上的片的通道 id。 */
    public static class_2960 idOf(Wire direction) {
        return direction == Wire.TO_SERVER ? TO_SERVER_ID : TO_CLIENT_ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10804(message);
        buf.method_10804(index);
        buf.method_10804(count);
        if (index == 0) {
            buf.method_10812(inner.orElseThrow());
        }
        buf.method_10813(chunk);
    }

    /** 这个方向上的片的解码器:一片装不了比这个方向的单包上限更多的字节。 */
    public static Function<class_2540, FragmentPayload> decoderOf(Wire direction) {
        return buf -> {
            int message = buf.method_10816();
            int index = buf.method_10816();
            int count = buf.method_10816();
            Optional<class_2960> inner = index == 0 ? Optional.of(buf.method_10810()) : Optional.empty();
            return new FragmentPayload(idOf(direction), message, index, count, inner,
                    buf.method_10803(direction.bytes()));
        };
    }
}
