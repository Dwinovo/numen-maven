package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.Wire;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.entity.CompanionRegistry;
import com.dwinovo.numen.network.NumenNetwork;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

/**
 * Client → Server: "where are these companions of mine right now?" Sent by the
 * roster panel (and the chat vitals strip) for entities the client can't see —
 * a working companion may be ticking in chunk-ticket-loaded terrain thousands
 * of blocks away, or in another dimension.
 *
 * <p>Answered with one {@link NumenLocationsPayload} carrying a snapshot per
 * requested UUID. Ownership is enforced per entity: UUIDs that don't resolve
 * to a pet owned by the sender come back {@code found=false} (no oracle for
 * other players' pets).
 */
public record LocateNumenPayload(List<UUID> entityUuids) implements class_8710 {

    /** Roster panels are small; cap defends against garbage input. */
    public static final int MAX_UUIDS = 16;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "locate_numen");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_34062(entityUuids, (b, id) -> b.method_10797(id));
    }

    public static LocateNumenPayload read(class_2540 buf) {
        return new LocateNumenPayload(Wire.readList(buf, MAX_UUIDS, b -> b.method_10790()));
    }

    /** Handler invoked on the server main thread. */
    public static void handle(LocateNumenPayload p, class_3222 player) {
        List<NumenLocationsPayload.Snapshot> out = new ArrayList<>(p.entityUuids().size());
        CompanionRegistry registry = CompanionRegistry.get(player.method_37908().method_8503());
        for (UUID uuid : p.entityUuids()) {
            NumenPlayer numen = NumenPlayer.findByUuid(player.method_37908().method_8503(), uuid);
            if (numen != null && numen.isOwnedByPlayer(player.method_5667())) {
                out.add(NumenLocationsPayload.Snapshot.live(uuid,
                        numen.method_23317(), numen.method_23318(), numen.method_23321(),
                        numen.method_37908().method_27983().method_29177().toString(),
                        numen.method_6032(), numen.method_6063()));
                continue;
            }
            // Dormant (owner logged out, or not yet respawned this session): fall
            // back to the persistent companion index so the roster can show WHERE
            // it sleeps instead of a useless "offline". Owner-gated — the registry
            // carries ownership and the respawn-hint position.
            CompanionRegistry.Entry entry = registry.find(uuid);
            if (numen == null && entry != null && entry.owner().equals(player.method_5667())) {
                var pos = entry.pos();
                out.add(NumenLocationsPayload.Snapshot.lastSeen(uuid,
                        pos.method_10263(), pos.method_10264(), pos.method_10260(),
                        entry.dimension().method_29177().toString()));
                continue;
            }
            out.add(NumenLocationsPayload.Snapshot.notFound(uuid));
        }
        NumenNetwork.sendToPlayer(player, new NumenLocationsPayload(out));
    }
}
