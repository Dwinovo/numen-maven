package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: an asynchronous WORLD EVENT for a companion's brain (dimension change, a hazard,
 * task wind-down, …). The server ships a ready-made {@code <event>} XML string; the client-side
 * INBOX decides consumption timing by the brain's state at arrival (mid-turn → next boundary;
 * background task running → immediate turn; fully idle → wait for the next turn). {@code principal}
 * marks "a live human is speaking" (bridge mods relaying danmaku / QQ messages): those open a turn
 * even from full idle, same privilege as the owner. Plain world events leave it false — their
 * timing is the inbox's business, not the producer's.
 */
public record NumenEventPayload(UUID entityUuid, String xml, boolean principal) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "numen_event");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_10814(xml);
        buf.method_52964(principal);
    }

    public static NumenEventPayload read(class_2540 buf) {
        return new NumenEventPayload(buf.method_10790(), buf.method_19772(), buf.readBoolean());
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenEventPayload p) {
        AgentLoopRegistry.get(p.entityUuid()).ifPresent(loop -> loop.pushEvent(p.xml(), p.principal()));
    }
}
