package com.dwinovo.numen.entity;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_7648;

/**
 * A channel-less {@link class_2535} for a companion fake {@code ServerPlayer}.
 * The server pushes a steady stream of clientbound packets at any list-resident
 * player (position, chunks, entity updates, keep-alives); a real connection
 * writes them to a netty channel, but our companion has no client on the other
 * end. A bare {@code new Connection(...)} is NOT safe: its {@code send} queues
 * every packet into an unbounded {@code pendingActions} list when no channel is
 * attached — a slow leak. So we subclass and DISCARD all outbound I/O.
 *
 * <p>{@code Connection} is non-final with a public {@code PacketFlow} ctor, so
 * this is pure common code — no reflection, access-wideners or mixins. Two
 * details make {@code placeNewPlayer} accept it:
 * <ul>
 *   <li><b>SERVERBOUND</b> receiving flow — a server-side player connection
 *       receives serverbound packets, so its listener is serverbound;
 *       {@code validateListener} rejects a CLIENTBOUND mismatch.</li>
 *   <li>a real (in-memory) {@link EmbeddedChannel} — registering this Connection
 *       as the embedded channel's handler fires {@code channelActive}, setting
 *       {@code this.channel} so {@code placeNewPlayer} has a channel to work on.</li>
 * </ul>
 * Outbound packets are still discarded by the {@code send} override (the embedded
 * channel is never written to, so it never buffers/leaks), and the keep-alive
 * timeout is neutralised via the no-op {@code disconnect}. Lifecycle is governed
 * by {@code CompanionLifecycle}, not by connection state.
 *
 * <p>1.20.2 introduced the configuration phase: the packet codec now lives in
 * channel ATTRIBUTES ({@code ATTRIBUTE_*_PROTOCOL}), and
 * {@code ServerGamePacketListenerImpl}'s ctor reads them immediately — a bare
 * embedded channel NPEs there, so both attributes are seeded with the PLAY
 * codec below.
 */
@com.dwinovo.numen.api.Internal
public final class FakeConnection extends class_2535 {

    public FakeConnection() {
        super(class_2598.field_11941);
        // channelActive (fired by registering this handler) sets this.channel.
        EmbeddedChannel ch = new EmbeddedChannel(this);
        // 1.20.2:协议编解码挂在 channel attribute 上,placeNewPlayer →
        // ServerGamePacketListenerImpl 构造即读取,不种直接 NPE。
        ch.attr(class_2535.field_45666)
                .set(net.minecraft.class_2539.field_20591.method_52921(class_2598.field_11941));
        ch.attr(class_2535.field_45667)
                .set(net.minecraft.class_2539.field_20591.method_52921(class_2598.field_11942));
    }

    /** Discard every outbound packet — there is no client to receive it.
     *  1.20.1's {@code send(Packet)} routes through this 2-arg overload. */
    @Override
    public void method_10752(class_2596<?> packet, class_7648 listener) {
        // no-op: drop it on the floor (no channel, no pendingActions growth)
    }

    /**
     * Report live so player ticking / chunk tracking proceed as for a real
     * player. Safe because every channel-dereferencing path (send, tick) is
     * overridden to no-op, so the null channel is never touched.
     */
    @Override
    public boolean method_10758() {
        return true;
    }

    /** Don't drive the packet listener's tick (that's what runs the keep-alive). */
    @Override
    public void method_10754() {
        // no-op
    }

    /** Neutralise the keep-alive timeout (and any other) disconnect. */
    @Override
    public void method_10747(class_2561 message) {
        // no-op: the companion is removed via CompanionLifecycle, never by the wire
    }

    @Override
    public void method_10768() {
        // no-op
    }

    @Override
    public void method_10757() {
        // no-op
    }
}
