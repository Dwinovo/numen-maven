package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.brain.Feed;
import com.dwinovo.numen.api.network.ClientPayloadSink;
import com.dwinovo.numen.api.network.Wire;
import com.google.gson.JsonParser;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: 一只同伴一刻里发生的、界面要画要听的事({@link Feed}),按发生的先后。一行日志里的工具结果可以很长,
 * 一刻的事件可能装不下一个包,所以可分片。
 */
public record FeedPayload(UUID companion, String eventsJson) implements class_8710, Wire.Fragmentable {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "feed");

    public static FeedPayload of(UUID companion, List<Feed> events) {
        return new FeedPayload(companion, Feed.toJson(events).toString());
    }

    /** 读出事件;读不懂的种类(新版本加的)跳过。 */
    public List<Feed> events() {
        return Feed.listFromJson(JsonParser.parseString(eventsJson).getAsJsonArray());
    }

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10797(companion);
        Wire.writeText(buf, eventsJson);
    }

    public static FeedPayload read(class_2540 buf) {
        return new FeedPayload(buf.method_10790(), Wire.readText(buf));
    }

    /** Client main thread. */
    public static void handle(FeedPayload p) {
        ClientPayloadSink.feed.accept(p);
    }
}
