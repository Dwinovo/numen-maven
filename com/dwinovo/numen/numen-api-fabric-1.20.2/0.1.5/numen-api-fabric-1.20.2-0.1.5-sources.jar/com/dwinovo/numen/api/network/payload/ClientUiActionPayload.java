package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: ask the receiving owner's client to perform a local UI action.
 * The {@code /numen} command tree lives entirely on the server now (so it
 * doesn't collide with the client-side command dispatcher), but a couple of its
 * verbs — opening the settings GUI, clearing the conversation loops — are
 * inherently client-local. The server command just fires this packet at the
 * caller and their client does the rest.
 */
public record ClientUiActionPayload(Action action) implements class_8710 {

    public enum Action { OPEN_SETTINGS, DEBUG_TEXT_ON, DEBUG_TEXT_OFF }

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "client_ui_action");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10817(action);
    }

    public static ClientUiActionPayload read(class_2540 buf) {
        return new ClientUiActionPayload(buf.method_10818(Action.class));
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(ClientUiActionPayload p) {
        com.dwinovo.numen.api.network.ClientPayloadSink.uiAction.accept(p);
    }
}
