package com.dwinovo.numen.api.entity;

import com.dwinovo.numen.api.platform.Services;
import net.minecraft.class_1297;
import net.minecraft.class_1690;
import net.minecraft.class_243;
import net.minecraft.class_3532;

/**
 * 同伴坐在载具里的驾驶:船压舵、马转身再按前进。走、跳、潜行、停是她的键盘({@link NumenPlayer#controls},{@link Controls}),
 * 看向哪儿、转身朝一个方向是她的视角({@link NumenPlayer#look},{@link Look}),这里只在它们上面管载具。
 */
public final class InputDriver {

    private InputDriver() {}

    /** 船的转向死区(度):差角小于它就不压舵。太小会和转向动量打架来回摆头。 */
    private static final float BOAT_TURN_DEADBAND = 5.0f;

    /**
     * 骑乘驾驶:朝 {@code target} 压舵,行进期间每刻调用。
     *
     * <p>船走原版桨物理:按差角给左右键、恒按前进,然后调原版 {@code controlBoat}
     * (经 {@link Services#BOATS})——输入语义和真玩家按 WASD 完全一致,推进常数零复制,
     * 划桨动画照常同步。服务端能动船的前提是原版把她当本机玩家(见 {@code NumenPlayer.isLocalPlayer})。
     *
     * <p>马这类生物载具由原版 {@code travelRidden} 读<b>骑手</b>的朝向与前进键,
     * 转过去、按住她的前进键即可,不用碰载具。
     */
    public static void steerVehicle(NumenPlayer p, class_243 target) {
        class_1297 vehicle = p.method_5854();
        if (vehicle instanceof class_1690 boat) {
            double dx = target.field_1352 - boat.method_23317();
            double dz = target.field_1350 - boat.method_23321();
            float want = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float diff = class_3532.method_15393(want - boat.method_36454());
            boat.method_7535(diff < -BOAT_TURN_DEADBAND, diff > BOAT_TURN_DEADBAND, true, false);
            Services.boats().paddle(boat);
            p.look().faceToward(target.field_1352, target.field_1350);   // 乘员朝向不驱动船,看向去处只是像个人
            return;
        }
        p.look().faceToward(target.field_1352, target.field_1350);
        p.controls().press(Controls.Key.FORWARD);
    }

    /** 松舵:船停桨,她的走路键松开。离开驾驶状态的每刻收尾。 */
    public static void haltVehicle(NumenPlayer p) {
        if (p.method_5854() instanceof class_1690 boat) {
            boat.method_7535(false, false, false, false);
        }
        p.controls().stop();
    }
}
