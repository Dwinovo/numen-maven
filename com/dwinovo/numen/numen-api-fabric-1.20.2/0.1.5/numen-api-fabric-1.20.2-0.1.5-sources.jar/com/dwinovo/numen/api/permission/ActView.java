package com.dwinovo.numen.api.permission;

import com.dwinovo.numen.api.data.ModLanguageData;
import com.dwinovo.numen.permission.Act;
import com.dwinovo.numen.permission.Atom;
import com.dwinovo.numen.permission.Rule;
import com.dwinovo.numen.permission.Verb;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * 游戏里的一下动作,按规则核心的口({@link Act})回答:{@link Action} 说做什么、对什么,{@link Facts} 说世界此刻的样子。
 * 组与属性交给 {@link Groups},种类 id 与标签这里认,指令认 {@link Action.CommandLine#names}。
 */
final class ActView implements Act {

    private final Action action;
    private final Facts facts;
    private Whose whose;
    private boolean whoseKnown;

    ActView(Action action, Facts facts) {
        this.action = action;
        this.facts = facts;
    }

    Action action() {
        return action;
    }

    Facts facts() {
        return facts;
    }

    /**
     * 动作的对象是谁的(归属,见 {@link Whose}):实体按驯服记录,格子上的方块按放置记录、结构、自然方块表。
     * 丢东西与指令没有这样的对象,为 null。一次裁决里几行规则问好几遍,算一次。
     */
    Whose whose() {
        if (!whoseKnown) {
            whose = action.entity() != null ? Whose.ofEntity(action.entity(), facts)
                    : action.pos() != null ? Whose.ofBlock(action, facts) : null;
            whoseKnown = true;
        }
        return whose;
    }

    /** 这一格上放置记号记的那一位;没有记号为 null。 */
    PlacedBlocks.Placer placer() {
        return action.pos() == null || facts.placed() == null ? null
                : facts.placed().placerIn(facts.view(), action.pos());
    }

    @Override
    public Verb verb() {
        return action.kind();
    }

    @Override
    public String actor() {
        return facts.actor().name();
    }

    @Override
    public boolean is(String name, String arg) {
        return Groups.byName(name).test(this, arg);
    }

    /** 挖/右键/拿看格子上的方块,放看要放的方块,实体动作看实体种类,其余看物品。 */
    @Override
    public boolean ofKind(String id) {
        class_2960 kind = subjectId(action);
        return kind != null && kind.equals(new class_2960(id));
    }

    @Override
    public boolean tagged(String tag) {
        class_2960 id = new class_2960(tag);
        class_2248 block = subjectBlock(action);
        if (block != null) {
            return class_7923.field_41175.method_47983(block).method_40220(class_6862.method_40092(class_7924.field_41254, id));
        }
        if (action.entity() != null) {
            return action.entity().method_5864().method_20210(class_6862.method_40092(class_7924.field_41266, id));
        }
        return action.item() != null
                && class_7923.field_41178.method_47983(action.item()).method_40220(class_6862.method_40092(class_7924.field_41197, id));
    }

    @Override
    public boolean isEntity(String uuid) {
        return action.entity() != null && action.entity().method_5667().toString().equals(uuid);
    }

    @Override
    public boolean runs(String command) {
        return action.command() != null && action.command().names().contains(command);
    }

    @Override
    public String subject() {
        if (action.command() != null) {
            return action.command().root();
        }
        class_2960 id = subjectId(action);
        return id == null ? null : id.toString();
    }

    @Override
    public String entityKey() {
        return action.entity() == null ? null : action.entity().method_5667().toString();
    }

    /**
     * 这个动作命中 {@code rule} 的理由给主人看的那一版:按主人的语言显示(说得出谁放的就说谁),
     * 种类、标签与实体照原文。没有可说的就是规则原文。
     */
    class_2561 shown(Rule rule) {
        class_5250 out = null;
        for (Atom atom : rule.reasons(this)) {
            class_2561 term = switch (atom.type()) {
                case NAMED -> Groups.byName(atom.name()).shown(this, atom.arg());
                case COMMAND -> class_2561.method_43470("/" + atom.name());
                default -> class_2561.method_43470(atom.text());
            };
            out = out == null ? class_2561.method_43473().method_10852(term)
                    : out.method_10852(class_2561.method_43471(ModLanguageData.Keys.LIST_SEPARATOR)).method_10852(term);
        }
        return out == null ? class_2561.method_43470(rule.toString()) : out;
    }

    /** 种类项认的那个 id:挖/右键/拿看格子上的方块,放看要放的方块,实体动作看实体种类,其余看物品。 */
    private static class_2960 subjectId(Action a) {
        class_2248 block = subjectBlock(a);
        if (block != null) {
            return class_7923.field_41175.method_10221(block);
        }
        if (a.entity() != null) {
            return class_1299.method_5890(a.entity().method_5864());
        }
        return a.item() == null ? null : class_7923.field_41178.method_10221(a.item());
    }

    private static class_2248 subjectBlock(Action a) {
        return switch (a.kind()) {
            case BREAK, USE_BLOCK, TAKE -> a.state() == null ? null : a.state().method_26204();
            case PLACE -> a.item() instanceof class_1747 bi ? bi.method_7711() : null;
            default -> null;
        };
    }
}
