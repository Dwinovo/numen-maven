package com.dwinovo.numen.api.permission;

import com.dwinovo.numen.api.data.ModLanguageData;
import com.dwinovo.numen.permission.Rule;
import com.dwinovo.numen.permission.Verb;
import com.dwinovo.numen.permission.Verdict;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_7923;

/**
 * 征询清单里的一条:一个等主人点头的动作。主人允许之后它就是一条任务期授权
 * ({@link #covers}),裁决把被它覆盖的 ask 放行;主人选"允许并记住"时,{@link #remember} 那一行写进
 * 主人的 allow 表。
 *
 * <p>同一件事两种说法:给模型的是英文短语({@code subject}、{@code cause}),给主人看的是物品图标与可翻译的
 * {@link class_2561}({@code icon}、{@code name}、{@code shownCause}),由主人的客户端按自己的语言显示——方块画成
 * 它的物品图标,起了名字的动物叫它的名字。两种说法在建这一条时从同一个动作、同一行规则一起得出。
 *
 * @param kind         动词
 * @param pos          方块动作的格子;实体动作与丢弃为 null——实体认的是那一只({@code entityId}),不是它脚下的格:
 *                     它走一步清单就不该变,否则同一件事会被当成新的征询重发
 * @param entityId     实体动作的实体 id;其余为 {@link #NO_ENTITY}
 * @param subject      方块、实体种类或物品的 id 路径({@code oak_log}、{@code wolf}、{@code diamond});指令是带 {@code /}
 *                     的整行({@code /setblock 1 64 2 stone});改区域是区域名({@code house})
 * @param icon         给主人看的图标:方块的物品形态、物品本身;实体、指令、区域与没有物品形态的方块为 null
 * @param name         给主人看的名字(没有图标时显示):方块、物品的名字,实体的名字(起了名的就是那个名字),
 *                     指令的整行,区域名
 * @param rule         问的是哪一行规则的原文;没有任何一行覆盖时为空串
 * @param cause        为什么要问:那一行规则的自述({@code placed by a player})
 * @param shownCause   给主人看的为什么要问:命中那行规则就这个动作说的那一版({@link ActView#shown}),哪一行都没说到就说没有规则
 * @param irreversible 这件事撤不回(对象身上有在这个动词下算撤不回的名字,见 {@link com.dwinovo.numen.permission.Vocabulary#irreversible})
 * @param remember     主人说"允许并记住"时存下的那一行 allow(推法见 {@link Rule#remembering});改规则的征询({@link #ruleEdit})
 *                     不能记住,为 null——她不能给自己发许可
 */
public record ConsentItem(Verb kind, class_2338 pos, int entityId, String subject, class_1792 icon, class_2561 name,
                          String rule, String cause, class_2561 shownCause, boolean irreversible, Rule remember) {

    public static final int NO_ENTITY = -1;

    public ConsentItem {
        pos = pos == null ? null : pos.method_10062();
    }

    /**
     * 她要改主人规则的一条征询:放宽(加 allow)与删行她自己不能做,主人点头才写。卡上就写成她没法自己跑的那条命令
     * ({@code /numen permission rules add allow …}),主人看得懂,也能自己敲。不能"允许并记住"。
     *
     * @param line   不带前导 {@code /} 的整行命令,如 {@code numen permission rules add allow break(owner)}
     * @param detail 命令本身说不清的补一句给主人看(删第几行,那一行是什么);没有为空串
     */
    public static ConsentItem ruleEdit(String line, String detail) {
        String shown = "/" + line;
        return new ConsentItem(Verb.COMMAND, null, NO_ENTITY, shown, null,
                class_2561.method_43470(detail.isEmpty() ? shown : shown + "  (" + detail + ")"), "",
                "changes the owner's rules", class_2561.method_43471(ModLanguageData.Keys.PERMISSION_RULE_EDIT), false,
                null);
    }

    /**
     * 她要对一个来历不明的界面做事(不是右键一格方块打开的,不知道它是哪一格):没有格子可交权限层裁决,拿不准就问主人。卡上写
     * 是什么界面;不能"允许并记住"(没有哪一格可记)。
     *
     * @param what 这个界面叫什么,如 {@code a beacon}
     */
    public static ConsentItem unknownWindow(String what) {
        return new ConsentItem(Verb.USE_BLOCK, null, NO_ENTITY, what, null, class_2561.method_43470(what), "",
                "no one can say whose block this window belongs to",
                class_2561.method_43471(ModLanguageData.Keys.PERMISSION_UNCOVERED), false, null);
    }

    /**
     * 清单里的一堆:同一个动词、同一种东西、同一个理由。给模型的说法({@link #text})与给主人看的那一版
     * (动词、{@code head} 的图标或名字、数量、{@code head} 的 {@code shownCause})都从这一堆出。
     *
     * @param head  这一堆的第一条
     * @param count 这一堆有几条
     * @param cells 这一堆点得出的格子(实体与丢弃没有)
     */
    public record Group(ConsentItem head, int count, List<class_2338> cells) {

        public boolean irreversible() {
            return head.irreversible;
        }

        /** 给模型:{@code break 6 oak_log (1,64,2; …; +2 more): placed by a player}。 */
        public String text() {
            return head.kind.word() + ' ' + Listing.part(head.subject, count, cells) + ": " + head.cause;
        }
    }

    /**
     * 从一个被裁成 ask 的动作建一条({@link Gate#consentItem} / {@link Gate#consentItemLive})。
     *
     * @param facts 裁决这个动作用的那一份事实——记住的规则按它推
     */
    static ConsentItem of(Action action, Verdict verdict, Facts facts) {
        String rule = verdict.rule() == null ? "" : verdict.rule().toString();
        ActView now = new ActView(action, facts);
        ActView blind = new ActView(action, facts.withoutLive());
        boolean irreversible = Groups.VOCABULARY.irreversible(now);
        Rule remember = Rule.remembering(now, blind, verdict.rule(), Groups.VOCABULARY);
        class_2561 why = verdict.rule() != null ? now.shown(verdict.rule())
                : class_2561.method_43471(ModLanguageData.Keys.PERMISSION_UNCOVERED);
        return switch (action.kind()) {
            case ATTACK, USE_ENTITY -> new ConsentItem(action.kind(), null, action.entity().method_5628(),
                    class_1299.method_5890(action.entity().method_5864()).method_12832(), null, action.entity().method_5477(), rule,
                    verdict.cause(), why, irreversible, remember);
            case DROP -> {
                Subject subject = Subject.of(action);
                yield new ConsentItem(action.kind(), null, NO_ENTITY, subject.id, subject.icon, subject.name, rule,
                        verdict.cause(), why, irreversible, remember);
            }
            default -> {
                Subject subject = Subject.of(action);
                yield new ConsentItem(action.kind(), action.pos(), NO_ENTITY, subject.id, subject.icon, subject.name,
                        rule, verdict.cause(), why, irreversible, remember);
            }
        };
    }

    /** 一批清单要记住的规则,去重、保持先后。 */
    public static List<Rule> remembered(List<ConsentItem> items) {
        List<Rule> rules = new ArrayList<>();
        for (ConsentItem item : items) {
            if (item.remember != null && !rules.contains(item.remember)) {
                rules.add(item.remember);
            }
        }
        return rules;
    }

    /**
     * 选"允许并记住"会写进主人 allow 表的那几行,写成表里的样子({@code allow break(placed & oak_log)})。
     * 主人在选项上看到的、回执里交代给模型的,都是这一份。
     */
    public static List<String> rememberedRows(List<ConsentItem> items) {
        List<String> rows = new ArrayList<>();
        for (Rule rule : remembered(items)) {
            rows.add("allow " + rule);
        }
        return rows;
    }

    /**
     * 主人对这一条的同意覆盖不覆盖这个动作:同一个动词、同一行规则问出来的,而且是同一种东西——
     * 方块与物品认种类,实体认那一只,指令认整行。于是挖一堆主人放的原木只问一次,换成主人放的箱子另问;
     * 点头打的是这只狼,别的狼另问。
     *
     * @param hit 这个动作此刻命中的那行 ask 规则;没有任何一行覆盖时为 null
     */
    public boolean covers(Action action, Rule hit) {
        return covers(action.kind(), hit == null ? "" : hit.toString(),
                action.entity() != null ? action.entity().method_5628() : NO_ENTITY, Subject.of(action).id);
    }

    /** 主人对这一条的同意覆盖不覆盖另一条征询:与 {@link #covers(Action, Rule)} 同一个判据。 */
    public boolean covers(ConsentItem other) {
        return covers(other.kind, other.rule, other.entityId, other.subject);
    }

    private boolean covers(Verb otherKind, String otherRule, int otherEntity, String otherSubject) {
        if (otherKind != kind || !rule.equals(otherRule)) {
            return false;
        }
        return switch (kind) {
            case ATTACK, USE_ENTITY -> otherEntity != NO_ENTITY && otherEntity == entityId;
            default -> subject.equals(otherSubject);
        };
    }

    /**
     * 清单,一堆一条:按"动词 + 对象 + 理由"归堆(实体按名字、玩家放的按谁放的再分开),保持先出现的先列。
     * 答复框与回执都用这一份。
     */
    public static List<Group> listing(List<ConsentItem> items) {
        Map<String, List<ConsentItem>> groups = new LinkedHashMap<>();
        for (ConsentItem item : items) {
            String key = item.kind.word() + ' ' + item.subject + ' ' + item.name.getString() + ' ' + item.rule
                    + ' ' + item.shownCause.getString();
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(item);
        }
        List<Group> out = new ArrayList<>();
        for (List<ConsentItem> group : groups.values()) {
            List<class_2338> cells = new ArrayList<>();
            for (ConsentItem item : group) {
                if (item.pos != null) {
                    cells.add(item.pos);
                }
            }
            out.add(new Group(group.get(0), group.size(), cells));
        }
        return out;
    }

    /** 清单拼成一句给模型(回执用)。 */
    public static String listingText(List<ConsentItem> items) {
        List<String> texts = new ArrayList<>();
        for (Group group : listing(items)) {
            texts.add(group.text());
        }
        return String.join("; ", texts);
    }

    /** 方块、物品、指令与区域动作的对象:挖、右键、拿看格子上的方块,放、丢看物品,指令就是那一整行,改区域是那块区域的名字。 */
    private record Subject(String id, class_1792 icon, class_2561 name) {

        static Subject of(Action action) {
            if (action.command() != null) {
                String line = "/" + action.command().line();
                return new Subject(line, null, class_2561.method_43470(line));
            }
            class_2680 state = action.state();
            if (state != null && action.kind() != Verb.PLACE) {
                class_1792 form = state.method_26204().method_8389();
                return new Subject(class_7923.field_41175.method_10221(state.method_26204()).method_12832(),
                        form == class_1802.field_8162 ? null : form, state.method_26204().method_9518());
            }
            if (action.item() != null) {
                return new Subject(class_7923.field_41178.method_10221(action.item()).method_12832(), action.item(),
                        action.item().method_7848());
            }
            return new Subject("block", null, class_2561.method_43471(ModLanguageData.Keys.PERMISSION_A_BLOCK));
        }
    }
}
