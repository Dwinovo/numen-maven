package com.dwinovo.numen.api.permission;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2791;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_3449;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

/**
 * 世界生成时记下的结构件范围,一份不可变的快照:一个格子在不在某个生成结构的某一件里(村庄的房子与路、废弃矿井的巷道、
 * 沉船),以及那是哪种结构。结构记录随区块存档({@code StructureManager} 读的就是它),装模组之前生成的结构也在。
 *
 * <p>主线程按她身边的已加载区块捕获一次({@link #capture}),之后任何线程只读——寻路工作线程给每条边定价、主线程判一下动作,
 * 问的是同一份。离她超出捕获半径的格子认不出结构,等她走近、下一份快照里就有了。
 */
public record Structures(List<Piece> pieces) {

    /** 一件结构件:它的包围盒,和它属于哪种结构。 */
    public record Piece(class_3341 box, class_6880<class_3195> structure) {}

    public static final Structures NONE = new Structures(List.of());

    /** 捕获半径(区块):结构起点的区块离被问的格子不会比这更远。 */
    public static final int CAPTURE_RADIUS_CHUNKS = 10;

    public Structures {
        pieces = List.copyOf(pieces);
    }

    /** {@code center} 周围 {@code chunkRadius} 个区块内、已加载区块里的结构件。主线程。 */
    public static Structures capture(class_3218 level, class_2338 center, int chunkRadius) {
        class_2378<class_3195> registry = level.method_30349().method_30530(class_7924.field_41246);
        class_1923 at = new class_1923(center);
        List<Piece> pieces = new ArrayList<>();
        for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
            for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                class_2791 chunk = level.method_14178().method_21730(at.field_9181 + dx, at.field_9180 + dz);
                if (chunk == null) {
                    continue;
                }
                for (Map.Entry<class_3195, class_3449> start : chunk.method_12016().entrySet()) {
                    if (!start.getValue().method_16657()) {
                        continue;
                    }
                    class_6880<class_3195> kind = registry.method_47983(start.getKey());
                    start.getValue().method_14963().forEach(piece -> pieces.add(new Piece(piece.method_14935(), kind)));
                }
            }
        }
        return new Structures(pieces);
    }

    /** 盖住这一格的结构件;不在任何结构里为 null。 */
    public Piece pieceAt(class_2338 pos) {
        for (Piece piece : pieces) {
            if (piece.box().method_14662(pos)) {
                return piece;
            }
        }
        return null;
    }
}
