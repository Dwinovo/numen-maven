package com.dwinovo.numen.api.permission;

import com.dwinovo.numen.permission.Verb;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.RootCommandNode;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * 身体要对世界做的一件具体的事及其目标。不带工具名、不带 JSON:权限是动作的属性,
 * 哪个工具走到这里都送同一种东西。
 *
 * @param kind    动词
 * @param pos     方块动作的格子;实体动作、丢弃与指令为 null
 * @param state   方块动作发生时那一格的方块状态(挖:要挖的;放:要被盖掉的;右键:被点的)
 * @param entity  实体动作的对象
 * @param item    放/拿/丢的物品;规划期还不知道会用哪种耗材时为 null
 * @param command 执行的游戏指令;其余动作为 null
 */
public record Action(Verb kind, class_2338 pos, class_2680 state, class_1297 entity, class_1792 item, CommandLine command) {

    /**
     * 一条游戏指令。规则按根名认它({@code command(setblock)}),认的是 {@link #names}:她打的那个根,连同服务器
     * 指令树上与它同指一个节点的别名——{@code tp} 与 {@code teleport}、{@code msg} 与 {@code tell}、{@code w}。
     * 主人写 {@code deny command(tp)} 说的是"传送",换个别名不该绕过去。
     *
     * @param line  整行,不带前导 {@code /}
     * @param root  她打的那个根
     * @param names 规则认的名字:{@code root} 与它的别名
     */
    public record CommandLine(String line, String root, Set<String> names) {
        public CommandLine {
            names = Set.copyOf(names);
        }
    }

    public Action {
        pos = pos == null ? null : pos.method_10062();
    }

    public static Action breakBlock(class_2338 pos, class_2680 state) {
        return new Action(Verb.BREAK, pos, state, null, null, null);
    }

    /** @param item 要放的物品;规划期未定时传 null */
    public static Action place(class_2338 pos, class_2680 current, class_1792 item) {
        return new Action(Verb.PLACE, pos, current, null, item, null);
    }

    public static Action attack(class_1297 target) {
        return new Action(Verb.ATTACK, null, null, target, null, null);
    }

    public static Action useBlock(class_2338 pos, class_2680 state) {
        return new Action(Verb.USE_BLOCK, pos, state, null, null, null);
    }

    public static Action useEntity(class_1297 target) {
        return new Action(Verb.USE_ENTITY, null, null, target, null, null);
    }

    public static Action take(class_2338 container, class_2680 state, class_1792 item) {
        return new Action(Verb.TAKE, container, state, null, item, null);
    }

    public static Action drop(class_1792 item) {
        return new Action(Verb.DROP, null, null, null, item, null);
    }

    /**
     * 以她的身份执行一条游戏指令。根名在服务器的指令树上认:与她打的那个根同指一个节点的根(重定向到它的,
     * 或它重定向去的)都算它的别名,见 {@link CommandLine}。
     *
     * @param line 整行,不带前导 {@code /}
     * @param tree 服务器指令树的根——她的指令就在这棵树上解析
     */
    public static Action command(String line, RootCommandNode<?> tree) {
        String text = line.strip();
        int space = text.indexOf(' ');
        String root = space < 0 ? text : text.substring(0, space);
        Set<String> names = new TreeSet<>();
        names.add(root);
        CommandNode<?> typed = tree.getChild(root);
        if (typed != null) {
            CommandNode<?> target = target(typed);
            for (CommandNode<?> node : tree.getChildren()) {
                if (target(node) == target) {
                    names.add(node.getName());
                }
            }
        }
        return new Action(Verb.COMMAND, null, null, null, null, new CommandLine(text, root, names));
    }

    /** 一个根真正指向的节点:别名重定向去的那个,不是别名就是它自己。 */
    private static CommandNode<?> target(CommandNode<?> node) {
        return node.getRedirect() != null ? node.getRedirect() : node;
    }

    /**
     * 回执里点名用:{@code break oak_log at 1,2,3}、{@code attack zombie}、{@code command /give @s diamond}。
     */
    public String describe() {
        StringBuilder sb = new StringBuilder(kind.word());
        if (command != null) {
            sb.append(" /").append(command.line());
        } else if (state != null) {
            sb.append(' ').append(net.minecraft.class_7923.field_41175
                    .method_10221(state.method_26204()).method_12832());
        } else if (item != null) {
            sb.append(' ').append(net.minecraft.class_7923.field_41178
                    .method_10221(item).method_12832());
        }
        if (entity != null) {
            sb.append(' ').append(entity.method_5477().getString());
        }
        if (pos != null) {
            sb.append(" at ").append(pos.method_10263()).append(',').append(pos.method_10264()).append(',').append(pos.method_10260());
        }
        return sb.toString();
    }
}
