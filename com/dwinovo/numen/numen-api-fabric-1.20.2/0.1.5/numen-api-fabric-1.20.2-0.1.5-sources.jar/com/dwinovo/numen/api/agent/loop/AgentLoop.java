package com.dwinovo.numen.api.agent.loop;

import com.dwinovo.numen.api.agent.http.CancelToken;
import com.dwinovo.numen.api.agent.inbox.EventQueue;
import com.dwinovo.numen.api.agent.inbox.EventTypes;
import com.dwinovo.numen.api.agent.llm.ConvoState;
import com.dwinovo.numen.api.agent.llm.ToolOutcome;
import com.dwinovo.numen.api.agent.provider.AssistantTurn;
import com.dwinovo.numen.api.agent.provider.LlmToolCall;
import com.dwinovo.numen.api.ai.AiLog;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * 同伴大脑的循环内核:一个 ReAct 循环加一个事件队列。设计见 {@code docs/agent-loop.md}。
 *
 * <h2>状态只有两样</h2>
 * <ul>
 *   <li><b>{@link Run}</b>——手上正在做的那件事;{@code null} 就是闲。"在不在跑"只问它,异步回调带着
 *       run 的编号回来,对不上就丢。</li>
 *   <li><b>{@link Hold}</b>——为什么不开 run,谁解开写在 {@link Hold#releasedBy} 的表里。</li>
 * </ul>
 *
 * <h2>唯一的推进点 {@link #pump}</h2>
 * 入队、run 结束、停牌解开、每个 tick 之后都只调它。它一步一步往下走({@link #step}:开 run / 执行控制条目 /
 * 什么也不做,只有这一个判断),直到没有能同步做完的事;不递归,调用栈不随步数变深。它只在真的开 run 或
 * 执行控制条目时打日志——停牌时每 tick 调一次也没有输出。
 *
 * <h2>一次 run 是两层循环</h2>
 * <pre>
 * startRun → turn:要不要调模型 →(先看自动压缩)→ 注入 → 调模型
 *            onModel:有工具调用 → 串行跑工具 → 全部结算 → turn
 *                     最终回复   → turn(队里有要她回应的就接着走,没有才结束)
 * </pre>
 * 每次调模型带上哪些条目、本来要停时要不要接着走,只看各投递档自己的声明
 * ({@link EventTypes.Delivery#wakes}/{@link EventTypes.Delivery#joins}),取件在 {@link EventQueue#takeForCall}
 * 一处;带上的一次取光合成一条 user。控制条目是循环在闲时自己执行的,排在它后面的等它执行完。
 *
 * <h2>切断只有一个入口 {@link #halt}</h2>
 * 主人停止、死亡、登出、外接接管、遣散的差别只在 {@link HaltReason} 那张表。
 *
 * <h2>对外只发事件</h2>
 * 界面、记账、落盘都订阅 {@link LoopEvent};内核读写的只有端口、会话历史和队列。
 *
 * <p>纯 JVM。一切状态只在一个线程(客户端主线程)上读写,端口负责把异步回调切回这个线程。
 */
public final class AgentLoop {

    /** 模型回了一个既没正文也没工具调用的空回复:算失败,不重试——重试的范围是调用本身出错。 */

    private final String name;
    private final ModelPort model;
    private final ToolPort tools;
    private final ConvoState transcript;
    private final EventQueue inbox;
    private final MemoryPort memory;
    private final HostPort host;
    private final List<Subscriber> listeners = new ArrayList<>();

    private Run run;
    private long lastRunId;
    /** 身体死着(身体事实,复活才解开)。 */
    private boolean dead;
    /** 后三种停牌:OWNER_STOP / BLOCKED / FAILED;{@code null} = 没有。 */
    private Hold stopped;
    /** 进入 {@link #stopped} 时带的那句话(端点不可用、失败的原因);解开时一起清。 */
    private Cause stoppedReason;
    /** 最近一次对外报过的停牌。只用来找变化沿发 {@link LoopEvent.HoldChanged},不参与任何判断。 */
    private Hold announced;
    /** 这次整理记忆已经流回来的摘要字数。 */
    private int compactChars;
    /** 正在 {@link #pump} 的那一圈里。这期间再来的推进请求不重入,只记下"再看一眼"。 */
    private boolean pumping;
    /** {@link #pump} 期间有人又要求推进(run 当场结束、订阅者推了新输入):那一圈做完接着再看一眼。 */
    private boolean pumpAgain;
    /** 外接大脑交来、正借用工具口的那一个调用的回报口({@link #runAside});没有是 {@code null}。 */
    private Consumer<String> aside;

    /**
     * @param name       日志里认这只同伴用的名字
     * @param transcript 会话历史;落盘由它的 sink 负责
     * @param inbox      主人的话与世界事件共用的队列;条目怎么投递查 {@link EventTypes}
     */
    public AgentLoop(String name, ModelPort model, ToolPort tools, ConvoState transcript, EventQueue inbox,
                     MemoryPort memory, HostPort host) {
        this.name = name;
        this.model = model;
        this.tools = tools;
        this.transcript = transcript;
        this.inbox = inbox;
        this.memory = memory;
        this.host = host;
        this.announced = hold();
    }

    /**
     * 订阅事件。事件在内核的线程上按发生顺序同步送达。内核发事件时正走在一步的中间,
     * 订阅者只做自己那一份(画、记账、落盘),不在回调里同步推进内核。
     *
     * <p>订阅者逐个隔离:一个抛了(运行时异常)只记日志,事件接着送给排在后面的订阅者,内核的这一步照常走完。
     * 同一个订阅者连续出错只在第一次记日志,它再成功处理一次事件之后重新计。
     */
    public void subscribe(Consumer<? super LoopEvent> listener) {
        listeners.add(new Subscriber(listener));
    }

    // ---- 输入 ----

    /**
     * 收一批输入。整批先入队、再推进一次:离线补发的条目一次到达,逐条推进的话第一条急件就开了 run,
     * 只带走已经到的那几条。
     *
     * <p>一批工具调用还没结算时,入了队的每一条都转给工具口({@link ToolPort#arrived}),带着队列的急件规则算出的急不急:
     * 一段程序在服务端跑着,急件让它停在调用之间。她派的活的收尾在服务端就交给了等它的程序(写进回执),不会作为一条输入到这里。
     *
     * <p>来自主人的插话解开 {@link Hold.Release#OWNER_SPOKE} 那几种停牌,急件解开 FAILED。死着、外接驾驶时也照收:
     * 条目盖着真实时间戳,之后模型看得出哪些是那期间发生的。
     */
    public void push(List<EventQueue.Entry> entries) {
        long now = host.now();
        boolean ownerSpoke = false;
        boolean urgent = false;
        List<Queued> queued = new ArrayList<>();
        for (EventQueue.Entry e : entries) {
            if (e.text() == null || e.text().isBlank()) {
                continue;
            }
            boolean asUrgent = inbox.push(e.type(), e.text(), e.ts() > 0 ? e.ts() : now, e.urgent());
            AiLog.LOG.info("[numen-entity#{}] queued {}{} ({} chars)", name, e.type(), asUrgent ? " URGENT" : "",
                    e.text().length());
            queued.add(new Queued(e, asUrgent));
            urgent |= asUrgent;
            ownerSpoke |= EventTypes.get(e.type()).ownerWords();
        }
        // 转给工具口可能让这一批当场结算、调下一次模型,那之后就不是它的事了
        for (int i = 0; i < queued.size() && toolsRunning(); i++) {
            tools.arrived(queued.get(i).entry(), queued.get(i).urgent());
        }
        if (ownerSpoke) {
            release(Hold.Release.OWNER_SPOKE);
        }
        if (urgent) {
            release(Hold.Release.URGENT);
        }
        announceHold();
        pump();
    }

    /** 游戏里此刻的时刻,创建条目的一方({@code GoalSteward})据它盖日期与钟点。 */
    public long dayTime() {
        return host.dayTime();
    }

    /** 工具口手上有一批没结算的调用:内脑这一轮的,或外接大脑借用的那一个。 */
    private boolean toolsRunning() {
        return (run != null && run.phase == Phase.TOOLS) || aside != null;
    }

    /**
     * 外接大脑的一次调用(一段程序):内核闲着时交给同一个工具口执行,结果交给 {@code done},不进会话历史。执行期间入队的条目
     * 同样转给工具口——等身体收尾、被急件停在调用之间,和内脑自己的调用是同一个等法;这期间内核不开 run。切断({@link #halt})
     * 照样收工具口,程序交出停在哪一行的回执。
     *
     * @return 收下了;内核手上有 run、或已有一个外接调用在跑时不收,{@code done} 不会被调
     */
    public boolean runAside(LlmToolCall call, Consumer<String> done) {
        if (run != null || aside != null) {
            return false;
        }
        aside = done;
        tools.run(List.of(call), new ToolPort.Sink() {
            @Override
            public void started(LlmToolCall c) {
            }

            @Override
            public void finished(LlmToolCall c, String resultJson) {
                Consumer<String> reply = aside;
                aside = null;
                if (reply != null) {
                    reply.accept(resultJson);
                }
            }

            @Override
            public void settled() {
                aside = null;
                pump();
            }
        });
        return true;
    }

    /** {@link #runAside} 此刻收不收:内核手上没有 run、也没有外接调用在跑。 */
    public boolean asideFree() {
        return run == null && aside == null;
    }

    /**
     * 外接大脑替她说了一句话:作为她的一条回复进会话历史、发 {@link LoopEvent.AssistantMessage},于是界面、语音、
     * 同会话旁听者见到的和内脑的回复同一个样子。不开 run,也不动停牌。
     */
    public void said(AssistantTurn turn) {
        transcript.addAssistant(turn);
        emit(new LoopEvent.AssistantMessage(lastRunId, turn));
    }

    /** 身体复活了。复活的叙事事件由调用方在这之前推进队列,解开后一起走。 */
    public void respawned() {
        release(Hold.Release.RESPAWN);
        announceHold();
        pump();
    }

    /** 这只同伴改绑了模型档案。 */
    public void bindingChanged() {
        release(Hold.Release.BINDING_CHANGED);
        announceHold();
        pump();
    }

    /** 每个客户端 tick 一次:报告现算停牌的变化(外接交还),并为"攒够时长"再问一次熟度。 */
    public void tick() {
        announceHold();
        pump();
    }

    // ---- 推进 ----

    /**
     * 推进:一步一步往下走,直到没有能同步做完的事。入队、run 结束、停牌解开、每个 tick 都只调它。
     *
     * <p>它不递归:一步里同步发生的事(端口当场回话让 run 当场结束、清空执行完、订阅者推了新输入)再要求推进时,
     * 只记下"再看一眼",由这一圈接着走。调用栈不随步数变深——哪天某一步又没推进任何东西,循环停下,不会越陷越深。
     */
    public void pump() {
        if (pumping) {
            pumpAgain = true;
            return;
        }
        pumping = true;
        try {
            boolean again;
            do {
                pumpAgain = false;
                again = step() || pumpAgain;
            } while (again);
        } finally {
            pumping = false;
        }
    }

    /**
     * 闲时的一步。"下一步做什么"只有这一个判断,看的是队列里墙之前那一段——和 run 取件同一段、同一份声明:
     * <ol>
     *   <li>没停牌、那一段熟了({@link EventQueue#ripeness}):开 run。熟了就一定有叫醒她的条目,
     *       开出来的 run 一定取得到它;</li>
     *   <li>开不了 run(没熟、或者停着),而队里有控制条目:执行它。控制条目不叫醒她,它的"急"不是开 run 的
     *       理由;排在它前面、此刻开不起 run 的条目(旁听、还没攒熟的事、停牌压着的话)不挡它——
     *       清空/整理是主人对内脑的直接要求,按了停止之后照样立即执行;</li>
     *   <li>否则什么也不做,也不说话。</li>
     * </ol>
     * 死着、外接驾驶、主人不在时什么都不做:身体不在、驾驶席不在内脑手里、主人不在线。
     *
     * @return 这一步动了队列或停牌(开了 run、执行了控制条目),值得再看一眼;什么也没做、或者被端点挡下是 {@code false}
     */
    private boolean step() {
        if (run != null || aside != null) {
            return false;   // run 里的边界自己取队列;外接大脑的调用借着工具口时不开 run
        }
        Hold hold = hold();
        if (hold == Hold.DEAD || hold == Hold.EXTERNAL || hold == Hold.AWAY) {
            return false;
        }
        int level = host.initiativeLevel();
        EventQueue.Ripeness ripeness = inbox.ripeness(host.now(), level);
        if (hold == null && ripeness.ripe()) {
            AiLog.LOG.info("[numen-queue#{}] 主动开轮:{}(攒了 {} 条/阈值 {},最老 {}s/上限 {}s,档位 {})",
                    name,
                    switch (ripeness.why()) {
                        case URGENT -> "有急件";
                        case ENOUGH -> "攒够了";
                        case LONG_ENOUGH -> "攒久了";
                    },
                    ripeness.waiting(), EventQueue.thresholdOf(level),
                    ripeness.oldestAge() / 1000L, EventQueue.maxWaitMsOf(level) / 1000L, level);
            startRun(false, false);
            return true;
        }
        return !inbox.nextControls().isEmpty() && runControl();
    }

    /**
     * 开一次 run。重试也走这里,于是过同样的端点检查,第一次调模型前同样先看自动压缩。
     * 端点不可用就进 BLOCKED 并把原因随事件交出去,不开 run。
     */
    private void startRun(boolean retried, boolean ownerSpoke) {
        Cause problem = model.unavailable();
        if (problem != null) {
            block(problem);
            return;
        }
        run = new Run(++lastRunId, false, retried, ownerSpoke);
        emit(new LoopEvent.RunStarted(run.id));
        // 重试接着回应失败那次的输入;闲时开的 run 是队里要她回应的条目引起的
        turn(retried);
    }

    /**
     * 内层循环的一个边界。这次调不调模型由边界自己知道的事定:有待回应的东西(一批工具结果、失败重试的那次输入)
     * 就调;没有的话(run 开头、模型给了最终回复),只在队里有要她回应的条目时调
     * ({@link EventQueue#wantsAnswer})——都没有就收尾。
     *
     * <p>不从历史末尾去猜有没有待回应的:整理记忆留下的摘要、被切断的那句话都停在末尾,看上去"待回应",
     * 却不是这次调用的原因。
     *
     * @param answerDue 有待回应的东西,这次调用无论如何都会发生
     */
    private void turn(boolean answerDue) {
        if (!answerDue && !inbox.wantsAnswer()) {
            end(RunEnd.DONE);
            return;
        }
        callModel(answerDue);
    }

    /**
     * 调一次模型:先压缩(要压的话)、再注入、再调。压缩放在注入之前:切分会把近段原文留下、更早的总结掉,
     * 先注入的话主人刚说的话也可能被总结进去。
     *
     * @param answerDue 同 {@link #turn}:取件按进边界时定下的原因,压缩改写历史不影响它
     */
    private void callModel(boolean answerDue) {
        if (memory.compactionDue()) {
            compact(true, "", () -> callModel(answerDue));
            return;
        }
        inject(inbox.takeForCall(answerDue, host.now(), host.dayTime()));
        run.phase = Phase.MODEL;
        ModelRequest request = model.turnRequest();
        transcript.incrementTurn();
        long id = run.id;
        AiLog.LOG.info("[numen-entity#{}] turn {}: convo={} msgs, tools={}",
                name, transcript.turnCount(), request.messages().size(), request.tools().size());
        emit(new LoopEvent.TurnStarted(id, run.ownerSpoke));
        model.call(request, run.cancel,
                delta -> {
                    if (current(id)) {
                        emit(new LoopEvent.ModelDelta(id, delta.content(), delta.reasoning()));
                    }
                },
                outcome -> onModel(id, request, outcome));
    }

    /**
     * 取出来的条目拼成一条 user 消息:现场块在前,世界的事按时间排进 {@code <events>},主人的话垫底
     * (排版规则在 {@link EventQueue#render})。
     */
    private void inject(List<EventQueue.Entry> batch) {
        List<String> rendered = EventQueue.render(batch);
        if (rendered.isEmpty()) {
            return;
        }
        List<String> parts = new ArrayList<>();
        String preamble = host.injectionPreamble();
        if (!preamble.isEmpty()) {
            parts.add(preamble);
        }
        parts.addAll(rendered);
        transcript.addUser(String.join("\n", parts));
        transcript.resetTurnCount();   // 新输入开始一条新链:只是日志编号
        if (batch.stream().anyMatch(e -> EventTypes.get(e.type()).ownerWords())) {
            run.ownerSpoke = true;
        }
    }

    private void onModel(long id, ModelRequest request, ModelOutcome outcome) {
        if (!current(id)) {
            return;
        }
        if (outcome instanceof ModelOutcome.Failed failed) {
            boolean overflow = Cause.CONTEXT_OVERFLOW.equals(failed.cause().code());
            if (overflow && !run.overflowRecovered) {
                // 服务商说上下文超长:整理一次再原样重试一次(照 pi 的 overflow recovery)
                run.overflowRecovered = true;
                AiLog.LOG.info("[numen-entity#{}] context overflow reported by the provider: compacting and retrying once", name);
                compact(true, "", () -> callModel(true));
            } else {
                // 整理过重试了仍然超长就停下告诉主人,不再循环——也不让失败重试再开一轮去重蹈覆辙
                end(new RunEnd.Failed(failed.cause(), !overflow));
            }
        } else {
            ModelOutcome.Answered answered = (ModelOutcome.Answered) outcome;
            emit(new LoopEvent.ModelUsed(answered.usage(), LoopEvent.Purpose.TURN));
            AssistantTurn reply = answered.turn();
            if (!reply.hasToolCalls() && reply.content().isEmpty()) {
                AiLog.LOG.warn("[numen-entity#{}] LLM returned an empty turn (no content, no tool calls)", name);
                end(new RunEnd.Failed(Cause.of(Cause.EMPTY_REPLY), false));
                return;
            }
            run.retried = false;
            run.overflowRecovered = false;
            run.ownerSpoke = false;
            transcript.addAssistant(reply);
            emit(new LoopEvent.AssistantMessage(id, reply));
            if (reply.hasToolCalls()) {
                run.phase = Phase.TOOLS;
                tools.run(reply.toolCalls(), toolSink(id));
            } else {
                transcript.resetTurnCount();
                turn(false);   // 本来要停了:队里还有要她回应的就接着走,没有才收尾
            }
        }
    }

    private ToolPort.Sink toolSink(long id) {
        return new ToolPort.Sink() {
            @Override
            public void started(LlmToolCall call) {
                if (current(id)) {
                    emit(new LoopEvent.ToolStarted(id, call));
                }
            }

            @Override
            public void finished(LlmToolCall call, String resultJson) {
                if (!current(id)) {
                    return;
                }
                transcript.addToolResult(call.id(), resultJson);
                emit(new LoopEvent.ToolFinished(id, call, resultJson));
            }

            @Override
            public void settled() {
                if (current(id)) {
                    turn(true);   // 工具结果等着回应
                }
            }

            @Override
            public void ended(LlmToolCall program, com.dwinovo.numen.script.ScriptCall.Ending ending,
                              java.util.List<com.dwinovo.numen.script.ScriptCall.Called> calls) {
                if (current(id)) {
                    emit(new LoopEvent.ProgramEnded(id, program, ending, calls.size()));
                }
            }

            @Override
            public void called(LlmToolCall program, com.dwinovo.numen.script.ScriptCall.Called called) {
                if (current(id)) {
                    emit(new LoopEvent.ApiCalled(id, program, called));
                }
            }
        };
    }

    private void end(RunEnd end) {
        Run finished = run;
        run = null;
        if (end instanceof RunEnd.Failed failed) {
            // 失败的回应不进历史;记一条切断点,之后的请求里模型知道上一轮没连上
            writeHalt("这一轮没连上(" + failed.cause().forModel() + ")", failed.cause());
        }
        emit(new LoopEvent.RunEnded(finished.id, end));
        if (end instanceof RunEnd.Failed failed) {
            afterFailure(finished, failed);
        }
        announceHold();
        pump();   // 端口当场回话、run 在推进那一步里就结束时,这里只记一笔"再看一眼",不重入
    }

    /**
     * 失败收尾时决定:调用出错且这条链还没重试过,就重开一次 run;否则让主人看见,进 FAILED——
     * 已经排着急件的话不停牌,它们本身就是解开 FAILED 的理由。
     */
    private void afterFailure(Run failed, RunEnd.Failed end) {
        AiLog.LOG.warn("[numen-entity#{}] turn failed: {}", name, end.cause().forModel());
        if (end.retryable() && !failed.retried) {
            AiLog.LOG.info("[numen-entity#{}] re-running failed turn once", name);
            startRun(true, failed.ownerSpoke);
            return;
        }
        emit(new LoopEvent.TurnFailed(end.cause()));
        stopped = Hold.FAILED;
        stoppedReason = end.cause();
        if (inbox.hasUrgent()) {
            release(Hold.Release.URGENT);
        }
    }

    // ---- 控制条目与整理记忆 ----

    /** @return 执行了(清完了、整理发出去了);端点不可用、条目留着是 {@code false} */
    private boolean runControl() {
        // 连着按的几次算一次;批里混着清空就清空说了算——整理要的是腾地方,清空把地方全腾出来了。
        // 分清是哪一条控制命令只能认 id:类型表只说"它是控制命令"。
        boolean clears = inbox.nextControls().stream().anyMatch(e -> EventTypes.CLEAR.equals(e.type()));
        if (!clears) {
            // 整理要发一次请求。端点不可用就进 BLOCKED,条目留在队里——绑定改好了自己接着走,按了就一定会发生。
            Cause problem = model.unavailable();
            if (problem != null) {
                block(problem);
                return false;
            }
        }
        List<EventQueue.Entry> controls = inbox.takeControls();
        if (clears) {
            // 排在清空前面、没叫醒她的旁听是她在清空之前听见的,属于被清掉的那段上下文,一并清掉;要她回应的条目
            // 留着,清完进新的上下文。整理不丢:它只把历史换成摘要,排着的条目还没进历史,照旧跟下一次调用走。
            int heard = inbox.discardQuietAhead();
            AiLog.LOG.info("[numen-entity#{}] 清空上下文:排到了(之前听见、还没交给她的 {} 条一并清掉)", name, heard);
            memory.clear();
            emit(new LoopEvent.TranscriptBoundary(LoopEvent.Boundary.CLEAR));
            return true;   // 排在清空后面的话,推进的下一步里进全新的上下文
        }
        AiLog.LOG.info("[numen-entity#{}] 整理记忆:排到了,开始", name);
        run = new Run(++lastRunId, true, false, false);
        // 连着按的几次整理算一次,各次附的关注点都留着
        String focus = controls.stream().filter(e -> EventTypes.COMPACT.equals(e.type()))
                .map(e -> EventTypes.controlArg(e.text())).filter(arg -> !arg.isEmpty())
                .collect(java.util.stream.Collectors.joining("\n"));
        compact(false, focus, () -> {
            run = null;
            announceHold();
            pump();
        });
        return true;
    }

    /**
     * 发一次整理记忆,落地后接着 {@code then}(调用失败或摘要为空也接着——历史不动,照原样往下走)。
     * 被切断的话结果作废,{@code then} 不再执行。没有可压的就不发请求,直接接着 {@code then}。
     */
    private void compact(boolean auto, String focus, Runnable then) {
        MemoryPort.Compaction compaction = memory.compaction(auto, focus).orElse(null);
        if (compaction == null) {
            then.run();
            return;
        }
        run.phase = Phase.COMPACT;
        compactChars = 0;
        summarize(compaction, compaction.requests(), 0, new ArrayList<>(), run.id, then);
    }

    /** 摘要请求一份份发:答完一份发下一份,都答完才落地。任何一份失败这次整理就算没压成,历史不动。 */
    private void summarize(MemoryPort.Compaction compaction, List<ModelRequest> requests, int next,
                           List<ModelOutcome.Answered> answers, long id, Runnable then) {
        if (next == requests.size()) {
            if (compaction.apply(answers)) {
                emit(new LoopEvent.TranscriptBoundary(LoopEvent.Boundary.COMPACT));
            } else {
                compaction.failed("摘要是空的");
            }
            then.run();
            return;
        }
        model.call(requests.get(next), run.cancel,
                delta -> {
                    if (current(id)) {
                        compactChars += delta.content().length();
                    }
                },
                outcome -> {
                    if (!current(id)) {
                        return;
                    }
                    if (outcome instanceof ModelOutcome.Failed failed) {
                        compaction.failed(failed.cause().forModel());
                        then.run();
                    } else {
                        ModelOutcome.Answered answered = (ModelOutcome.Answered) outcome;
                        emit(new LoopEvent.ModelUsed(answered.usage(), LoopEvent.Purpose.COMPACT));
                        answers.add(answered);
                        summarize(compaction, requests, next + 1, answers, id, then);
                    }
                });
    }

    // ---- 旁路调用 ----

    /**
     * 发一次不属于任何 run 的模型调用(目标评估这类旁路判断):不占内核、不看停牌、不进历史,但用量照样
     * 经 {@link LoopEvent.ModelUsed} 报出去——账只有这一条路。端点不可用时不发,直接交回失败。
     *
     * @param purpose 用量记在哪一项名下
     * @param cancel  调用方自己管的取消令牌;取消之后 {@code onDone} 不再来
     */
    public void consult(LoopEvent.Purpose purpose, ModelRequest request, CancelToken cancel,
                        Consumer<ModelOutcome> onDone) {
        Cause problem = model.unavailable();
        if (problem != null) {
            onDone.accept(new ModelOutcome.Failed(problem));
            return;
        }
        model.call(request, cancel, delta -> { }, outcome -> {
            if (outcome instanceof ModelOutcome.Answered answered) {
                emit(new LoopEvent.ModelUsed(answered.usage(), purpose));
            }
            onDone.accept(outcome);
        });
    }

    // ---- 切断 ----

    /** 切断,没有细节可附。 */
    public void halt(HaltReason reason) {
        halt(reason, null);
    }

    /**
     * 切断:作废手上的 run,放弃未结算的工具调用,在历史里记下切断点,再按 {@link HaltReason} 的表清队列、
     * 进停牌。闲着的时候同样执行——主人在闲时按停止也要叫停身体、清掉排着的指令。
     *
     * @param detail 附在切断原因后面的细节(死因);没有传 {@code null}
     */
    public void halt(HaltReason reason, String detail) {
        Run cut = run;
        // 外接大脑借的那一个调用(见 runAside)随这一批一起作废;收批次的人不叫 sink,等它的人就得在这里被放开。
        // 少了这一句,aside 永远留着,此后每一次 runAside 都以为还有一段程序在跑,她再也收不下外接的调用。
        Consumer<String> cutAside = aside;
        aside = null;
        // 先收工具口、再作废 run:在跑的脚本这时交出它停在哪一行的回执,还记在这次 run 名下进历史
        List<String> abandoned = tools.cancel(reason.stopsBody());
        if (cut != null) {
            run = null;
            cut.cancel.cancel();
        }
        if (cut != null) {
            // 切断的是一次模型回复或一批工具往返才记切断点:悬空调用的结果、给模型的说明由下一次请求的
            // ProtocolView 按它现算。整理记忆被切断时对话本身没断,不记。
            if (!cut.control && (cut.phase == Phase.MODEL || cut.phase == Phase.TOOLS)) {
                writeHalt(reason.words(detail), reason.cause(detail));
            }
            transcript.resetTurnCount();
            if (!cut.control) {
                emit(new LoopEvent.RunEnded(cut.id, new RunEnd.Halted(reason)));
            }
        }
        int cleared = reason.clearsInterrupted() ? inbox.clearInterrupted() : 0;
        if (reason.enters() == Hold.DEAD) {
            dead = true;
        } else if (reason.enters() != null) {
            stopped = reason.enters();
            stoppedReason = null;
        }
        AiLog.LOG.info("[numen-entity#{}] halt {}{} (phase={}, abandoned calls={}, cleared queued={}, left={})",
                name, reason, detail == null ? "" : " (" + detail + ")",
                cut == null ? "idle" : cut.phase, abandoned.size(), cleared, inbox.size());
        emit(new LoopEvent.Halted(reason));
        announceHold();
        if (cutAside != null) {
            // 回一条失败(不是回执:那一批已经作废),等它的人据此收场;再推一次,和工具口自己结算时同一套收尾
            cutAside.accept(ToolOutcome.failure("this turn was cut off: " + reason.name()
                    + (detail == null || detail.isBlank() ? "" : " (" + detail + ")") + "; nothing else ran"));
            pump();
        }
    }

    /** 切断点:{@code words} 是给模型看的那句,{@code cause} 是给界面的结构化原因,两句各自生成、互不拼接。 */
    private void writeHalt(String words, Cause cause) {
        transcript.addHalt(words, cause.code(), cause.args());
        emit(new LoopEvent.TranscriptBoundary(LoopEvent.Boundary.HALT));
    }

    // ---- 读 ----

    /**
     * 没有在飞的回合,也没有哪一条马上要开出回合:此刻停牌的、以及没熟的收件箱都算(开不了 run 的就是不会动)。
     * 渠道来访做完了没有,问的是它。
     */
    public boolean settled() {
        if (run != null || aside != null) {
            return false;
        }
        if (hold() != null) {
            return true;
        }
        return !inbox.ripeness(host.now(), host.initiativeLevel()).ripe() && inbox.nextControls().isEmpty();
    }

    /** 合成后的停牌;{@code null} = 没有。 */
    public Hold hold() {
        if (dead) {
            return Hold.DEAD;
        }
        if (host.externallyDriven()) {
            return Hold.EXTERNAL;
        }
        if (!host.ownerPresent()) {
            return Hold.AWAY;
        }
        return stopped;
    }

    /** 此刻在干哪一档;没在跑回合是 {@code null}。只要这一项的调用(每刻一次的路径)走这里,不必构造整份 {@link #status}。 */
    public Phase phase() {
        return run == null ? null : run.phase;
    }

    /** 此刻在干的那件事,同 {@link LoopStatus#activity}。 */
    public LoopStatus.Doing activity() {
        return host.activity();
    }

    /** 整份快照:含逐条渲染收件箱的聊天预览,只在有人要看的时候取。 */
    public LoopStatus status() {
        Phase phase = phase();
        double progress = phase == Phase.COMPACT ? 1.0 - Math.exp(-(compactChars / 4.0) / 1200.0) : 0.0;
        Hold hold = hold();
        return new LoopStatus(phase, hold, hold != null && hold == stopped ? stoppedReason : null,
                host.bodyTaskRunning(), inbox.chatPreview(), progress, activity());
    }

    // ---- 内部 ----

    private boolean current(long id) {
        return run != null && run.id == id;
    }

    private void release(Hold.Release release) {
        if (dead && Hold.DEAD.releasedBy(release)) {
            dead = false;
        }
        if (stopped != null && stopped.releasedBy(release)) {
            AiLog.LOG.info("[numen-entity#{}] {} 解开停牌 {}", name, release, stopped);
            stopped = null;
            stoppedReason = null;
        }
    }

    /** 模型端点不可用:进 BLOCKED,把原因随事件交出去。只在刚进去的那一下打日志——停牌期间每 tick 推进也不刷屏。 */
    private void block(Cause problem) {
        if (stopped != Hold.BLOCKED) {
            AiLog.LOG.warn("[numen-entity#{}] can't reach the model: {}", name, problem.forModel());
        }
        stopped = Hold.BLOCKED;
        stoppedReason = problem;
        announceHold();
    }

    /** 原因跟着停牌本身走({@link #status} 同此):别的停牌遮住又解开后重新露出的 BLOCKED,仍带着当初的原因。 */
    private void announceHold() {
        Hold now = hold();
        if (now == announced) {
            return;
        }
        announced = now;
        emit(new LoopEvent.HoldChanged(now, now != null && now == stopped ? stoppedReason : null));
    }

    private void emit(LoopEvent event) {
        for (Subscriber subscriber : List.copyOf(listeners)) {
            subscriber.deliver(event);
        }
    }

    /** 一个订阅者,带着"上一次是不是出错了"——连续出错只记一次日志。 */
    private final class Subscriber {
        private final Consumer<? super LoopEvent> listener;
        private boolean failing;

        Subscriber(Consumer<? super LoopEvent> listener) {
            this.listener = listener;
        }

        void deliver(LoopEvent event) {
            try {
                listener.accept(event);
                failing = false;
            } catch (RuntimeException e) {
                if (!failing) {
                    AiLog.LOG.error("[numen-entity#{}] 事件订阅者处理 {} 时出错,其余订阅者照常收(它连续出错不再重复记)", name,
                            event.getClass().getSimpleName(), e);
                }
                failing = true;
            }
        }
    }

    /** 入了队的一条,和队列的急件规则给它算出的急不急。 */
    private record Queued(EventQueue.Entry entry, boolean urgent) {}
}
