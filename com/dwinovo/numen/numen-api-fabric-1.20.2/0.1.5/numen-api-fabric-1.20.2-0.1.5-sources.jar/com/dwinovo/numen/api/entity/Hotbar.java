package com.dwinovo.numen.api.entity;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_3222;

/**
 * 把东西拿到手上,照原版玩家的几个按键:数字键切换快捷栏选中的格({@code handleSetCarriedItem}),中键把背包深处的
 * 东西换进快捷栏({@code handlePickItem},换进的是原版挑的那一格——先空格,再不是附魔过的,原来那件换回背包,不丢),
 * F 键交换主副手,创造模式中键凭空取一叠。每一次真的换了都交回一个 {@link BodyAction},由调用方记进结局。同伴的是
 * {@link NumenPlayer#hotbar}。
 */
public final class Hotbar {

    /** 副手在 {@link BodyAction.Held#from} 里的编号(原版物品栏里副手那一格)。 */
    public static final int OFFHAND = class_1661.field_30639;

    private final class_3222 body;
    private final ClientPackets packets;

    public Hotbar(class_3222 body) {
        this.body = body;
        this.packets = new ClientPackets(body);
    }

    /**
     * 把主背包第 {@code slot} 格的东西拿到主手;{@code slot} 是 {@link #OFFHAND} 就交换主副手;{@code slot} 为负是空手——切到
     * 快捷栏里一个空格({@link #emptyHand}),没有空格就拿着手上的东西。已经在主手上就什么也不做。手上本来就空着、只是换到
     * 另一个空格时,手上拿的没变,不算一个身体动作。
     */
    public Optional<BodyAction> hold(int slot) {
        class_1661 inventory = body.method_31548();
        if (slot == OFFHAND) {
            class_1799 offhand = body.method_6079().method_46651(1);
            packets.playerAction(class_2846.class_2847.field_12969, class_2338.field_10980,
                    class_2350.field_11033, 0);
            return Optional.of(new BodyAction.Held(offhand, OFFHAND, inventory.field_7545));
        }
        if (slot < 0) {
            int empty = emptyHand(inventory);
            if (empty < 0 || empty == inventory.field_7545) {
                return Optional.empty();
            }
            boolean wasEmpty = inventory.method_7391().method_7960();
            BodyAction action = select(empty, class_1799.field_8037);
            return wasEmpty ? Optional.empty() : Optional.of(action);
        }
        if (slot == inventory.field_7545) {
            return Optional.empty();
        }
        class_1799 stack = inventory.method_5438(slot).method_46651(1);
        if (class_1661.method_7380(slot)) {
            return Optional.of(select(slot, stack));
        }
        packets.pickItem(slot);
        return Optional.of(new BodyAction.Held(stack, slot, inventory.field_7545));
    }

    /**
     * 让一只手拿着 {@code item},右键就能用上它:主手已经是它,或主手空着而副手是它(原版右键主手用不了就试副手),
     * 什么也不做;背包里有就拿到主手(拿哪一叠由 {@link Stacks#pick} 定);只在副手、主手又占着,就交换主副手;创造模式背包里没有就凭空取一叠。
     *
     * @return 拿到了没有、拿在哪只手上,连同做了什么(没做为 null)
     */
    public Grip grip(class_1792 item) {
        class_1661 inventory = body.method_31548();
        class_1799 main = inventory.method_7391();
        if (main.method_31574(item)) {
            return new Grip(class_1268.field_5808, null);
        }
        if (main.method_7960() && body.method_6079().method_31574(item)) {
            return new Grip(class_1268.field_5810, null);
        }
        Optional<Stacks.Pick> pick = Stacks.pick(inventory, item);
        if (pick.isPresent()) {
            return new Grip(class_1268.field_5808, hold(pick.get().slot()).orElse(null));
        }
        if (body.method_6079().method_31574(item)) {
            return new Grip(class_1268.field_5808, hold(OFFHAND).orElse(null));
        }
        if (body.field_13974.method_14268()) {
            inventory.method_7374(new class_1799(item));
            return new Grip(class_1268.field_5808, new BodyAction.Conjured(item, inventory.field_7545));
        }
        return new Grip(null, null);
    }

    /**
     * {@link #grip} 的结果。
     *
     * @param hand   拿着它的那只手;没拿到为 null
     * @param action 为此做了什么;什么也没做为 null
     */
    public record Grip(class_1268 hand, BodyAction action) {

        /** 拿到了。 */
        public boolean ready() {
            return hand != null;
        }
    }

    /**
     * 空手用快捷栏的哪一格。捡起的东西先进背包的第一个空格;空手挖着的时候那一格被塞进东西,手上就换了一样东西,原版会从头挖。
     * 所以挑一个不是第一个空格的空格:手上正空着的那一格是就不动,不是就从后往前找;只有第一个空格可用时用它。没有空格为 -1。
     */
    private static int emptyHand(class_1661 inventory) {
        int first = inventory.method_7376();
        if (inventory.method_7391().method_7960() && inventory.field_7545 != first) {
            return inventory.field_7545;
        }
        for (int i = class_1661.method_7368() - 1; i >= 0; i--) {
            if (inventory.method_5438(i).method_7960() && i != first) {
                return i;
            }
        }
        return first >= 0 && class_1661.method_7380(first) ? first : -1;
    }

    private BodyAction select(int slot, class_1799 stack) {
        packets.setCarriedItem(slot);
        return new BodyAction.Held(stack, slot, slot);
    }
}
