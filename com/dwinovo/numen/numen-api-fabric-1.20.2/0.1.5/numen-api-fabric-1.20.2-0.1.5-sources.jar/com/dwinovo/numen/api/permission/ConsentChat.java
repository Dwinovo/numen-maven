package com.dwinovo.numen.api.permission;

import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.network.payload.ConsentRequestPayload;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

/**
 * 她的征询在聊天栏里的样子,给没装我们客户端的主人:一条消息写着她想做什么,下面是三个可点的按钮——[允许]、[以后都允许]、
 * [拒绝],点下去就是主人自己敲了 {@code /numen consent …}(底层就是那条命令,答复同走 {@link ConsentDesk#reply})。
 * 内容就是答复框画的那一份({@link ConsentRequestPayload},一堆一行:动词、对象、数量、为什么),语言键也是答复框用的同一批,
 * 所以两处说的是同一件事;服务端按主人客户端的语言把键翻成字再放行(见 {@code ServerLang})。
 */
public final class ConsentChat {

    /** 几件事一起问时最多列几件,其余计数。 */
    private static final int MAX_LISTED = 3;

    private ConsentChat() {}

    /** 一条挂着的请求。 */
    public static class_2561 ask(String companion, ConsentRequestPayload request) {
        class_5250 text = class_2561.method_43470("[" + companion + "] ");
        List<ConsentRequestPayload.Line> lines = request.lines();
        if (lines.size() == 1) {
            text.method_10852(class_2561.method_43469(Keys.CONSENT_ASK, thing(lines.get(0)))).method_27693("\n")
                    .method_10852(cause(lines.get(0)));
        } else {
            text.method_10852(class_2561.method_43471(Keys.CONSENT_ASK_MANY));
            for (ConsentRequestPayload.Line line : lines.subList(0, Math.min(MAX_LISTED, lines.size()))) {
                text.method_27693("\n· ").method_10852(thing(line)).method_27693(" · ").method_10852(cause(line));
            }
            if (lines.size() > MAX_LISTED) {
                text.method_27693("\n+" + (lines.size() - MAX_LISTED));
            }
        }
        return text.method_27693("\n")
                .method_10852(button(Keys.CONSENT_ALLOW, class_124.field_1060, "allow", request.requestId(), null)).method_27693(" ")
                .method_10852(button(Keys.CONSENT_ALLOW_REMEMBER, class_124.field_1075, "remember", request.requestId(),
                        class_2561.method_43470(String.join("\n", request.remember()))))
                .method_27693(" ").method_10852(button(Keys.CONSENT_DENY, class_124.field_1061, "deny", request.requestId(), null));
    }

    /** 一条请求没等到他答复就撤了,为什么。 */
    public static class_2561 withdrawn(String companion, ConsentDesk.Withdrawal why) {
        return class_2561.method_43469(Keys.CONSENT_WITHDRAWN, companion, class_2561.method_43471(why.key()));
    }

    /** 一件事本身:动词、对象(名字)、数量。 */
    private static class_2561 thing(ConsentRequestPayload.Line line) {
        return class_2561.method_43471(Keys.CONSENT_VERB_PREFIX + line.kind().word()).method_27693(" ").method_10852(line.name())
                .method_27693(line.count() > 1 ? "×" + line.count() : "");
    }

    /** 为什么要问;撤不回的整条是警示色。 */
    private static class_2561 cause(ConsentRequestPayload.Line line) {
        return line.cause().method_27661().method_27692(line.irreversible() ? class_124.field_1061 : class_124.field_1080);
    }

    /** 一个按钮:点下去敲 {@code /numen consent <答复> <请求号>};悬停时没有特别要说的就露出那条命令。 */
    private static class_2561 button(String label, class_124 color, String answer, long id, class_2561 hover) {
        String command = "/numen consent " + answer + " " + id;
        return class_2561.method_43470("[").method_10852(class_2561.method_43471(label)).method_27693("]").method_27696(class_2583.field_24360
                .method_10977(color)
                .method_10958(new class_2558(class_2558.class_2559.field_11750, command))
                .method_10949(new class_2568(class_2568.class_5247.field_24342,
                        hover == null || hover.getString().isEmpty() ? class_2561.method_43470(command) : hover)));
    }
}
