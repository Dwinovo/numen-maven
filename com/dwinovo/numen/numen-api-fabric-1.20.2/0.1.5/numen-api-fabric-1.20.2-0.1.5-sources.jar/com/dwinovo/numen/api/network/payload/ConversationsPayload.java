package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.agent.conversation.Conversation;
import com.dwinovo.numen.api.network.ClientPayloadSink;
import com.dwinovo.numen.api.network.Wire;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: 这位主人落过盘的会话(成员表与名字),整份——报到时一次,之后成员或名字变了再发。
 * "就他俩"的会话不在里面:客户端按名册自己有。成员表的真源在服务端,客户端只显示。
 */
public record ConversationsPayload(String json) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "conversations");

    public List<Conversation> conversations() {
        List<Conversation> out = new ArrayList<>();
        for (JsonElement e : JsonParser.parseString(json).getAsJsonArray()) {
            Conversation conv = Conversation.fromJson(e.getAsJsonObject());
            if (conv != null) {
                out.add(conv);
            }
        }
        return out;
    }

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        Wire.writeText(buf, json);
    }

    public static ConversationsPayload read(class_2540 buf) {
        return new ConversationsPayload(Wire.readText(buf));
    }

    /** Client main thread. */
    public static void handle(ConversationsPayload p) {
        ClientPayloadSink.conversations.accept(p);
    }
}
