package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.brain.Replies;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

/**
 * Client → Server: 紧跟 {@link HelloPayload} 之后,客户端说它提供哪些<b>目标模组只在客户端</b>的联动(名字空间的清单,见
 * {@link com.dwinovo.numen.api.plugin.ClientMods}):这台电脑上装着 Litematica 就报 {@code litematica}。服务端收到它才算这位玩家报到齐
 * (回 {@link HelloAckPayload}、记进 {@code Presence}),所以"有客户端"与"客户端提供什么"总是同一刻成立。
 *
 * @param provided 提供的联动名字空间;没有是空表
 */
public record ClientCapsPayload(List<String> provided) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "client_caps");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_34062(provided, class_2540::method_10814);
    }

    public static ClientCapsPayload read(class_2540 buf) {
        return new ClientCapsPayload(buf.method_34066(class_2540::method_19772));
    }

    /** Handler invoked on the server main thread. */
    public static void handle(ClientCapsPayload p, class_3222 player) {
        Replies.ready(player, Set.copyOf(p.provided()));
    }
}
