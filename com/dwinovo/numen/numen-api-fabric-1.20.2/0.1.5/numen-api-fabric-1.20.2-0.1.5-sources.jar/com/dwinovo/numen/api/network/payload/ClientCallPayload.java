package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.network.NumenNetwork;
import com.dwinovo.numen.api.network.Wire;
import com.dwinovo.numen.api.program.ClientEndpoint;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server-to-client payload: a request the other way round. A program running on the server called an API function that
 * only the owner's client can answer (a {@code ClientCall} function: anything reading data only the client has, such as
 * a skin the owner's client holds); the program waits while the client runs it and answers with a
 * {@link ClientCallResultPayload}. Same shape as the server asking the client for something in the protocols this is
 * modelled on (MCP sampling, LSP {@code workspace/configuration}).
 *
 * <p>{@code function} is the function's full name, {@code argumentsJson} the arguments the program's call was read into
 * on the server; the client reads them again with the same codecs before running the function. The arguments can be
 * as long as the program that wrote them, so the payload is {@link Wire.Fragmentable}.
 */
public record ClientCallPayload(UUID entityUuid, String callId, String function, String argumentsJson)
        implements class_8710, Wire.Fragmentable {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "client_call");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10797(entityUuid);
        Wire.writeText(buf, callId);
        Wire.writeText(buf, function);
        Wire.writeText(buf, argumentsJson);
    }

    public static ClientCallPayload read(class_2540 buf) {
        return new ClientCallPayload(buf.method_10790(),
                Wire.readText(buf),
                Wire.readText(buf),
                Wire.readText(buf));
    }

    /** 编码后的字节数。 */
    public int size() {
        return Wire.size(this);
    }

    /** Client-side handler. */
    public static void handle(ClientCallPayload p) {
        Constants.LOG.debug("[numen-net] client_call entity={} id={} {}", p.entityUuid(), p.callId(), p.function());
        ClientEndpoint.handle(p, NumenNetwork::sendToServer);
    }
}
