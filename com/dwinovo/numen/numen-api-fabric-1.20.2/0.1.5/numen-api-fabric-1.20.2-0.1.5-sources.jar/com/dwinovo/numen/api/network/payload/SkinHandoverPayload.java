package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.network.ClientPayloadSink;
import com.dwinovo.numen.api.network.Wire;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: 玩家在旧版本里存在服务器上的一张皮肤原图的一段。皮肤现在是玩家本机文件夹里的 png,旧版本存在服务器上的"我的皮肤"
 * 在他下一次带着客户端连上时按段下行({@code SkinHandover}:每刻至多一段,和导出的记忆是同一套分段),客户端按序收齐存进本机的
 * 皮肤文件夹,只做一次。
 *
 * @param name  皮肤的名字(落成 {@code <名字>.png})
 * @param index 这是第几段,从 0 起
 * @param total 一共几段
 */
public record SkinHandoverPayload(String name, int index, int total, byte[] bytes) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "skin_handover");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        Wire.writeText(buf, name);
        buf.method_10804(index);
        buf.method_10804(total);
        buf.method_10813(bytes);
    }

    public static SkinHandoverPayload read(class_2540 buf) {
        return new SkinHandoverPayload(Wire.readText(buf), buf.method_10816(), buf.method_10816(), buf.method_10803(ExportChunkPayload.SEGMENT_BYTES));
    }

    /** Client main thread. */
    public static void handle(SkinHandoverPayload p) {
        ClientPayloadSink.skinHandover.accept(p);
    }
}
