package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.network.ClientPayloadSink;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: 收下了 {@link HelloPayload}(协议对得上)——这位玩家能不能改服务器上的配置(模型档案与 key、外部大脑……,
 * 见 {@code Authority}),以及他是不是这台服务器的房主(他的"我的"就是服务器目录那一份,见 {@code Homes#isHost})。
 * 只发给协议对得上的客户端,格式随协议走。
 */
public record HelloAckPayload(boolean admin, boolean host) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "hello_ack");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_52964(admin);
        buf.method_52964(host);
    }

    public static HelloAckPayload read(class_2540 buf) {
        return new HelloAckPayload(buf.readBoolean(), buf.readBoolean());
    }

    /** Client main thread. */
    public static void handle(HelloAckPayload p) {
        ClientPayloadSink.helloAck.accept(p);
    }
}
