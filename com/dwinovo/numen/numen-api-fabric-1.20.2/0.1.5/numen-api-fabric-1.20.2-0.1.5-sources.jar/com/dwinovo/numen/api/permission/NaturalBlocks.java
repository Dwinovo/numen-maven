package com.dwinovo.numen.api.permission;

import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

/**
 * 地形自己会长出来的方块:没人放过、也不属于哪个结构的格子,种类在这张表里才算 {@code nature}(没人的),不在表里的说不清是谁的,
 * 落到 {@code unknown} 去问。表是数据标签 {@value #TAG_ID}(随模组发,整合包与主人都能用数据包改):原版的石头泥土沙子、
 * 矿石、洞穴与下界的植被,加各模组通用的 {@code c:} 标签,模组矿石与模组石头不用逐个适配。
 *
 * <p>标签只看种类,原木与树叶还要看状态:玩家放下的树叶带持久标记({@link class_2397#field_11200}),自然长出的不带;
 * 原木连着不持久的树叶才是野树,木屋的原木连着的是持久树叶或根本没有树叶。不靠"看形状像不像建筑"去猜。
 *
 * <p>表不全的后果是"多问",不是"误挖":漏掉的种类落到 {@code unknown},主人答"以后都允许"就记住这一种。
 */
final class NaturalBlocks {

    static final String TAG_ID = "numen:natural";
    static final class_6862<class_2248> TAG = class_6862.method_40092(class_7924.field_41254, new class_2960(TAG_ID));

    /** 从一根原木出发沿原木顺藤摸瓜,最多看这么多根。 */
    private static final int LOGS_LOOKED_AT = 64;

    private NaturalBlocks() {}

    /** 这一格的方块是不是地形自己长的。任何线程:只读视图。 */
    static boolean is(class_2680 state, class_2338 pos, class_1922 view) {
        if (!state.method_26164(TAG)) {
            return false;
        }
        if (state.method_26204() instanceof class_2397) {
            return !state.method_11654(class_2397.field_11200);
        }
        if (state.method_26164(class_3481.field_39030)) {
            return hangsFromLeaves(pos, view);
        }
        return true;
    }

    /** 这根原木所在的一串原木,有没有哪一根贴着不持久的树叶。 */
    private static boolean hangsFromLeaves(class_2338 start, class_1922 view) {
        LongOpenHashSet seen = new LongOpenHashSet();
        LongArrayFIFOQueue queue = new LongArrayFIFOQueue();
        seen.add(start.method_10063());
        queue.enqueue(start.method_10063());
        class_2338.class_2339 cursor = new class_2338.class_2339();
        while (!queue.isEmpty() && seen.size() <= LOGS_LOOKED_AT) {
            class_2338 log = class_2338.method_10092(queue.dequeueLong());
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        cursor.method_10103(log.method_10263() + dx, log.method_10264() + dy, log.method_10260() + dz);
                        class_2680 next = view.method_8320(cursor);
                        boolean face = Math.abs(dx) + Math.abs(dy) + Math.abs(dz) == 1;
                        if (face && next.method_26204() instanceof class_2397 && !next.method_11654(class_2397.field_11200)) {
                            return true;
                        }
                        if (next.method_26164(class_3481.field_15475) && seen.add(cursor.method_10063())) {
                            queue.enqueue(cursor.method_10063());
                        }
                    }
                }
            }
        }
        return false;
    }
}
