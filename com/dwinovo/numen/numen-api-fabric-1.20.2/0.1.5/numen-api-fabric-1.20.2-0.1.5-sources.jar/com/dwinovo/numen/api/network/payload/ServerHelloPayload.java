package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.network.ClientPayloadSink;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Server → Client: 服务端对一个连接说的第一句话,只有它说的协议版本。玩家在世界里、他的连接登记了这个频道,服务端就发这一包,
 * 别的 Numen 包都要等他用 {@link HelloPayload} 报上同一版协议之后才发。客户端版本对得上才报到。
 *
 * <p><b>格式永远只是一个协议号。</b>协议怎么改,这一包和 {@link HelloPayload} 都不改:两端版本对不上时,能读懂的只剩这两包,
 * 它们一变,对不上的一端连"对不上"都读不出来,解包失败就被断开。
 */
public record ServerHelloPayload(int protocol) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "server_hello");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10804(protocol);
    }

    public static ServerHelloPayload read(class_2540 buf) {
        return new ServerHelloPayload(buf.method_10816());
    }

    /** Client main thread. */
    public static void handle(ServerHelloPayload p) {
        ClientPayloadSink.serverHello.accept(p);
    }
}
