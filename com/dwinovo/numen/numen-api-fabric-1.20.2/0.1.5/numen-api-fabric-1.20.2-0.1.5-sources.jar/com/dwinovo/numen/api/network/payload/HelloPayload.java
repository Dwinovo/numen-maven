package com.dwinovo.numen.api.network.payload;

import com.dwinovo.numen.api.Constants;
import com.dwinovo.numen.api.brain.Replies;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

/**
 * Client → Server: 对 {@link ServerHelloPayload} 的回答,客户端说的协议版本。版本对得上,服务端接着等它的 {@link ClientCapsPayload},
 * 到齐了回 {@link HelloAckPayload},随后把名册、这位玩家名下各大脑此刻的样子和会话列表补给他;对不上就什么也不发。没报到的玩家(没装客户端、或装的版本不同)
 * 收不到任何 Numen 包。
 *
 * <p><b>格式永远只是一个协议号</b>,理由见 {@link ServerHelloPayload}。
 */
public record HelloPayload(int protocol) implements class_8710 {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "hello");

    @Override
    public class_2960 comp_1678() {
        return ID;
    }

    @Override
    public void method_53028(class_2540 buf) {
        buf.method_10804(protocol);
    }

    public static HelloPayload read(class_2540 buf) {
        return new HelloPayload(buf.method_10816());
    }

    /** Handler invoked on the server main thread. */
    public static void handle(HelloPayload p, class_3222 player) {
        Replies.reported(player, p.protocol());
    }
}
