package com.dwinovo.numen.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_303;
import net.minecraft.class_338;

/**
 * 聊天框流式输出的钥匙:原版聊天行加了就不能改,同伴的流式回复靠
 * "摘掉旧行 → 补一条更长的新行"模拟打字机效果——摘行要碰私有的
 * {@code allMessages},摘完要 {@code refreshTrimmedMessages} 重排版。
 * 只读一写,不改任何原版逻辑。
 */
@Mixin(class_338.class)
public interface ChatComponentAccessor {

    @Accessor("allMessages")
    List<class_303> numen$allMessages();

    @Invoker("refreshTrimmedMessages")
    void numen$refreshTrimmedMessages();
}
