package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client:某个同伴的头顶气泡状态(见 {@link SpeechBubblePayload}
 * 的上行说明)。收到的客户端不一定是主人——附近路过的玩家同样收到,
 * 同伴说话路人也听得见。
 */
public record SpeechBubbleSyncPayload(UUID entityUuid, byte kind, String text) implements class_8710 {

    public static final class_9154<SpeechBubbleSyncPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "speech_bubble_sync"));

    public static final class_9139<class_9129, SpeechBubbleSyncPayload> STREAM_CODEC =
            class_9139.method_56436(
                    class_4844.field_48453, SpeechBubbleSyncPayload::entityUuid,
                    class_9135.field_48548, SpeechBubbleSyncPayload::kind,
                    class_9135.method_56364(SpeechBubblePayload.MAX_TEXT), SpeechBubbleSyncPayload::text,
                    SpeechBubbleSyncPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client main thread. */
    public static void handle(SpeechBubbleSyncPayload p) {
        com.dwinovo.numen.client.hud.SpeechBubbles.apply(p.entityUuid(), p.kind(), p.text());
    }
}
