package com.dwinovo.numen.client.hud;

import com.dwinovo.numen.client.NumenKeys;
import com.dwinovo.numen.client.chat.CompanionChatScreen;
import com.dwinovo.numen.client.screen.UiTheme;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_742;

/**
 * 快捷对话提醒:准星指着自己的同伴时,准星下方浮一行「按 [键] 与 名字
 * 对话」。键名跟着 Controls 里的实际绑定走,改键提示自动变;设置的
 * THEME 区可整体关掉。纯 HUD 文本,不占用世界渲染。
 */
public final class TalkHint {

    private TalkHint() {}

    /** 短暂的教学/反馈行(如转盘关盘后的「按 [键] 对话」),盖过常规提示。 */
    private static String flashText;
    private static long flashUntilMs;

    public static void flash(String text, long lifeMs) {
        flashText = text;
        flashUntilMs = System.currentTimeMillis() + lifeMs;
    }

    public static void render(class_332 g) {
        // 崩溃护栏:HUD 层逐帧执行,异常绝不外抛
        com.dwinovo.numen.client.ui.SafeUi.run("talk-hint", () -> renderInner(g));
    }

    private static void renderInner(class_332 g) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null || mc.field_1690.field_1842) {
            return;
        }
        // 快捷语音的实时状态(录音中/没听清等提示)优先于按键提示
        String voiceLine = com.dwinovo.numen.client.chat.QuickVoice.hudLine();
        if (voiceLine != null) {
            draw(g, mc, voiceLine, 0xFFFFC862);
            return;
        }
        if (flashText != null && System.currentTimeMillis() < flashUntilMs) {
            draw(g, mc, flashText, 0xFFFFE9B0);
            return;
        }
        if (!UiTheme.talkHintEnabled()) {
            return;
        }
        class_742 body = CompanionChatScreen.crosshairCompanion();
        if (body == null) {
            return;
        }
        String name = com.dwinovo.numen.client.agent.NumenRoster.instance().name(body.method_5667());
        if (name == null || name.isBlank()) {
            name = body.method_5820();
        }
        String talk = NumenKeys.TALK_COMPANION.method_16007().getString();
        String voice = NumenKeys.QUICK_VOICE.method_16007().getString();
        draw(g, mc, "按 [" + talk + "] 与 " + name + " 对话 · 按住 [" + voice + "] 说话",
                0xFFFFFFFF);
    }

    private static void draw(class_332 g, class_310 mc, String text, int color) {
        class_327 font = mc.field_1772;
        int x = (g.method_51421() - font.method_1727(text)) / 2;
        int y = g.method_51443() / 2 + 16;   // 准星正下方一点,不挡视线焦点
        g.method_51433(font, text, x, y, color, true);
    }
}
