package com.dwinovo.numen.client.chat;

import com.dwinovo.numen.client.screen.UiTheme;
import com.dwinovo.numen.mixin.ChatComponentAccessor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_338;
import net.minecraft.class_5250;

/**
 * 同伴对话在聊天框里的唯一出样口——聊天框是不开面板时的全量实时面:
 *
 * <pre>
 * 你 → sadasdas:帮我看看矿洞          (整行暗灰;语音带「(语音)」记号)
 * sadasdas:我看看…▌                    (流式行:边生成边长,完成后定格)
 * ⚙ sadasdas · goto                    (工具调用,最暗的状态行)
 * sadasdas:到了,矿洞在这边……          (回复全文,不折叠)
 * </pre>
 *
 * 统一格式统一配色,整体比真人聊天暗一层;没有尖括号,不冒充真人发言。
 * 瞬态提示(没能送达/先选人/没听清)不进聊天框,走 {@code TalkHint#flash}。
 *
 * <p>流式实现:原版聊天行不可编辑,靠"摘掉旧行 → 补一条更长的新行"
 * 模拟打字机(经 {@link ChatComponentAccessor});每个同伴最多一条在飞行,
 * 完成后由定格行接替。客户端主线程专用。
 */
public final class ChatLines {

    /** 自己发言:暗一层的灰(知道自己说了什么,回显只为日志完整)。 */
    private static final int OWN = 0xAAB0B8;
    /** 同伴正文:近白——正文必须一眼可读,"退后"交给名字配色与工具行。 */
    private static final int TEXT = 0xE8EBEF;
    /** 工具调用状态行:最暗一档——是动作记录,不是话。 */
    private static final int TOOL = 0x8A9099;

    /** 每个同伴的在飞流式行(摘行用的句柄)。 */
    private static final Map<UUID, class_303> LIVE = new HashMap<>();

    private ChatLines() {}

    /**
     * 主人发出的一句(文字或语音),回显为暗灰字幕行;{@code queued} 时
     * 缀上排队标记——她正忙,这条在队列里等她收口。
     */
    public static void owner(String companionName, String text, boolean voice, boolean queued) {
        class_5250 line = class_2561.method_43470(
                "你 → " + companionName + ":" + (voice ? "(语音) " : "") + text)
                .method_54663(OWN);
        if (queued) {
            line.method_10852(class_2561.method_43470("  (排队中,她忙完就看)").method_54663(TOOL));
        }
        add(line);
    }

    /** 同伴的回复定格行:加粗着色名字 + 近白正文,全文显示不折叠。 */
    public static void companion(String companionName, String text) {
        String flat = text.replaceAll("\\s+", " ").trim();
        if (flat.isEmpty()) {
            return;
        }
        add(name(companionName).method_10852(class_2561.method_43470(flat).method_54663(TEXT)));
    }

    /** 系统性提醒(连接失败/配置问题):琥珀警示行——玩家必须知道发生了什么,
     *  不能让失败沉进日志里变成"已读不回"。 */
    public static void notice(String companionName, String text) {
        add(class_2561.method_43470("⚠ " + companionName + ":").method_54663(0xE0A53A)
                .method_10852(class_2561.method_43470(text).method_54663(OWN)));
    }

    /**
     * 流式行更新:摘掉这只同伴的旧行,补上更长的新行(带光标记号)。
     * 新行永远落在聊天最新位,像正在打字。
     */
    public static void streaming(UUID companion, String companionName, String partial) {
        // 崩溃护栏:摘行手术碰的是原版聊天内部结构,出错宁可这帧不更新
        com.dwinovo.numen.client.ui.SafeUi.run("chat-streaming", () -> {
            class_338 chat = class_310.method_1551().field_1705.method_1743();
            ChatComponentAccessor acc = (ChatComponentAccessor) chat;
            removeLive(acc, companion);
            class_5250 line = name(companionName)
                    .method_10852(class_2561.method_43470(partial).method_54663(TEXT))
                    .method_10852(class_2561.method_43470("▌").method_54663(OWN));
            chat.method_1812(line);
            List<class_303> all = acc.numen$allMessages();
            if (!all.isEmpty()) {
                LIVE.put(companion, all.get(0));   // addMessage 把新行放在 0 位
            }
        });
    }

    /** 流式收尾:摘掉在飞行(定格行由调用方随后补上)。 */
    public static void streamingDone(UUID companion) {
        com.dwinovo.numen.client.ui.SafeUi.run("chat-streaming", () -> {
            class_338 chat = class_310.method_1551().field_1705.method_1743();
            removeLive((ChatComponentAccessor) chat, companion);
        });
    }

    /** 退出世界:清句柄(聊天框本身随会话销毁)。 */
    public static void clearLive() {
        LIVE.clear();
    }

    private static void removeLive(ChatComponentAccessor acc, UUID companion) {
        class_303 old = LIVE.remove(companion);
        if (old != null && acc.numen$allMessages().remove(old)) {
            acc.numen$refreshTrimmedMessages();
        }
    }

    /** 加粗的主题色名字前缀——同伴行的视觉锚点。 */
    private static class_5250 name(String companionName) {
        return class_2561.method_43470(companionName + ":")
                .method_54663(UiTheme.current().reply() & 0xFFFFFF)
                .method_27694(s -> s.method_10982(true));
    }

    private static void add(class_2561 line) {
        class_310.method_1551().field_1705.method_1743().method_1812(line);
    }
}
