package com.dwinovo.numen.client.ui;

import com.dwinovo.numen.Constants;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.class_10789;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;
import org.jetbrains.annotations.Nullable;

/**
 * Anti-aliased rounded-rectangle fill via a tiny SDF core shader
 * ({@code assets/numen_api/shaders/core/rendertype_round_rect.vsh/.fsh}).
 * 1.21.6+ deferred GUI: GuiGraphics no longer draws immediately — elements are
 * collected as {@link class_11244}s and batched by the GuiRenderer at
 * frame end, with meshes built in each state's pipeline's own vertex format and
 * only the standard UBOs (DynamicTransforms/Projection) bound. Custom uniforms
 * are therefore gone entirely: the SDF parameters ride vertex attributes instead
 * (UV0 = local offset from the rect centre; UV1 = half-size ×16; UV2.x = radius
 * ×16, flat-interpolated), so fills batch like any vanilla element. If the
 * pipeline fails to compile (a pack replaced the GLSL with garbage) every call
 * degrades to a plain square fill, so the GUI never breaks — it just loses its
 * corners.
 */
public final class RoundRect {

    /** 管线定义:着色器位置指 {@code assets/numen_api/shaders/core/rendertype_round_rect.*}。 */
    public static final RenderPipeline PIPELINE = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(Constants.MOD_ID, "pipeline/round_rect"))
            .withVertexShader(class_2960.method_60655(Constants.MOD_ID, "core/rendertype_round_rect"))
            .withFragmentShader(class_2960.method_60655(Constants.MOD_ID, "core/rendertype_round_rect"))
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withVertexFormat(class_290.field_1580, VertexFormat.class_5596.field_27382)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withCull(false)
            .build();

    /** SDF 参数的定点倍率(short 属性,1/16 px 精度,尺寸上限 ±2047px)。 */
    private static final int FP = 16;

    private RoundRect() {}

    /** A bordered card: 1px border colour ring + inset body fill, same corner family. */
    public static void card(class_332 g, int x1, int y1, int x2, int y2, float radius, int fill, int border) {
        fill(g, x1, y1, x2, y2, radius, border);
        fill(g, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0f, radius - 1f), fill);
    }

    public static void fill(class_332 g, int x1, int y1, int x2, int y2, float radius, int argb) {
        radius = Math.min(radius, Math.min(x2 - x1, y2 - y1) / 2f);
        if (radius <= 0) {
            g.method_25294(x1, y1, x2, y2, argb);
            return;
        }
        // 编译失败(资源包换了坏 GLSL)→ 降级方角。precompilePipeline 有缓存,重复调用只是查表。
        if (!RenderSystem.getDevice().precompilePipeline(PIPELINE).isValid()) {
            g.method_25294(x1, y1, x2, y2, argb);
            return;
        }
        g.field_59826.method_70919(new State(
                new Matrix3x2f(g.method_51448()), x1, y1, x2, y2, radius, argb, g.field_44659.method_70863()));
    }

    /** 单个圆角矩形的延迟渲染状态;同管线的连续状态会被 GuiRenderer 合并成一批。 */
    private record State(Matrix3x2f pose, int x0, int y0, int x1, int y1, float radius, int argb,
                         @Nullable class_8030 scissorArea, @Nullable class_8030 bounds)
            implements class_11244 {

        State(Matrix3x2f pose, int x0, int y0, int x1, int y1, float radius, int argb,
              @Nullable class_8030 scissorArea) {
            this(pose, x0, y0, x1, y1, radius, argb, scissorArea,
                    computeBounds(x0, y0, x1, y1, pose, scissorArea));
        }

        @Override
        public void method_70917(class_4588 vc, float z) {
            float hw = (x1 - x0) / 2f;
            float hh = (y1 - y0) / 2f;
            int h16x = Math.round(hw * FP);
            int h16y = Math.round(hh * FP);
            int r16 = Math.round(radius * FP);
            vertex(vc, z, x0, y0, -hw, -hh, h16x, h16y, r16);
            vertex(vc, z, x0, y1, -hw, hh, h16x, h16y, r16);
            vertex(vc, z, x1, y1, hw, hh, h16x, h16y, r16);
            vertex(vc, z, x1, y0, hw, -hh, h16x, h16y, r16);
        }

        private void vertex(class_4588 vc, float z, float x, float y,
                            float lx, float ly, int h16x, int h16y, int r16) {
            vc.method_70815(pose, x, y, z)
                    .method_39415(argb)
                    .method_22913(lx, ly)
                    .method_60796(h16x, h16y)
                    .method_22921(r16, 0)
                    .method_22914(0f, 0f, 1f);
        }

        @Override
        public RenderPipeline comp_4055() {
            return PIPELINE;
        }

        @Override
        public class_11231 comp_4056() {
            return class_11231.method_70899();
        }

        private static @Nullable class_8030 computeBounds(int x0, int y0, int x1, int y1,
                                                               Matrix3x2f pose,
                                                               @Nullable class_8030 scissor) {
            class_8030 rect = new class_8030(x0, y0, x1 - x0, y1 - y0).method_71523(pose);
            return scissor != null ? scissor.method_49701(rect) : rect;
        }
    }
}
