package com.dwinovo.numen.client.debug;

import com.dwinovo.numen.network.payload.PathDebugPayload;
import java.util.List;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

/**
 * 寻路调试世界渲染:把 {@link PathDebugState} 里的快照画成世界空间的
 * 线与方框——当前路径红、下一段品红、在飞最优蓝、待挖红框、待放绿框、
 * 挤身品红框、目标绿框、x/z 目标画通天竖线。逐帧矢量绘制,零粒子。
 * 线条会被地形遮挡(深度测试开启,原版 lines 管线)。
 */
public final class PathDebugRenderer {

    private static final float[] RED = {1.0f, 0.15f, 0.15f};
    private static final float[] MAGENTA = {1.0f, 0.25f, 1.0f};
    private static final float[] BLUE = {0.25f, 0.45f, 1.0f};
    private static final float[] GREEN = {0.15f, 1.0f, 0.15f};

    private PathDebugRenderer() {}

    /** 世界渲染钩子入口(半透明方块阶段之后;poseStack 为世界空间)。 */
    public static void render(class_4587 poseStack, class_4184 camera) {
        List<PathDebugPayload> snapshots = PathDebugState.live();
        if (snapshots.isEmpty()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        class_243 cam = camera.method_71156();
        class_4597.class_4598 buffers = mc.method_22940().method_23000();
        class_4588 vc = buffers.getBuffer(class_1921.method_23594());
        poseStack.method_22903();
        poseStack.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);
        class_4587.class_4665 pose = poseStack.method_23760();
        int minY = mc.field_1687.method_31607();
        int maxY = mc.field_1687.method_31600();
        for (PathDebugPayload p : snapshots) {
            drawPolyline(vc, pose, p.currentPath(), RED);
            drawPolyline(vc, pose, p.nextPath(), MAGENTA);
            drawPolyline(vc, pose, p.bestPath(), BLUE);
            for (long packed : p.toBreak()) {
                drawBox(poseStack, vc, packed, RED);
            }
            for (long packed : p.toPlace()) {
                drawBox(poseStack, vc, packed, GREEN);
            }
            for (long packed : p.toWalkInto()) {
                drawBox(poseStack, vc, packed, MAGENTA);
            }
            for (long packed : p.goalBoxes()) {
                drawBox(poseStack, vc, packed, GREEN);
            }
            for (long packed : p.goalColumns()) {
                class_2338 pos = class_2338.method_10092(packed);
                seg(vc, pose,
                        pos.method_10263() + 0.5, minY, pos.method_10260() + 0.5,
                        pos.method_10263() + 0.5, maxY, pos.method_10260() + 0.5, GREEN);
            }
        }
        poseStack.method_22909();
        buffers.method_22994(class_1921.method_23594());
    }

    /** 折线:相邻格心连线段。 */
    private static void drawPolyline(class_4588 vc, class_4587.class_4665 pose,
                                     List<Long> packedPositions, float[] color) {
        for (int i = 0; i + 1 < packedPositions.size(); i++) {
            class_2338 a = class_2338.method_10092(packedPositions.get(i));
            class_2338 b = class_2338.method_10092(packedPositions.get(i + 1));
            seg(vc, pose,
                    a.method_10263() + 0.5, a.method_10264() + 0.5, a.method_10260() + 0.5,
                    b.method_10263() + 0.5, b.method_10264() + 0.5, b.method_10260() + 0.5, color);
        }
    }

    private static void drawBox(class_4587 poseStack, class_4588 vc, long packed, float[] color) {
        class_2338 pos = class_2338.method_10092(packed);
        net.minecraft.class_9974.method_62292(poseStack, vc,
                pos.method_10263() + 0.02, pos.method_10264() + 0.02, pos.method_10260() + 0.02,
                pos.method_10263() + 0.98, pos.method_10264() + 0.98, pos.method_10260() + 0.98,
                color[0], color[1], color[2], 0.9f);
    }

    /** 一条线段(法线取线段方向,lines 渲染管线要求)。 */
    private static void seg(class_4588 vc, class_4587.class_4665 pose,
                            double x1, double y1, double z1,
                            double x2, double y2, double z2, float[] color) {
        float dx = (float) (x2 - x1);
        float dy = (float) (y2 - y1);
        float dz = (float) (z2 - z1);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-5f) {
            return;
        }
        float nx = dx / len;
        float ny = dy / len;
        float nz = dz / len;
        vc.method_56824(pose, (float) x1, (float) y1, (float) z1)
                .method_22915(color[0], color[1], color[2], 0.9f)
                .method_60831(pose, nx, ny, nz);
        vc.method_56824(pose, (float) x2, (float) y2, (float) z2)
                .method_22915(color[0], color[1], color[2], 0.9f)
                .method_60831(pose, nx, ny, nz);
    }
}
