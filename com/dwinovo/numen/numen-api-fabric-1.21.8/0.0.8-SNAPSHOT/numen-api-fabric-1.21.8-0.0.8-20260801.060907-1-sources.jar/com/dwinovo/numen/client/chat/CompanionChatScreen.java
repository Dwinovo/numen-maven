package com.dwinovo.numen.client.chat;

import com.dwinovo.numen.api.NumenGateway;
import com.dwinovo.numen.client.agent.NumenRoster;
import com.dwinovo.numen.client.screen.FlatEditBox;
import com.dwinovo.numen.client.screen.Nb;
import com.dwinovo.numen.client.screen.UiTheme;
import com.dwinovo.numen.client.ui.RoundRect;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_742;

/**
 * 快捷对话:按对话键(默认 Y,入口在 {@code NumenKeys})对「当前交互
 * 对象」弹出这一条极简输入框——就一行字,回车说出去立刻关屏,回复会浮
 * 在它头顶的气泡里。收件人由 {@code SelectedCompanion} 解析:准星指着
 * 谁优先谁,否则是轮盘选中的那位。屏只是输入法,不是对话窗口;历史与
 * 长文在 G 面板。准星提示见 {@code TalkHint}。
 *
 * <p>与 {@code @名字} 路由是同一条管线({@link NumenGateway#enqueue}),
 * 对应两种社交距离:@ 是远程喊话,这里是走到跟前说话。
 */
public class CompanionChatScreen extends class_437 {

    private static final int INPUT_W = 300;
    private static final int INPUT_H = 14;

    private final UUID companionUuid;
    private final String companionName;
    private FlatEditBox input;

    public CompanionChatScreen(UUID companionUuid, String companionName) {
        super(class_2561.method_43470("Numen face-to-face chat"));
        this.companionUuid = companionUuid;
        this.companionName = companionName == null ? "?" : companionName;
    }

    /**
     * 准星此刻指着的「自己的」同伴,不在指着返回 null。花名册只含本人的
     * 同伴,身份校验是白送的;别人的同伴不响应(它的大脑不在你机器上)。
     */
    public static class_742 crosshairCompanion() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1724.method_7325()) return null;
        if (!(mc.field_1765 instanceof class_3966 hit)) return null;
        if (!(hit.method_17782() instanceof class_742 body)) return null;
        for (NumenRoster.Entry entry : NumenRoster.instance().entries()) {
            if (entry.uuid().equals(body.method_5667())) {
                return body;
            }
        }
        return null;
    }

    @Override
    protected void method_25426() {
        String kept = input != null ? input.method_1882() : "";
        int x = (this.field_22789 - INPUT_W) / 2;
        int y = this.field_22790 - 44;
        // G 面板同款 FlatEditBox:深色字、无阴影、占位提示画在光标下层——
        // 原版 EditBox 的阴影是写死的,浅底上深色字会糊成一团
        input = new FlatEditBox(this.field_22793, x, y, INPUT_W, INPUT_H,
                class_2561.method_43470("numen chat input"));
        input.method_1858(false);
        input.method_1868(UiTheme.current().text());
        input.method_47404(Nb.colored("想说什么…(回车说出去,Esc 算了)", UiTheme.current().textDim()));
        input.method_1880(256);
        input.method_1852(kept);
        input.method_1856(false);
        method_25429(input);
        method_48265(input);
    }

    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float partialTicks) {
        // 刻意留空:super.render 默认会画菜单模糊+压暗遮罩,面对面说话
        // 不该把世界糊掉——她就站在你面前
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partialTicks) {
        UiTheme th = UiTheme.current();
        int x = input.method_46426();
        int y = input.method_46427();

        // 名字牌:输入框左上角一枚小卡,标明这句话说给谁
        String tag = companionName;
        int tagW = this.field_22793.method_1727(tag) + 12;
        RoundRect.card(g, x - 6, y - 24, x - 6 + tagW, y - 9, 3, th.band(), th.border());
        Nb.text(g, this.field_22793, tag, x, y - 20, th.onBand());

        // 输入卡:与 G 面板同方言的浅底粗边卡片
        RoundRect.card(g, x - 8, y - 6, x + INPUT_W + 8, y + INPUT_H + 4, 4,
                th.aiFill(), th.border());
        input.method_25394(g, mouseX, mouseY, partialTicks);

        super.method_25394(g, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            send();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private void send() {
        String text = input.method_1882().trim();
        if (!text.isEmpty()) {
            boolean queued = com.dwinovo.numen.client.agent.AgentLoopRegistry.get(companionUuid)
                    .map(l -> l.isBusy() || l.hasQueuedPrompts()).orElse(false);
            boolean accepted = NumenGateway.enqueue(companionUuid, text);
            if (accepted) {
                ChatLines.owner(companionName, text, false, queued);
            } else {
                com.dwinovo.numen.client.hud.TalkHint.flash(
                        companionName + " 没能收到——它可能不在线", 3000);
            }
        }
        method_25419();
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
