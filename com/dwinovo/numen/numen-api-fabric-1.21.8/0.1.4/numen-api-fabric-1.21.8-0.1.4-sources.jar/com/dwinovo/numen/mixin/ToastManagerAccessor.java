package com.dwinovo.numen.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.BitSet;
import net.minecraft.class_374;

/**
 * 原版右上角的 toast 占着哪几格:我们的通知排在它们下面,不叠在成就提示上。只读。
 */
@Mixin(class_374.class)
public interface ToastManagerAccessor {

    @Accessor("occupiedSlots")
    BitSet numen$occupiedSlots();
}
