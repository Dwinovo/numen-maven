package com.dwinovo.numen.client.command;

import com.dwinovo.numen.data.ModLanguageData.Keys;
import net.minecraft.class_1074;
import com.dwinovo.numen.client.agent.EntityAgentLoop;

/**
 * {@code /compact} —— 整理记忆。
 *
 * <p>可用性问 {@link EntityAgentLoop#compactProblem()},那是唯一的判据。补全行会把
 * 理由原样显示出来——从前那颗按钮只会灰着,不说为什么。
 */
final class CompactCommand implements ChatCommand {

    @Override
    public String name() {
        return "compact";
    }

    @Override
    public String description() {
        return class_1074.method_4662(Keys.LOOP_COMPACT);
    }

    @Override
    public boolean touchesContext() {
        return true;
    }

    @Override
    public String unavailable(EntityAgentLoop loop) {
        return loop == null ? null : loop.compactProblem();
    }

    @Override
    public String run(EntityAgentLoop loop, String args) {
        String refused = loop.requestCompact();
        if (refused != null) {
            return refused;
        }
        // 空闲时进队列就当场走掉了,忙的时候才真排着——照实说哪一种。
        return loop.status().phase() == com.dwinovo.numen.agent.loop.Phase.COMPACT
                ? class_1074.method_4662(Keys.CMD_COMPACT_STARTED) : class_1074.method_4662(Keys.CMD_COMPACT_QUEUED);
    }
}
