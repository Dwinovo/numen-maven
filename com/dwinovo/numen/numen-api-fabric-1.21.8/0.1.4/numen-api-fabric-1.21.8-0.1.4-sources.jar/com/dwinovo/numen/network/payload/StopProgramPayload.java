package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.OwnedBody;
import com.dwinovo.numen.network.Wire;
import com.dwinovo.numen.program.ServerPrograms;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client-to-server payload: "stop the program I sent". Two ways to stop, both the client's call because they are about
 * the client's side of things — the owner spoke, the stop button, an external brain took over, the connection is
 * closing:
 * <ul>
 *   <li>{@code cutOff = false}: stop between calls with {@code why} as the reason (the owner spoke, an urgent event the
 *       client synthesised); the call in flight finishes first, a body job it waits for keeps running;</li>
 *   <li>{@code cutOff = true}: the turn is cut off, the program stops at once; {@code stopBody} says whether the body
 *       job was stopped too ({@link CancelTasksPayload} does that), so the receipt tells the truth about it.</li>
 * </ul>
 * Urgent events the server emits itself it judges itself, with the same rule ({@code EventQueue.isUrgent}); they never
 * come through here. Only the owner's program, and only the one named by {@code programId}, is touched.
 */
public record StopProgramPayload(UUID entityUuid, String programId, boolean cutOff, boolean stopBody, String why)
        implements class_8710 {

    public static final class_9154<StopProgramPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "stop_program"));

    public static final class_9139<ByteBuf, StopProgramPayload> STREAM_CODEC =
            class_9139.method_56906(
                    class_4844.field_48453, StopProgramPayload::entityUuid,
                    Wire.TO_SERVER.text(), StopProgramPayload::programId,
                    class_9135.field_48547, StopProgramPayload::cutOff,
                    class_9135.field_48547, StopProgramPayload::stopBody,
                    Wire.TO_SERVER.text(), StopProgramPayload::why,
                    StopProgramPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Handler invoked on the server main thread. */
    public static void handle(StopProgramPayload p, class_3222 player) {
        NumenPlayer companion = NumenPlayer.findByUuid(player.method_51469().method_8503(), p.entityUuid());
        if (companion == null || !companion.isOwnedByPlayer(player.method_5667())) {
            Constants.LOG.debug("[numen-net] stop_program for {} ignored: not the sender's companion", p.entityUuid());
            return;
        }
        if (p.cutOff()) {
            ServerPrograms.cutOff(p.entityUuid(), p.programId(), p.stopBody());
        } else {
            ServerPrograms.interrupt(p.entityUuid(), p.programId(), p.why());
        }
    }
}
