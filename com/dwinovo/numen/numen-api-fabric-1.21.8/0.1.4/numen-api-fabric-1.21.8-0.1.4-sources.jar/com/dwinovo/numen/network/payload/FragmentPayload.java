package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.Fragments;
import com.dwinovo.numen.network.Wire;
import io.netty.buffer.ByteBuf;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_8703;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 一条超过单包上限的消息({@link Wire.Fragmentable})的一片:消息 id、第几片、共几片,第 0 片再带上原包的种类,其余是编码后字节
 * 的一段。两个方向各有自己的种类 id,NeoForge 与 Fabric 都按"一个 id 一个方向"登记。怎么切、怎么拼、拼多大见 {@link Fragments}。
 *
 * <p>{@code type} 是这一片所在方向的种类({@link #TO_SERVER}、{@link #TO_CLIENT}),跟着片走,所以一个记录类服务两个方向。
 *
 * @param inner 原包的种类,只有第 0 片带
 * @param chunk 原包编码后字节的一段:除最后一片外都正好是 {@link Fragments#chunkBytes}
 */
public record FragmentPayload(class_9154<FragmentPayload> type, int id, int index, int count,
                              Optional<class_2960> inner, byte[] chunk) implements class_8710 {

    public static final class_9154<FragmentPayload> TO_SERVER = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "fragment_to_server"));
    public static final class_9154<FragmentPayload> TO_CLIENT = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "fragment_to_client"));

    public static final class_9139<ByteBuf, FragmentPayload> TO_SERVER_CODEC =
            codec(TO_SERVER, Wire.TO_SERVER_PACKET);
    public static final class_9139<ByteBuf, FragmentPayload> TO_CLIENT_CODEC =
            codec(TO_CLIENT, Wire.TO_CLIENT_PACKET);

    /** 这个方向上的片的种类。 */
    public static class_9154<FragmentPayload> typeOf(Wire direction) {
        return direction == Wire.TO_SERVER ? TO_SERVER : TO_CLIENT;
    }

    /** 这个方向上的片的编解码器。 */
    public static class_9139<ByteBuf, FragmentPayload> codecOf(Wire direction) {
        return direction == Wire.TO_SERVER ? TO_SERVER_CODEC : TO_CLIENT_CODEC;
    }

    private static class_9139<ByteBuf, FragmentPayload> codec(class_9154<FragmentPayload> type, int maxChunk) {
        class_9139<ByteBuf, byte[]> bytes = class_9135.method_56895(maxChunk);
        return class_9139.method_56437((buf, p) -> {
            class_8703.method_53017(buf, p.id);
            class_8703.method_53017(buf, p.index);
            class_8703.method_53017(buf, p.count);
            if (p.index == 0) {
                class_2960.field_48267.encode(buf, p.inner.orElseThrow());
            }
            bytes.encode(buf, p.chunk);
        }, buf -> {
            int id = class_8703.method_53016(buf);
            int index = class_8703.method_53016(buf);
            int count = class_8703.method_53016(buf);
            Optional<class_2960> inner = index == 0 ? Optional.of(class_2960.field_48267.decode(buf))
                    : Optional.empty();
            return new FragmentPayload(type, id, index, count, inner, bytes.decode(buf));
        });
    }
}
