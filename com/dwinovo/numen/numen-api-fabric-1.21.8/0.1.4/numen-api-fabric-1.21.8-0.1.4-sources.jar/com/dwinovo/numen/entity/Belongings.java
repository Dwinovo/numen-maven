package com.dwinovo.numen.entity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_7923;

/**
 * 某一刻她身上有什么:背包每格的物品与数量,加上经验。拿来和之后的她比,说出这中间实际多了、少了什么。
 *
 * <p>只认"什么物品、几个"——耐久、附魔等组件不比。每刻都要记一次,所以就地覆盖两个数组,不分配。
 */
public final class Belongings {

    private final class_1792[] items;
    private final int[] counts;
    private int level;
    private int points;

    public Belongings(int slots) {
        items = new class_1792[slots];
        counts = new int[slots];
    }

    /** 此刻的她。 */
    public static Belongings of(class_1657 body) {
        Belongings now = new Belongings(body.method_31548().method_5439());
        now.copyFrom(body);
        return now;
    }

    public void copyFrom(class_1657 body) {
        copyItems(body.method_31548());
        level = body.field_7520;
        points = body.field_7495;
    }

    /** 只记物品那一半(经验不在容器里)。 */
    void copyItems(class_1263 inv) {
        for (int i = 0; i < items.length; i++) {
            items[i] = inv.method_5438(i).method_7909();
            counts[i] = inv.method_5438(i).method_7947();
        }
    }

    /** 从记下的那一刻到现在的变化,形如 {@code +3 minecraft:diamond, -1 minecraft:apple; experience +100 points};没变是空串。 */
    public String changeTo(class_1657 body) {
        String items = itemChange(body);
        String xp = experienceChange(body);
        return xp.isEmpty() ? items : items.isEmpty() ? xp : items + "; " + xp;
    }

    /** 背包(含穿戴与副手)里物品的增减,形如 {@code +3 minecraft:diamond, -1 minecraft:apple};没变是空串。 */
    public String itemChange(class_1657 body) {
        return itemChange(body.method_31548());
    }

    String itemChange(class_1263 now) {
        Map<class_1792, Integer> delta = new LinkedHashMap<>();
        for (int i = 0; i < items.length; i++) {
            delta.merge(items[i], -counts[i], Integer::sum);
        }
        for (int i = 0; i < items.length; i++) {
            delta.merge(now.method_5438(i).method_7909(), now.method_5438(i).method_7947(), Integer::sum);
        }
        List<String> parts = new ArrayList<>();
        delta.forEach((item, n) -> {
            if (n != 0) {
                parts.add(signed(n) + " " + class_7923.field_41178.method_10221(item));
            }
        });
        return String.join(", ", parts);
    }

    /** 经验的变化,形如 {@code experience +100 points, level 3 -> 4};没变是空串。 */
    public String experienceChange(class_1657 body) {
        List<String> xp = new ArrayList<>();
        if (body.field_7495 != points) {
            xp.add(signed(body.field_7495 - points) + " points");
        }
        if (body.field_7520 != level) {
            xp.add("level " + level + " -> " + body.field_7520);
        }
        return xp.isEmpty() ? "" : "experience " + String.join(", ", xp);
    }

    private static String signed(int n) {
        return (n > 0 ? "+" : "") + n;
    }
}
