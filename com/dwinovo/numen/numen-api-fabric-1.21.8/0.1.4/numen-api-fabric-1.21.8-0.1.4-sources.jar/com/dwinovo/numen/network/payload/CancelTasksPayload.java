package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.NumenPlayer;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client-to-server payload: "the owner pressed Stop — cancel everything my
 * entity is doing". Sent by {@code EntityAgentLoop.abort()} alongside the
 * client-side turn teardown, so the interrupt stops the <em>body</em> (the
 * running task: walking, mining, placing), not just the model conversation.
 *
 * <h2>Trust model</h2>
 * Owner check only — no distance check, deliberately: the owner must be able
 * to stop a companion that has wandered far away. Cancelling is the one action
 * that is always safe to allow from anywhere.
 *
 * <p>A program the owner sent is stopped by {@link StopProgramPayload}; the task's
 * own end comes as a task_finished event (or in the receipt of a program still
 * waiting for it). This payload's job is purely the body stop.
 */
public record CancelTasksPayload(UUID entityUuid) implements class_8710 {

    public static final class_9154<CancelTasksPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "cancel_tasks"));

    public static final class_9139<ByteBuf, CancelTasksPayload> STREAM_CODEC =
            class_9139.method_56434(
                    class_4844.field_48453, CancelTasksPayload::entityUuid,
                    CancelTasksPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Handler invoked on the server main thread. */
    public static void handle(CancelTasksPayload p, class_3222 player) {
        // Cross-dimension lookup: the owner must be able to stop a companion
        // that has wandered into another dimension or out of view distance.
        NumenPlayer numen = NumenPlayer.findByUuid(player.method_51469().method_8503(), p.entityUuid());
        if (numen == null) {
            Constants.LOG.debug("[numen-net] cancel_tasks for unknown entity {}", p.entityUuid());
            return;
        }
        if (!numen.isOwnedByPlayer(player.method_5667())) {
            Constants.LOG.warn("[numen-net] ✗ cancel_tasks rejected from {}: not the owner",
                    player.method_5477().getString());
            return;
        }
        com.dwinovo.numen.task.CompanionTickDispatcher.cancelFor(numen);
        Constants.LOG.info("[numen-net] ✓ cancel_tasks on entity {} for {}",
                p.entityUuid(), player.method_5477().getString());
    }
}
