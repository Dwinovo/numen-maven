package com.dwinovo.numen.pathing.body;

import net.minecraft.class_1675;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

/**
 * 准星此刻落在哪:照原版客户端每刻算准星的那一次拾取({@code GameRenderer.pick})——沿视线先找方块轮廓(不看流体),
 * 再找挡在它前面、能被点中的实体,各按自己的交互距离截断。左键挖、右键放与开门都只对准星落着的东西起作用,
 * 所以准星被实体挡住时,挖掘停下、放置不按,与真玩家一样。
 */
public final class Crosshair {

    private Crosshair() {}

    /** 准星落着的东西:方块、实体,或什么也没有({@link class_239.class_240#field_1333})。 */
    public static class_239 pick(class_3222 body) {
        double blockRange = body.method_55754();
        double entityRange = body.method_55755();
        double range = Math.max(blockRange, entityRange);
        double rangeSqr = class_3532.method_33723(range);
        class_243 eye = body.method_33571();
        class_239 block = body.method_5745(range, 1.0F, false);
        double blockSqr = block.method_17784().method_1025(eye);
        if (block.method_17783() != class_239.class_240.field_1333) {
            rangeSqr = blockSqr;
            range = Math.sqrt(blockSqr);
        }
        class_243 view = body.method_5828(1.0F);
        class_243 end = eye.method_1031(view.field_1352 * range, view.field_1351 * range, view.field_1350 * range);
        class_238 swept = body.method_5829().method_18804(view.method_1021(range)).method_1009(1.0, 1.0, 1.0);
        class_3966 entity = class_1675.method_18075(body, eye, end, swept,
                e -> !e.method_7325() && e.method_5863(), rangeSqr);
        return entity != null && entity.method_17784().method_1025(eye) < blockSqr
                ? within(entity, eye, entityRange)
                : within(block, eye, blockRange);
    }

    /** 准星正落在 {@code pos} 这一格上时交出那一下;否则为 null。 */
    public static class_3965 on(class_3222 body, class_2338 pos) {
        return pick(body) instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332
                && hit.method_17777().equals(pos) ? hit : null;
    }

    /**
     * 手里的东西在空中右键时自己沿视线打的那一条,照原版 {@code Item.getPlayerPOVHitResult}(桶倒水、舀水就用它):从眼睛沿视线
     * 打方块交互距离,按方块轮廓,液体按 {@code fluid} 的规矩算不算;不看实体。和准星那一次拾取不是同一条:桶瞄的是它自己这条。
     */
    public static class_3965 itemRay(class_3222 body, class_3959.class_242 fluid) {
        class_243 eye = body.method_33571();
        class_243 end = eye.method_1019(body.method_5631(body.method_36455(), body.method_36454()).method_1021(body.method_55754()));
        return body.method_51469().method_17742(new class_3959(eye, end, class_3959.class_3960.field_17559, fluid, body));
    }

    private static class_239 within(class_239 hit, class_243 eye, double range) {
        class_243 at = hit.method_17784();
        if (at.method_24802(eye, range)) {
            return hit;
        }
        class_2350 direction = class_2350.method_10142(at.field_1352 - eye.field_1352, at.field_1351 - eye.field_1351, at.field_1350 - eye.field_1350);
        return class_3965.method_17778(at, direction, class_2338.method_49638(at));
    }
}
