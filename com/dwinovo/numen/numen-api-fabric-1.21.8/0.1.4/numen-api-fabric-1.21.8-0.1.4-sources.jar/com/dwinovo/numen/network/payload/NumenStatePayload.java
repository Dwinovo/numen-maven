package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.Wire;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: a companion's 36 main backpack slots. Sent both as the answer to
 * {@link RequestStatePayload} (the Items tab asking) and unprompted whenever her
 * inventory actually changes, so the agent loop can state what she carries without
 * spending a turn on {@code status_self}. {@code loaded=false} means the body is
 * asleep in unloaded chunks (or not the requester's) — no contents.
 *
 * <p>{@code selectedSlot} and {@code offhand} ride along rather than being read off the
 * client-side entity: vanilla only syncs equipment for entities the client is tracking,
 * so once she walks out of view the hands would go blank while the backpack (pushed from
 * the server) stayed readable. Two fields buy one answer that is the same everywhere.
 *
 * <h2>为什么这里装的不只是背包</h2>
 * 饱食度、选中槽、副手早就在里面了 —— 它一直是<b>这具身体此刻的样子</b>,只是原来叫背包。
 * 身上的效果同理:模型每一轮都要读它才知道自己中没中毒、有没有抗性,而这类东西<b>一进对话
 * 历史就永远不会过期</b>,只能每次现挂。同一条通道、同一份快照,不必为每样状态另开一路。
 * 骑乘同理:她坐没坐在船上决定了"再点一次船"是不是废话、numen.move.go 会驾船还是走路,
 * 模型必须实时看见。{@code vehicleType} 空串 = 没骑任何东西,{@code vehicleId} 相应为 -1。
 * 身体状态片段({@code bodyState}:打头的 {@code <worn>} 与插件经 {@code NumenApi.contributeBodyState} 读的)同理:
 * 身体上的事实,同一份快照带过去;空串 = 没有插件要说什么。
 *
 * <h2>装不下一个包时</h2>
 * 身体状态片段是插件给的,物品带着任意的组件(写满的书、装满的潜影盒),长短都不归这个包定。整包装不下时
 * ({@link #shrunk})先把身体状态换成一句说明;还装不下,背包也不带,说明里一并交代——她读到的是"这次没送到",
 * 不是一个空背包。
 */
public record NumenStatePayload(UUID uuid, boolean loaded, List<class_1799> items,
                                List<class_1799> craft, int foodLevel, float saturation,
                                int selectedSlot, class_1799 offhand,
                                List<class_1293> effects,
                                String vehicleType, int vehicleId, String bodyState)
        implements class_8710, Wire.Oversized<NumenStatePayload> {

    public static final class_9154<NumenStatePayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "numen_state"));

    /** 手写而不是 {@code composite}:后者最多拼 6 个分量,这里有十二个。 */
    public static final class_9139<class_9129, NumenStatePayload> STREAM_CODEC =
            class_9139.method_56437(NumenStatePayload::write, NumenStatePayload::read);

    private static void write(class_9129 buf, NumenStatePayload p) {
        class_4844.field_48453.encode(buf, p.uuid());
        class_9135.field_48547.encode(buf, p.loaded());
        class_1799.field_49269.encode(buf, p.items());
        class_1799.field_49269.encode(buf, p.craft());
        class_9135.field_48550.encode(buf, p.foodLevel());
        class_9135.field_48552.encode(buf, p.saturation());
        class_9135.field_48550.encode(buf, p.selectedSlot());
        class_1799.field_49268.encode(buf, p.offhand());
        class_1293.field_49207.method_56433(class_9135.method_56363()).encode(buf, p.effects());
        Wire.TO_CLIENT.text().encode(buf, p.vehicleType());
        class_9135.field_48550.encode(buf, p.vehicleId());
        Wire.TO_CLIENT.text().encode(buf, p.bodyState());
    }

    private static NumenStatePayload read(class_9129 buf) {
        UUID uuid = class_4844.field_48453.decode(buf);
        boolean loaded = class_9135.field_48547.decode(buf);
        List<class_1799> items = class_1799.field_49269.decode(buf);
        List<class_1799> craft = class_1799.field_49269.decode(buf);
        int foodLevel = class_9135.field_48550.decode(buf);
        float saturation = class_9135.field_48552.decode(buf);
        int selectedSlot = class_9135.field_48550.decode(buf);
        class_1799 offhand = class_1799.field_49268.decode(buf);
        List<class_1293> effects =
                class_1293.field_49207.method_56433(class_9135.method_56363()).decode(buf);
        String vehicleType = Wire.TO_CLIENT.text().decode(buf);
        int vehicleId = class_9135.field_48550.decode(buf);
        String bodyState = Wire.TO_CLIENT.text().decode(buf);
        return new NumenStatePayload(uuid, loaded, items, craft, foodLevel, saturation,
                selectedSlot, offhand, effects, vehicleType, vehicleId, bodyState);
    }

    @Override
    public NumenStatePayload shrunk(Predicate<NumenStatePayload> fits, int bytes, int budget) {
        NumenStatePayload lighter = new NumenStatePayload(uuid, loaded, items, craft, foodLevel, saturation,
                selectedSlot, offhand, effects, vehicleType, vehicleId, "<not_delivered>"
                + Wire.TO_CLIENT.tooBig("Your body state", bytes) + ", so it is left out this time.</not_delivered>");
        if (fits.test(lighter)) {
            return lighter;
        }
        List<class_1799> none = java.util.Collections.nCopies(items.size(), class_1799.field_8037);
        return new NumenStatePayload(uuid, loaded, none, java.util.Collections.nCopies(craft.size(), class_1799.field_8037),
                foodLevel, saturation, selectedSlot, class_1799.field_8037, effects, vehicleType, vehicleId,
                "<not_delivered>" + Wire.TO_CLIENT.tooBig("Your body state with your inventory", bytes)
                        + ", so both are left out this time: the empty slots here are not your inventory."
                        + "</not_delivered>");
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Client main thread. */
    public static void handle(NumenStatePayload p) {
        com.dwinovo.numen.network.ClientPayloadSink.state.accept(p);
    }
}
