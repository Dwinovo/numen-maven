package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.Wire;
import com.dwinovo.numen.program.ModuleSet;
import com.dwinovo.numen.program.NetworkTransport;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client-to-server payload: the answer to a {@link ClientCallPayload}, the call's result in the shape every API call
 * returns ({@code ApiReply}). When the function changed her modules (a {@code numen.module.save}), the client's new
 * module list rides along as {@code modules}, so the program that is still running sees the new text the next time it
 * uses the module and the client stays the only source of truth. A result can be as long as what the function read
 * (a module's code) and the new module texts ride along, so the payload is {@link Wire.Fragmentable}.
 */
public record ClientCallResultPayload(UUID entityUuid, String callId, String replyJson, Optional<ModuleSet> modules)
        implements class_8710, Wire.Fragmentable {

    public static final class_9154<ClientCallResultPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "client_call_result"));

    public static final class_9139<ByteBuf, ClientCallResultPayload> STREAM_CODEC =
            class_9139.method_56905(
                    class_4844.field_48453, ClientCallResultPayload::entityUuid,
                    Wire.TO_SERVER.text(), ClientCallResultPayload::callId,
                    Wire.TO_SERVER.text(), ClientCallResultPayload::replyJson,
                    class_9135.method_56382(ModuleSet.STREAM_CODEC), ClientCallResultPayload::modules,
                    ClientCallResultPayload::new);

    /** 编码后的字节数。 */
    public int size() {
        return Wire.size(STREAM_CODEC, this, Unpooled::buffer);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Handler invoked on the server main thread. */
    public static void handle(ClientCallResultPayload p, class_3222 player) {
        NetworkTransport.INSTANCE.answered(player.method_5667(), p);
    }
}
