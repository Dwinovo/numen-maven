package com.dwinovo.numen.entity;

import io.netty.channel.ChannelFutureListener;
import io.netty.channel.embedded.EmbeddedChannel;
import java.util.function.Consumer;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_9812;

/**
 * A channel-less {@link class_2535} for a companion fake {@code ServerPlayer}.
 * The server pushes a steady stream of clientbound packets at any list-resident
 * player (position, chunks, entity updates, keep-alives); a real connection
 * writes them to a netty channel, but our companion has no client on the other
 * end. A bare {@code new Connection(...)} is NOT safe: its {@code send} queues
 * every packet into an unbounded {@code pendingActions} list when no channel is
 * attached — a slow leak. So we subclass and DISCARD all outbound I/O.
 *
 * <p>{@code Connection} is non-final with a public {@code PacketFlow} ctor, so
 * this is pure common code — no reflection, access-wideners or mixins. Two
 * details make {@code placeNewPlayer} accept it:
 * <ul>
 *   <li><b>SERVERBOUND</b> receiving flow — a server-side player connection
 *       receives serverbound packets (the client sends them), so its listener
 *       is serverbound; {@code validateListener} rejects a CLIENTBOUND mismatch.</li>
 *   <li>a real (in-memory) {@link EmbeddedChannel} — {@code placeNewPlayer ->
 *       setupInboundProtocol} configures the channel's pipeline, which NPEs on a
 *       channel-less connection. Registering this Connection as the embedded
 *       channel's handler fires {@code channelActive}, setting the channel.</li>
 * </ul>
 * Outbound packets are still discarded by the {@code send} override (the
 * embedded channel is never written to, so it never buffers/leaks), and the
 * keep-alive timeout is neutralised via the no-op {@code disconnect} (a fake
 * player never answers keep-alive). Lifecycle is governed by
 * {@code CompanionLifecycle}, not by connection state.
 */
@com.dwinovo.numen.api.Internal
public final class FakeConnection extends class_2535 {

    public FakeConnection() {
        super(class_2598.field_11941);
        // Registering this Connection (a netty inbound handler) as the embedded
        // channel's handler fires channelActive → sets this.channel, so the
        // pipeline setup inside placeNewPlayer has a channel to work on.
        new EmbeddedChannel(this);
    }

    /** Discard every outbound packet — there is no client to receive it.
     *  The 1-arg and 2-arg {@code send} overloads route through this one. */
    @Override
    public void method_52906(class_2596<?> packet, ChannelFutureListener listener, boolean flush) {
        // no-op: drop it on the floor (no channel, no pendingActions growth)
    }

    /** Vanilla queues these until "connected"; we never connect, so run nothing. */
    @Override
    public void method_52905(Consumer<class_2535> action) {
        // no-op
    }

    /**
     * Report live so player ticking / chunk tracking proceed as for a real
     * player. Safe because every channel-dereferencing path (send, tick,
     * flushChannel) is overridden to no-op below, so the null channel is never
     * touched.
     */
    @Override
    public boolean method_10758() {
        return true;
    }

    /** Don't drive the packet listener's tick (that's what runs the keep-alive). */
    @Override
    public void method_10754() {
        // no-op
    }

    /** Neutralise the keep-alive timeout (and any other) disconnect — both overloads. */
    @Override
    public void method_10747(class_2561 message) {
        // no-op: the companion is removed via CompanionLifecycle, never by the wire
    }

    @Override
    public void method_60924(class_9812 details) {
        // no-op
    }

    @Override
    public void method_10768() {
        // no-op
    }

    @Override
    public void method_52915() {
        // no-op
    }

    @Override
    public void method_10757() {
        // no-op
    }
}
