package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.entity.CompanionRegistry;
import com.dwinovo.numen.platform.Services;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client → Server: "where are these companions of mine right now?" Sent by the
 * roster panel (and the chat vitals strip) for entities the client can't see —
 * a working companion may be ticking in chunk-ticket-loaded terrain thousands
 * of blocks away, or in another dimension.
 *
 * <p>Answered with one {@link NumenLocationsPayload} carrying a snapshot per
 * requested UUID. Ownership is enforced per entity: UUIDs that don't resolve
 * to a pet owned by the sender come back {@code found=false} (no oracle for
 * other players' pets).
 */
public record LocateNumenPayload(List<UUID> entityUuids) implements class_8710 {

    /** Roster panels are small; cap defends against garbage input. */
    public static final int MAX_UUIDS = 16;

    public static final class_9154<LocateNumenPayload> TYPE = new class_9154<>(
            class_2960.method_60655(Constants.MOD_ID, "locate_numen"));

    public static final class_9139<class_9129, LocateNumenPayload> STREAM_CODEC =
            class_9139.method_56434(
                    class_4844.field_48453.method_56433(class_9135.method_58000(MAX_UUIDS)),
                    LocateNumenPayload::entityUuids,
                    LocateNumenPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    /** Handler invoked on the server main thread. */
    public static void handle(LocateNumenPayload p, class_3222 player) {
        List<NumenLocationsPayload.Snapshot> out = new ArrayList<>(p.entityUuids().size());
        CompanionRegistry registry = CompanionRegistry.get(player.method_51469().method_8503());
        for (UUID uuid : p.entityUuids()) {
            NumenPlayer numen = NumenPlayer.findByUuid(player.method_51469().method_8503(), uuid);
            if (numen != null && numen.isOwnedByPlayer(player.method_5667())) {
                out.add(NumenLocationsPayload.Snapshot.live(uuid,
                        numen.method_23317(), numen.method_23318(), numen.method_23321(),
                        numen.method_51469().method_27983().method_29177().toString(),
                        numen.method_6032(), numen.method_6063()));
                continue;
            }
            // Dormant (owner logged out, or not yet respawned this session): fall
            // back to the persistent companion index so the roster can show WHERE
            // it sleeps instead of a useless "offline". Owner-gated — the registry
            // carries ownership and the respawn-hint position.
            CompanionRegistry.Entry entry = registry.find(uuid);
            if (numen == null && entry != null && entry.owner().equals(player.method_5667())) {
                var pos = entry.pos();
                out.add(NumenLocationsPayload.Snapshot.lastSeen(uuid,
                        pos.method_10263(), pos.method_10264(), pos.method_10260(),
                        entry.dimension().method_29177().toString()));
                continue;
            }
            out.add(NumenLocationsPayload.Snapshot.notFound(uuid));
        }
        Services.NETWORK.sendToPlayer(player, new NumenLocationsPayload(out));
    }
}
