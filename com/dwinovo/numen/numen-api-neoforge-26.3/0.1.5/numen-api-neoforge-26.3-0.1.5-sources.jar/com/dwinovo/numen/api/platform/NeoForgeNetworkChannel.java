package com.dwinovo.numen.api.platform;

import com.dwinovo.numen.api.platform.services.INetworkChannel;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.HandlerThread;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * NeoForge implementation of {@link INetworkChannel}. NeoForge requires
 * payload registration to happen during the {@code RegisterPayloadHandlersEvent}
 * window, so this channel buffers registrations (both C→S and S→C) into a
 * pending queue and flushes them when
 * {@link #flushPending(RegisterPayloadHandlersEvent)} is invoked from the
 * event handler (see {@code NumenMod}).
 *
 * <p>Handlers run on the main thread (server-main for C→S, client-main for S→C) unless the registration asks for
 * {@link Execution#NETWORK}, which registers the handler on the connection's own thread.
 */
public final class NeoForgeNetworkChannel implements INetworkChannel {

    private record C2SRegistration<T extends CustomPacketPayload>(
            CustomPacketPayload.Type<T> type,
            StreamCodec<? super RegistryFriendlyByteBuf, T> codec,
            BiConsumer<T, ServerPlayer> handler,
            Execution execution) {}

    private record S2CRegistration<T extends CustomPacketPayload>(
            CustomPacketPayload.Type<T> type,
            StreamCodec<? super RegistryFriendlyByteBuf, T> codec,
            Consumer<T> handler) {}

    private final List<C2SRegistration<?>> pendingC2S = new ArrayList<>();
    private final List<S2CRegistration<?>> pendingS2C = new ArrayList<>();

    @Override
    public <T extends CustomPacketPayload> void registerClientToServer(
            CustomPacketPayload.Type<T> type,
            StreamCodec<? super RegistryFriendlyByteBuf, T> codec,
            BiConsumer<T, ServerPlayer> handler,
            Execution execution) {
        pendingC2S.add(new C2SRegistration<>(type, codec, handler, execution));
    }

    @Override
    public void sendToServer(CustomPacketPayload payload) {
        // Lazy class-load: Minecraft is client-only. Server JVM never reaches this call site.
        // 没连接就发不出去，而发包往往夹在一串清理中间（登出钩子），一报错就把
        // 后面的清理全截断了。警告并丢包：丢一个本来就发不出去的包无害，截断清理有害。
        // 不静默：真有人在错的时机发包，日志里看得到。
        if (net.minecraft.client.Minecraft.getInstance().getConnection() == null) {
            com.dwinovo.numen.api.Constants.LOG.warn("[numen] 无连接,丢弃 C2S 包 {}", payload.type().id());
            return;
        }
        // 1.21.8: client->server sends moved to the client-only ClientPacketDistributor.
        net.neoforged.neoforge.client.network.ClientPacketDistributor.sendToServer(payload);
    }

    @Override
    public <T extends CustomPacketPayload> void registerServerToClient(
            CustomPacketPayload.Type<T> type,
            StreamCodec<? super RegistryFriendlyByteBuf, T> codec,
            Consumer<T> handler) {
        pendingS2C.add(new S2CRegistration<>(type, codec, handler));
    }

    @Override
    public void sendToPlayer(ServerPlayer player, CustomPacketPayload payload) {
        PacketDistributor.sendToPlayer(player, payload);
    }

    @Override
    public boolean canSend(ServerPlayer player, CustomPacketPayload.Type<?> type) {
        return player.connection.hasChannel(type);
    }

    /**
     * Apply every buffered registration against the live registrar. Called
     * exactly once per mod load from the {@code RegisterPayloadHandlersEvent}
     * subscriber in {@code NumenMod}.
     */
    public void flushPending(RegisterPayloadHandlersEvent event) {
        // 全部可选:协商时服务端有而客户端没有的可选频道不算缺——原版客户端(与没装我们的 NeoForge 客户端)才进得来。
        // 谁装着我们的客户端由它报到(Presence)说了算,发包前问 canSend。
        PayloadRegistrar registrar = event.registrar("1").optional();
        PayloadRegistrar onNetwork = registrar.executesOn(HandlerThread.NETWORK);
        for (C2SRegistration<?> r : pendingC2S) {
            applyC2S(r.execution() == Execution.NETWORK ? onNetwork : registrar, r);
        }
        for (S2CRegistration<?> r : pendingS2C) applyS2C(registrar, r);
        pendingC2S.clear();
        pendingS2C.clear();
    }

    private static <T extends CustomPacketPayload> void applyC2S(
            PayloadRegistrar registrar, C2SRegistration<T> r) {
        registrar.playToServer(r.type(), r.codec(), (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer server) {
                r.handler().accept(payload, server);
            }
        });
    }

    private static <T extends CustomPacketPayload> void applyS2C(
            PayloadRegistrar registrar, S2CRegistration<T> r) {
        // playToClient registers a handler that fires on the client side
        // when a S→C packet of this type arrives. On a dedicated server,
        // the handler closure is never invoked (the server is the sender,
        // not the receiver).
        registrar.playToClient(r.type(), r.codec(), (payload, ctx) -> {
            r.handler().accept(payload);
        });
    }
}
