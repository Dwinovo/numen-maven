package com.dwinovo.numen.core.nav;

import com.dwinovo.numen.pathing.body.Snapshots;
import com.dwinovo.numen.pathing.drive.LiveWorld;
import com.dwinovo.numen.pathing.plan.Stance;
import com.dwinovo.numen.pathing.search.Goal;
import com.dwinovo.numen.pathing.search.Origin;
import com.dwinovo.numen.pathing.world.Footing;
import net.minecraft.class_2338;
import net.minecraft.class_3222;

/**
 * 她此刻在哪个节点上、怎么待着——与寻路定起点、认步用的是同一条规则({@link Origin}、{@link Stance}),任务问"我是不是已经
 * 站在该站的地方"时也问这里,不另判。
 *
 * @param node   脚所在的节点(身体站在边沿时是托着它的那一列)
 * @param stance 在那个节点上怎么待着
 */
public record Feet(class_2338 node, Stance stance) {

    /** 她此刻的节点;悬在半空、卡在方块里时为 null。 */
    public static Feet of(class_3222 body) {
        LiveWorld world = new LiveWorld(body.method_51469());
        var stats = Snapshots.stats(body);
        class_2338 node = Origin.of(world, stats, body.method_23317(), body.method_23318(), body.method_23321()).orElse(null);
        if (node == null) {
            return null;
        }
        Stance stance = Stance.at(world, stats, node);
        return stance == null ? null : new Feet(node, stance);
    }

    /** 脚的高度归在的那一格(不管待不待得住)。 */
    public static class_2338 cell(class_3222 body) {
        return class_2338.method_49637(body.method_23317(), Footing.cellOf(body.method_23318()), body.method_23321());
    }

    /** 站在这里算不算到了 {@code goal}。 */
    public boolean in(Goal goal) {
        return goal.contains(node.method_10263(), node.method_10264(), node.method_10260(), stance);
    }
}
