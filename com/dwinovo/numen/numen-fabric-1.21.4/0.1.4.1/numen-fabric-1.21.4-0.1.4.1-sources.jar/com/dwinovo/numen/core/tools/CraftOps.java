package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.agent.script.ApiError;
import com.dwinovo.numen.agent.script.ErrorKind;
import com.dwinovo.numen.core.PlayerInv;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.sdk.Doc;
import com.dwinovo.numen.core.mixin.CraftingMenuAccessor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1731;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1869;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3955;
import net.minecraft.class_7923;
import net.minecraft.class_8566;
import net.minecraft.class_8786;

/**
 * The {@code inv craft} command: one craft in the crafting grid that is open — lay one batch of a named recipe
 * (up to a stack per cell) into the REAL grid via menu clicks and shift-take the result once. Everything runs
 * through the vanilla container path ({@code menu.clicked} on a live {@code CraftingMenu} / {@code InventoryMenu}),
 * so recipe-unlock, stats, ingredient remainders (bucket back from milk) and container-observing mods all see a
 * normal player crafting — items never appear out of thin air.
 *
 * <p>The grid is the one open now: her own 2x2 when nothing else is. Which recipe to use, and finding, opening and
 * closing a crafting table, are the Lua module {@code numen.inv.make}'s; the recipe facts it decides with (the
 * smallest grid a recipe fits, what she is short of) are read here, the same as the craft checks them.
 */
public final class CraftOps {

    /** One call crafts at most this many times per cell: a full stack. */
    private static final int MAX_BATCH = 64;

    /** One grid cell to fill: row-major position in the target grid + what goes there. */
    private record Placement(int gridPos, class_1856 ing) {}

    /** The clickable geometry of an open crafting surface. */
    private record Grid(int w, int h, int[] cells, int result) {}

    /** 合了一次:合出几件、现在背着几件、用掉什么、还回来什么(牛奶桶还回空桶这类),背着的料够不够再合。 */
    @Doc("What one craft made.")
    public record Crafted(@Doc("How many it made.") int crafted,
                          @Doc("How many you carry now.") int carrying,
                          @Doc("What it used, 3x oak_planks.") List<String> used,
                          @Doc("What came back, a bucket from milk.") List<String> gotBack,
                          @Doc("Whether what you carry crafts more of it: call again for the rest.") boolean more) {}

    /** {@code numen.inv.craft}:在开着的格里照 {@code id} 那条配方合一次,至多合到 {@code count} 件。 */
    public static Crafted craft(class_2960 id, int want, NumenPlayer self) {
        class_3218 level = self.method_51469();
        class_8786<?> found = level.method_64577().method_8130(net.minecraft.class_5321.method_29179(
                net.minecraft.class_7924.field_52178, id)).orElse(null);
        if (found == null || !(found.comp_1933() instanceof class_3955 recipe) || recipe.method_8118()
                || ingredientsOf(recipe).isEmpty()) {
            throw new ApiError(ErrorKind.NOT_FOUND, "no crafting recipe " + id,
                    "numen.inv.recipes(item) lists every recipe that makes an item, each with its id");
        }
        @SuppressWarnings("unchecked")
        class_8786<class_3955> holder = (class_8786<class_3955>) found;
        class_1799 result = RecipeProbe.resultOf(recipe, level.method_30349());
        class_1792 target = result.method_7909();
        String name = class_7923.field_41178.method_10221(target).method_12832();

        class_1703 menu = self.field_7512;
        Grid grid = findGrid(menu);
        if (grid == null) {
            throw new ApiError(ErrorKind.FAILED, "the open window (" + menu.getClass().getSimpleName() + ") has no "
                    + "crafting grid — numen.gui.close() it to craft in your own 2x2, or numen.use.block a crafting "
                    + "table", null);
        }
        // 先把搁在格子里的收回来,再数料
        sweepGrid(menu, self, grid);
        List<class_1856> ings = ingredientsOf(recipe);
        Map<class_1792, Integer> pool = poolOf(menu, self);
        if (feasibleBatch(ings, pool, 1) == 0) {
            throw new ApiError(ErrorKind.NO_MATERIAL, "not enough materials for " + name + " — missing: "
                    + String.join(", ", missingFor(ings, pool)), null, Map.of("missing", missingFor(ings, pool)));
        }
        if (!fits(recipe, grid.w(), grid.h())) {
            throw new ApiError(ErrorKind.FAILED, name + " needs a " + gridOf(recipe) + "x" + gridOf(recipe) + " grid; "
                    + "the open one is " + grid.w() + "x" + grid.h() + " — numen.use.block a crafting table, then "
                    + "craft again (numen.inv.make finds one and opens it)", null);
        }
        if (!settleCarried(menu, self)) {
            throw new ApiError(ErrorKind.FAILED, "the cursor is holding items and no inventory slot is free to put "
                    + "them down — free a slot first (numen.inv.drop).", null);
        }

        Map<class_1792, Integer> before = poolOf(menu, self);
        int output = Math.max(1, result.method_7947());
        int batch = feasibleBatch(ings, before, Math.min(Math.ceilDiv(want, output), MAX_BATCH));
        // Lay out the batch: per cell, the matching inventory item with the deepest supply.
        Map<class_1792, Integer> sim = new HashMap<>(before);
        for (Placement pl : placements(recipe, grid.w())) {
            class_1792 pick = pickItem(pl.ing(), sim);
            int cellIdx = pick == null ? -1 : grid.cells()[pl.gridPos()];
            if (cellIdx < 0 || placeIntoCell(menu, self, cellIdx, pick, pl.ing(), batch) < batch) {
                sweepGrid(menu, self, grid);
                throw new ApiError(ErrorKind.FAILED, "couldn't lay " + name + " out in the grid: a cell took fewer "
                        + "items than the recipe needs", null);
            }
            sim.merge(pick, -batch, Integer::sum);
        }
        // 摆完就自己要一次重算,不等 slotsChanged。那是个可被覆写的触发器:把重算推迟到
        // 之后 server tick 的模组覆写的正是它,于是这一刻读到的结果槽还是空的(#110)。
        // 结果槽只有原版那一趟写,这里直接要它算,对原版和那类模组都成立。
        recompute(menu, grid, self, holder);
        if (menu.field_7761.get(grid.result()).method_7677().method_7960()) {
            sweepGrid(menu, self, grid);
            throw new ApiError(ErrorKind.FAILED, "the laid-out grid doesn't form " + name + " (another mod overrides "
                    + "this grid?)", null);
        }
        int have0 = PlayerInv.count(self.method_31548(), target);
        menu.method_7593(grid.result(), 0, class_1713.field_7794, self);   // vanilla mass-craft + onTake
        self.method_6104(class_1268.field_5808);
        sweepGrid(menu, self, grid);
        int crafted = PlayerInv.count(self.method_31548(), target) - have0;
        if (crafted <= 0) {
            throw new ApiError(ErrorKind.FAILED, "crafted nothing — your inventory is full and the result doesn't "
                    + "fit.", null);
        }

        // Report material flow as inventory deltas (covers remainders like buckets coming back).
        Map<class_1792, Integer> after = poolOf(menu, self);
        List<String> used = new ArrayList<>();
        List<String> back = new ArrayList<>();
        for (class_1792 item : new TreeSet<>(union(before, after))) {
            int delta = after.getOrDefault(item, 0) - before.getOrDefault(item, 0);
            String path = class_7923.field_41178.method_10221(item).method_12832();
            if (delta < 0) {
                used.add((-delta) + "x " + path);
            } else if (delta > 0 && item != target) {
                back.add(delta + "x " + path);
            }
        }
        return new Crafted(crafted, PlayerInv.count(self.method_31548(), target), used, back,
                feasibleBatch(ings, after, 1) > 0);
    }

    /** {@code numen.inv.craftable}:她背着的料现在合得出的每一条合成配方。 */
    public static List<Recipe> craftable(NumenPlayer self) {
        class_3218 level = self.method_51469();
        Map<class_1792, Integer> pool = poolOf(self.field_7498, self);
        List<Recipe> recipes = new ArrayList<>();
        // 1.21.2 起服务端没有按类型取配方表的口子:全表遍历,只看合成配方
        for (class_8786<?> holder : level.method_64577().method_8126()) {
            if (!(holder.comp_1933() instanceof class_3955 recipe)) {
                continue;
            }
            try {
                class_1799 result = RecipeProbe.resultOf(recipe, level.method_30349());
                if (recipe.method_8118() || result.method_7960() || !RecipeProbe.usableIngredients(recipe)
                        || ingredientsOf(recipe).isEmpty() || gridOf(recipe) == 0
                        || feasibleBatch(ingredientsOf(recipe), pool, 1) == 0) {
                    continue;
                }
                recipes.add(recipe(holder, recipe, result, self));
            } catch (RuntimeException broken) {
                // 坏一条丢一条,记下 id 方便去上游反馈;绝不让它杀掉整个调用
                com.dwinovo.numen.core.Constants.LOG.debug(
                        "[numen-craft] 配方 {} 坏了,跳过: {}", holder.comp_1932().method_29177(), broken.toString());
            }
        }
        return recipes;
    }

    /**
     * 一条合成配方:编号、合出几件、每格的料、装得下的最小的格,以及照她背着的合一次还缺什么(不缺时没有)。
     * {@code numen.inv.recipes} 与 {@code numen.inv.craftable} 共用这一份。
     */
    static Recipe recipe(class_8786<?> holder, class_3955 recipe, class_1799 result, NumenPlayer self) {
        List<class_1856> ings = ingredientsOf(recipe);
        Map<class_1792, Integer> pool = poolOf(self.field_7498, self);
        return new Recipe(holder.comp_1932().method_29177().toString(), Recipe.Station.CRAFTING,
                class_7923.field_41178.method_10221(result.method_7909()).toString(), result.method_7947(),
                ings.stream().map(RecipeBook::describeIngredient).toList(), java.util.Optional.of(gridOf(recipe)),
                feasibleBatch(ings, pool, 1) == 0 ? java.util.Optional.of(missingFor(ings, pool))
                        : java.util.Optional.empty(), java.util.Optional.empty());
    }

    /** 这条合成配方装得下的最小的格:2(她自己的)、3(工作台);更大的(模组工位)是 0。 */
    static int gridOf(class_3955 recipe) {
        return fits(recipe, 2, 2) ? 2 : fits(recipe, 3, 3) ? 3 : 0;
    }

    /**
     * 按当前格局重算结果槽。容器从菜单自己的槽位上取({@code Slot.container}),所以
     * 工作台和她自己的 2×2 走同一条;拿不到原版那两种容器的(模组自定义合成台)就不动。
     */
    private static void recompute(class_1703 menu, Grid grid, NumenPlayer self,
                                  class_8786<class_3955> hint) {
        if (!(self.method_37908() instanceof class_3218 level)) {
            return;
        }
        class_1263 cells = menu.field_7761.get(grid.cells()[0]).field_7871;
        class_1263 out = menu.field_7761.get(grid.result()).field_7871;
        if (cells instanceof class_8566 craft && out instanceof class_1731 result) {
            CraftingMenuAccessor.numen$recompute(menu, level, self, craft, result, hint);
        }
    }

    private static TreeSet<class_1792> union(Map<class_1792, Integer> a, Map<class_1792, Integer> b) {
        TreeSet<class_1792> keys = new TreeSet<>((x, y) -> class_7923.field_41178.method_10221(x).method_12833(
                class_7923.field_41178.method_10221(y)));
        keys.addAll(a.keySet());
        keys.addAll(b.keySet());
        return keys;
    }

    // ---- recipe feasibility ----

    /** The recipe's non-empty ingredients — the per-craft shopping list. */
    private static List<class_1856> ingredientsOf(class_3955 recipe) {
        // 1.21.2 起静态清单在 PlacementInfo(产出依赖输入的特殊配方它摆不出来,清单是空的)
        return recipe.method_61671().method_64675().stream().filter(i -> !i.method_65799()).toList();
    }

    private static boolean fits(class_3955 recipe, int w, int h) {
        if (recipe instanceof class_1869 s) {
            return s.method_8150() <= w && s.method_8158() <= h;
        }
        return ingredientsOf(recipe).size() <= w * h;
    }

    /** Where each ingredient goes in a grid of width {@code gridW} (shaped anchors top-left). */
    private static List<Placement> placements(class_3955 recipe, int gridW) {
        List<Placement> out = new ArrayList<>();
        if (recipe instanceof class_1869 s) {
            int w = s.method_8150(), h = s.method_8158();
            var cells = s.method_61693();   // 1.21.2 起 List<Optional<Ingredient>>,空格是 empty
            for (int r = 0; r < h; r++) {
                for (int c = 0; c < w; c++) {
                    class_1856 ing = cells.get(r * w + c).orElse(null);
                    if (ing != null && !ing.method_65799()) {
                        out.add(new Placement(r * gridW + c, ing));
                    }
                }
            }
        } else {
            int pos = 0;
            for (class_1856 ing : recipe.method_61671().method_64675()) {
                if (!ing.method_65799()) {
                    out.add(new Placement(pos++, ing));
                }
            }
        }
        return out;
    }

    /** The matching item with the deepest supply in {@code pool}, or null. */
    private static class_1792 pickItem(class_1856 ing, Map<class_1792, Integer> pool) {
        class_1792 best = null;
        int bestN = 0;
        for (var h : ing.method_8105().toList()) {   // 1.21.2 起 Stream<Holder<Item>>
            class_1792 item = h.comp_349();
            int n = pool.getOrDefault(item, 0);
            if (n > bestN) {
                best = item;
                bestN = n;
            }
        }
        return best;
    }

    /**
     * The largest per-cell stack size {@code <= wantBatch} the pool can feed for one grid
     * layout (each cell drawing greedily, shared items competing). 0 = can't craft once.
     */
    private static int feasibleBatch(List<class_1856> ings, Map<class_1792, Integer> pool0, int wantBatch) {
        int n = Math.max(0, wantBatch);
        while (n > 0) {
            Map<class_1792, Integer> pool = new HashMap<>(pool0);
            int cap = n;
            boolean ok = true;
            for (class_1856 ing : ings) {
                class_1792 pick = pickItem(ing, pool);
                int have = pick == null ? 0 : pool.getOrDefault(pick, 0);
                int usable = pick == null ? 0 : Math.min(have, new class_1799(pick).method_7914());
                if (usable < n) {
                    cap = usable;
                    ok = false;
                    break;
                }
                pool.merge(pick, -n, Integer::sum);
            }
            if (ok) {
                return n;
            }
            n = cap;
        }
        return 0;
    }

    /** "3x iron_ingot (have 1)" lines for every ingredient the pool can't cover once. */
    private static List<String> missingFor(List<class_1856> ings, Map<class_1792, Integer> pool) {
        Map<String, int[]> tally = new LinkedHashMap<>();       // desc -> [need]
        Map<String, class_1856> rep = new LinkedHashMap<>();
        for (class_1856 ing : ings) {
            String desc = RecipeBook.describeIngredient(ing);
            tally.computeIfAbsent(desc, k -> new int[1])[0]++;
            rep.putIfAbsent(desc, ing);
        }
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, int[]> e : tally.entrySet()) {
            int need = e.getValue()[0];
            int have = 0;
            for (var h : rep.get(e.getKey()).method_8105().toList()) {   // 1.21.2 起 Stream<Holder<Item>>
                have += pool.getOrDefault(h.comp_349(), 0);
            }
            if (have < need) {
                out.add(need + "x " + e.getKey() + " (have " + have + ")");
            }
        }
        return out;
    }

    // ---- menu plumbing ----

    /** Detect a crafting surface generically: CraftingContainer-backed slots + the ResultSlot. */
    private static Grid findGrid(class_1703 menu) {
        if (menu == null) {
            return null;
        }
        int w = 0, h = 0, result = -1;
        int[] cells = null;
        for (class_1735 slot : menu.field_7761) {
            if (slot instanceof class_1734) {
                result = slot.field_7874;
                continue;
            }
            if (slot.field_7871 instanceof class_8566 cc) {
                if (cells == null) {
                    w = cc.method_17398();
                    h = cc.method_17397();
                    cells = new int[w * h];
                    Arrays.fill(cells, -1);
                }
                int pos = slot.method_34266();
                if (pos >= 0 && pos < cells.length) {
                    cells[pos] = slot.field_7874;
                }
            }
        }
        return (cells == null || result < 0) ? null : new Grid(w, h, cells, result);
    }

    /**
     * The body's spendable materials as seen through {@code menu}: player-side slots only,
     * and only main inventory + hotbar (container slots 0–35) — armor and offhand stay on.
     */
    private static Map<class_1792, Integer> poolOf(class_1703 menu, NumenPlayer self) {
        Map<class_1792, Integer> pool = new HashMap<>();
        if (menu == null) {
            return pool;
        }
        for (class_1735 slot : menu.field_7761) {
            if (slot.field_7871 != self.method_31548() || slot.method_34266() >= 36) {
                continue;
            }
            class_1799 s = slot.method_7677();
            if (!s.method_7960()) {
                pool.merge(s.method_7909(), s.method_7947(), Integer::sum);
            }
        }
        return pool;
    }

    /** Put {@code n} of {@code item} into one grid cell via clicks; returns how many landed. */
    private static int placeIntoCell(class_1703 menu, NumenPlayer self, int cellIdx,
                                     class_1792 item, class_1856 ing, int n) {
        int placed = 0;
        int guard = 0;
        while (placed < n && guard++ < 40) {
            int src = -1;
            for (class_1735 slot : menu.field_7761) {
                if (slot.field_7871 != self.method_31548() || slot.method_34266() >= 36) {
                    continue;
                }
                class_1799 s = slot.method_7677();
                if (!s.method_7960() && s.method_31574(item) && ing.method_8093(s)) {
                    src = slot.field_7874;
                    break;
                }
            }
            if (src < 0) {
                break;
            }
            int before = placed;
            MenuOps.dripInto(menu, self, src, cellIdx, n - placed);
            placed = menu.field_7761.get(cellIdx).method_7677().method_7947();
            if (placed <= before) {
                break;   // 这一轮没放进任何东西(抓空/拒收),别空转
            }
        }
        return placed;
    }

    /** Shift every non-empty grid cell back into the inventory. */
    private static void sweepGrid(class_1703 menu, NumenPlayer self, Grid grid) {
        if (menu == null || grid == null) {
            return;
        }
        for (int idx : grid.cells()) {
            if (idx >= 0 && idx < menu.field_7761.size() && !menu.field_7761.get(idx).method_7677().method_7960()) {
                menu.method_7593(idx, 0, class_1713.field_7794, self);
            }
        }
    }

    /** Park a carried stack into a free main-inventory slot; false if none accepts it. */
    private static boolean settleCarried(class_1703 menu, NumenPlayer self) {
        if (menu.method_34255().method_7960()) {
            return true;
        }
        for (class_1735 slot : menu.field_7761) {
            if (slot.field_7871 != self.method_31548() || slot.method_34266() >= 36) {
                continue;
            }
            if (slot.method_7677().method_7960()) {
                menu.method_7593(slot.field_7874, 0, class_1713.field_7790, self);
                return menu.method_34255().method_7960();
            }
        }
        return false;
    }
}
