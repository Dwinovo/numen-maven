package com.dwinovo.numen.core.scan;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_3218;

/**
 * 读地形的原语:只读已加载的 chunk({@link #loadedChunk})与一条命中({@link Hit})。找方块是 {@link BlockSearch}
 * 的事——它经共享索引读,调色板里没有目标的整节一次跳过。
 */
public final class BlockScanner {

    private BlockScanner() {}

    /**
     * The fully-loaded chunk at ({@code cx},{@code cz}), or {@code null} if it isn't loaded — a pure
     * cache read via {@link net.minecraft.class_3215#method_21730} that <b>never</b>
     * forces a load, generates, or bounces to the main thread. Every scan in this package reads terrain
     * through here: {@code getChunk} with a status would block the server thread on chunk I/O or
     * generation, and a scan is a perception query — it reports what is loaded and says so, it does not
     * make the world bigger to answer.
     */
    static class_2791 loadedChunk(class_1937 level, int cx, int cz) {
        return level instanceof class_3218 serverLevel
                ? serverLevel.method_14178().method_21730(cx, cz)
                : null;
    }

    /** One match: world position, its state, and Euclidean distance from the search centre. */
    public record Hit(class_2338 pos, class_2680 state, double distance) {}
}
