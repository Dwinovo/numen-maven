package com.dwinovo.numen.core.nav;

import com.dwinovo.numen.pathing.plan.Permit;
import com.dwinovo.numen.pathing.plan.TerrainPolicy;
import com.dwinovo.numen.permission.Action;
import com.dwinovo.numen.permission.Gate;
import com.dwinovo.numen.permission.Verdict;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * 端口 {@link TerrainPolicy} 的实现:权限层的一份裁决快照({@link Gate},开一趟路时在主线程上取),之后搜索线程逐格问它,
 * 只读快照与传进来的视图。放行;要问——凭据是写给主人的那一条征询({@link com.dwinovo.numen.permission.ConsentItem});
 * 拒绝——理由是裁决本身({@link Verdict})。
 *
 * <p>挖是拆这一格;放是往这一格里放那块方块的物品,接住坠落倒的水是放一桶水。
 */
record GateTerrain(Gate gate) implements TerrainPolicy {

    @Override
    public Permit judge(Change change, class_2338 pos, class_2680 state, class_1922 view) {
        Action action = action(change, pos, state);
        Verdict verdict = gate.judge(action, view);
        return switch (verdict.kind()) {
            case ALLOW -> Permit.ALLOW;
            case ASK -> Permit.ask(gate.consentItem(action, verdict, view));
            case DENY -> Permit.deny(verdict);
        };
    }

    /** 对 {@code pos}(此刻是 {@code state})做 {@code change} 是权限层的哪个动作:挖是拆这一格,放是往里放那块方块的物品。 */
    static Action action(Change change, class_2338 pos, class_2680 state) {
        return switch (change) {
            case Change.Dig dig -> Action.breakBlock(pos, state);
            case Change.Place place -> Action.place(pos, state, itemOf(place));
        };
    }

    /** 放的是什么物品:水方块没有物品形态,倒水用的是水桶。 */
    private static class_1792 itemOf(Change.Place place) {
        return place.block() == class_2246.field_10382 ? class_1802.field_8705 : place.block().method_8389();
    }
}
