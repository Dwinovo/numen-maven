package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.agent.script.ApiError;
import com.dwinovo.numen.agent.script.ErrorKind;
import com.mojang.datafixers.util.Either;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_3902;
import net.minecraft.class_7923;


/**
 * {@code use sleep} 的业务半边:<b>上床,然后确认她真的睡着了</b>。
 *
 * <h2>为什么它这么薄</h2>
 * 找床归 {@code scan_blocks}(现在能写 {@code #minecraft:beds},一句话覆盖全部颜色),
 * 走过去归 {@code numen.move.to}——那两件事今天已经各有一个统一的实现,再包一份进来就是第三个入口。
 * 这里只做别处做不了的那一件:<b>把原版的睡眠判定翻译成模型能接住的回执</b>。
 *
 * <h2>三态,不是两态</h2>
 * {@code startSleepInBed} 返回 {@code Either<Problem, Unit>},而 {@code right} 只意味着
 * "没被拒绝"——它不等于"睡着了"。真判据是 {@code isSleeping()}。所以中间那一态必须存在:
 * <b>请求被接受了,但她并没有进入睡眠状态</b>。少了它,一次右键成功就会被当成睡着。
 *
 * <p>被拒绝时的措辞直接用原版自己的({@code BedSleepingProblem.message()})——白天、床被占、
 * 附近有怪、离得太远,一句都不用我们编,而且跟着语言文件走。
 */
public final class SleepOps {

    /** 原版判"够不够得着床"的盒子({@code Player.startSleepInBed} 用的就是这个)。 */
    private static final int REACH_H = 3;
    private static final int REACH_V = 2;

    /** 躺下了没有、在哪张床。 */
    public record Slept(@com.dwinovo.numen.sdk.Doc("The bed's head.") class_2338 bed, boolean sleeping) {}

    /**
     * @param at 指定哪张床;为 null 时用手边够得着的那张
     * @throws ApiError 没有床({@code not_found});原版拒绝或没真躺下({@code failed},数据里是那张床)
     */
    public static Slept sleep(class_2338 at, NumenPlayer self) {
        boolean given = at != null;
        class_2338 bedHead = given ? headOf(self.method_37908(), at) : nearestBedHeadInReach(self);
        if (bedHead == null) {
            throw noBed(self, given);
        }

        Either<class_1657.class_1658, class_3902> result = self.method_7269(bedHead);
        class_1657.class_1658 rejection = result.left().orElse(null);

        // 这三条的顺序就是判据本身:先看原版拒没拒,再看她是不是真躺下了。
        if (rejection != null) {
            throw new ApiError(ErrorKind.FAILED, explain(rejection) + " (bed at " + pretty(bedHead) + ")", null,
                    new Slept(bedHead, false));
        }
        if (!self.method_6113()) {
            throw new ApiError(ErrorKind.FAILED, "the sleep request was accepted but you did not actually enter sleep "
                    + "— something cancelled it in the same tick; look around before assuming you rested", null,
                    new Slept(bedHead, false));
        }
        return new Slept(bedHead, true);
    }

    /**
     * 拒绝理由<b>用原版自己的话</b>——它已经足够具体("there are monsters nearby"、
     * "the bed is too far away"、"you can only sleep at night and during thunderstorms"),
     * 我们再翻一遍只会得到一份要跟着原版措辞走的硬编码。而且它跟着语言文件,主人也看得懂。
     *
     * <p>{@code NOT_POSSIBLE_HERE} 与 {@code OTHER_PROBLEM} 原版没配文案({@code getMessage()}
     * 是 {@code null},那两种它在别处另行处理),那时枚举名就是全部信息——不能因为 null 就炸,
     * 那会把"她睡不着"变成"工具报错",而模型对后者无从下手。
     */
    static String explain(class_1657.class_1658 problem) {
        var vanilla = problem.method_19206();
        return vanilla != null
                ? vanilla.getString()
                : "the bed refused you (" + problem.name().toLowerCase(java.util.Locale.ROOT) + ")";
    }

    /** 手边够得着的床(原版口径:床的任一半在 ±3/±2/±3 内),归一到床头。 */
    private static class_2338 nearestBedHeadInReach(NumenPlayer self) {
        class_1937 level = self.method_37908();
        class_2338 me = self.method_24515();
        class_2338 best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (class_2338 p : class_2338.method_10097(
                me.method_10069(-REACH_H, -REACH_V, -REACH_H),
                me.method_10069(REACH_H, REACH_V, REACH_H))) {
            class_2338 head = headOf(level, p);
            if (head == null) {
                continue;
            }
            double d = head.method_10262(me);
            if (d < bestDistSq) {
                bestDistSq = d;
                best = head;
            }
        }
        return best;
    }

    /**
     * 这一格是床的话,给出它的<b>床头</b>;不是床则 null。
     *
     * <p>床占两格而 {@code startSleepInBed} 只认床头,所以从任一半算得出来——省得模型
     * 撞运气给了床尾那格。
     */
    private static class_2338 headOf(class_1937 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (!(state.method_26204() instanceof class_2244)
                || !state.method_28498(class_2244.field_9967)
                || !state.method_28498(class_2244.field_11177)) {
            return null;   // 认床看类型不看 id:模组的床自动算数,不用列 16 种颜色
        }
        return state.method_11654(class_2244.field_9967) == class_2742.field_12560
                ? pos.method_10062()
                : pos.method_10093(state.method_11654(class_2244.field_11177)).method_10062();
    }

    /** 没床时把下一步递到她面前——包括"你自己身上就带着一张"。 */
    private static ApiError noBed(NumenPlayer self, boolean coordsGiven) {
        String carried = carriedBed(self);
        String base = coordsGiven
                ? "there is no bed at those coordinates"
                : "there is no bed within reach (you must be standing next to one)";
        String next = carried != null
                ? " You are carrying " + carried + " — place it on flat ground and try again."
                : " `numen.scan.blocks(\"#minecraft:beds\")` finds one; `numen.move.to(bed, {arrive = \"use\"})` with "
                        + "its pos, then `numen.use.sleep()` again.";
        return new ApiError(ErrorKind.NOT_FOUND, base + "." + next, null);
    }

    /** 背包里的第一张床;没有则 null。 */
    private static String carriedBed(NumenPlayer self) {
        var inv = self.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && stack.method_7909() instanceof class_1747 block
                    && block.method_7711() instanceof class_2244) {
                return class_7923.field_41178.method_10221(stack.method_7909()).toString()
                        + " x" + stack.method_7947();
            }
        }
        return null;
    }



    private static String pretty(class_2338 p) {
        return p.method_10263() + "," + p.method_10264() + "," + p.method_10260();
    }
}
