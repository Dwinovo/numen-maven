package com.dwinovo.numen.platform;

import java.util.List;
import net.minecraft.class_1536;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1731;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3915;
import net.minecraft.class_3955;
import net.minecraft.class_8566;
import net.minecraft.class_8786;

/**
 * 内容要读、要调的几处原版私有成员。私有成员怎么够得着是平台的事(模组用 Mixin 访问器,Fabric 生产环境是中间名,
 * 不能按 Mojang 名反射),内容只说她要干什么。
 */
public interface IVanillaAccess {

    /** 鱼上钩的倒计时:有鱼在咬钩的窗口里时它落在原版定的那几刻内,窗口的判据由钓鱼任务自己定。 */
    int biteCountdown(class_1536 hook);

    /** 掉落物还要过几刻才让人捡(刚掉下来的东西有一小段冷却)。 */
    int pickupDelay(class_1542 item);

    /** 界面同步给客户端的数据槽:机器进度、燃料、能量这些真屏幕画进度条读的整数。 */
    List<class_3915> syncedDataSlots(class_1703 menu);

    /**
     * 按当前格局重算合成结果槽,当场生效。它是结果槽唯一的写入处;原版的 {@code slotsChanged} 只是触发器,
     * 可被覆写成之后再算(FastWorkbench 一类),所以摆完格子要直接要这趟计算。{@code hint} 是已知的那条配方,省一次全表扫。
     */
    void recomputeCraftingResult(class_1703 menu, class_3218 level, class_1657 player, class_8566 grid,
                                 class_1731 result, class_8786<class_3955> hint);

    /**
     * 方块物品在这次点击下会放成什么状态:{@code BlockItem.place} 里决定状态的那一步(连带"站得住、没被挡着"的判断),只读、
     * 不动世界;放不出来为 null。它是受保护成员,各物品还会覆写(火把分立地与贴墙),所以只能经物品自己问。
     */
    class_2680 placementState(class_1747 item, class_1750 context);
}
