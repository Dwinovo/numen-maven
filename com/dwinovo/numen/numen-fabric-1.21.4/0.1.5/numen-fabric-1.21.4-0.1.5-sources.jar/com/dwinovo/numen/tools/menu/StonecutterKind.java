package com.dwinovo.numen.tools.menu;

import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.sdk.Call;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import com.dwinovo.numen.tools.inventory.InvApi.Stack;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_10291;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_1799;
import net.minecraft.class_3971;
import net.minecraft.class_3975;

/**
 * 切石机:放进输入格的东西能切出的配方(产物与每次的数量),选一个就是按钮 = 配方序号(编号减一);选好之后结果格才出东西,拿走它是
 * {@code numen.gui.take} 或 {@code numen.gui.quick}(结果格那一格)。
 */
final class StonecutterKind implements MenuKind.Chooses<class_3971> {

    @Override
    public Class<class_3971> menu() {
        return class_3971.class;
    }

    @Override
    public String name() {
        return "a stonecutter";
    }

    @Override
    public Screen read(class_3971 menu, NumenPlayer her) {
        List<Screen.Cut> recipes = new ArrayList<>();
        // 1.21.2 起界面里列的是可选项,每项带一格展示(原版切石机界面画的就是它)
        List<class_10291.class_10292<class_3975>> held = menu.method_17863().comp_3255();
        class_10352 context = class_10363.method_65008(her.method_37908());
        for (int i = 0; i < held.size(); i++) {
            class_1799 makes = held.get(i).comp_3254().comp_3251().method_64742(context);
            recipes.add(new Screen.Cut(i + 1, Stack.of(makes, makes.method_7947())));
        }
        int selected = menu.method_17862();
        return new Screen.Stonecutting(recipes, selected < 0 ? Optional.empty() : Optional.of(selected + 1));
    }

    @Override
    public String choose(class_3971 menu, NumenPlayer her, Pick first, Pick second) {
        if (second != null) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "a stonecutter takes one recipe number", Call.of("numen.gui.view"));
        }
        if (menu.method_17864() == 0) {
            throw new ApiError(ErrorKind.FAILED, "the stonecutter offers no recipe: its input slot is empty or holds "
                    + "nothing it cuts — put the block in first (numen.gui.put)", Call.of("numen.gui.view"));
        }
        int n = first.numberIn("recipe", menu.method_17864());
        her.packets().menuButton(n - 1);
        if (menu.method_17862() != n - 1 || menu.method_7611(class_3971.field_30843).method_7677().method_7960()) {
            throw new ApiError(ErrorKind.FAILED, "recipe " + n + " was not selected: the result slot is still empty",
                    Call.of("numen.gui.view"));
        }
        return "selected stonecutter recipe " + n;
    }
}
