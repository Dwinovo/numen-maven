package com.dwinovo.numen.tools;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_7225;
import net.minecraft.class_9887;

/**
 * 读配方表的安全口。整合包里的配方什么都干得出来:空输入 {@code assemble} 返回
 * null 而不是抛异常、{@code placementInfo} 或其 ingredient 的 {@code items()} 返回 null(实测
 * ATM10 里的 gear 类配方)。判据对齐 JEI 的 {@code CategoryRecipeValidator}:
 * 枚举期只走展示路——1.21.2 起是配方的 {@code display()}(原版配方书也读它),不用空输入
 * {@code assemble}(那是出合同的问法);产出的 null 与异常一律折成 EMPTY,坏一条丢一条——一条坏配方杀掉整个遍历才是事故。
 */
public final class RecipeProbe {

    private RecipeProbe() {}

    /** 展示产出:配方展示里产出那一格解出的第一叠——枚举配方表用它。 */
    public static class_1799 resultOf(class_1860<?> recipe, class_7225.class_7874 registries) {
        class_10352 context = new class_10352.class_10353().method_64970(class_10363.field_54906, registries)
                .method_64971(class_10363.field_54907);
        return probe(() -> recipe.method_64664().stream().map(display -> display.comp_3258().method_64742(context))
                .filter(stack -> !stack.method_7960()).findFirst().orElse(class_1799.field_8037));
    }

    /** 探一次产出:null 与异常一律折成 EMPTY,调用方只看 {@code isEmpty()}。 */
    public static class_1799 probe(Supplier<class_1799> supplier) {
        try {
            class_1799 result = supplier.get();
            return result == null ? class_1799.field_8037 : result;
        } catch (RuntimeException broken) {
            return class_1799.field_8037;
        }
    }

    /**
     * 这条配方的输入表能不能安全交给下游:{@code placementInfo} 本身、它的清单与每个 ingredient 的
     * {@code items()} 都不为 null。craft 的摆料、盘点、缺料描述都在这道门之后,过了门就不必层层判空。
     */
    public static boolean usableIngredients(class_1860<?> recipe) {
        try {
            class_9887 info = recipe.method_61671();
            List<class_1856> ings = info == null ? null : info.method_64675();
            if (ings == null) {
                return false;
            }
            for (class_1856 ing : ings) {
                if (ing == null || ing.method_8105() == null) {
                    return false;
                }
            }
            return true;
        } catch (RuntimeException broken) {
            return false;
        }
    }
}
