package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.agent.tool.ToolArgs;
import com.dwinovo.numen.agent.tool.api.ToolContext;
import com.dwinovo.numen.task.TaskRecord;
import com.dwinovo.numen.core.task.collect.CollectItemsTaskRecord;
import com.dwinovo.numen.core.task.inventory.DropItemsTaskRecord;
import com.dwinovo.numen.core.task.inventory.EatItemTaskRecord;
import com.dwinovo.numen.core.task.inventory.EquipTaskRecord;
import com.dwinovo.numen.core.task.inventory.UnequipTaskRecord;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Inventory-management tool implementations — the business half of
 * {@code EquipItemTool} / {@code EatItemTool} / {@code DropItemsTool} /
 * {@code CollectItemsTool}. Each returns a {@link TaskRecord} the body's task
 * queue runs; the {@link ToolContext} carries the call id and deadline basis.
 */
public final class InventoryOps {

    private static final long EQUIP_TIMEOUT_TICKS = 5 * 20;   // instant; generous floor

    /** Generous — covers any food's eat duration (most ~1.6s) plus buffer. */
    private static final long EAT_TIMEOUT_TICKS = 15 * 20;

    private static final int DROP_MAX_COUNT = 999;
    private static final long DROP_TIMEOUT_TICKS = 10 * 20;

    private static final int COLLECT_DEFAULT_RADIUS = 16;
    private static final int COLLECT_MAX_RADIUS = 48;
    private static final long COLLECT_TIMEOUT_TICKS = 60 * 20;   // 1 min

    public TaskRecord equipItem(
String action,
String item_id,
String slot,
            ToolContext ctx) {
        if ("unequip".equalsIgnoreCase(action)) {
            return new UnequipTaskRecord(ctx.toolCallId(), ctx.deadline(EQUIP_TIMEOUT_TICKS),
                    readUnequipSlots(slot), slot.toLowerCase());
        }
        if (item_id == null || item_id.isBlank()) {
            throw new IllegalArgumentException(
                    "item_id is required to equip (to take gear off, use action=unequip with a slot)");
        }
        class_1304 equipSlot = readSlot(slot);

        class_1792 item = ToolArgs.parseItem(item_id);
        String label = class_7923.field_41178.method_10221(item).method_12832();
        return new EquipTaskRecord(ctx.toolCallId(), ctx.deadline(EQUIP_TIMEOUT_TICKS), item, equipSlot, label);
    }

    /** Parse the optional slot; {@code null} means auto-route. */
    private static class_1304 readSlot(String slot) {
        if (slot == null) {
            return null;
        }
        String name = slot.toLowerCase();
        return switch (name) {
            case "mainhand", "hand" -> class_1304.field_6173;
            case "offhand" -> class_1304.field_6171;
            case "head" -> class_1304.field_6169;
            case "chest" -> class_1304.field_6174;
            case "legs" -> class_1304.field_6172;
            case "armor" -> throw new IllegalArgumentException(
                    "slot=armor is only for action=unequip (it means all four armor pieces)");
            case "feet" -> class_1304.field_6166;
            default -> throw new IllegalArgumentException("unknown slot: " + name);
        };
    }

    /** 脱哪些槽:必填;{@code armor} 展开为四件甲。 */
    private static List<class_1304> readUnequipSlots(String slot) {
        if (slot == null || slot.isBlank()) {
            throw new IllegalArgumentException(
                    "slot is required for unequip ('armor' takes all four armor pieces off)");
        }
        if ("armor".equalsIgnoreCase(slot)) {
            return List.of(class_1304.field_6169, class_1304.field_6174,
                    class_1304.field_6172, class_1304.field_6166);
        }
        return List.of(readSlot(slot));
    }

    public TaskRecord eatItem(
String item_id,
            ToolContext ctx) {
        class_1792 item = ToolArgs.parseItem(item_id);
        String label = class_7923.field_41178.method_10221(item).method_12832();
        return new EatItemTaskRecord(ctx.toolCallId(), ctx.deadline(EAT_TIMEOUT_TICKS), item, label);
    }

    public TaskRecord dropItems(
String item_id,
int count,
            ToolContext ctx) {
        class_1792 item = ToolArgs.parseItem(item_id);
        count = Math.clamp(count, 1, DROP_MAX_COUNT);
        String label = class_7923.field_41178.method_10221(item).method_12832();
        return new DropItemsTaskRecord(ctx.toolCallId(), ctx.deadline(DROP_TIMEOUT_TICKS),
                item, count, label);
    }

    public TaskRecord collectItems(
List<String> item_ids,
Integer radius,
            ToolContext ctx) {
        // Lenient set from the id list: unparseable / unknown ids are skipped, and
        // an absent list yields an empty set — the "match everything" filter.
        Set<class_1792> filter = new LinkedHashSet<>();
        if (item_ids != null) {
            for (String el : item_ids) {
                if (el == null) continue;
                class_2960 id = class_2960.method_12829(el);
                if (id != null && class_7923.field_41178.method_10250(id)) {
                    filter.add(class_7923.field_41178.method_63535(id));
                }
            }
        }

        int searchRadius = COLLECT_DEFAULT_RADIUS;
        if (radius != null) {
            searchRadius = radius;
            if (searchRadius < 1) searchRadius = 1;
            if (searchRadius > COLLECT_MAX_RADIUS) searchRadius = COLLECT_MAX_RADIUS;
        }

        String label = filter.isEmpty() ? "all items" : labelFor(filter);
        return new CollectItemsTaskRecord(ctx.toolCallId(), ctx.deadline(COLLECT_TIMEOUT_TICKS),
                filter, searchRadius, label);
    }

    private static String labelFor(Set<class_1792> filter) {
        class_1792 first = filter.iterator().next();
        String path = class_7923.field_41178.method_10221(first).method_12832();
        return filter.size() == 1 ? path : path + "+" + (filter.size() - 1);
    }

}
