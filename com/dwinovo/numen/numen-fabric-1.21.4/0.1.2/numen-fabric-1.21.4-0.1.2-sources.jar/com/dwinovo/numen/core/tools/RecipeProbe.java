package com.dwinovo.numen.core.tools;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_3955;
import net.minecraft.class_7225;
import net.minecraft.class_9694;
import net.minecraft.class_9696;
import net.minecraft.class_9887;

/**
 * 读配方表的安全口。整合包里的配方什么都干得出来:空输入 {@code assemble} 返回
 * null 而不是抛异常、{@code placementInfo} 或其 ingredient 的 {@code items()} 返回
 * null(实测 ATM10 里的 gear 类配方)。1.21.2+ 删掉了展示产出口(getResultItem),
 * 枚举期改用空输入 {@code assemble} 问产出——shaped/shapeless/熔炼/切石都无视输入;
 * 产出的 null 与异常一律折成 EMPTY,坏一条丢一条——一条坏配方杀掉整个遍历才是事故。
 */
public final class RecipeProbe {

    private RecipeProbe() {}

    /** 枚举合成配方的产出——空输入 assemble(shaped/shapeless 不看输入)。 */
    public static class_1799 resultOf(class_3955 recipe, class_7225.class_7874 registries) {
        return probe(() -> recipe.method_8116(class_9694.field_51631, registries));
    }

    /** 枚举单输入配方(熔炼/切石)的产出——空输入 assemble(它们同样不看输入)。 */
    public static class_1799 resultOf(class_1860<class_9696> recipe, class_7225.class_7874 registries) {
        return probe(() -> recipe.method_8116(new class_9696(class_1799.field_8037), registries));
    }

    /** 探一次产出:null 与异常一律折成 EMPTY,调用方只看 {@code isEmpty()}。 */
    public static class_1799 probe(Supplier<class_1799> supplier) {
        try {
            class_1799 result = supplier.get();
            return result == null ? class_1799.field_8037 : result;
        } catch (RuntimeException broken) {
            return class_1799.field_8037;
        }
    }

    /**
     * 这条配方的输入表能不能安全交给下游:{@code placementInfo} 本身、它的清单与
     * 每个 ingredient 的 {@code items()} 都不为 null。craft 的摆料、盘点、缺料描述
     * 都在这道门之后,过了门就不必层层判空。
     */
    public static boolean usableIngredients(class_1860<?> recipe) {
        try {
            class_9887 info = recipe.method_61671();
            List<class_1856> ings = info == null ? null : info.method_64675();
            if (ings == null) {
                return false;
            }
            for (class_1856 ing : ings) {
                if (ing == null || ing.method_8105() == null) {
                    return false;
                }
            }
            return true;
        } catch (RuntimeException broken) {
            return false;
        }
    }
}
