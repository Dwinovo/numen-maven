package com.dwinovo.numen.core.task.move;
import com.dwinovo.numen.core.pathing.settings.ScaffoldMaterials;
import com.dwinovo.numen.core.FailureType;

import com.dwinovo.numen.task.TaskState;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.core.pathing.calc.NavGoal;
import com.dwinovo.numen.core.pathing.execute.PlayerNav;
import com.dwinovo.numen.core.task.base.AbstractCompanionTask;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2338;

/**
 * {@code goto} on the companion player body — a coordinate walk whose goal
 * type is chosen by which coordinates were supplied
 * ({@link MoveToTaskRecord.Kind}):
 * <ul>
 *   <li>{@link MoveToTaskRecord.Kind#COLUMN} → {@link NavGoal#column}:
 *       reach the (x,z) location at any height — the default "go there", a wrong/
 *       absent Y can never make it unreachable;</li>
 *   <li>{@link MoveToTaskRecord.Kind#BLOCK} → {@link NavGoal#exact}: occupy exactly
 *       that cell; whatever occupies it has to be dug out, which only a goto with
 *       may_alter_terrain may do (the block form is how the caller says "walk up
 *       beside it instead");</li>
 *   <li>{@link MoveToTaskRecord.Kind#YLEVEL} → {@link NavGoal#yLevel}:
 *       reach a target elevation.</li>
 * </ul>
 * The planner is untouched; only the goal/arrival/result semantics differ per kind.
 * Results always echo the ACTUAL position reached (and the real ground height) so
 * the model learns the terrain and which intent to use next time.
 *
 * <p>Nav-only reactive task: it drives {@link PlayerNav} with a custom settle loop
 * (no "act" step), so it grows on {@link AbstractCompanionTask} directly rather than
 * {@code GoToThenDoTask}.
 */
public final class MoveToCompanionTask extends AbstractCompanionTask<MoveToTaskRecord> {

    private static final long TICKS_PER_BLOCK = 20;
    private static final long MAX_EXTRA_TICKS = 5 * 60 * 20;
    /** Progress lease: while the journey is consuming its plan, the deadline is kept
     *  this far ahead — a healthy multi-minute dig route never times out mid-stride,
     *  and a stalled one still returns the body within one lease. */
    private static final long PROGRESS_LEASE_TICKS = 30 * 20;
    /** How recent "progress" must be to renew the lease. Generous enough to span one
     *  slow legitimate move (a long bare-hand dig holds the executor's progress clock
     *  at 0 anyway; this covers place maneuvers and replan gaps). */
    private static final int PROGRESS_GRACE_TICKS = 100;
    /** Hard check-in cap: even a healthy marathon yields (with a resumable result) after
     *  this long, bounding how long the LLM goes without control. Renewals never push
     *  the deadline past start + this. */
    private static final long CHECK_IN_CAP_TICKS = 5 * 60 * 20;
    /** When the planner CAN'T reach the exact goal, a stop within this of the
     *  requested column still counts as "got there" (a teaching success, not a
     *  thrash). This is the only tolerance — arrival itself is exact. */
    private static final double WALK_SPEED = 1.0;
    private static final double NEAR_SUCCESS_RADIUS = 3.0;
    /** Once the planner can't get closer (e.g. it stopped at the water surface above an
     *  underwater goal), keep the task alive this many ticks of NO progress before giving
     *  up — long enough for the body to passively drift onto a reachable underwater target,
     *  short enough to bail under an out-of-reach above-water one. */
    private static final int MAX_SETTLE_TICKS = 60;

    private final int bx;
    private final int by;
    private final int bz;
    private final class_2338 blockTarget;   // only meaningful for BLOCK kind

    private double bestDist = Double.MAX_VALUE;   // closest we've gotten to the goal
    private int settleTicks = 0;                  // ticks of no progress after the planner gave up
    /** The one near-retry recovery rung has been consumed (ladder state — survives suspend). */
    private boolean nearRetried;
    /** Absolute ceiling for lease renewals (start + {@link #CHECK_IN_CAP_TICKS}); 0 = unset. */
    private long leaseCapGameTime;

    /** FIND(就近方块)子系统:扫描/入册/契约/轮换全在组件里,此处只驱动。 */
    private NearestBlockFinder finder;

    /** 船腿:开工时坐在船上就先驾船,靠岸(或搁浅)后接步行。null = 没有/已交棒。 */
    private com.dwinovo.numen.core.pathing.execute.BoatNav boatLeg;

    public MoveToCompanionTask(NumenPlayer player, MoveToTaskRecord record) {
        super(player, record);
        this.bx = record.x != null ? (int) Math.floor(record.x) : 0;
        this.by = record.y != null ? (int) Math.floor(record.y) : 0;
        this.bz = record.z != null ? (int) Math.floor(record.z) : 0;
        this.blockTarget = new class_2338(bx, by, bz);
    }

    @Override
    protected void onStart() {
        // 载具处置:坐在船上且有明确去处,先驾船——船腿走到离目标最近的水格,
        // 靠岸后接步行(见 tickBoatLeg)。其余情况(矿车没有舵、马的寻路仍按步行
        // 物理算、FIND 要先扫描)直接走步行段;下座驾是步行导航自己的事(PlayerNav)。
        if (player.method_5765()
                && player.method_5854() instanceof net.minecraft.class_10255
                && (r.kind == MoveToTaskRecord.Kind.BLOCK || r.kind == MoveToTaskRecord.Kind.COLUMN)
                && !reached()) {
            boatLeg = new com.dwinovo.numen.core.pathing.execute.BoatNav(player, blockTarget);
            long extra = Math.min(MAX_EXTRA_TICKS,
                    600 + (long) (repDistance() * TICKS_PER_BLOCK));
            r.extendDeadlineTo(player.method_51469().method_8510() + extra);
            leaseCapGameTime = player.method_51469().method_8510() + CHECK_IN_CAP_TICKS;
            com.dwinovo.numen.core.Constants.LOG.info(
                    "[numen-task] goto start kind={} target={},{},{} 驾船先行",
                    r.kind, bx, by, bz);
            return;
        }
        if (r.kind == MoveToTaskRecord.Kind.FIND) {
            // 就近方块:解析 id → 离线扫描附近候选;导航等首批候选到手再建
            var id = net.minecraft.class_2960.method_12829(r.block);
            var b = id == null ? null : net.minecraft.class_7923.field_41175.method_63535(id);
            if (b == null || b == net.minecraft.class_2246.field_10124) {
                fail("unknown block id '" + r.block
                        + "' — use a namespaced block id like minecraft:crafting_table",
                        FailureType.NO_PATH);
                return;
            }
            finder = new NearestBlockFinder(player, b);
            long findExtra = Math.min(MAX_EXTRA_TICKS,
                    600 + (long) NearestBlockFinder.BUDGET_BLOCKS * TICKS_PER_BLOCK);
            r.extendDeadlineTo(player.method_51469().method_8510() + findExtra);
            leaseCapGameTime = player.method_51469().method_8510() + CHECK_IN_CAP_TICKS;
            finder.kickScan();
            com.dwinovo.numen.core.Constants.LOG.info(
                    "[numen-task] goto start kind=FIND block={}", r.block);
            return;
        }
        // Already there: don't build a nav (and don't extend the deadline). The first
        // onTick observes reached() and returns SUCCESS — same outcome as the old
        // start-time short-circuit, one tick later per the base's lifecycle.
        if (reached()) return;
        startWalkingNav();
    }

    /** 这次 goto 的地形许可:模型点头了才开路,否则只走不改。四处建导航都从这儿取。 */
    private PlayerNav.ContextProvider terrain() {
        return r.mayAlterTerrain ? PlayerNav.ContextProvider.TERRAFORM : PlayerNav.ContextProvider.DEFAULT;
    }

    /**
     * 步行段的启动:预算、租约、建导航。开工时走它,船腿靠岸后接力也走它——
     * 两个入口一份逻辑。
     */
    private void startWalkingNav() {
        // Initial budget from straight-line distance (terrain difficulty is unknowable
        // here — the progress lease below takes over once the journey is under way).
        long extra = Math.min(MAX_EXTRA_TICKS, 600 + (long) (repDistance() * TICKS_PER_BLOCK));
        r.extendDeadlineTo(player.method_51469().method_8510() + extra);
        leaseCapGameTime = player.method_51469().method_8510() + CHECK_IN_CAP_TICKS;
        // BLOCK targets go through the compiled front door so the target cell is
        // SACRED when solid — the route may neither dig through nor bury the very
        // block it was asked to reach. COLUMN/YLEVEL have no block objective.
        nav = (r.kind == MoveToTaskRecord.Kind.BLOCK
                ? PlayerNav.to(player, this::blockCompiled, WALK_SPEED, this::reached, terrain())
                : PlayerNav.toGoal(player, this::goal, WALK_SPEED, this::reached, terrain()))
                .withTerrainProbe();
        com.dwinovo.numen.core.Constants.LOG.info(
                "[numen-task] goto start kind={} target={},{},{} solid={}",
                r.kind, bx, by, bz,
                r.kind == MoveToTaskRecord.Kind.BLOCK && targetCellSolid());
        // Highlight the ACTUAL requested cell (not the path's best-effort end) so the overlay
        // box sits on the real target — e.g. a BLOCK goal under/over water that the path can
    }

    /** The navigation goal for this move's kind. */
    private NavGoal goal() {
        return switch (r.kind) {
            case BLOCK -> blockGoal();
            case COLUMN -> NavGoal.column(bx, bz);
            case YLEVEL -> NavGoal.yLevel(by);
            case FIND -> finder.contract() == null ? null : finder.contract().goal();
        };
    }

    /**
     * BLOCK auto-typing: an enterable target cell means "stand exactly there"
     * ({@link NavGoal#exact}); a cell occupied by a solid means "get to that
     * block" ({@link NavGoal#getToBlock} — beside/on top counts, the block stays
     * untouched). Re-evaluated per replan, so a cell that opens up mid-journey
     * (the occupant broke) tightens back to exact.
     */
    private NavGoal blockGoal() {
        return blockCompiled().goal();
    }

    /** The BLOCK kind's navigation contract: bare coordinates mean occupy
     *  exactly that cell, digging out whatever is there (the block form is
     *  the way to say "walk up beside it instead"). */
    private com.dwinovo.numen.core.pathing.goal.GoalCompiler.Compiled blockCompiled() {
        return com.dwinovo.numen.core.pathing.goal.GoalCompiler.standOn(blockTarget);
    }

    /** Does a collision shape occupy the target cell (feet can't go there)? */
    private boolean targetCellSolid() {
        return !player.method_51469().method_8320(blockTarget)
                .method_26220(player.method_51469(), blockTarget).method_1110();
    }

    /** Slab-aware feet cell — the pathing node, not raw blockPosition (standing on a
     *  bottom slab counts as the cell above it, like the planner sees it). */
    private class_2338 feet() {
        return com.dwinovo.numen.core.pathing.util.BlockHelper.playerFeet(
                player.method_51469(), player.method_23317(), player.method_23318(), player.method_23321());
    }

    /**
     * Live arrival — DOUBLE membership: the feet cell AND the supported
     * fake-start cell must both satisfy the goal. The second gate is what keeps
     * transient cell-entry from counting as arrival: a pillar's final jump puts
     * the feet in the goal cell at the APEX a tick before its support block is
     * placed, and a bridge's final backplace hovers the feet into the goal cell
     * while sneak-clinging to the previous block's edge — in both states the
     * body has no support under the goal cell yet, pathStart resolves to the
     * neighbouring supported cell, and arrival is (correctly) withheld until
     * the block is actually placed and stood on. Declaring success on the
     * feet-only test stopped the nav mid-move: the place never fired and the
     * halt released the sneak that was holding the body on the edge — the
     * "one block short, one step too far" fall.
     */
    private boolean reached() {
        return inGoalCell(feet())
                && inGoalCell(com.dwinovo.numen.core.pathing.moves.Movement.pathStart(player));
    }

    /** ONE membership definition per kind, shared with the search:
     *  BLOCK (cell == target per arrival mode), COLUMN (x/z match),
     *  YLEVEL (y match + on the ground). */
    private boolean inGoalCell(class_2338 cell) {
        return switch (r.kind) {
            case BLOCK -> blockGoal().isAt(cell);
            case COLUMN -> cell.method_10263() == bx && cell.method_10260() == bz;
            case YLEVEL -> cell.method_10264() == by && player.method_24828();
            case FIND -> finder.contract() != null && finder.contract().goal().isAt(cell);
        };
    }

    @Override
    protected TaskState onTick() {
        // reached() is checked BEFORE the nav==null guard so an already-at-target start
        // (which never builds a nav) lands on SUCCESS rather than the defensive FAILED.
        if (reached()) return TaskState.SUCCESS;
        if (boatLeg != null) {
            return tickBoatLeg();
        }
        if (r.kind == MoveToTaskRecord.Kind.FIND && nav == null) {
            TaskState pre = tickFindDiscovery();
            if (pre != null) {
                return pre;
            }
        }
        if (nav == null) {
            fail(blockedMessage("no path"), FailureType.NO_PATH);
            return TaskState.FAILED;
        }
        // Progress lease: while the nav is consuming its plan (steps advancing / digging),
        // keep the deadline PROGRESS_LEASE ahead — never past the check-in cap. Plan
        // consumption, NOT goal distance, is the liveness signal: healthy routes routinely
        // move away from the goal (skirting a lake, spiraling down), and the flat budget
        // above can't price terrain (a dig-heavy route once died 1 block short).
        if (nav.stallTicks() <= PROGRESS_GRACE_TICKS && leaseCapGameTime > 0) {
            long now = player.method_51469().method_8510();
            r.extendDeadlineTo(Math.min(now + PROGRESS_LEASE_TICKS, leaseCapGameTime));
        }
        // Track passive progress toward the goal: the planner stops at the water surface
        // above an underwater target, but the body keeps drifting toward it on its own (it
        // sinks). Reset the settle timer whenever we get closer.
        double d = repDistance();
        if (d < bestDist - 0.1) {
            bestDist = d;
            settleTicks = 0;
        } else {
            settleTicks++;
        }
        return switch (nav.tick()) {
            case RUNNING -> TaskState.RUNNING;
            case ARRIVED -> TaskState.SUCCESS;
            case FAILED -> {
                // FIND:打不通就近候选 -> 除名,朝余下候选重开导航
                if (r.kind == MoveToTaskRecord.Kind.FIND && finder.rotateAfterFailure()) {
                    stopNav();
                    nav = PlayerNav.to(player, finder::contract, WALK_SPEED, this::reached, terrain())
                            .withTerrainProbe();
                    yield TaskState.RUNNING;
                }
                // The planner can't get closer. In water, keep waiting while the body is
                // still drifting toward the goal (sinking onto an underwater target); give
                // up only once it's stopped making progress (bobbing at the surface below an
                // out-of-reach above-water target). So the body settles onto an underwater
                // goal but bails under an unreachable air one. On land a failure is final.
                if (player.method_5799() && settleTicks < MAX_SETTLE_TICKS) {
                    yield TaskState.RUNNING;
                }
                // Otherwise: as close as the terrain allows → (teaching) success or fail.
                if (closeEnoughToSucceed()) yield TaskState.SUCCESS;
                // Recovery ladder — ONE retry rung, land nav only: re-plan accepting
                // anywhere within NEAR_SUCCESS_RADIUS of the destination. Goal-consistent,
                // not scope creep: a stop within that radius already counts as arrival
                // (closeEnoughToSucceed above), the retry just lets the SEARCH aim for it.
                // YLEVEL has no looser near-equivalent (its goal is already any-x/z), and
                // the water-settle path above is untouched.
                if (!nearRetried && !player.method_5799()
                        && r.kind != MoveToTaskRecord.Kind.YLEVEL
                        && r.kind != MoveToTaskRecord.Kind.FIND) {
                    nearRetried = true;
                    stopNav();
                    NavGoal retry = nearRetryGoal();
                    nav = PlayerNav.toGoal(player, () -> retry, WALK_SPEED, this::closeEnoughToSucceed,
                            terrain()).withTerrainProbe();
                    yield TaskState.RUNNING;
                }
                String also = nearRetried
                        ? " (also retried accepting anywhere within "
                                + (int) NEAR_SUCCESS_RADIUS + " blocks — no path either)"
                        : "";
                fail(blockedMessage(nav.failReason() + also), nav.failType());
                yield TaskState.FAILED;
            }
        };
    }

    /**
     * 船腿的一刻:驾船朝目标推进,终态(靠岸或搁浅)都走同一条接力——到不了目标的
     * 水路不算失败,只是"这条腿到此为止",剩下的路归步行段(步行导航起步自会下船)。
     * 目标就在水上时她留在船里,不往水里跳。船留在原地,那是她的船,不是垃圾。
     */
    private TaskState tickBoatLeg() {
        // 船腿的续约与步行段同一制式:还在消耗航线就把期限保持在租约窗口里
        if (boatLeg.progressing() && leaseCapGameTime > 0) {
            long now = player.method_51469().method_8510();
            r.extendDeadlineTo(Math.min(now + PROGRESS_LEASE_TICKS, leaseCapGameTime));
        }
        var status = boatLeg.tick();
        if (status == com.dwinovo.numen.core.pathing.execute.BoatNav.Status.RUNNING) {
            return TaskState.RUNNING;
        }
        String how = status == com.dwinovo.numen.core.pathing.execute.BoatNav.Status.ARRIVED
                ? "靠岸" : boatLeg.failReason();
        boatLeg.stop();
        boatLeg = null;
        if (reached()) {
            com.dwinovo.numen.core.Constants.LOG.info(
                    "[numen-task] 船腿结束({}),目标已在船下 feet={}", how,
                    player.method_24515().method_23854());
            return TaskState.SUCCESS;
        }
        com.dwinovo.numen.core.Constants.LOG.info(
                "[numen-task] 船腿结束({}),接步行 feet={}", how,
                player.method_24515().method_23854());
        startWalkingNav();
        return TaskState.RUNNING;
    }

    /** The retry rung's loosened goal — the destination widened to the SAME radius that
     *  already counts as arrival ({@link #NEAR_SUCCESS_RADIUS}), never wider. */
    private NavGoal nearRetryGoal() {
        if (r.kind == MoveToTaskRecord.Kind.BLOCK) {
            return NavGoal.near(blockTarget, NEAR_SUCCESS_RADIUS);
        }
        // COLUMN: within the radius HORIZONTALLY at any height (NavGoal.near is 3D and
        // needs a Y this kind doesn't have; heuristic/center reuse the column's own).
        NavGoal column = NavGoal.column(bx, bz);
        double radiusSqr = NEAR_SUCCESS_RADIUS * NEAR_SUCCESS_RADIUS;
        return new NavGoal() {
            @Override public boolean isAt(class_2338 feet) {
                double dx = feet.method_10263() - bx;
                double dz = feet.method_10260() - bz;
                return dx * dx + dz * dz <= radiusSqr;
            }
            @Override public double heuristic(class_2338 from) {
                return column.heuristic(from);
            }
            @Override public class_2338 center() {
                return column.center();
            }
        };
    }

    /** Did we get close enough to the destination to call it done (teaching success)?
     *  Requires solid footing (or water — the settle path): as a live arrival
     *  predicate on the near-retry nav this must not fire during a mid-air jump
     *  or a sneak-hover over the edge, for the same reason as {@link #reached}. */
    private boolean closeEnoughToSucceed() {
        if (!player.method_24828() && !player.method_5799()) {
            return false;
        }
        return switch (r.kind) {
            case BLOCK, COLUMN -> horizontalDistSqr(bx, bz) <= NEAR_SUCCESS_RADIUS * NEAR_SUCCESS_RADIUS;
            case YLEVEL -> Math.abs(feet().method_10264() - by) <= 1;
            // FIND 候选众多,失败梯已在候选间轮换过,不设贴近成功档
            case FIND -> false;
        };
    }

    private double horizontalDistSqr(int cellX, int cellZ) {
        double dx = (cellX + 0.5) - player.method_23317();
        double dz = (cellZ + 0.5) - player.method_23321();
        return dx * dx + dz * dz;
    }

    /** Representative remaining distance (blocks) for the deadline estimate. */
    private double repDistance() {
        return switch (r.kind) {
            case BLOCK -> Math.sqrt(player.method_5649(bx + 0.5, by, bz + 0.5));
            case COLUMN -> Math.sqrt(horizontalDistSqr(bx, bz));
            case YLEVEL -> Math.abs(player.method_23318() - by);
            case FIND -> {
                class_2338 n = finder.nearest();
                yield n == null ? NearestBlockFinder.BUDGET_BLOCKS
                        : Math.sqrt(player.method_5649(n.method_10263() + 0.5, n.method_10264() + 0.5, n.method_10260() + 0.5));
            }
        };
    }

    // ==================== FIND(就近方块)驱动 ====================

    /**
     * 候选发现期(导航尚未建立)推进一步:收割扫描 -> 有候选即建导航
     * (返回 null 表示落入正常驱动),扫完仍无候选 -> 失败,否则继续等。
     */
    private TaskState tickFindDiscovery() {
        finder.drain();
        if (finder.hasCandidates()) {
            nav = PlayerNav.to(player, finder::contract, WALK_SPEED, this::reached, terrain())
                    .withTerrainProbe();
            return null;
        }
        if (finder.exhausted()) {
            fail("no " + r.block + " found in the loaded area around me — explore"
                    + " closer to one, or give exact coordinates (scan_blocks/locate can find some).",
                    FailureType.NO_PATH);
            return TaskState.FAILED;
        }
        return TaskState.RUNNING;
    }

    @Override
    protected Map<String, Object> resultData() {
        int gy = player.method_24515().method_10264();
        Map<String, Object> data = new HashMap<>();
        data.put("final_x", player.method_23317());
        data.put("final_y", player.method_23318());
        data.put("final_z", player.method_23321());
        data.put("ground_y", gy);
        return data;
    }

    /** Success copy — always names the real position so the model learns the terrain. */
    @Override
    protected String successMessage() {
        int gy = player.method_24515().method_10264();
        return switch (r.kind) {
            case BLOCK -> {
                if (feet().equals(blockTarget)) {
                    yield "reached the exact cell " + bx + "," + by + "," + bz + ".";
                }
                // Got to the column but not the exact y (the usual "guessed Y was in
                // the air" case) — teach the model to drop Y for a location.
                int dy = by - gy;
                yield "arrived at location x=" + bx + " z=" + bz + ", standing on the ground at y=" + gy
                        + ". The exact cell y=" + by + " wasn't reachable (" + Math.abs(dy) + " blocks "
                        + (dy > 0 ? "up — likely mid-air" : "down — likely blocked")
                        + "); for a location, omit y and I resolve the surface.";
            }
            case COLUMN -> "arrived at location x=" + bx + " z=" + bz
                    + ", standing on the ground at y=" + gy + ".";
            case YLEVEL -> "reached elevation y=" + gy
                    + (gy == by ? "." : " (requested y=" + by + ").");
            case FIND -> {
                class_2338 n = finder.nearest();
                yield n == null
                        ? "arrived beside the target block."
                        : "arrived beside " + r.block + " at " + n.method_10263() + "," + n.method_10264()
                                + "," + n.method_10260() + " — within reach to use.";
            }
        };
    }

    @Override
    protected String timeoutMessage() {
        int gy = player.method_24515().method_10264();
        double remaining = repDistance();
        // Two different stories for the model: a stall (progress dried up — something is
        // wrong, reconsider) vs a check-in (journey healthy but longer than the cap —
        // resuming is the right move).
        boolean stalled = nav == null || nav.stallTicks() > PROGRESS_GRACE_TICKS;
        return "timed out " + String.format("%.1f", remaining) + " blocks from target (now at "
                + bx(gy) + "); "
                + (stalled
                        ? "progress had stopped — likely blocked; call goto again to retry, or"
                                + " try a nearer waypoint / scan_blocks for a way through."
                        : "the journey was still progressing and simply exceeded its check-in budget;"
                                + " call goto again with the same target to resume.");
    }

    @Override
    protected String cancelledMessage() {
        return "cancelled before reaching target";
    }

    private String bx(int gy) {
        return String.format("%.0f,%d,%.0f", player.method_23317(), gy, player.method_23321());
    }

    /** Release the nav (base) and drop a FIND lookup that is still walking rings for a
     *  destination nobody is going to any more. */
    @Override
    protected void cleanup() {
        super.cleanup();
        if (finder != null) {
            finder.cancelScan();
        }
        if (boatLeg != null) {
            boatLeg.stop();   // 中途被取消/让位:收桨,别让船带着按下的前进键漂走
            boatLeg = null;
        }
    }

    /** The give-up message for a planner failure that wasn't close enough to count as arrival.
     *  Captured at the fail site (nav still alive) so its {@code failReason} is readable before
     *  the base's {@code cleanup()} releases the nav. */
    private String blockedMessage(String failReason) {
        int gy = player.method_24515().method_10264();
        double remaining = repDistance();
        String where = switch (r.kind) {
            case BLOCK, COLUMN -> "location x=" + bx + " z=" + bz;
            case YLEVEL -> "elevation y=" + by;
            case FIND -> "the nearest " + r.block;
        };
        // 地形封路的验尸自带下一步(清单 + 重发提示),不再叠几何建议;其余无路才是
        // 几何问题:换近一点的路点或扫描。除非她只是没有垫路的料——读起来同样是死路,
        // 其实不是。
        String advice = "";
        if (nav.failType() != FailureType.TERRAIN_BLOCKED) {
            advice = ScaffoldMaterials.shortageAdvice(player);
            if (advice == null) {
                advice = " Try a nearer waypoint or scan_blocks for a way through.";
            }
        }
        return "blocked: got within " + String.format("%.1f", remaining) + " blocks of " + where
                + " (now on the ground at y=" + gy + "). " + failReason + "." + advice;
    }
}
