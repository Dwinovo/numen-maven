package com.dwinovo.numen.core.task.interact;
import com.dwinovo.numen.core.task.MouseButton;
import com.dwinovo.numen.core.PlayerInv;

import com.dwinovo.numen.task.TaskState;
import com.dwinovo.numen.entity.InputDriver;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.core.pathing.calc.NavGoal;
import com.dwinovo.numen.core.FailureType;
import com.dwinovo.numen.core.act.Interaction;
import com.dwinovo.numen.core.act.PressReceipt;
import com.dwinovo.numen.core.pathing.execute.PlayerNav;
import com.dwinovo.numen.core.task.base.GoToThenDoTask;
import com.dwinovo.numen.core.task.base.Precondition;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_7923;

/**
 * {@code interact_at} on the player body — the point-aimed native interaction (BLOCK + AIR).
 * Walk within reach of the aim (if one is given), look at it, fire ONE native crosshair
 * raytrace ({@link Interaction#nativeRaytrace}) and press the requested mouse button on
 * whatever it resolves to ({@link Interaction#forHit}): break / activate the block hit, or —
 * on a clear-air aim — use the held item in that direction (throw / eat / draw). The mouse
 * model is the two record fields {@code button} (left/right) × {@code holdTicks} (tap/hold).
 */
public final class InteractAtCompanionTask extends GoToThenDoTask<InteractAtTaskRecord> {

    private static final double REACH = 4.5;
    private static final double REACH_SQR = REACH * REACH;
    private static final double WALK_SPEED = 1.0;
    /** Reposition-rung stance radius: any feet cell this close to the aim (< {@link #REACH},
     *  so an accepted stance is still within interact reach). Never wider than the goal. */

    private Interaction interaction;
    /** 按键前的世界快照,收尾时对账出"真发生了什么"(见 {@link PressReceipt})。 */
    private PressReceipt receipt;
    private java.util.List<String> changes = List.of();
    // ---- bounded recovery state (fields, so a Suspendable mid-rung suspend/resume
    //      picks straight back up: the counter and the rebuilt nav both survive) ----
    /** The FIRST nav failure's reason, preserved so the final give-up keeps the original wording. */
    private long holdUntil = -1;       // game tick to release a fixed-duration hold (holdTicks > 0)
    private String successMsg = "done";
    // A right-click that activated a real block (a station's GUI): captured so the
    // result can report it and the agent loop can remember it in <known_blocks>.
    private net.minecraft.class_2338 activatedBlock;
    private String activatedBlockId;

    public InteractAtCompanionTask(NumenPlayer player, InteractAtTaskRecord record) {
        super(player, record);
    }

    @Override
    protected List<Precondition> preconditions() {
        // If an item to use was named, fail fast unless we actually carry it.
        return List.of(() -> r.item == null || PlayerInv.count(player.method_31548(), r.item) > 0 ? null
                : new Precondition.Failure(
                        "don't have " + class_7923.field_41178.method_10221(r.item).method_12832() + " to use",
                        FailureType.NO_MATERIAL));
    }

    @Override
    protected PlayerNav buildNav() {
        // 本任务不自带到场导航:身体须已在触及距离内(基座在 reached()==false
        // 且无导航时直接教学失败,旅行归 goto)。
        return null;
    }

    @Override
    protected net.minecraft.class_2338 gotoFirstTarget() {
        return r.aim;
    }

    @Override
    protected boolean reached() {
        return r.aim == null || withinReach();
    }

    @Override
    protected TaskState act() {
        // Resolve the crosshair once we're in position, then drive the action.
        if (interaction == null) {
            if (r.item != null) {
                player.holdInHand(PlayerInv.findSlot(player.method_31548(), r.item));
            }
            if (r.aim != null) {
                InputDriver.lookAt(player, class_243.method_24953(r.aim));
            }
            class_239 hit = Interaction.nativeRaytrace(player, REACH);
            // 目标格本身是实心方块、而准星实际落在别的方块上 = 被遮挡:
            // 拒绝并点名遮挡物(点下去只会交互到错误对象还谎报成功)。
            // 目标格是空气或流体的瞄点保持准星穿透语义——流体本来就不该被准星
            // 点中,对水面右键的原版含义正是"射线穿过去,物品自己找水"(桶、船)。
            if (r.aim != null
                    && !player.method_51469().method_8320(r.aim).method_26215()
                    && !(player.method_51469().method_8320(r.aim).method_26204()
                            instanceof net.minecraft.class_2404)
                    && hit instanceof net.minecraft.class_3965 blockedHit
                    && !blockedHit.method_17777().equals(r.aim)) {
                var blocker = blockedHit.method_17777();
                String blockerId = class_7923.field_41175
                        .method_10221(player.method_51469().method_8320(blocker).method_26204()).method_12832();
                fail("aim " + aimLabel() + " is blocked from here — the crosshair lands on "
                        + blockerId + " at " + blocker.method_10263() + "," + blocker.method_10264() + ","
                        + blocker.method_10260() + " instead. break_block that blocker, or goto the"
                        + " target's open side, then retry.", FailureType.OCCLUDED);
                return TaskState.FAILED;
            }
            // A consumable / ender pearl used in the AIR is body-bound (would feed or teleport the
            // fake player) — refuse even when it's just whatever happened to be in hand.
            if (button() == Interaction.Button.USE && hit.method_17783() == class_239.class_240.field_1333) {
                String reason = InteractAtTaskRecord.bodyBoundReason(player.method_6047().method_7909());
                if (reason != null) {
                    fail(reason, FailureType.UNKNOWN);
                    return TaskState.FAILED;
                }
            }
            // A right-click landing on a block activates it (opens a station's GUI,
            // flips a switch, …). Remember the block we touched so <known_blocks> can
            // walk us back to stations we've used, not just ones we placed. The harvest
            // filters to tracked station types; doors/buttons fall away there.
            if (button() == Interaction.Button.USE && hit instanceof net.minecraft.class_3965 bhr) {
                activatedBlock = bhr.method_17777();
                activatedBlockId = class_7923.field_41175
                        .method_10221(player.method_51469().method_8320(activatedBlock).method_26204()).method_12832();
            }
            // 兜底开关:身体约束物品(食物、末影珍珠)在任何一只手上都不落到物品
            // 自用——否则点一块石头没反应,同一次按键会把她自己喂了或传送走。
            boolean fallthroughOk =
                    InteractAtTaskRecord.bodyBoundReason(player.method_6047().method_7909()) == null
                    && InteractAtTaskRecord.bodyBoundReason(player.method_6079().method_7909()) == null;
            receipt = PressReceipt.before(player, r.aim);
            interaction = Interaction.forHit(player, hit, button(), r.holdTicks, fallthroughOk);
            if (interaction == null) {       // left-click on air — a swing, nothing to do
                successMsg = "nothing under the aim (left-click in the air)";
                return TaskState.SUCCESS;
            }
            if (r.holdTicks > 0) {
                holdUntil = player.method_51469().method_8510() + r.holdTicks;
            }
        }

        // A fixed-duration hold ends when its window elapses: release the button.
        if (holdUntil >= 0 && player.method_51469().method_8510() >= holdUntil) {
            interaction.stop();
            successMsg = describeDone() + settle();
            return TaskState.SUCCESS;
        }
        return switch (interaction.tick()) {
            case DONE -> {
                successMsg = describeDone() + settle();
                yield TaskState.SUCCESS;
            }
            case FAILED -> {
                fail(interaction.failReason(), FailureType.UNKNOWN);
                yield TaskState.FAILED;
            }
            case RUNNING -> TaskState.RUNNING;
        };
    }


    /** In-ladder nav causes the reposition rung handles; anything else kicks straight back to the LLM. */
    private static boolean repositionable(FailureType type) {
        return type == FailureType.NO_PATH || type == FailureType.TERRAIN_BLOCKED
                || type == FailureType.BOXED_IN
                || type == FailureType.OUT_OF_REACH || type == FailureType.STANCE_DUD;
    }

    private Interaction.Button button() {
        return r.button == MouseButton.LEFT
                ? Interaction.Button.ATTACK : Interaction.Button.USE;
    }

    private boolean withinReach() {
        return bodySettled() && player.method_5707(class_243.method_24953(r.aim)) <= REACH_SQR;
    }

    private String aimLabel() {
        return r.aim.method_10263() + "," + r.aim.method_10264() + "," + r.aim.method_10260();
    }

    private String describeDone() {
        String verb = r.button == MouseButton.LEFT ? "left-clicked" : "right-clicked";
        return verb + (r.aim != null ? " " + aimLabel() : " (forward)");
    }

    /**
     * 收尾对账:回执只报事实,不判成败。"按键被消费"不等于"发生了什么"——
     * 船可以吃掉点击却因站位碰撞一无所成,此前这里会报一句裸的成功,模型
     * 就当船已经放下了。什么都没变时明说,她自己决定挪个位置再试还是放弃。
     */
    private String settle() {
        changes = receipt == null ? List.of() : receipt.diff(player);
        if (changes.isEmpty()) {
            return " — but nothing visibly changed (hands, aimed block, nearby entities all "
                    + "as before). If you expected an effect, reposition or rethink.";
        }
        return " — " + String.join("; ", changes);
    }

    /** Release the interaction, then the nav + overlay (base default). */
    @Override
    protected void cleanup() {
        if (interaction != null) interaction.stop();
        super.cleanup();
    }

    @Override
    protected Map<String, Object> resultData() {
        Map<String, Object> data = new HashMap<>();
        data.put("button", r.button == MouseButton.LEFT ? "left" : "right");
        if (r.aim != null) {
            data.put("x", r.aim.method_10263());
            data.put("y", r.aim.method_10264());
            data.put("z", r.aim.method_10260());
        }
        // Report the activated station (and its exact position, authoritative over the
        // raw aim) so the agent loop can harvest it into <known_blocks>.
        if (activatedBlock != null) {
            data.put("block", activatedBlockId);
            data.put("x", activatedBlock.method_10263());
            data.put("y", activatedBlock.method_10264());
            data.put("z", activatedBlock.method_10260());
        }
        if (!changes.isEmpty()) {
            data.put("changes", changes);
        }
        return data;
    }

    @Override
    protected String successMessage() {
        return successMsg;
    }

    @Override
    protected String timeoutMessage() {
        return "timed out before interacting at " + (r.aim != null ? aimLabel() : "forward");
    }

    @Override
    protected String cancelledMessage() {
        return "interact_at interrupted";
    }
}
