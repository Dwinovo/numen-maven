package com.dwinovo.numen.core.pathing.moves;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_1540;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import com.dwinovo.numen.core.pathing.settings.NavSettings;

/**
 * 移动原语抽象基类:一条"从 src 到 dest"的最小可执行动作,
 * 自带成本计算(规划期)与逐 tick 状态机(执行期)。
 *
 * <p>执行侧通用框架在 {@link #update()}:先由子类推进状态机,再叠加
 * 水中上浮强跳与卡墙自救,最后把本 tick 的按键表交给执行层钩子。
 * 准备阶段({@link #prepared}):等待落沙实体落定、把仍挡路的
 * toBreak 逐个交给 {@link #beginBreaking} 钩子挖掉。
 */
public abstract class Movement {

    protected final class_3222 player;

    protected final class_2338 src;
    protected final class_2338 dest;

    /** 本动作开跑前需要挖穿的格。 */
    protected final class_2338[] positionsToBreak;

    /** 本动作开跑前需要放上方块的格(无则 null)。 */
    protected final class_2338 positionToPlace;

    private MovementState currentState = new MovementState().setStatus(MovementStatus.PREPPING);

    /** 缓存成本;override 机制允许外部钉入更严的估价。 */
    private Double cost;

    private Set<class_2338> validPositionsCached;

    /** 仍需挖穿的格(懒算缓存,{@link #resetBlockCache()} 后按当前世界重算)。 */
    protected List<class_2338> toBreakCached;
    /** 仍需放上方块的格(懒算缓存)。 */
    protected List<class_2338> toPlaceCached;
    /** 会用身体挤进去的格(懒算缓存;仅对角移动产出非空)。 */
    protected List<class_2338> toWalkIntoCached;

    /** 成本是否是在 dest 所在 chunk 已加载时算出的(执行期涨价豁免用)。 */
    private Boolean calculatedWhileLoaded;

    protected Movement(class_3222 player, class_2338 src, class_2338 dest,
                       class_2338[] toBreak, class_2338 toPlace) {
        this.player = player;
        this.src = src;
        this.dest = dest;
        this.positionsToBreak = toBreak;
        this.positionToPlace = toPlace;
    }

    protected Movement(class_3222 player, class_2338 src, class_2338 dest, class_2338[] toBreak) {
        this(player, src, dest, toBreak, null);
    }

    // ==================== 成本 ====================

    /** 已算出的成本;未算先抛(调用方须先走 getCost(context))。 */
    public double getCost() {
        return cost;
    }

    public double getCost(CalculationContext context) {
        if (cost == null) {
            MutableMoveResult result = new MutableMoveResult();
            cost = calculateCost(context, result);
        }
        return cost;
    }

    /** 重算成本(丢弃缓存与 override)。 */
    public double recalculateCost(CalculationContext context) {
        cost = null;
        return getCost(context);
    }

    /** 外部钉入成本(取"算时成本与节点差的较严者"时用)。 */
    public void override(double cost) {
        this.cost = cost;
    }

    /**
     * 计算本动作成本;动态落点的动作把实际落点写进 result。
     * 不可行返回 {@link ActionCosts#COST_INF}。
     */
    public abstract double calculateCost(CalculationContext context, MutableMoveResult result);

    // ==================== 合法过程位 ====================

    /** 执行期允许身体出现的格集合(重定位锚)。 */
    protected abstract Set<class_2338> calculateValidPositions();

    public Set<class_2338> getValidPositions() {
        if (validPositionsCached == null) {
            validPositionsCached = calculateValidPositions();
            Objects.requireNonNull(validPositionsCached);
        }
        return validPositionsCached;
    }

    /**
     * 当前身位是否属于本动作的合法过程位集合。脚下不在集合里时,
     * 再按 {@link #pathStart(ServerPlayer)} 算一个假起点(脚下不可站时
     * 取 3×3 邻格/下一格的支撑点)——重算/回退后,整体路径起点不一定
     * 属于本移动自身的 {src,dest} 集合,假起点兜住这种情形。
     */
    /**
     * 脚位约定:实体坐标 y 加 0.1251(灵魂沙/农田顶面矮一截仍归上格),
     * 落在台阶格里再上抬一格。执行器重定位、validPositions 与本类状态
     * 机的到达/失败判定**全部**用这一把尺,避免半砖/灵魂沙顶面错位一格
     * 导致 SUCCESS 推进与回退扫循环。
     */
    public static class_2338 feet(class_3222 player) {
        class_2338 f = class_2338.method_49637(
                player.method_19538().field_1352, player.method_19538().field_1351 + 0.1251, player.method_19538().field_1350);
        class_2680 at = player.method_51469().method_8320(f);
        // 楼梯与半砖同理:踩在矮的那半格上时,实体 y 只比格底高半格,加完偏移
        // 仍落在该格自身里,而寻路模型认定人站在它<b>上面</b>那一格。两把尺不
        // 一致,执行器就会认为"人不在本动作的合法位上",前后重定位都对不上,
        // 动作硬撑到超时——而这栋房子越往高层楼梯越密,正好卡在爬升的关口。
        if (at.method_26204() instanceof class_2482 || at.method_26204() instanceof class_2510) {
            return f.method_10084();
        }
        return f;
    }

    protected boolean playerInValidPosition() {
        class_2338 feet = feet(player);
        if (getValidPositions().contains(feet)) {
            return true;
        }
        class_2338 fakeStart = pathStart(player);
        return getValidPositions().contains(fakeStart);
    }

    /**
     * 脚下不可站时的假起点:在地面 → 3×3 邻格按水平距离取最近四个,
     * 第一个下可站、本格与上格可穿的格;空中 → 再下一格可站则用脚下格。
     * 其余情况用脚位。与 PathingCore.pathStart 同一语义,提取为基类静态
     * 助手供 Movement 子类(如 Downward 的 UNREACHABLE 判定)复用。
     */
    public static class_2338 pathStart(class_3222 player) {
        class_2338 feet = feet(player);
        var level = player.method_51469();
        if (MovementHelper.canWalkOn(level, feet.method_10074())) {
            return feet;
        }
        if (player.method_24828()) {
            double playerX = player.method_19538().field_1352;
            double playerZ = player.method_19538().field_1350;
            java.util.List<class_2338> closest = new java.util.ArrayList<>();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    closest.add(new class_2338(feet.method_10263() + dx, feet.method_10264(), feet.method_10260() + dz));
                }
            }
            closest.sort(java.util.Comparator.comparingDouble(pos ->
                    ((pos.method_10263() + 0.5) - playerX) * ((pos.method_10263() + 0.5) - playerX)
                    + ((pos.method_10260() + 0.5) - playerZ) * ((pos.method_10260() + 0.5) - playerZ)));
            for (int i = 0; i < 4; i++) {
                class_2338 possibleSupport = closest.get(i);
                double xDist = Math.abs((possibleSupport.method_10263() + 0.5) - playerX);
                double zDist = Math.abs((possibleSupport.method_10260() + 0.5) - playerZ);
                if (xDist > 0.8 && zDist > 0.8) {
                    continue;
                }
                if (MovementHelper.canWalkOn(level, possibleSupport.method_10074())
                        && MovementHelper.canWalkThrough(level, possibleSupport)
                        && MovementHelper.canWalkThrough(level, possibleSupport.method_10084())) {
                    return possibleSupport;
                }
            }
        } else {
            if (MovementHelper.canWalkOn(level, feet.method_10074().method_10074())) {
                return feet.method_10074();
            }
        }
        return feet;
    }

    // ==================== 执行状态机 ====================

    /**
     * 每 tick 推进一次。通用框架:强制关闭飞行能力(走地面物理)→
     * 子类状态机 → 水中且低于目标高度时强按跳(上浮)→ 卡墙时先换上
     * 对该方块最优工具再按左键 → 视角与按键交执行层钩子,按键先清
     * 后设、终态清空。
     */
    public MovementStatus update() {
        // 强制关闭飞行能力:寻路执行期走地面物理(跳跃/下落),不被外部
        // 置真的飞行状态干扰
        player.method_31549().field_7479 = false;
        currentState = updateState(currentState);
        class_2338 feet = feet(player);
        if (MovementHelper.isLiquid(player.method_51469().method_8320(feet))
                && player.method_23318() < dest.method_10264() + 0.6) {
            currentState.setInput(Input.JUMP, true);
        }
        if (player.method_5757()) {
            // 卡墙自救:先换上对当前准星命中方块最优的工具再按左键,
            // 破墙速度不拖
            class_2680 hitState = crosshairBlockState();
            if (hitState != null && player instanceof com.dwinovo.numen.entity.NumenPlayer np) {
                com.dwinovo.numen.core.act.ToolSelect.holdBestTool(np, hitState);
            }
            currentState.setInput(Input.CLICK_LEFT, true);
        }

        if (currentState.getTarget().hasRotation()) {
            applyRotation(currentState.getTarget());
        }
        clearInputs();
        currentState.getInputStates().forEach(this::applyInput);
        currentState.getInputStates().clear();

        if (currentState.getStatus().isComplete()) {
            clearInputs();
        }
        return currentState.getStatus();
    }

    /** 玩家准星当前命中的方块状态;未命中返回 null。 */
    private class_2680 crosshairBlockState() {
        double reach = NavSettings.get().blockReachDistance;
        class_239 hit = player.method_5745(reach, 1.0f, false);
        if (hit.method_17783() == class_239.class_240.field_1332) {
            return player.method_51469().method_8320(((class_3965) hit).method_17777());
        }
        return null;
    }

    /**
     * 准备阶段:toBreak 里任一格上有下坠方块实体(且开了等待开关)
     * → 等待,不挖不动;任一格仍不可穿行 → 交给 {@link #beginBreaking}
     * 挖,返回未就绪。全部通透即就绪(WAITING 后不再重查)。
     */
    protected boolean prepared(MovementState state) {
        if (state.getStatus() == MovementStatus.WAITING) {
            return true;
        }
        for (class_2338 pos : positionsToBreak) {
            if (NavSettings.get().pauseMiningForFallingBlocks
                    && !player.method_51469().method_18467(class_1540.class,
                            new class_238(0, 0, 0, 1, 1.1, 1).method_996(pos)).isEmpty()) {
                return false;
            }
            if (!MovementHelper.canWalkThrough(player.method_51469(), pos)) {
                beginBreaking(state, pos);
                return false;
            }
        }
        return true;
    }

    /**
     * 状态机推进,子类覆写并先走本实现:未就绪 → PREPPING;
     * 就绪后 PREPPING → WAITING → RUNNING。
     */
    public MovementState updateState(MovementState state) {
        if (!prepared(state)) {
            return state.setStatus(MovementStatus.PREPPING);
        } else if (state.getStatus() == MovementStatus.PREPPING) {
            state.setStatus(MovementStatus.WAITING);
        }
        if (state.getStatus() == MovementStatus.WAITING) {
            state.setStatus(MovementStatus.RUNNING);
        }
        return state;
    }

    /** 当前是否可被安全中断(默认恒可;悬空放置中的子类覆写)。 */
    public boolean safeToCancel() {
        return safeToCancel(currentState);
    }

    protected boolean safeToCancel(MovementState state) {
        return true;
    }

    /** 重置状态机(路径回退重执行时用)。 */
    public void reset() {
        currentState = new MovementState().setStatus(MovementStatus.PREPPING);
    }

    // ==================== 执行层钩子(经注入代理落地) ====================

    /**
     * 执行代理:四个钩子的真实落点。移动原语只描述"要看哪、按什么键、
     * 挖哪格",代理负责把这些落到实体上(视角步进、输入字段、渐进挖掘)。
     */
    public interface ExecutionDelegate {

        /** 开挖一格:选可视面、转头,视线就位后按左键。 */
        void beginBreaking(MovementState state, class_2338 pos);

        /** 应用期望视角(按鼠标步进量化逼近,不瞬间对准)。 */
        void applyRotation(MovementState.MovementTarget target);

        /** 清空全部按键。 */
        void clearInputs();

        /** 应用单个按键。 */
        void applyInput(Input input, boolean held);

        /** 这次导航对地形的许可:执行期"顺手"的放置(跑酷落点补块)只在可改地形时做。 */
        TerrainPermit permit();
    }

    private ExecutionDelegate executionDelegate;

    /** 注入执行代理;未注入时四个钩子为空操作(纯规划用途)。 */
    public void setExecutionDelegate(ExecutionDelegate delegate) {
        this.executionDelegate = delegate;
    }

    /** 开挖一格,转发执行代理。 */
    protected void beginBreaking(MovementState state, class_2338 pos) {
        if (executionDelegate != null) {
            executionDelegate.beginBreaking(state, pos);
        }
    }

    /** 应用期望视角,转发执行代理。 */
    protected void applyRotation(MovementState.MovementTarget target) {
        if (executionDelegate != null) {
            executionDelegate.applyRotation(target);
        }
    }

    /** 清空全部按键,转发执行代理。 */
    protected void clearInputs() {
        if (executionDelegate != null) {
            executionDelegate.clearInputs();
        }
    }

    /** 应用单个按键,转发执行代理。 */
    protected void applyInput(Input input, boolean held) {
        if (executionDelegate != null) {
            executionDelegate.applyInput(input, held);
        }
    }

    /** 执行期能不能改地形;未注入代理(纯规划)按不能算——规划已由上下文成本裁决。 */
    protected boolean mayAlterTerrain() {
        return executionDelegate != null && executionDelegate.permit().mayAlter();
    }

    // ==================== 元数据 ====================

    public class_2338 getSrc() {
        return src;
    }

    public class_2338 getDest() {
        return dest;
    }

    public class_2338 getDirection() {
        return dest.method_10059(src);
    }

    public class_2338[] toBreakAll() {
        return positionsToBreak;
    }

    /** 丢弃三类格集缓存,下次查询按当前世界重算。 */
    public void resetBlockCache() {
        toBreakCached = null;
        toPlaceCached = null;
        toWalkIntoCached = null;
    }

    /** 此刻仍不可穿行、需要挖掉的格(缓存到 {@link #resetBlockCache()})。 */
    public List<class_2338> toBreak(net.minecraft.class_1922 level) {
        if (toBreakCached != null) {
            return toBreakCached;
        }
        List<class_2338> result = new ArrayList<>();
        for (class_2338 pos : positionsToBreak) {
            if (!MovementHelper.canWalkThrough(level, pos)) {
                result.add(pos);
            }
        }
        toBreakCached = result;
        return result;
    }

    /** 此刻仍不可站立、需要放上方块的格(缓存到 {@link #resetBlockCache()})。 */
    public List<class_2338> toPlace(net.minecraft.class_1922 level) {
        if (toPlaceCached != null) {
            return toPlaceCached;
        }
        List<class_2338> result = new ArrayList<>();
        if (positionToPlace != null && !MovementHelper.canWalkOn(level, positionToPlace)) {
            result.add(positionToPlace);
        }
        toPlaceCached = result;
        return result;
    }

    /** 会用身体挤进去的格(基类恒空;对角移动覆写产出切角柱)。 */
    public List<class_2338> toWalkInto(net.minecraft.class_1922 level) {
        if (toWalkIntoCached == null) {
            toWalkIntoCached = new ArrayList<>();
        }
        return toWalkIntoCached;
    }

    public class_2338 getToPlace() {
        return positionToPlace;
    }

    /** 记录成本计算时 dest 所在 chunk 是否已加载。 */
    public void checkLoadedChunk(CalculationContext context) {
        calculatedWhileLoaded = context.isLoaded(dest.method_10263(), dest.method_10260());
    }

    public boolean calculatedWhileLoaded() {
        return calculatedWhileLoaded;
    }
}
