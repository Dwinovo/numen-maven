package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.sdk.ServerCall;
import com.dwinovo.numen.core.act.MenuOrigin;
import com.dwinovo.numen.core.task.inventory.TransferTaskRecord;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.permission.Action;
import com.dwinovo.numen.task.TaskRecord;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_7923;


/**
 * 在打开的界面里搬东西的业务半边:{@code gui move}(一格挪到另一格:挪、并、换)与 {@code gui quick}(整叠挪到另一边,
 * 像按住 Shift 点它)。一次调用一步({@link Move}),作为有界短活跑({@code TransferCompanionTask}):从容器里拿东西的那一步
 * 和别的身体动作一样,可能要等主人点头。
 */
public final class ContainerOps {

    /** Generous for clicks that normally land in one tick. */
    private static final long TRANSFER_TIMEOUT_TICKS = 10 * 20;

    /**
     * 搬一步。
     *
     * @param to    放到哪一格;null 是整叠挪到另一边({@code gui quick})
     * @param count 挪几个;null 是整叠。只和 {@code to} 一起用
     */
    public record Move(int from, Integer to, Integer count) {}

    /** 这一步交任务槽的那件活:点击通常一刻就完,期限只为等主人点头之外的意外留着。 */
    public static TaskRecord transfer(ServerCall source, Move move) {
        return new TransferTaskRecord(source, source.her().method_51469().method_75260() + TRANSFER_TIMEOUT_TICKS, move);
    }

    /**
     * 这一步会不会从容器里拿东西进她的背包:会就是那个 {@code take} 动作,不会是 null。
     *
     * <p>拿 = 东西离开界面里不是她背包的那一段,落进她的背包——整叠分流过去({@code to} 省略)、放到她背包的
     * 某一格,或者整叠对换时换回来的那一叠。她自己的背包界面(2x2 合成格)是她的沙盒,不算;右键没有方块实体的
     * 方块(工作台、切石机)开的界面里,格子里只有她自己刚放进去的东西,也不算。容器是哪一格从
     * {@link MenuOrigin} 取;右键实体开的、来历不明的,动作不带格子。
     */
    public static Action taking(Move m, NumenPlayer self) {
        class_1703 menu = self.field_7512;
        int max = menu.field_7761.size() - 1;
        if (menu == self.field_7498 || m.from() < 0 || m.from() > max
                || (m.to() != null && (m.to() < 0 || m.to() > max))) {
            return null;
        }
        class_1735 from = menu.field_7761.get(m.from());
        class_1735 to = m.to() == null ? null : menu.field_7761.get(m.to());
        class_1799 taken = class_1799.field_8037;
        if (!mine(from, self) && (to == null || mine(to, self))) {
            taken = from.method_7677();
        } else if (mine(from, self) && to != null && !mine(to, self) && (m.count() == null || m.count() <= 0)
                && !from.method_7677().method_7960() && !sameItem(to.method_7677(), from.method_7677())) {
            taken = to.method_7677();
        }
        if (taken.method_7960()) {
            return null;
        }
        class_2338 block = MenuOrigin.block(self);
        if (block == null) {
            return Action.take(null, null, taken.method_7909());
        }
        class_2680 state = self.method_51469().method_8320(block);
        return state.method_31709() ? Action.take(block, state, taken.method_7909()) : null;
    }

    private static boolean mine(class_1735 slot, NumenPlayer self) {
        return slot.field_7871 == self.method_31548();
    }

    /** 执行一步,回执这一步的一行(不带序号)。 */
    public String step(Move m, NumenPlayer self) {
        class_1703 menu = self.field_7512;
        int max = menu.field_7761.size() - 1;
        int from = m.from();
        Integer to = m.to();
        Integer count = m.count();
        if (from < 0 || from > max) {
            return "from slot " + from + " OUT OF RANGE (0.." + max + ") — skipped; numen.gui.view() shows the indices.";
        }
        if (to != null && (to < 0 || to > max)) {
            return "to slot " + to + " OUT OF RANGE (0.." + max + ") — skipped; numen.gui.view() shows the indices.";
        }
        try {
            return to == null ? route(menu, self, from) : place(menu, self, from, to, count);
        } catch (RuntimeException ex) {
            return "slot " + from + " — ERROR: " + ex.getMessage();
        }
    }

    /** No destination: shift the whole stack to the other section, menu-routed (deposit/take/feed). */
    private static String route(class_1703 menu, NumenPlayer entity, int from) {
        class_1799 before = menu.field_7761.get(from).method_7677().method_7972();
        if (before.method_7960()) {
            if (menu.field_7761.get(from) instanceof class_1734) {
                // Empty crafting result = the grid doesn't form a valid recipe (usually a mis-placed
                // 2x2 layout). Point the model back at the recipe so it self-corrects.
                return "slot " + from + " (crafting result) is empty — the grid doesn't form a valid "
                        + "recipe yet. Call numen.inv.recipes for the exact layout, then numen.gui.view() and match "
                        + "it onto the grid cell-for-cell (a smaller recipe goes top-left; 2x2 slot "
                        + "indices are easy to guess wrong).";
            }
            return "slot " + from + " is empty — nothing to move.";
        }
        menu.method_7593(from, 0, class_1713.field_7794, entity);
        class_1799 after = menu.field_7761.get(from).method_7677();
        int moved = before.method_7947() - (sameItem(before, after) ? after.method_7947() : 0);
        if (moved <= 0) {
            return "slot " + from + " (" + name(before) + ") didn't move — the other section is full "
                    + "or won't accept it.";
        }
        return "routed " + moved + " " + name(before) + " from slot " + from + " to the other section "
                + "(deposit/take/feed)." + (after.method_7960() ? "" : " " + after.method_7947() + " left in slot "
                + from + ".");
    }

    /** A destination slot: place exactly there — empty→move, same item→merge, different item→swap. */
    private static String place(class_1703 menu, NumenPlayer entity, int from, int to, Integer count) {
        if (from == to) {
            return "slot " + from + " → itself — nothing to do.";
        }
        class_1799 fromBefore = menu.field_7761.get(from).method_7677().method_7972();
        class_1799 toBefore = menu.field_7761.get(to).method_7677().method_7972();
        if (fromBefore.method_7960()) {
            return "slot " + from + " is empty — nothing to move.";
        }

        boolean exact = count != null && count > 0;
        boolean differentItem = !toBefore.method_7960() && !sameItem(toBefore, fromBefore);

        if (exact && differentItem) {
            return "can't move " + count + " from slot " + from + " — slot " + to + " holds "
                    + name(toBefore) + ". Omit count to swap the whole stacks instead.";
        }

        if (exact) {
            int want = Math.min(count, fromBefore.method_7947());
            MenuOps.dripInto(menu, entity, from, to, want);
        } else {
            menu.method_7593(from, 0, class_1713.field_7790, entity);          // grab the stack
            menu.method_7593(to, 0, class_1713.field_7790, entity);            // place / merge / swap
            if (!menu.method_34255().method_7960()) {
                menu.method_7593(from, 0, class_1713.field_7790, entity);      // settle leftover / swapped item back
            }
        }

        class_1799 fromAfter = menu.field_7761.get(from).method_7677();
        class_1799 toAfter = menu.field_7761.get(to).method_7677();
        int moved = fromBefore.method_7947() - (sameItem(fromBefore, fromAfter) ? fromAfter.method_7947() : 0);

        if (differentItem) {     // whole-stack onto a different item = swap
            if (sameItem(toAfter, fromBefore) && sameItem(fromAfter, toBefore)) {
                return "swapped slot " + from + " (" + name(fromBefore) + ") ⇄ slot " + to + " ("
                        + name(toBefore) + ").";
            }
            return "slot " + from + " → " + to + ": nothing moved — slot " + to + " refused it "
                    + "(output-only slot?).";
        }
        if (moved <= 0) {
            return "slot " + from + " → " + to + ": nothing moved — slot " + to
                    + (toBefore.method_7960() ? " refused it (output-only slot?)." : " is already full.");
        }
        String verb = toBefore.method_7960() ? "moved " : "merged ";
        return verb + moved + " " + name(fromBefore) + " from slot " + from + " to slot " + to
                + " (slot " + to + " now " + toAfter.method_7947()
                + (fromAfter.method_7960() ? "; slot " + from + " emptied)." : "; " + fromAfter.method_7947()
                + " left in slot " + from + ").");
    }

    private static boolean sameItem(class_1799 a, class_1799 b) {
        return class_1799.method_31577(a, b);
    }

    private static String name(class_1799 stack) {
        return stack.method_7960() ? "nothing" : class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
    }
}
