package com.dwinovo.numen.core.act;

import com.dwinovo.numen.entity.BodyDelta;
import com.dwinovo.numen.entity.NumenPlayer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_7923;

/**
 * 一次按键前后的世界事实差异。按键被"消费"不等于"发生了什么"——船可以吃掉点击,
 * 却因为生成位置和身体重叠被原版静默拒绝,世界纹丝不动。这里不判成败,只把看得见的变化如实报出:
 * 她身上的(背包与经验、血量、骑乘,见 {@link BodyDelta})、瞄着的那一格、身边新冒出来的实体。
 * 判断交给读回执的人——什么算"成"只有意图知道,而意图在模型那边。
 */
public final class PressReceipt {

    /** 新实体的观察半径:够罩住触及距离(4.5)内放出的船/掷物,不把远处的路人算进来。 */
    private static final double ENTITY_RADIUS = 6.0;

    private final BodyDelta body;
    private final class_2338 aim;
    private final class_2680 aimBefore;
    private final Set<Integer> entityIdsBefore;

    private PressReceipt(NumenPlayer player, class_2338 aim) {
        this.body = BodyDelta.open(player);
        this.aim = aim;
        this.aimBefore = aim == null ? null : player.method_51469().method_8320(aim);
        this.entityIdsBefore = nearbyIds(player);
    }

    /** 按键之前拍快照;{@code aim} 可空(朝空气挥没有目标格)。 */
    public static PressReceipt before(NumenPlayer player, class_2338 aim) {
        return new PressReceipt(player, aim);
    }

    /**
     * 按键之后对账:每一条是一件真发生的事,空表 = 观察的几个面都没动静。
     * 语言面向工具回执(英文),坐标点名,方便模型下一步引用。
     */
    public List<String> diff(NumenPlayer player) {
        List<String> facts = new ArrayList<>();
        facts.addAll(body.changes(player));
        if (aim != null) {
            class_2680 now = player.method_51469().method_8320(aim);
            if (now != aimBefore) {
                facts.add("block at " + aim.method_10263() + "," + aim.method_10264() + "," + aim.method_10260()
                        + ": " + blockName(aimBefore) + " -> " + blockName(now));
            }
        }
        for (class_1297 e : nearby(player)) {
            if (!entityIdsBefore.contains(e.method_5628())) {
                facts.add("appeared: " + class_7923.field_41177.method_10221(e.method_5864()).method_12832()
                        + " (id " + e.method_5628() + ")");
            }
        }
        return facts;
    }

    private static String blockName(class_2680 state) {
        return class_7923.field_41175.method_10221(state.method_26204()).method_12832();
    }

    private static Set<Integer> nearbyIds(NumenPlayer player) {
        Set<Integer> ids = new HashSet<>();
        for (class_1297 e : nearby(player)) {
            ids.add(e.method_5628());
        }
        return ids;
    }

    private static List<class_1297> nearby(NumenPlayer player) {
        return player.method_51469().method_8335(player,
                player.method_5829().method_1014(ENTITY_RADIUS));
    }
}
