package com.dwinovo.numen.core.task.fish;
import com.dwinovo.numen.task.TaskResult;
import com.dwinovo.numen.core.FailureType;

import com.dwinovo.numen.core.Constants;
import com.dwinovo.numen.core.mixin.FishingHookAccessor;
import com.dwinovo.numen.core.nav.Feet;
import com.dwinovo.numen.core.nav.Terrain;
import com.dwinovo.numen.core.task.base.AbstractCompanionTask;
import com.dwinovo.numen.core.task.base.Precondition;
import com.dwinovo.numen.entity.InputDriver;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.pathing.body.Hotbar;
import com.dwinovo.numen.pathing.spec.RouteSpec;
import com.dwinovo.numen.task.Preparation;
import com.dwinovo.numen.task.TaskState;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3486;
import net.minecraft.class_3959;

/**
 * {@code numen.work.fish}:站在原地用钓竿抛一竿——对准、抛竿、等咬钩、收线,钓上来就收工,回执说钓上来的是什么。它不走动:站的地方
 * 得是干的、抛得进水面,受理之前({@link #preparation})就判,不成就当场拒绝,说清要先站到岸边。这一竿没落进水、钩到了实体、等不来
 * 咬钩,就如实失败;再抛一竿、钓几条是程序里一圈一圈调它。收线时原版把战果甩向她,落在半路的留在地上,{@code numen.work.collect}
 * 去捡;它不去追。
 */
public final class FishCompanionTask extends AbstractCompanionTask<FishTaskRecord> {

    private enum Phase { PREPARE, AIM, WAIT }

    private static final int CAST_SEARCH_RADIUS = 10;
    private static final int CAST_SEARCH_Y = 4;
    private static final double MIN_CAST_DISTANCE = 4.0;
    private static final double IDEAL_CAST_DISTANCE = 6.0;
    private static final double WATER_SURFACE_OFFSET = 0.85;
    private static final int AIM_TICKS = 3;
    private static final int CAST_SETTLE_TIMEOUT = 5 * 20;
    /** 一竿至多等多久的咬钩;任务的期限照它给({@link FishTaskRecord})。 */
    static final int CAST_LIFETIME = 60 * 20;


    private static final double FISHING_DRAG = 0.92;
    private static final double FISHING_GRAVITY = 0.03;
    private static final int MAX_FLIGHT_TICKS = 80;

    private Phase phase = Phase.PREPARE;
    /** 她站着钓的那一格:受理时脚下那一格,离开它就不钓了。 */
    private class_2338 stance;
    private class_2338 target;
    private int phaseTicks;
    /** 收线时甩上来的东西:{@code minecraft:cod x1}。 */
    private final List<String> caught = new ArrayList<>();

    public FishCompanionTask(NumenPlayer player, FishTaskRecord record) {
        super(player, record);
    }

    @Override
    protected List<Precondition> preconditions() {
        return List.of(() -> findRodSlot() >= 0 ? null
                : new Precondition.Failure("fish needs a fishing rod in inventory",
                        FailureType.WRONG_TOOL));
    }

    @Override
    protected TaskState onTick() {
        if (player.method_29504()) return TaskState.CANCELLED;

        player.controls().stop();

        int rodSlot = findRodSlot();
        if (rodSlot < 0) {
            discardHook();
            fail("fishing stopped because there is no fishing rod left", FailureType.WRONG_TOOL);
            return TaskState.FAILED;
        }
        Hotbar.hold(player, rodSlot);
        if (!player.method_6047().method_31574(class_1802.field_8378)) return TaskState.RUNNING;

        return switch (phase) {
            case PREPARE -> prepare();
            case AIM -> aimAndCast();
            case WAIT -> waitForBite();
        };
    }

    /**
     * 受理之前:身上有鱼竿(前置条件),她站的地方是干的、从这儿抛得进水面。不成就当场回那句话,不受理;成就记下站位与落点。
     */
    @Override
    protected Preparation preparation() {
        class_2338 here = feet();
        if (!isDryStance(here)) {
            return Preparation.refused(TaskResult.fail(NOT_DRY));
        }
        class_2338 water = findCastTarget(here, player.method_33571());
        if (water == null) {
            return Preparation.refused(TaskResult.fail(com.dwinovo.numen.agent.script.ErrorKind.NOT_FOUND, NO_WATER,
                    null));
        }
        stance = here;
        target = water;
        return Preparation.READY;
    }

    /** 站的地方不干时说的那句话。 */
    private static final String NOT_DRY = "I do not stand on dry ground here, and fishing does not move me: stand on "
            + "the shore with open water " + (int) MIN_CAST_DISTANCE + "-" + CAST_SEARCH_RADIUS + " blocks away "
            + "(numen.scan.blocks finds water; numen.move.to takes you there), then numen.work.fish again";

    /** 从这儿抛不进水面时说的那句话。 */
    private static final String NO_WATER = "no open water to cast into " + (int) MIN_CAST_DISTANCE + "-"
            + CAST_SEARCH_RADIUS + " blocks from where I stand, and fishing does not move me: stand on the shore "
            + "facing open water (numen.scan.blocks finds water; numen.move.to takes you there), then numen.work.fish again";

    private TaskState prepare() {
        if (player.field_7513 != null) {
            discardHook();
            return TaskState.RUNNING;
        }

        class_2338 current = feet();
        if (stance == null) {
            // 重启后接回来的活不经受理前的准备:站位就是此刻脚下
            stance = current;
        }
        if (!current.equals(stance) || !isDryStance(current)) {
            fail("I was moved off the spot I fished from (" + stance.method_23854() + "), and fishing does not "
                    + "walk me back", FailureType.OUT_OF_REACH);
            return TaskState.FAILED;
        }
        if (target == null || !isCastableSurface(target)
                || !trajectoryClear(player.method_33571(), target)) {
            target = findCastTarget(stance, player.method_33571());
        }
        if (target == null) {
            fail(NO_WATER, FailureType.OUT_OF_REACH);
            return TaskState.FAILED;
        }

        phase = Phase.AIM;
        phaseTicks = 0;
        aimAtTarget();
        return TaskState.RUNNING;
    }

    private TaskState aimAndCast() {
        if (!isCastableSurface(target) || !trajectoryClear(player.method_33571(), target)) {
            return failedCast("the selected water surface became obstructed");
        }
        aimAtTarget();
        if (++phaseTicks < AIM_TICKS) return TaskState.RUNNING;

        double pitch = castPitchDegrees(player.method_33571(), target);
        player.field_13974.method_14256(player, player.method_51469(), player.method_6047(), class_1268.field_5808);
        if (player.field_7513 == null) {
            return failedCast("the fishing rod did not cast");
        }
        Constants.LOG.debug("[numen-fish] cast target={} pitch={}",
                target.method_23854(), String.format(java.util.Locale.ROOT, "%.1f", pitch));
        phase = Phase.WAIT;
        phaseTicks = 0;
        return TaskState.RUNNING;
    }

    private TaskState waitForBite() {
        class_1536 hook = player.field_7513;
        if (hook == null || hook.method_31481()) {
            return failedCast("the fishing hook disappeared before a catch");
        }
        phaseTicks++;

        class_1297 hooked = hook.method_26957();
        if (hooked != null) {
            reelIn();
            return failedCast("the hook caught an entity instead of landing in the water");
        }

        int nibble = ((FishingHookAccessor) (Object) hook).numen$getNibble();
        if (isBiteWindow(nibble)) {
            class_243 at = hook.method_73189();
            reelIn();
            // 原版收线把战果就地生在浮漂那儿、甩向她:刚生出来的那几个就是这一竿钓上来的
            for (net.minecraft.class_1542 item : hook.method_73183().method_8390(
                    net.minecraft.class_1542.class, new net.minecraft.class_238(at, at)
                            .method_1014(1.5), e -> e.field_6012 == 0)) {
                caught.add(net.minecraft.class_7923.field_41178.method_10221(item.method_6983().method_7909())
                        + " x" + item.method_6983().method_7947());
            }
            Constants.LOG.debug("[numen-fish] caught {}", caught);
            succeed();
            return TaskState.SUCCESS;
        }

        boolean inWater = hook.method_73183().method_8316(hook.method_24515()).method_15767(class_3486.field_15517);
        if (!inWater && phaseTicks >= CAST_SETTLE_TIMEOUT) {
            Constants.LOG.debug("[numen-fish] miss hook={} on_ground={} age={}",
                    hook.method_24515().method_23854(), hook.method_24828(), phaseTicks);
            return failedCast("the fishing hook did not settle in water");
        }
        if (phaseTicks >= CAST_LIFETIME) {
            return failedCast("no bite came in " + CAST_LIFETIME / 20 + " seconds");
        }
        return TaskState.RUNNING;
    }

    /** 这一竿没成:收回浮漂,如实失败;再抛一竿是下一次调用。 */
    private TaskState failedCast(String reason) {
        discardHook();
        fail(reason + "; numen.work.fish casts again", FailureType.OUT_OF_REACH);
        return TaskState.FAILED;
    }

    private void reelIn() {
        if (player.field_7513 != null && player.method_6047().method_31574(class_1802.field_8378)) {
            player.field_13974.method_14256(player, player.method_51469(), player.method_6047(),
                    class_1268.field_5808);
        }
    }

    private int findRodSlot() {
        var inventory = player.method_31548();
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_31574(class_1802.field_8378)) return i;
        }
        return -1;
    }

    private class_2338 findCastTarget(class_2338 fromStance, class_243 eye) {
        List<class_2338> candidates = new ArrayList<>();
        for (int dy = -CAST_SEARCH_Y; dy <= CAST_SEARCH_Y; dy++) {
            for (int dx = -CAST_SEARCH_RADIUS; dx <= CAST_SEARCH_RADIUS; dx++) {
                for (int dz = -CAST_SEARCH_RADIUS; dz <= CAST_SEARCH_RADIUS; dz++) {
                    double horizontal = Math.sqrt(dx * dx + dz * dz);
                    if (horizontal < MIN_CAST_DISTANCE || horizontal > CAST_SEARCH_RADIUS) continue;
                    class_2338 candidate = fromStance.method_10069(dx, dy, dz);
                    if (isCastableSurface(candidate)) {
                        candidates.add(candidate.method_10062());
                    }
                }
            }
        }
        candidates.sort(Comparator.comparingDouble(candidate -> castScore(fromStance, candidate)));
        for (class_2338 candidate : candidates) {
            if (trajectoryClear(eye, candidate)) return candidate;
        }
        return null;
    }

    private double castScore(class_2338 fromStance, class_2338 candidate) {
        double dx = candidate.method_10263() - fromStance.method_10263();
        double dz = candidate.method_10260() - fromStance.method_10260();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return Math.abs(horizontal - IDEAL_CAST_DISTANCE)
                + Math.abs(candidate.method_10264() - fromStance.method_10264()) * 0.35
                - waterNeighbourCount(candidate) * 0.04;
    }

    private int waterNeighbourCount(class_2338 pos) {
        int count = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (isCastableSurface(pos.method_10069(dx, 0, dz))) count++;
            }
        }
        return count;
    }

    private boolean isCastableSurface(class_2338 pos) {
        var fluid = player.method_51469().method_8316(pos);
        if (!fluid.method_15767(class_3486.field_15517) || !fluid.method_15771()) return false;
        if (player.method_51469().method_8316(pos.method_10084()).method_15767(class_3486.field_15517)) return false;
        return player.method_51469().method_8320(pos.method_10084())
                .method_26220(player.method_51469(), pos.method_10084()).method_1110();
    }

    /**
     * 能站着钓鱼的干地方:出厂规格的路线会让她在这儿站着({@link Terrain#standingSpot}),脚与头所在的两格没有液体。
     */
    private boolean isDryStance(class_2338 pos) {
        Terrain terrain = Terrain.of(player);
        return terrain.state(pos).method_26227().method_15769() && terrain.state(pos.method_10084()).method_26227().method_15769()
                && terrain.standingSpot(pos, RouteSpec.defaults());
    }

    private class_2338 feet() {
        return Feet.cell(player);
    }

    private void aimAtTarget() {
        InputDriver.lookAt(player, castAimPoint(player.method_33571(), target));
    }

    private static class_243 castAimPoint(class_243 eye, class_2338 target) {
        double tx = target.method_10263() + 0.5;
        double tz = target.method_10260() + 0.5;
        double dx = tx - eye.field_1352;
        double dz = tz - eye.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 1.0e-6) return new class_243(tx, waterSurfaceY(target), tz);
        double pitch = Math.toRadians(castPitchDegrees(eye, target));
        double scale = 16.0 / horizontal;
        return new class_243(eye.field_1352 + dx * scale,
                eye.field_1351 - Math.tan(pitch) * 16.0,
                eye.field_1350 + dz * scale);
    }

    private boolean trajectoryClear(class_243 eye, class_2338 target) {
        double tx = target.method_10263() + 0.5;
        double tz = target.method_10260() + 0.5;
        double dx = tx - eye.field_1352;
        double dz = tz - eye.field_1350;
        double directDistance = Math.sqrt(dx * dx + dz * dz);
        if (directDistance < 1.0e-6) return false;
        double ux = dx / directDistance;
        double uz = dz / directDistance;
        // Vanilla spawns the bobber 0.3 blocks in front of the player's eyes.
        class_243 pos = eye.method_1031(ux * 0.3, 0.0, uz * 0.3);
        double distance = Math.sqrt((tx - pos.field_1352) * (tx - pos.field_1352) + (tz - pos.field_1350) * (tz - pos.field_1350));
        double pitch = Math.toRadians(solvePitchDegrees(distance, waterSurfaceY(target) - eye.field_1351));
        double horizontalVelocity = 0.6 * Math.cos(pitch) + 0.5;
        double verticalVelocity = -Math.tan(pitch) * horizontalVelocity;
        double travelled = 0.0;

        for (int tick = 0; tick < MAX_FLIGHT_TICKS; tick++) {
            verticalVelocity -= FISHING_GRAVITY;
            double fraction = Math.min(1.0, (distance - travelled) / horizontalVelocity);
            class_243 next = pos.method_1031(ux * horizontalVelocity * fraction,
                    verticalVelocity * fraction, uz * horizontalVelocity * fraction);
            class_239 hit = player.method_51469().method_17742(new class_3959(pos, next,
                    class_3959.class_3960.field_17558, class_3959.class_242.field_1348, player));
            if (hit.method_17783() != class_239.class_240.field_1333) return false;
            travelled += horizontalVelocity * fraction;
            if (travelled >= distance - 1.0e-6) return true;
            pos = next;
            horizontalVelocity *= FISHING_DRAG;
            verticalVelocity *= FISHING_DRAG;
        }
        return false;
    }

    private static double castPitchDegrees(class_243 eye, class_2338 target) {
        double dx = target.method_10263() + 0.5 - eye.field_1352;
        double dz = target.method_10260() + 0.5 - eye.field_1350;
        double distance = Math.max(0.1, Math.sqrt(dx * dx + dz * dz) - 0.3);
        return solvePitchDegrees(distance, waterSurfaceY(target) - eye.field_1351);
    }

    static double solvePitchDegrees(double horizontalDistance, double targetHeight) {
        double low = -45.0;
        double high = 55.0;
        for (int i = 0; i < 32; i++) {
            double mid = (low + high) * 0.5;
            double height = trajectoryHeightAtDistance(horizontalDistance, mid);
            if (height > targetHeight) {
                low = mid;  // trajectory is high: aim farther down
            } else {
                high = mid;
            }
        }
        return (low + high) * 0.5;
    }

    static double trajectoryHeightAtDistance(double horizontalDistance, double pitchDegrees) {
        double pitch = Math.toRadians(pitchDegrees);
        double horizontalVelocity = 0.6 * Math.cos(pitch) + 0.5;
        double verticalVelocity = -Math.tan(pitch) * horizontalVelocity;
        double travelled = 0.0;
        double height = 0.0;
        for (int tick = 0; tick < MAX_FLIGHT_TICKS; tick++) {
            verticalVelocity -= FISHING_GRAVITY;
            double nextDistance = travelled + horizontalVelocity;
            double nextHeight = height + verticalVelocity;
            if (nextDistance >= horizontalDistance) {
                double fraction = (horizontalDistance - travelled) / horizontalVelocity;
                return height + verticalVelocity * fraction;
            }
            travelled = nextDistance;
            height = nextHeight;
            horizontalVelocity *= FISHING_DRAG;
            verticalVelocity *= FISHING_DRAG;
        }
        return Double.NEGATIVE_INFINITY;
    }

    private static double waterSurfaceY(class_2338 target) {
        return target.method_10264() + WATER_SURFACE_OFFSET;
    }

    static boolean isBiteWindow(int nibbleTicks) {
        return nibbleTicks > 0;
    }

    private void discardHook() {
        class_1536 hook = player.field_7513;
        if (hook != null) {
            hook.method_31472();
            if (player.field_7513 == hook) player.field_7513 = null;
        }
    }

    @Override
    public void stop(NumenPlayer companion, StopReason why) {
        super.stop(companion, why);
        discardHook();
        phase = Phase.PREPARE;
        phaseTicks = 0;
    }

    @Override
    protected void cleanup() {
        player.controls().stop();
        discardHook();
        super.cleanup();
    }

    /** 钓上来的,{@code minecraft:cod x1}:{@code numen.work.fish} 交回的值。 */
    @Override
    protected List<String> value() {
        return List.copyOf(caught);
    }

    @Override
    protected String successMessage() {
        return "reeled in " + (caught.isEmpty() ? "a catch" : String.join(", ", caught)) + "; the reel throws it to "
                + "me, and what lands short lies on the ground: `numen.work.collect()` picks it up";
    }

    @Override
    protected String timeoutMessage() {
        return "the cast timed out without a catch";
    }

    @Override
    protected String cancelledMessage() {
        return "fishing interrupted before a catch";
    }
}
