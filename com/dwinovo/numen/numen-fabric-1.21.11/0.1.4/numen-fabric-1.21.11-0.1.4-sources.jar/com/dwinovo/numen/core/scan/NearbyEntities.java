package com.dwinovo.numen.core.scan;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1297;

/**
 * "她身边半径 r 内的实体",全仓按范围找实体都从这里问。
 *
 * <p>半径就是离她的距离:先拿外接的方盒向世界要候选(实体分区只认盒子),再按距离滤掉盒角——
 * 方盒的角离她有 r·√3 远,只拿盒子当半径,说好的 16 格实际够到 27 格外。工具对模型说的是半径,
 * 回来的就得是半径以内的。
 */
public final class NearbyEntities {

    private NearbyEntities() {}

    /** {@code self} 半径 {@code radius} 格以内(按两者位置的距离)、类型为 {@code type} 且满足 {@code filter} 的实体,不含她自己。 */
    public static <T extends class_1297> List<T> within(class_1297 self, double radius, Class<T> type,
                                                    Predicate<? super T> filter) {
        double radiusSqr = radius * radius;
        return self.method_73183().method_8390(type, self.method_5829().method_1014(radius),
                e -> e != self && self.method_5858(e) <= radiusSqr && filter.test(e));
    }
}
