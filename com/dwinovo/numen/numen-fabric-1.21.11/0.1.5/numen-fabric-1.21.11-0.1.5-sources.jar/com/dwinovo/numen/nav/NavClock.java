package com.dwinovo.numen.nav;

import com.dwinovo.numen.pathing.search.SearchClock;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_4284;
import net.minecraft.server.MinecraftServer;

/**
 * 同伴的寻路看哪块表({@link SearchClock}):跟着服务器实例走的一份,挂在主世界的数据存储上,服务器在它在,服务器没了它也没了。
 * Numen 侧只在这里决定:正式运行是墙钟;GameTest 服务器起好时由测试夹具换成按做了多少活折算的表({@link #use}),
 * 用例的结论与机器快慢无关。搜索拿到的表经 {@link CompanionPorts} 交进寻路的端口,模块那边只有这一个接缝。
 *
 * <p>不写盘:表不是世界的一部分,从不标脏;读到的(本来也没有)一律是一块新的墙钟表。
 */
public final class NavClock extends class_18 {

    private static final String NAME = "numen_nav_clock";
    private static final class_10741<NavClock> TYPE = new class_10741<>(NAME, NavClock::new,
            MapCodec.unitCodec(NavClock::new), class_4284.field_45082);

    private SearchClock clock = SearchClock.WALL;

    private NavClock() {}

    private static NavClock get(MinecraftServer server) {
        return server.method_30002().method_17983().method_17924(TYPE);
    }

    /** 这台服务器上同伴的寻路看的表。 */
    static SearchClock of(MinecraftServer server) {
        return get(server).clock;
    }

    /** 这台服务器上同伴的寻路改看 {@code clock}:GameTest 服务器起好时由测试夹具调。 */
    public static void use(MinecraftServer server, SearchClock clock) {
        get(server).clock = clock;
    }

}
