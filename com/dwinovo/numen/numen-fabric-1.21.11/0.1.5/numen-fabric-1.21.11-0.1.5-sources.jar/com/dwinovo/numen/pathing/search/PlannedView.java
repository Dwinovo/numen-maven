package com.dwinovo.numen.pathing.search;

import java.util.List;
import java.util.function.ObjIntConsumer;
import java.util.function.Predicate;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_3610;
import com.dwinovo.numen.pathing.plan.Edit;
import com.dwinovo.numen.pathing.plan.EditedView;
import com.dwinovo.numen.pathing.world.CellFlags;

/**
 * 接着一条还没走完的路线往下搜时搜索读的世界:派发那一刻的快照,叠上身体走到那条路线终点之前还要做的改动——她到那里时世界就是这样。
 * 搭到半空的桥、往上垫的台阶、挖开的隧道在快照里都还没有,只叠最后一步的话,接着搜的那一次看不见来路,以为退不回去、下不来。
 * 叠法与搜索展开节点、执行往前核是同一种({@link EditedView}),改动取自路线({@link Route#edits(int, int)})。
 *
 * <p>没改过的格照快照的快路径读(标志字成层现成的);改过的格按叠完的方块状态推出标志字。估价按层扫方块({@link #forEachBlock})时,
 * 改过的格的新状态也报一遍,原来的状态照快照报:多报只会让估价更低,仍是下界。
 */
public final class PlannedView implements SearchView {

    private final SearchView base;
    private final EditedView after;

    private PlannedView(SearchView base, EditedView after) {
        this.base = base;
        this.after = after;
    }

    /** {@code base} 做完 {@code edits} 之后的样子;没有改动就是 {@code base} 本身。 */
    public static SearchView of(SearchView base, List<Edit> edits) {
        return edits.isEmpty() ? base : new PlannedView(base, EditedView.over(base, edits));
    }

    private boolean changed(int x, int yMin, int yMax, int z) {
        return after.changed(x, yMin, yMax, z);
    }

    @Override
    public boolean isLoaded(int x, int z) {
        return base.isLoaded(x, z);
    }

    @Override
    public class_2680 loadedBlockState(class_2338 pos) {
        return base.isLoaded(pos.method_10263(), pos.method_10260()) ? after.method_8320(pos) : null;
    }

    @Override
    public class_2680 method_8320(class_2338 pos) {
        return after.method_8320(pos);
    }

    @Override
    public class_3610 method_8316(class_2338 pos) {
        return after.method_8316(pos);
    }

    @Override
    public class_2586 method_8321(class_2338 pos) {
        return after.method_8321(pos);
    }

    @Override
    public int cellFlags(int x, int y, int z) {
        if (!changed(x, y, y, z)) {
            return base.cellFlags(x, y, z);
        }
        return base.isLoaded(x, z) ? CellFlags.of(after.method_8320(new class_2338(x, y, z))) : CellFlags.UNLOADED;
    }

    @Override
    public int cellFlags(int x, int y, int z, int n, byte[] into, int at) {
        if (!changed(x, y, y + n - 1, z)) {
            return base.cellFlags(x, y, z, n, into, at);
        }
        return SearchView.super.cellFlags(x, y, z, n, into, at);
    }

    @Override
    public boolean airSection(int x, int y, int z) {
        return after.airSection(x, y, z);
    }

    @Override
    public void forEachBlock(int fromY, int toY, Predicate<class_2680> wanted, ObjIntConsumer<class_2680> visitor) {
        base.forEachBlock(fromY, toY, wanted, visitor);
        after.forEachChanged((pos, state) -> {
            if (pos.method_10264() >= fromY && pos.method_10264() < toY && wanted.test(state)) {
                visitor.accept(state, pos.method_10264());
            }
        });
    }

    @Override
    public int method_31605() {
        return base.method_31605();
    }

    @Override
    public int method_31607() {
        return base.method_31607();
    }

    @Override
    public class_2784 border() {
        return base.border();
    }

    @Override
    public boolean waterEvaporates(class_2338 pos) {
        return base.waterEvaporates(pos);
    }
}
