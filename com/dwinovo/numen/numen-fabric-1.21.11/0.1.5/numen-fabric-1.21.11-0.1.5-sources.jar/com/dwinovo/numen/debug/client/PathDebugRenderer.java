package com.dwinovo.numen.debug.client;

import com.dwinovo.numen.debug.PathDebugPayload;
import java.util.List;
import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9848;
import net.minecraft.class_9974;

/**
 * 寻路调试世界渲染:把 {@link PathDebugState} 里的快照画成世界空间的
 * 线与方框——当前路径红、下一段品红、在飞最优蓝、待挖红框、待放绿框、
 * 挤身品红框、目标绿框、x/z 目标画通天竖线。逐帧矢量绘制,零粒子。
 * 线条会被地形遮挡(深度测试开启,原版 lines 管线),线宽与原版方块选中框相同。
 */
public final class PathDebugRenderer {

    private static final int RED = class_9848.method_61318(0.9f, 1.0f, 0.15f, 0.15f);
    private static final int MAGENTA = class_9848.method_61318(0.9f, 1.0f, 0.25f, 1.0f);
    private static final int BLUE = class_9848.method_61318(0.9f, 0.25f, 0.45f, 1.0f);
    private static final int GREEN = class_9848.method_61318(0.9f, 0.15f, 1.0f, 0.15f);
    /** 方框比整格略小一圈,相邻两格的框不叠在一起。 */
    private static final class_265 BOX = class_259.method_1081(0.02, 0.02, 0.02, 0.98, 0.98, 0.98);

    private PathDebugRenderer() {}

    /** 世界渲染钩子入口(半透明方块阶段之后;poseStack 为世界空间)。 */
    public static void render(class_4587 poseStack, class_4184 camera) {
        List<PathDebugPayload> snapshots = PathDebugState.live();
        if (snapshots.isEmpty()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        class_243 cam = camera.method_71156();
        class_4597.class_4598 buffers = mc.method_22940().method_23000();
        class_4588 vc = buffers.method_73477(class_12249.method_76015());
        poseStack.method_22903();
        poseStack.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);
        class_4587.class_4665 pose = poseStack.method_23760();
        float width = mc.method_22683().method_75291();
        int minY = mc.field_1687.method_31607();
        int maxY = mc.field_1687.method_31600();
        for (PathDebugPayload p : snapshots) {
            drawPolyline(vc, pose, p.currentPath(), RED, width);
            drawPolyline(vc, pose, p.nextPath(), MAGENTA, width);
            drawPolyline(vc, pose, p.bestPath(), BLUE, width);
            for (long packed : p.toBreak()) {
                drawBox(poseStack, vc, packed, RED, width);
            }
            for (long packed : p.toPlace()) {
                drawBox(poseStack, vc, packed, GREEN, width);
            }
            for (long packed : p.toWalkInto()) {
                drawBox(poseStack, vc, packed, MAGENTA, width);
            }
            for (long packed : p.goalBoxes()) {
                drawBox(poseStack, vc, packed, GREEN, width);
            }
            for (long packed : p.goalColumns()) {
                class_2338 pos = class_2338.method_10092(packed);
                seg(vc, pose,
                        pos.method_10263() + 0.5, minY, pos.method_10260() + 0.5,
                        pos.method_10263() + 0.5, maxY, pos.method_10260() + 0.5, GREEN, width);
            }
        }
        poseStack.method_22909();
        buffers.method_22994(class_12249.method_76015());
    }

    /** 折线:相邻格心连线段。 */
    private static void drawPolyline(class_4588 vc, class_4587.class_4665 pose,
                                     List<Long> packedPositions, int color, float width) {
        for (int i = 0; i + 1 < packedPositions.size(); i++) {
            class_2338 a = class_2338.method_10092(packedPositions.get(i));
            class_2338 b = class_2338.method_10092(packedPositions.get(i + 1));
            seg(vc, pose,
                    a.method_10263() + 0.5, a.method_10264() + 0.5, a.method_10260() + 0.5,
                    b.method_10263() + 0.5, b.method_10264() + 0.5, b.method_10260() + 0.5, color, width);
        }
    }

    private static void drawBox(class_4587 poseStack, class_4588 vc, long packed, int color, float width) {
        class_2338 pos = class_2338.method_10092(packed);
        class_9974.method_62296(poseStack, vc, BOX, pos.method_10263(), pos.method_10264(), pos.method_10260(), color, width);
    }

    /** 一条线段(法线取线段方向、线宽逐顶点写,lines 渲染管线要求)。 */
    private static void seg(class_4588 vc, class_4587.class_4665 pose,
                            double x1, double y1, double z1,
                            double x2, double y2, double z2, int color, float width) {
        float dx = (float) (x2 - x1);
        float dy = (float) (y2 - y1);
        float dz = (float) (z2 - z1);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-5f) {
            return;
        }
        float nx = dx / len;
        float ny = dy / len;
        float nz = dz / len;
        vc.method_56824(pose, (float) x1, (float) y1, (float) z1)
                .method_39415(color)
                .method_60831(pose, nx, ny, nz)
                .method_75298(width);
        vc.method_56824(pose, (float) x2, (float) y2, (float) z2)
                .method_39415(color)
                .method_60831(pose, nx, ny, nz)
                .method_75298(width);
    }
}
