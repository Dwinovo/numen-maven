package com.dwinovo.numen.core.task.chain;

import com.dwinovo.numen.task.reflex.Reflex;
import net.minecraft.class_243;
import com.dwinovo.numen.entity.InputDriver;

import com.dwinovo.numen.task.Task;
import com.dwinovo.numen.task.TaskState;
import com.dwinovo.numen.core.task.survival.SurvivalDecisions;
import com.dwinovo.numen.core.task.survival.UnstuckDetector;
import com.dwinovo.numen.entity.NumenPlayer;

/**
 * Autonomous positional-recovery survival chain. Each tick it samples the body's
 * horizontal position and whether the body was trying to move (nonzero locomotion
 * input); when a full rolling window shows "kept pushing, never moved" — the
 * signature of a body wedged against geometry — it spikes above the LLM task and
 * drives a short break-out burst (turn to a new heading, walk forward, hop), then
 * drops back. Conservative by construction: an idle body (no locomotion input) is
 * never counted as stuck, so it will not wake during legitimate idle.
 *
 * <p>The break-out is a bounded, best-effort wander driven straight through
 * {@link InputDriver} (no nav, no dig plan) — rough but safe: it is capped at
 * {@link #WANDER_TICKS} and never travels far. The pure detection logic lives in
 * {@link UnstuckDetector} so it is unit-tested headless.
 */
public final class UnstuckChain implements Task, com.dwinovo.numen.task.reflex.Reflex {

    /** Rolling window length (ticks) and the disc radius (blocks) that counts as "not moving". */
    private static final int WINDOW = 40;
    private static final double MOVE_THRESHOLD = 0.75;
    /** Length of one break-out burst. */
    private static final int WANDER_TICKS = 30;

    private final UnstuckDetector detector = new UnstuckDetector(WINDOW, MOVE_THRESHOLD);
    private int wanderTicksLeft;
    private float wanderYaw;

    @Override
    public boolean canRun(NumenPlayer companion) {
        class_243 pos = companion.method_73189();
        boolean tryingToMove = companion.field_6250 != 0.0f || companion.field_6212 != 0.0f;
        detector.record(pos.field_1352, pos.field_1350, tryingToMove);

        if (wanderTicksLeft > 0) return true;   // finish the burst
        return detector.isStuck();
    }

    @Override
    public TaskState tick(NumenPlayer companion) {
        if (wanderTicksLeft <= 0) {
            // Begin a fresh break-out: pick a new heading (turn ~137° off current so
            // repeated attempts fan out) and clear the window so we re-evaluate after.
            wanderTicksLeft = WANDER_TICKS;
            wanderYaw = companion.method_36454() + 137.0f;
            detector.reset();
        }
        driveWander(companion);
        if (--wanderTicksLeft <= 0) {
            InputDriver.halt(companion);
        }
        return TaskState.RUNNING;
    }

    @Override
    public void stop(NumenPlayer companion, StopReason why) {
        InputDriver.halt(companion);
        companion.method_5660(false);
        wanderTicksLeft = 0;
        detector.reset();
    }

    @Override
    public String name() {
        return "unstuck";
    }

    // ---- Reflex roster paperwork (constitution §6) ----

    @Override
    public String id() {
        return name();
    }

    @Override
    public String describe() {
        return "被地形卡住时会自己挣脱出来";
    }

    /** Face the chosen heading, push forward, and hop periodically to clear a lip/step. */
    private void driveWander(NumenPlayer companion) {
        companion.method_36456(wanderYaw);
        companion.method_5847(wanderYaw);
        companion.field_6250 = 1.0f;
        companion.field_6212 = 0.0f;
        companion.method_5728(false);
        if (wanderTicksLeft % 5 == 0) {
            InputDriver.jump(companion);
        }
    }
}
