package com.dwinovo.numen.core.pathing.cache;

import com.dwinovo.numen.entity.NumenPlayer;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4076;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-level snapshots of the loaded chunks near companions, for the off-thread planner.
 * Once per tick (from both loaders' end-of-tick hook) we rebuild each
 * companion-level's {@link LoadedChunks} from the chunks currently loaded around its companions — a
 * cheap gather of live {@link class_2818} references via the non-blocking {@code getChunkNow}. The
 * planner then reads those refs LIVE; because the snapshot is
 * rebuilt fresh each tick and never mutated after, there is no cache to invalidate, no block-change
 * tracking, and no staleness beyond a single tick of drift — the server's own chunk
 * loading/unloading bounds it for free.
 */
public final class PathCaches {

    private PathCaches() {}

    static {
        // 这两份都描述一个具体的世界，世界没了就得跟着没。报到写在这里而不是
        // 各 loader 的启动代码里：清理跟状态同居，就不会再出现「清单上漏了一项」。见 ServerLifecycle。
        com.dwinovo.numen.platform.ServerLifecycle.onStopped(PathCaches::dropAll);
    }

    /** How far around each companion to capture loaded chunks (radius in chunks). */
    private static final int RADIUS_CHUNKS = 8;
    /** Keep a companion-less level's snapshot this long before freeing it, so a brief roster gap
     *  doesn't churn. */
    private static final int IDLE_GRACE_TICKS = 600;

    private static final ConcurrentHashMap<class_5321<class_1937>, LoadedChunks> SNAPSHOTS = new ConcurrentHashMap<>();
    /** Consecutive ticks each level has had no companion (main-thread only). */
    private static final Map<class_5321<class_1937>, Integer> idleTicks = new HashMap<>();

    /** The current snapshot for {@code level}, or null if no companion is operating there. */
    public static LoadedChunks peek(class_1937 level) {
        return SNAPSHOTS.get(level.method_27983());
    }

    /**
     * The snapshot for {@code level}, building one around {@code around} on the spot if none exists yet.
     * Called on the main thread right before a search so the planner always gets a thread-safe view —
     * without this, a level's very first search (dispatched before {@link #serverTick} has run) would
     * fall back to a LIVE read-through, which is unsafe once the search runs off-thread.
     */
    public static LoadedChunks ensureSnapshot(class_3218 level, class_2338 around) {
        LoadedChunks existing = SNAPSHOTS.get(level.method_27983());
        if (existing != null) {
            return existing;
        }
        LoadedChunks built = snapshot(level, List.of(around));
        SNAPSHOTS.put(level.method_27983(), built);
        return built;
    }

    public static void dropAll() {
        SNAPSHOTS.clear();
        idleTicks.clear();
    }

    /**
     * Rebuild every companion-level's loaded-chunk snapshot for this tick, and free levels that no
     * longer host a companion (after a grace period). Cheap when no companions exist. Dimension travel
     * is automatic — the old level falls out of the active set and ages out, the new one is rebuilt.
     */
    public static void serverTick(MinecraftServer server) {
        // Tick-interval pulse for the profiler: this hook runs EVERY server tick on every loader,
        // so gap measurements never mistake a task-idle stretch for a slow tick.
        com.dwinovo.numen.core.pathing.util.NavProfiler.serverTickPulse();
        Map<class_3218, List<class_2338>> byLevel = new HashMap<>();
        for (class_3222 p : server.method_3760().method_14571()) {
            if (p instanceof NumenPlayer && p.method_51469() instanceof class_3218 sl) {
                byLevel.computeIfAbsent(sl, k -> new ArrayList<>()).add(p.method_24515());
            }
        }

        Set<class_5321<class_1937>> active = new HashSet<>();
        for (class_3218 sl : byLevel.keySet()) {
            active.add(sl.method_27983());
        }
        for (class_5321<class_1937> key : new ArrayList<>(SNAPSHOTS.keySet())) {
            if (active.contains(key)) {
                idleTicks.remove(key);
            } else if (idleTicks.merge(key, 1, Integer::sum) > IDLE_GRACE_TICKS) {
                SNAPSHOTS.remove(key);
                idleTicks.remove(key);
            }
        }

        for (Map.Entry<class_3218, List<class_2338>> e : byLevel.entrySet()) {
            SNAPSHOTS.put(e.getKey().method_27983(), snapshot(e.getKey(), e.getValue()));
        }
    }

    /** Gather references to the chunks loaded within {@link #RADIUS_CHUNKS} of any companion in this
     *  level (non-blocking — unloaded chunks are simply absent → the reader sees AIR). */
    private static LoadedChunks snapshot(class_3218 level, List<class_2338> feet) {
        Long2ObjectOpenHashMap<class_2818> map = new Long2ObjectOpenHashMap<>();
        LongOpenHashSet blockEntities = new LongOpenHashSet();
        for (class_2338 f : feet) {
            int ccx = class_4076.method_18675(f.method_10263());
            int ccz = class_4076.method_18675(f.method_10260());
            for (int dx = -RADIUS_CHUNKS; dx <= RADIUS_CHUNKS; dx++) {
                for (int dz = -RADIUS_CHUNKS; dz <= RADIUS_CHUNKS; dz++) {
                    int cx = ccx + dx;
                    int cz = ccz + dz;
                    long key = class_1923.method_8331(cx, cz);
                    if (!map.containsKey(key)) {
                        class_2818 chunk = level.method_14178().method_21730(cx, cz);
                        if (chunk != null) {
                            map.put(key, chunk);
                            for (class_2338 bePos : chunk.method_12214().keySet()) {
                                blockEntities.add(bePos.method_10063());
                            }
                        }
                    }
                }
            }
        }
        return new LoadedChunks(map, blockEntities);
    }
}
