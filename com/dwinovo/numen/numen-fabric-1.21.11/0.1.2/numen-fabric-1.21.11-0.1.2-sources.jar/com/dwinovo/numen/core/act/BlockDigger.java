package com.dwinovo.numen.core.act;
import com.dwinovo.numen.core.pathing.moves.AimGeometry;

import com.dwinovo.numen.entity.InputDriver;

import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import com.dwinovo.numen.core.pathing.util.BlockHelper;
import com.dwinovo.numen.core.act.ToolSelect;

/**
 * Progressive block breaking that drives the SAME native server entry point a
 * real client's packets hit. A fake player has no client to
 * run the mining loop, so this class stands in for the client:
 * <ul>
 *   <li>begin: {@code handleBlockBreakAction(START_DESTROY_BLOCK)} + the block's
 *       left-click {@code attack} (note blocks, redstone-ore glow, …); creative
 *       breaks instantly on START; an insta-mineable block breaks on START too;</li>
 *   <li>each tick: accumulate the block's real {@link class_2680#method_26165}
 *       and broadcast the crack overlay (breaker id {@code -1} — the
 *       server does NOT self-complete a survival break for a fake player);</li>
 *   <li>finish: {@code handleBlockBreakAction(STOP_DESTROY_BLOCK)} → the SERVER
 *       destroys the block (drops / durability / events). We do NOT clear the
 *       crack — the block vanishing removes it, so there's no "intact for one
 *       frame" flicker — and we set a {@code blockHitDelay} so the next dig waits
 *       for the destroy to land instead of re-starting the same block;</li>
 *   <li>interrupted: {@code ABORT_DESTROY_BLOCK} + clear the crack.</li>
 * </ul>
 * Shared by path-obstruction clearing ({@code ExecHarness}), auto-mine
 * ({@code MineCompanionTask}), and {@link Interaction} (break_block / interact).
 */
public final class BlockDigger {

    /** The crack is broadcast under breaker id -1 (not the player's entity id),
     *  so the server's own per-player crack clearing on STOP can't wipe it early. */
    private static final int CRACK_ID = -1;

    /** Ticks to wait after a survival break before starting another; follows the
     *  blockBreakSpeed setting (period = the setting, delay = setting − 1). */
    private static int postBreakDelay() {
        return Math.max(0,
                com.dwinovo.numen.core.pathing.settings.NavSettings.get().blockBreakSpeed - 1);
    }

    private final NumenPlayer player;
    private class_2338 pos;
    private float progress;       // accumulated 0..1 destroy fraction
    private boolean started;      // START_DESTROY_BLOCK has been sent for `pos`
    private int blockHitDelay;    // post-break cooldown (survives reset())
    /** 开挖时的主手物品快照;中途换持(物品/组件级)即重开进度。 */
    private net.minecraft.class_1799 destroyingItem;

    public BlockDigger(NumenPlayer player) {
        this.player = player;
    }

    /** The block currently being dug, or {@code null} when idle. */
    public class_2338 current() {
        return pos;
    }

    /** Outcome of one {@link #digStep} tick — lets callers distinguish "still working"
     *  from "physically can't get at it", which the old boolean folded together. */
    public enum DigResult {
        /** Break in progress, cooling down, or begun this tick — keep calling. */
        PROGRESSING,
        /** The TARGET block's break committed this tick. */
        BROKE_TARGET,
        /** An OCCLUDER in the way broke this tick (not the target) — a step toward it. */
        BROKE_OCCLUDER,
        /** No face of the target is reachable and nothing safe occludes it — stuck (maps to OCCLUDED). */
        NO_SHOT;

        /** 本 tick 有方块真的没了(目标或遮挡物)。 */
        public boolean broke() {
            return this == BROKE_TARGET || this == BROKE_OCCLUDER;
        }
    }

    /** Legacy boolean shim: {@code true} only on the tick the TARGET breaks. Kept so
     *  pre-migration callers ({@link Interaction}) compile unchanged; delete once every
     *  caller consumes {@link #digStep}. */
    public boolean dig(class_2338 target) {
        return digStep(target) == DigResult.BROKE_TARGET;
    }

    /**
     * Advance the dig of {@code target} by one tick (restarting cleanly if the
     * target changed): face it, drive the native break action, swing.
     *
     * @return the {@link DigResult} for this tick.
     */
    /**
     * Advance the dig one tick using an ALREADY-RESOLVED crosshair hit: dig
     * exactly the block (and face) the caller's view ray landed on, no internal
     * aim-point search. The hit block is always treated as the target.
     */
    public DigResult digStep(class_3965 crosshairHit) {
        if (blockHitDelay > 0) {                    // let the previous break land first
            blockHitDelay--;
            InputDriver.halt(player);
            return DigResult.PROGRESSING;
        }
        InputDriver.halt(player);
        class_2338 effective = crosshairHit.method_17777();
        if (pos == null || !pos.equals(effective)) {
            // 工具由外层(移动原语按意图格)选择,这里不按命中格改选
            start(effective, false);
        }
        return advance(crosshairHit, true);
    }

    /** 破块后冷却按游戏刻递减;本 tick 没走 digStep 的驱动方调用此保持计时。 */
    public void tickCooldown() {
        if (blockHitDelay > 0) {
            blockHitDelay--;
        }
    }

    public DigResult digStep(class_2338 target) {
        class_1937 level = player.method_51469();
        if (blockHitDelay > 0) {                    // let the previous break land first
            blockHitDelay--;
            InputDriver.halt(player);
            return DigResult.PROGRESSING;
        }
        // Resolve what to actually swing at this tick. First try a raycast-VERIFIED face on the
        // target. If the target is OCCLUDED — no face in line of
        // sight (leaves in front, a tight column overhead) — fall back to breaking the
        // occluder: aim at the target's centre and break whatever the
        // crosshair actually hits, opening the way, instead of holding forever for a clear angle.
        // One guard: never grind a do_not_break / container block as the occluder.
        class_3965 hit = reachableHit(target);
        class_2338 effective = target;
        if (hit == null) {
            class_3965 center = centerRaycast(target);
            if (center != null && !center.method_17777().equals(target)
                    && !BlockHelper.shouldAvoidBreaking(level, center.method_17777())) {
                hit = center;
                effective = center.method_17777();
            }
        }
        InputDriver.halt(player);
        if (hit == null) {
            return DigResult.NO_SHOT;                // no clear shot, nothing safe in the way — stuck
        }
        if (pos == null || !pos.equals(effective)) {
            start(effective, true);
        }
        // dig() may be clearing an OCCLUDER this tick, not the target; report the break (true) ONLY
        // when the TARGET itself goes, so callers that count mined targets / treat the cell as cleared
        // aren't fooled by a leaf we broke just to open the line of sight.
        return advance(hit, effective.equals(target));
    }


    public DigResult digTargetStep(class_2338 target) {
        if (blockHitDelay > 0) {
            blockHitDelay--;
            InputDriver.halt(player);
            return DigResult.PROGRESSING;
        }
        class_3965 hit = reachableHit(target);
        InputDriver.halt(player);
        if (hit == null) {
            return DigResult.NO_SHOT;
        }
        if (pos == null || !pos.equals(target)) {
            start(target, true);
        }
        return advance(hit, true);
    }
    /** Shared per-tick dig advance against a resolved hit (face + aim point). */
    private DigResult advance(class_3965 hit, boolean targetBreak) {
        class_1937 level = player.method_51469();
        // 主手物品与开挖时不同(物品/组件级比较)→ 重开:ABORT 旧进度、
        // 按新手持重新 START(与原版换持重置破坏进度同语义)
        if (started && destroyingItem != null
                && !net.minecraft.class_1799.method_31577(
                        destroyingItem, player.method_6047())) {
            class_2338 samePos = pos;
            start(samePos, false);
        }
        InputDriver.lookAt(player, hit.method_17784());
        class_2350 side = hit.method_17780();
        class_2680 state = level.method_8320(pos);

        if (!started) {
            started = true;
            player.field_13974.method_14263(pos,
                    class_2846.class_2847.field_12968, side, level.method_31600(), -1);
            player.method_6104(class_1268.field_5808);
            if (player.method_31549().field_7477) {
                // creative: START 即破,连挖不设间隔(每 tick 一格)
                reset();
                return targetBreak ? DigResult.BROKE_TARGET : DigResult.BROKE_OCCLUDER;
            }
            if (!state.method_26215()) {
                // START 通道内服务端已自带 attack 与 insta-mine 判定,这里
                // 不再补一次(重复 attack 会翻倍副作用,红石矿甚至会在
                // insta-mine 后被旧 state 的 attack 原地点亮放回)
                if (state.method_26165(player, level, pos) >= 1.0f) {
                    reset();                         // instamine: START broke it (no STOP is sent)
                    return targetBreak ? DigResult.BROKE_TARGET : DigResult.BROKE_OCCLUDER;
                }
            }
            return DigResult.PROGRESSING;            // begin accumulating next tick
        }

        // Survival: accumulate the real per-tick destroy fraction; broadcast the crack.
        progress += state.method_26165(player, level, pos);
        int stage = Math.min(9, (int) (progress * 10.0f));
        level.method_8517(CRACK_ID, pos, stage);
        player.method_6104(class_1268.field_5808);
        if (progress >= 1.0f) {
            // STOP → server destroys. Do NOT clear the crack: the block vanishing
            // removes it (no intact-for-a-frame flicker).
            player.field_13974.method_14263(pos,
                    class_2846.class_2847.field_12973, side, level.method_31600(), -1);
            blockHitDelay = postBreakDelay();
            reset();
            return targetBreak ? DigResult.BROKE_TARGET : DigResult.BROKE_OCCLUDER;
        }
        return DigResult.PROGRESSING;
    }

    private void start(class_2338 target, boolean selectTool) {
        cancel();
        pos = target.method_10062();
        progress = 0.0f;
        started = false;
        if (selectTool) {
            // Hold the best tool BEFORE timing the dig — getDestroyProgress reads the held
            // item, and the pathing cost model prices every break with the best
            // available tool. ToolSelect owns the scan (whole inventory) so this stays
            // consistent with the pathing cost model (ToolSet).
            ToolSelect.holdBestTool(player, player.method_51469().method_8320(pos));
        }
        // 存活引用而非副本:主手栈原地变异(修补吸经验改耐久)时引用相等,
        // 不触发重置;只有真正换持(不同栈对象且物品/组件不同)才重开
        destroyingItem = player.method_6047();
    }

    /** Abandon an IN-PROGRESS dig: ABORT it server-side and clear the crack.
     *  A completed break never comes through here — its crack is left
     *  for the block-break to remove. */
    public void cancel() {
        if (pos != null) {
            if (started) {
                player.field_13974.method_14263(pos,
                        class_2846.class_2847.field_12971,
                        class_2350.field_11033, player.method_51469().method_31600(), -1);
            }
            player.method_51469().method_8517(CRACK_ID, pos, -1);   // clear the crack
        }
        reset();
    }

    /** Clear dig state. Deliberately does NOT touch {@link #blockHitDelay} (a
     *  post-break cooldown that must outlive the break) or the crack overlay. */
    private void reset() {
        pos = null;
        progress = 0.0f;
        started = false;
    }

    /**
     * The first point ON {@code pos} the eye can
     * actually raycast to — the block's shape centre first, then its six face centres. The
     * returned {@link class_3965} carries the exact aim point ({@code getLocation}) AND
     * the face the ray hits ({@code getDirection}), so the dig looks at the real interaction
     * face like a player would. {@code null} if nothing on the block is in line of sight.
     */
    private class_3965 reachableHit(class_2338 pos) {
        class_1937 level = player.method_51469();
        class_243 eye = player.method_33571();
        double reach = com.dwinovo.numen.core.pathing.moves.AimGeometry.blockReachDistance(player);
        class_2680 state = level.method_8320(pos);
        class_265 shape = state.method_26218(level, pos);
        if (shape.method_1110()) {
            shape = class_259.method_1077();
        }
        // Collision-shape centre first (empty collision → whole-cell centre),
        // then the six face centres on the outline shape.
        class_243[] aims = {
                com.dwinovo.numen.core.pathing.moves.AimGeometry.collisionCenter(level, pos, state),
                offsetOn(pos, shape, 0.5, 0.0, 0.5),
                offsetOn(pos, shape, 0.5, 1.0, 0.5),
                offsetOn(pos, shape, 0.5, 0.5, 0.0),
                offsetOn(pos, shape, 0.5, 0.5, 1.0),
                offsetOn(pos, shape, 0.0, 0.5, 0.5),
                offsetOn(pos, shape, 1.0, 0.5, 0.5),
        };
        for (class_243 aim : aims) {
            class_243 dir = aim.method_1020(eye);
            if (dir.method_1027() < 1.0e-8) continue;
            class_243 end = eye.method_1019(dir.method_1029().method_1021(reach));
            class_3965 res = level.method_17742(new class_3959(
                    eye, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, player));
            if (res.method_17783() == class_239.class_240.field_1332 && res.method_17777().equals(pos)) {
                return res;
            }
        }
        return null;
    }

    /**
     * A single ray from the eye to {@code target}'s shape centre — the break-the-occluder
     * fallback when {@link #reachableHit} finds no clear face: the ray lands on the
     * occluder (a leaf / a tight overhead), and we break THAT to open the way. Null on a miss / out
     * of reach. ({@link #reachableHit} already tries the centre first, so if that hit the target it
     * would have returned it; reaching here means the centre ray hits something else.)
     */
    private class_3965 centerRaycast(class_2338 target) {
        class_1937 level = player.method_51469();
        class_243 eye = player.method_33571();
        double reach = com.dwinovo.numen.core.pathing.moves.AimGeometry.blockReachDistance(player);
        class_243 center = class_243.method_24953(target);
        class_243 dir = center.method_1020(eye);
        if (dir.method_1027() < 1.0e-8) {
            return null;
        }
        class_243 end = eye.method_1019(dir.method_1029().method_1021(reach));
        class_3965 res = level.method_17742(new class_3959(
                eye, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, player));
        return res.method_17783() == class_239.class_240.field_1332 ? res : null;
    }

    /** A point on the block's shape:
     *  {@code min*m + max*(1-m)} on each axis. */
    private static class_243 offsetOn(class_2338 pos, class_265 shape, double mx, double my, double mz) {
        double x = shape.method_1091(class_2350.class_2351.field_11048) * mx + shape.method_1105(class_2350.class_2351.field_11048) * (1 - mx);
        double y = shape.method_1091(class_2350.class_2351.field_11052) * my + shape.method_1105(class_2350.class_2351.field_11052) * (1 - my);
        double z = shape.method_1091(class_2350.class_2351.field_11051) * mz + shape.method_1105(class_2350.class_2351.field_11051) * (1 - mz);
        return new class_243(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
    }

}
