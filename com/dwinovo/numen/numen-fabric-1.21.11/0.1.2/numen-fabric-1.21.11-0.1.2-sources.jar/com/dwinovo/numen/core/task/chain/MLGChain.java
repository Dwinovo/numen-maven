package com.dwinovo.numen.core.task.chain;

import com.dwinovo.numen.core.act.Interaction;
import com.dwinovo.numen.core.WorkProfile;
import com.dwinovo.numen.task.Task;
import com.dwinovo.numen.task.TaskState;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2402;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3612;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import com.dwinovo.numen.core.task.survival.SurvivalDecisions;
import com.dwinovo.numen.entity.InputDriver;
import com.dwinovo.numen.entity.NumenPlayer;

/**
 * 摔落自救:掉得够快就在落点铺一摊水(或者垫一块软方块),落进去之后<b>把水收回来</b>。
 *
 * <h2>两个阶段,一条链</h2>
 * <pre>
 * 正在摔        → 瞄准落点、够得着就倒水
 * 落进自己的水  → 换空桶、瞄住那格、收回来
 * </pre>
 * 收水必须留在同一条链里:桶是消耗品,放完不收就只能救一次。而它压过一切(这条链在最前),
 * 所以窗口卡死在 {@link #RECLAIM_TICKS} ——装桶、看向、点右键统共三五刻,到点无条件放手。
 *
 * <h2>够不够得着由桶自己说</h2>
 * 放水和收水都先按<b>原版 {@code BucketItem} 那条射线</b>问一次:从眼睛沿视线打
 * {@code blockInteractionRange}。够得着才点,而且必须真的瞄在那一格上 —— 判据与真正
 * 执行的是同一条射线,不会出现"以为够得着、点下去什么也没发生"。
 *
 * <h2>探落点用五条射线</h2>
 * 她的碰撞箱宽 0.6,单一条竖直射线会从格缝里漏下去。中心加四角各打一条、取最近的那个落点,
 * 边缘擦着掉也找得到。横向漂移不用外推:每刻重探一次,而临放水时她离地只剩一两刻,
 * 那点位移还在碰撞箱以内。
 */
public final class MLGChain implements Task, com.dwinovo.numen.task.reflex.Reflex {

    /** 向下探地的最大深度。 */
    private static final double PROBE_DEPTH = 40.0;

    /**
     * 放完水之后收桶的窗口(刻)。这条链压过自卫、脱困等一切,所以窗口只够动作本身:
     * 装桶、转头、点一下右键。到点就放手,免得水流走了她还锁着身体不放。
     */
    private static final int RECLAIM_TICKS = 20;

    /** 刚倒下去的那摊水在哪一格;没放过水则 null。 */
    private class_2338 placed;
    /** 收桶窗口的倒计时。 */
    private int reclaimTicks;

    /** One diary line per fall episode (reset when the save ends). */
    private boolean notedThisFall;

    public MLGChain() {
    }

    @Override
    public boolean canRun(NumenPlayer companion) {
        if (WorkProfile.of(companion).fearless()) {
            return false;
        }
        return falling(companion) || reclaiming(companion);
    }

    /** 正在快速下落,而且身上有能救自己的东西。 */
    private static boolean falling(NumenPlayer companion) {
        boolean grounded = companion.method_24828() || companion.method_5799()
                || companion.method_5681() || companion.method_6101();
        boolean canSave = waterBucketSlot(companion) >= 0 || softBlockSlot(companion) >= 0;
        return SurvivalDecisions.mlgTriggered(grounded,
                companion.method_18798().field_1351, canSave);
    }

    /** 水还在那儿、手上有空桶、窗口没到点 —— 该去收。 */
    private boolean reclaiming(NumenPlayer companion) {
        if (placed == null || reclaimTicks <= 0) {
            return false;
        }
        if (slotWith(companion, class_1802.field_8550) < 0 || waterBucketSlot(companion) >= 0) {
            return false;   // 没空桶可装,或者已经收到手了
        }
        class_2680 state = companion.method_51469().method_8320(placed);
        return state.method_26227().method_15772() == class_3612.field_15910
                && state.method_26227().method_15771();
    }

    @Override
    public TaskState tick(NumenPlayer companion) {
        if (falling(companion)) {
            return clutch(companion);
        }
        if (placed != null) {
            if (--reclaimTicks <= 0 || !reclaiming(companion)) {
                placed = null;
                return TaskState.RUNNING;
            }
            return reclaim(companion);
        }
        return TaskState.RUNNING;
    }

    /** 摔落中:瞄住落点,够得着就倒水/垫块。 */
    private TaskState clutch(NumenPlayer companion) {
        class_2338 ground = groundBelow(companion);
        if (ground == null) {
            companion.method_36457(90.0f);   // 底下四十格没东西:先朝下候着
            return TaskState.RUNNING;
        }
        InputDriver.lookAt(companion, class_243.method_24953(ground));

        class_3965 aim = bucketRay(companion, class_3959.class_242.field_1348);
        if (aim.method_17783() != class_239.class_240.field_1332 || !aim.method_17777().equals(ground)) {
            return TaskState.RUNNING;   // 还够不着,或者这一刻没瞄准 —— 下一刻更近
        }

        // 下界的水一倒就蒸发,倒下去只是白扔一个桶。判据与原版倒桶同源:
        // 落点处的 WATER_EVAPORATES 环境属性(BucketItem 蒸发分支即此查询)。
        int bucket = companion.method_51469().method_75598().method_75697(
                        net.minecraft.class_12206.field_63755, ground)
                ? -1 : waterBucketSlot(companion);
        if (bucket >= 0) {
            companion.holdInHand(bucket);
            placed = waterLandsAt(companion, aim);
            reclaimTicks = RECLAIM_TICKS;
            Interaction.useInAir(companion, class_1268.field_5808,
                    Interaction.Timing.once()).tick();
            noteSave(companion, "a water bucket");
            return TaskState.RUNNING;
        }
        int block = softBlockSlot(companion);
        if (block >= 0) {
            companion.holdInHand(block);
            Interaction.useBlock(companion, aim, class_1268.field_5808).tick();
            noteSave(companion, "a soft block");
        }
        return TaskState.RUNNING;
    }

    /** 落进自己那摊水:等沉稳了,换空桶把水收回来。 */
    private TaskState reclaim(NumenPlayer companion) {
        if (companion.method_18798().field_1351 < SurvivalDecisions.MLG_SETTLED_SPEED) {
            return TaskState.RUNNING;   // 还在往水里沉,等停稳再收
        }
        InputDriver.lookAt(companion, class_243.method_24953(placed));
        // 空桶那条射线是认水源的(SOURCE_ONLY),和满桶那条不是同一种。
        class_3965 aim = bucketRay(companion, class_3959.class_242.field_1345);
        if (aim.method_17783() != class_239.class_240.field_1332 || !aim.method_17777().equals(placed)) {
            return TaskState.RUNNING;
        }
        int empty = slotWith(companion, class_1802.field_8550);
        if (empty >= 0) {
            companion.holdInHand(empty);
            Interaction.useInAir(companion, class_1268.field_5808,
                    Interaction.Timing.once()).tick();
        }
        return TaskState.RUNNING;
    }

    /** One diary line per fall episode, stamped with the height it survived. */
    private void noteSave(NumenPlayer companion, String means) {
        if (notedThisFall) return;
        notedThisFall = true;
        com.dwinovo.numen.event.NumenEvents.body(companion, "broke a fall with " + means);
    }

    @Override
    public void stop(NumenPlayer companion, StopReason why) {
        if (companion.method_6115()) {
            companion.method_6075();
        }
        companion.method_36457(0.0f);   // stop staring straight down; the resumed task re-aims as needed
        notedThisFall = false;     // the fall episode is over — the next fall diaries anew
        placed = null;
        reclaimTicks = 0;
    }

    @Override
    public String name() {
        return "mlg";
    }

    // ---- Reflex roster paperwork (constitution §6) ----

    @Override
    public String id() {
        return name();
    }

    @Override
    public String describe() {
        return "高处坠落时会用水桶或软方块自救,落地后把水收回来";
    }

    /**
     * 原版 {@code BucketItem} 自己那条射线:从眼睛沿视线打 {@code blockInteractionRange}。
     * 判"够不够得着"和真正执行用的是同一条,所以不会有点了没反应的情况。
     */
    private static class_3965 bucketRay(NumenPlayer companion, class_3959.class_242 fluids) {
        class_243 eye = companion.method_33571();
        class_243 end = eye.method_1019(companion.method_5631(companion.method_36455(), companion.method_36454())
                .method_1021(companion.method_55754()));
        return companion.method_51469().method_17742(new class_3959(
                eye, end, class_3959.class_3960.field_17559, fluids, companion));
    }

    /** 水会落在哪一格 —— 与 {@code BucketItem.use} 同一个算法(可含水的方块就地灌,否则贴面)。 */
    private static class_2338 waterLandsAt(NumenPlayer companion, class_3965 hit) {
        class_2680 state = companion.method_51469().method_8320(hit.method_17777());
        return state.method_26204() instanceof class_2402
                ? hit.method_17777() : hit.method_17777().method_10093(hit.method_17780());
    }

    /**
     * 她会砸到的那一格。碰撞箱中心加四角各打一条竖直射线,取最近的那个 —— 单一条会从
     * 格缝里漏下去,而擦着边掉正是最需要救的那种。
     */
    private static class_2338 groundBelow(NumenPlayer companion) {
        class_238 box = companion.method_5829();
        double y = companion.method_23318();
        class_243[] origins = {
                new class_243(companion.method_23317(), y, companion.method_23321()),
                new class_243(box.field_1323, y, box.field_1321), new class_243(box.field_1320, y, box.field_1321),
                new class_243(box.field_1323, y, box.field_1324), new class_243(box.field_1320, y, box.field_1324),
        };
        class_2338 best = null;
        double bestDrop = Double.MAX_VALUE;
        for (class_243 from : origins) {
            class_3965 hit = companion.method_51469().method_17742(new class_3959(
                    from, from.method_1031(0.0, -PROBE_DEPTH, 0.0),
                    class_3959.class_3960.field_17558, class_3959.class_242.field_1348, companion));
            if (hit.method_17783() != class_239.class_240.field_1332) {
                continue;
            }
            double drop = y - hit.method_17784().field_1351;
            if (drop < bestDrop) {
                bestDrop = drop;
                best = hit.method_17777();
            }
        }
        return best;
    }

    private static int waterBucketSlot(NumenPlayer companion) {
        return slotWith(companion, class_1802.field_8705);
    }

    private static int slotWith(NumenPlayer companion, net.minecraft.class_1792 item) {
        class_1661 inv = companion.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_31574(item)) return i;
        }
        return -1;
    }

    /** Slot of a placeable fall-dampening block (hay / slime), or -1. */
    private static int softBlockSlot(NumenPlayer companion) {
        class_1661 inv = companion.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(class_1802.field_17528) || s.method_31574(class_1802.field_8828)) return i;
        }
        return -1;
    }
}
