package com.dwinovo.numen.core.task.move;
import com.dwinovo.numen.core.task.mine.MineCompanionTask;

import com.dwinovo.numen.core.pathing.bridge.ContextFactory;
import com.dwinovo.numen.core.pathing.goal.GoalCompiler;
import com.dwinovo.numen.core.pathing.util.BlockHelper;
import com.dwinovo.numen.core.Constants;
import com.dwinovo.numen.core.scan.BlockScanner;
import com.dwinovo.numen.core.scan.BlockSearch;
import com.dwinovo.numen.entity.NumenPlayer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

/**
 * goto 的 FIND(就近方块)子系统:起一次 {@link BlockSearch} 找出候选、按 mine 同一道
 * 剪枝入册、编译 anyOf 导航契约、打不通时逐个除名轮换。它与 goto 的坐标三态
 * (BLOCK/COLUMN/YLEVEL)不共享任何逻辑,任务只管驱动。
 *
 * <p>搜索和 {@code scan_blocks} 走同一条路,只是 {@code want} 不同——所以
 * "最近的铁矿在哪"两个工具给的是同一个答案。
 */
final class NearestBlockFinder {

    /** 候选上限、最远环半径、行程预算基准。 */
    private static final int MAX_CANDIDATES = 64;
    private static final int MAX_CHUNK_RADIUS = 32;
    /**
     * 收工判据的配额。要 1 个:她只需要最近的那一个,余下的候选是寻路打不通时的备胎,
     * 顺路捡到多少算多少。要 64 个会逼着搜索一路走到能证明"这 64 个都是最近的"为止
     * ——找一把独一份的工作台时,那就是把整个加载区走一遍。
     */
    private static final int NEAREST_WANTED = 1;
    static final int BUDGET_BLOCKS = 128;

    private final NumenPlayer player;
    private final class_2248 target;
    /** 仍在册的候选格(打不通的会被逐个除名)。 */
    private final List<class_2338> candidates = new ArrayList<>();
    /** 在飞搜索的句柄;0 表示没有在飞的。 */
    private int scanId;
    /** 搜索回来的命中,等 {@link #drain()} 收割。 */
    private List<BlockScanner.Hit> hits;
    private boolean scanDrained;
    /** 候选集编译出的导航契约(候选变动时重建)。 */
    private GoalCompiler.Compiled contract;

    NearestBlockFinder(NumenPlayer player, class_2248 target) {
        this.player = player;
        this.target = target;
    }

    /** 踢一次搜索:按环序由近及远走已加载地形,最近的那个一被证明就收工。 */
    void kickScan() {
        if (!(player.method_51469() instanceof class_3218 level)) {
            scanDrained = true;
            return;
        }
        // 圆心用寻路口径的脚位格(0.1251 上抬 + 台阶取上格)——section 遍历序从它导出。
        class_2338 feet = BlockHelper.playerFeet(level, player.method_23317(), player.method_23318(), player.method_23321());
        scanId = BlockSearch.start(player.method_5667(), level, feet, MAX_CHUNK_RADIUS * 16,
                NEAREST_WANTED, Set.of(target), res -> {
                    scanId = 0;
                    hits = res.matches();
                });
    }

    /** 任务收尾:丢掉还在飞的搜索,免得回执落到一个已经没人读的组件上。 */
    void cancelScan() {
        if (scanId != 0) {
            BlockSearch.cancel(scanId);
            scanId = 0;
            scanDrained = true;
        }
    }

    /** 收割搜索结果:按距离取最近的前 {@link #MAX_CANDIDATES} 个入册。 */
    void drain() {
        if (hits == null) {
            return;   // 还在飞,或者已经收割过
        }
        List<BlockScanner.Hit> found = hits;
        hits = null;
        scanDrained = true;
        // 入册前过与 mine 同一道目标剪枝:挖不动/禁挖(贴液体等)/基岩上下
        // 夹死的格不作候选——省得选中一个走近了也没法处置的目标。问的是这块
        // "能不能被处置",与她怎么走过去无关,按可改地形算。
        var ctx = ContextFactory.forExecution(player,
                com.dwinovo.numen.core.pathing.moves.TerrainPermit.TERRAFORM);
        found.stream()
                .sorted(Comparator.comparingDouble(BlockScanner.Hit::distance))
                .map(h -> h.pos().method_10062())
                .filter(p -> MineCompanionTask.plausibleToBreak(
                        ctx, p, ctx.get(p.method_10263(), p.method_10264(), p.method_10260())))
                .limit(MAX_CANDIDATES)
                .forEach(candidates::add);
        // "她为什么去了那一块而不是最近的" 要靠这一行答:有几个被剪掉了,直线最近的是哪个。
        // 实际去哪一个由 A* 在候选之间按代价定,到达回执里有坐标,两者一对就清楚了。
        Constants.LOG.info("[numen-task] goto FIND {} → {} hit(s), {} usable after pruning,"
                        + " straight-line nearest {}",
                class_7923.field_41175.method_10221(target).method_12832(), found.size(), candidates.size(),
                candidates.isEmpty() ? "none" : candidates.get(0).method_23854());
        rebuildContract();
    }

    boolean hasCandidates() {
        return !candidates.isEmpty();
    }

    /** 搜索已收割,且没有候选可给了。 */
    boolean exhausted() {
        return scanId == 0 && scanDrained;
    }

    /** 当前候选集的导航契约;无候选为 null。 */
    GoalCompiler.Compiled contract() {
        return contract;
    }

    private void rebuildContract() {
        contract = candidates.isEmpty() ? null : GoalCompiler.anyOf(candidates);
    }

    /** 打不通时的轮换:还有得换就把最近候选除名并重建契约,只剩一个则不动。 */
    boolean rotateAfterFailure() {
        if (candidates.size() <= 1) {
            return false;
        }
        int nearest = nearestIndex();
        if (nearest >= 0) {
            candidates.remove(nearest);
        }
        rebuildContract();
        return true;
    }

    /** 离身体最近的在册候选;无候选返回 null。 */
    class_2338 nearest() {
        int i = nearestIndex();
        return i < 0 ? null : candidates.get(i);
    }

    private int nearestIndex() {
        int best = -1;
        double bestD = Double.MAX_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            class_2338 c = candidates.get(i);
            double d = player.method_5649(c.method_10263() + 0.5, c.method_10264() + 0.5, c.method_10260() + 0.5);
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        return best;
    }
}
