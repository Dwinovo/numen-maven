package com.dwinovo.numen.core.act;

import com.dwinovo.numen.entity.InputDriver;

import com.dwinovo.numen.entity.NumenPlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import com.dwinovo.numen.core.FailureType;

/**
 * The most-native interaction primitive for a fake-player body:
 * aim the eyes at a target, then "press"
 * one mouse button (left = ATTACK, right = USE) with a {@link Timing}. Every
 * higher-level action is a thin layer on top: mining = ATTACK a block (hold),
 * {@code attack} = ATTACK an entity, eat/bow = hold USE in the air.
 *
 * <h2>Native dispatch (the same server entry points a real client's packets reach)</h2>
 * <ul>
 *   <li>ATTACK + block  → {@link BlockDigger} (creative insta / survival timed) → {@code handleBlockBreakAction} START/STOP (server destroys)</li>
 *   <li>ATTACK + entity → {@code player.attack} (cooldown-scaled damage / sweep / knockback)</li>
 *   <li>USE + block     → {@code gameMode.useItemOn} (vanilla place / activate), both hands tried</li>
 *   <li>USE + entity    → {@code entity.interact} then {@code player.interactOn} (trade / breed / mount), both hands</li>
 *   <li>USE + air       → {@code gameMode.useItem} (+ a hold for food / bow)</li>
 * </ul>
 *
 * <p>准星语义的 USE({@link #forHit} 建的)另有一步收尾:方块/实体没吃掉点击时落到
 * 物品自用——真客户端的完整右键顺序,见 {@link #fallthroughUse}。指定命中面的外科
 * 原语({@link #useBlock(NumenPlayer, class_3965, class_1268)})没有这一步。
 *
 * <h2>Timing</h2>
 * {@link Timing#once()} taps once; {@link Timing#repeat} taps N times spaced by an
 * interval (auto-click a button, grind a mob); {@link Timing#hold()} holds the
 * button until the action self-completes (a block breaks, food finishes);
 * {@link Timing#hold(int)} holds up to N ticks then releases (draw + loose a bow).
 *
 * <p>Stateful + ticked (like {@link BlockDigger} / {@code PlayerNav}). The caller
 * walks the body within reach first; this only aims and presses.
 */
public final class Interaction {

    public enum Status { RUNNING, DONE, FAILED }
    public enum Button { ATTACK, USE }

    /** Vanilla block-interaction reach (survival); creative is 5. */
    private static final double REACH = 4.5;
    /** The two hands USE tries, main first (vanilla interaction tries both). */
    private static final class_1268[] HANDS = {class_1268.field_5808, class_1268.field_5810};

    /**
     * When and how often the button fires
     * (once / continuous / interval). {@code hold} actions press-and-hold until
     * the action finishes on its own (breaking, eating) or {@code maxHold} elapses
     * (bow); discrete actions fire {@code limit} times spaced by {@code interval}.
     */
    public static final class Timing {
        final boolean hold;
        final int limit;     // discrete fires (>=1); ignored for hold
        final int interval;  // ticks between discrete fires (>=1)
        final int maxHold;   // hold: release after this many ticks; 0 = until self-complete

        private Timing(boolean hold, int limit, int interval, int maxHold) {
            this.hold = hold;
            this.limit = limit;
            this.interval = interval;
            this.maxHold = maxHold;
        }

        /** One single press. */
        public static Timing once() {
            return new Timing(false, 1, 1, 0);
        }

        /** {@code times} presses, each spaced {@code interval} ticks apart. */
        public static Timing repeat(int times, int interval) {
            return new Timing(false, Math.max(1, times), Math.max(1, interval), 0);
        }

        /** Hold until the action finishes on its own (block broken / food eaten). */
        public static Timing hold() {
            return new Timing(true, -1, 1, 0);
        }

        /** Hold up to {@code maxTicks}, then release (e.g. draw a bow and loose). */
        public static Timing hold(int maxTicks) {
            return new Timing(true, -1, 1, Math.max(1, maxTicks));
        }
    }

    private final NumenPlayer player;
    private final Button button;
    private final class_2338 block;     // non-null → block target
    private final class_1297 entity;      // non-null → entity target
    private final class_1268 hand;
    private final Timing timing;

    private final BlockDigger digger; // only for ATTACK + block
    private class_3965 presetHit; // USE+block: an exact hit the caller already resolved (placement)
    /**
     * 准星语义的 USE 才有的兜底:方块/实体没吃掉点击时,同一次按键落到物品自用
     * ({@code gameMode.useItem})——真客户端就是这个顺序(useItemOn 不消费就发
     * ServerboundUseItemPacket),桶找水、船找水面、掷物出手都住在那条路上。
     * 外科原语(指定命中面的放置、开台)不设兜底:那里落空就该落空,兜底会把
     * 手里的东西扔出去。false = 兜底关闭或被任务层否决(身体约束物品)。
     */
    private boolean itemFallthrough;
    private int fires;
    private int cooldown;             // ticks until the next discrete press
    private boolean started;          // USE+air: the hold has begun
    private int held;                 // USE+air: ticks held so far
    private boolean hardFail;         // a fire hit an unrecoverable error
    private String failReason = "interaction failed";
    private FailureType failType = FailureType.UNKNOWN;
    private String lastUseOutcome = "not fired";

    private Interaction(NumenPlayer player, Button button, class_2338 block, class_1297 entity,
                        class_1268 hand, Timing timing) {
        this.player = player;
        this.button = button;
        this.block = block == null ? null : block.method_10062();
        this.entity = entity;
        this.hand = hand;
        this.timing = timing;
        this.digger = (button == Button.ATTACK && block != null) ? new BlockDigger(player) : null;
    }

    // ---- factories (default timings; overloads take an explicit Timing) ----

    /** Left-click a block: break it (held until gone; creative insta / survival timed). */
    public static Interaction attackBlock(NumenPlayer p, class_2338 pos) {
        return new Interaction(p, Button.ATTACK, pos, null, class_1268.field_5808, Timing.hold());
    }

    /** Left-click an entity once (cooldown-gated native attack). */
    public static Interaction attackEntity(NumenPlayer p, class_1297 target) {
        return attackEntity(p, target, Timing.once());
    }

    public static Interaction attackEntity(NumenPlayer p, class_1297 target, Timing timing) {
        return new Interaction(p, Button.ATTACK, null, target, class_1268.field_5808, timing);
    }

    /** Right-click a block: place / activate with the held item (raycasts to {@code pos}). */
    public static Interaction useBlock(NumenPlayer p, class_2338 pos, class_1268 hand) {
        return new Interaction(p, Button.USE, pos, null, hand, Timing.once());
    }

    /** Right-click a pre-resolved block hit — placement / precise activation supplies
     *  the exact support face, so this skips the raycast and presses against {@code hit}. */
    public static Interaction useBlock(NumenPlayer p, class_3965 hit, class_1268 hand) {
        Interaction i = new Interaction(p, Button.USE, hit.method_17777(), null, hand, Timing.once());
        i.presetHit = hit;
        return i;
    }

    /** Right-click in the air with the held item, on the given {@link Timing}
     *  ({@code hold()} eats food / {@code hold(n)} draws and looses a bow). */
    public static Interaction useInAir(NumenPlayer p, class_1268 hand, Timing timing) {
        return new Interaction(p, Button.USE, null, null, hand, timing);
    }

    /** vanilla {@code Minecraft.rightClickDelay} — held right-click re-fires this often. */
    private static final int RIGHT_CLICK_DELAY = 4;
    /** A "hold forever" fire count; the owning task stops us after hold_ticks / on completion. */
    private static final int CONTINUOUS = 1_000_000;

    /**
     * The vanilla crosshair pick: one ray from the eyes along the CURRENT
     * look, resolving the CLOSER of a block or an entity (else MISS). A wall occludes a mob behind
     * it (entities are searched only as near as the block hit). {@code reach} 4.5 = survival.
     */
    public static class_239 nativeRaytrace(NumenPlayer player, double reach) {
        class_1937 level = player.method_51469();
        class_243 eye = player.method_33571();
        class_243 reachVec = player.method_5828(1.0f).method_1021(reach);
        class_243 end = eye.method_1019(reachVec);
        class_3965 block = level.method_17742(new class_3959(
                eye, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, player));
        double maxSq = block.method_17783() == class_239.class_240.field_1333
                ? reach * reach : block.method_17784().method_1025(eye);
        class_238 box = player.method_5829().method_18804(reachVec).method_1014(1.0);
        class_3966 ent = class_1675.method_18075(
                player, eye, end, box, e -> !e.method_7325() && e.method_5863(), maxSq);
        return ent != null ? ent : block;   // entity (closer than the block) wins, else the block/miss
    }

    /**
     * Build the native action for a resolved crosshair {@code hit} + {@code button}, mapping
     * {@code holdTicks} to the cell's natural cadence — a 6-cell (button × target) dispatch:
     * <ul>
     *   <li>ATTACK·BLOCK → break (BlockDigger holds till the block is gone);</li>
     *   <li>ATTACK·ENTITY → hit (tap = one cooldown-gated hit; hold = keep hitting);</li>
     *   <li>USE·BLOCK → activate (tap once; hold re-clicks every rightClickDelay — modded crank);</li>
     *   <li>USE·ENTITY → interact (tap once; hold re-clicks);</li>
     *   <li>USE·AIR → useItem (tap = throw; hold = charge/eat up to ticks, or self-complete);</li>
     *   <li>ATTACK·AIR → {@code null} (left-click air does nothing).</li>
     * </ul>
     * {@code holdTicks}: 0 = tap, &gt;0 / -1 = hold. The block/entity hit is used as-is (the
     * native raytrace already resolved the exact face/point — no re-raycast). The caller drives
     * the returned object to completion and enforces the hold duration.
     *
     * @param itemFallthrough USE 的准星兜底开关(见 {@link #itemFallthrough}):方块/实体
     *                        没吃掉点击就落到物品自用。任务层拿它挡身体约束物品——
     *                        手里是食物/末影珍珠时传 false,免得点了块石头把自己喂了。
     */
    public static Interaction forHit(NumenPlayer p, class_239 hit, Button button, int holdTicks,
                                     boolean itemFallthrough) {
        boolean hold = holdTicks != 0;
        switch (hit.method_17783()) {
            case field_1332 -> {
                class_3965 bh = (class_3965) hit;
                if (button == Button.ATTACK) {
                    return attackBlock(p, bh.method_17777());
                }
                Interaction i = new Interaction(p, Button.USE, bh.method_17777(), null,
                        class_1268.field_5808,
                        hold ? Timing.repeat(CONTINUOUS, RIGHT_CLICK_DELAY) : Timing.once());
                i.presetHit = bh;   // use the robust native hit, no re-raycast
                i.itemFallthrough = itemFallthrough;
                return i;
            }
            case field_1331 -> {
                class_1297 e = ((class_3966) hit).method_17782();
                if (button == Button.ATTACK) {
                    return attackEntity(p, e, hold ? Timing.repeat(CONTINUOUS, 1) : Timing.once());
                }
                Interaction i = new Interaction(p, Button.USE, null, e, class_1268.field_5808,
                        hold ? Timing.repeat(CONTINUOUS, RIGHT_CLICK_DELAY) : Timing.once());
                i.itemFallthrough = itemFallthrough;
                return i;
            }
            default -> {   // MISS = air
                if (button == Button.ATTACK) {
                    return null;
                }
                Timing t = hold ? (holdTicks > 0 ? Timing.hold(holdTicks) : Timing.hold()) : Timing.once();
                return useInAir(p, class_1268.field_5808, t);
            }
        }
    }

    public String failReason() {
        return failReason;
    }

    /** Structured cause of a {@link Status#FAILED}, for the reactive task layer to branch on. */
    public FailureType failType() {
        return failType;
    }

    public Status tick() {
        if (button == Button.ATTACK && block != null) {
            return breakBlock();                       // inherently continuous
        }
        if (button == Button.USE && block == null && entity == null) {
            return useAir();
        }
        return discrete();                             // attack entity / use block / use entity
    }

    // ---- ATTACK + block: continuous break ----

    private Status breakBlock() {
        if (player.method_51469().method_8320(block).method_26215()) return Status.DONE;
        return digger.dig(block) ? Status.DONE : Status.RUNNING;
    }

    // ---- USE + air: tap or hold (food / bow) ----

    private Status useAir() {
        InputDriver.halt(player);
        if (!started) {
            started = true;
            player.field_13974.method_14256(player, player.method_51469(), player.method_5998(hand), hand);
            if (!timing.hold) return Status.DONE;      // single tap (throw / instant use)
        }
        if (!player.method_6115()) return Status.DONE; // e.g. food finished eating
        if (timing.maxHold > 0 && ++held >= timing.maxHold) {
            player.method_6075();                 // e.g. loose the bow
            return Status.DONE;
        }
        return Status.RUNNING;
    }

    // ---- discrete: attack entity / use block / use entity (once or repeat) ----

    private Status discrete() {
        if (cooldown > 0) {
            cooldown--;
            return Status.RUNNING;
        }
        boolean fired = switch (button) {
            case ATTACK -> fireAttackEntity();
            case USE -> entity != null ? fireUseEntity() : fireUseBlock();
        };
        if (hardFail) return Status.FAILED;
        if (!fired) return Status.RUNNING;             // soft wait (attack cooldown not ready)
        if (++fires >= timing.limit) return Status.DONE;
        cooldown = timing.interval;
        return Status.RUNNING;
    }

    private boolean fireAttackEntity() {
        if (entity == null || !entity.method_5805()) return false;
        InputDriver.halt(player);
        InputDriver.lookAt(player, entity.method_33571());
        boolean recovering = entity instanceof net.minecraft.class_1309 living
                && living.field_6235 > 0;
        // 无敌帧与冷却的判据在 Swing 里,战斗任务用的是同一处。
        if (!com.dwinovo.numen.core.combat.Swing.mayStrike(
                false, recovering, player.method_7261(0.0f))) {
            return false;
        }
        player.method_5728(false);                    // 疾跑会让原版取消暴击判定
        player.method_7324(entity);                         // native damage / cooldown / sweep / knockback (resets the ticker itself)
        player.method_6104(class_1268.field_5808);
        return true;
    }

    private boolean fireUseBlock() {
        InputDriver.halt(player);
        class_3965 hit;
        if (presetHit != null) {
            hit = presetHit;                                  // caller already resolved the support face
            InputDriver.lookAt(player, hit.method_17784());
        } else {
            InputDriver.lookAt(player, class_243.method_24953(block));
            hit = raycastBlock();
            if (hit == null) {
                failReason = "can't see the block to use (out of reach or line of sight blocked)";
                failType = FailureType.OCCLUDED;
                hardFail = true;
                return false;
            }
        }
        StringBuilder outcome = new StringBuilder();
        for (class_1268 h : HANDS) {
            class_1269 res = player.field_13974.method_14262(
                    player, player.method_51469(), player.method_5998(h), h, hit);
            String handName = h == class_1268.field_5808 ? "main_hand" : "off_hand";
            if (res.method_23665()) {
                player.method_6104(h);
                lastUseOutcome = "consumed (" + handName + "=" + res + ")";
                return true;
            }
            if (outcome.length() > 0) outcome.append(", ");
            outcome.append(handName).append('=').append(res);
        }
        if (fallthroughUse()) {
            return true;
        }
        // Nothing consumed (e.g. empty hand on a non-interactive block) — still a press.
        lastUseOutcome = outcome.toString();
        return true;
    }

    /**
     * 准星 USE 的收尾一步:方块/实体都没吃掉点击时,把同一次按键落到物品自用——
     * 与真客户端一致(useItemOn 不消费就发 ServerboundUseItemPacket → Item.use)。
     * 桶、船、钓竿这类物品的行为全写在 Item.use 里,自带各自的流体射线,
     * 所以准星根本不需要点中水。开关见 {@link #itemFallthrough}。
     *
     * @return true = 有一只手的物品吃掉了这次按键
     */
    private boolean fallthroughUse() {
        if (!itemFallthrough) {
            return false;
        }
        for (class_1268 h : HANDS) {
            if (player.field_13974.method_14256(player, player.method_51469(),
                    player.method_5998(h), h).method_23665()) {
                player.method_6104(h);
                lastUseOutcome = "consumed (item self-use, "
                        + (h == class_1268.field_5808 ? "main_hand" : "off_hand") + ")";
                return true;
            }
        }
        return false;
    }

    /**
     * The vanilla verdict of the most recent USE-on-block press: {@code "consumed (...)"}
     * or the per-hand results (e.g. {@code "main_hand=FAIL, off_hand=PASS"}). A press that
     * consumes can STILL have placed nothing (the item's own rules refused) — placement
     * callers must verify the world afterwards, and this string is what they log when a
     * press quietly did nothing.
     */
    public String lastUseOutcome() {
        return lastUseOutcome;
    }

    private boolean fireUseEntity() {
        if (entity == null || !entity.method_5805()) {
            failReason = "the entity is gone";
            failType = FailureType.TARGET_LOST;
            hardFail = true;
            return false;
        }
        InputDriver.halt(player);
        InputDriver.lookAt(player, entity.method_33571());
        for (class_1268 h : HANDS) {
            if (entity.method_5688(player, h).method_23665()) {       // animals / villagers
                return true;
            }
            if (player.method_7287(entity, h).method_23665()) {     // item frames / leads
                return true;
            }
        }
        fallthroughUse();          // 实体没吃掉点击:真客户端同样落到物品自用
        return true;               // a press with no effect is still a press
    }

    /** Raycast from the eyes along the current look; the hit must be the target block. */
    private class_3965 raycastBlock() {
        class_1937 level = player.method_51469();
        class_243 eye = player.method_33571();
        class_243 look = player.method_5828(1.0f);
        class_243 end = eye.method_1031(look.field_1352 * REACH, look.field_1351 * REACH, look.field_1350 * REACH);
        class_3965 hit = level.method_17742(new class_3959(
                eye, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, player));
        if (hit.method_17783() == class_239.class_240.field_1332 && hit.method_17777().equals(block)) {
            return hit;
        }
        return null;
    }

    /** Abandon any in-progress interaction (clears a dig overlay / releases a held use). */
    public void stop() {
        if (digger != null) digger.cancel();
        if (player.method_6115()) player.method_6075();
        InputDriver.halt(player);
    }
}
