package com.dwinovo.numen.core.mixin;

import com.dwinovo.numen.core.scan.TargetIndex;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Feed every successful server-side block state change into {@link TargetIndex}.
 *
 * <p>{@code ServerLevel.updatePOIOnBlockStateChange} (1.21.5 renamed it from
 * {@code onBlockStateChange}; signature and both call sites unchanged) is the exact hook vanilla's
 * own POI index consumes: it fires for every change routed through {@code Level.setBlock} (players,
 * pistons, explosions, commands, growth, fluids) and for worldgen writes via
 * {@code WorldGenRegion.setBlock}. The handler is O(1) for irrelevant blocks and a single volatile
 * read when no task has any target registered, so this costs effectively nothing while no
 * companion is mining.
 */
@Mixin(class_3218.class)
public abstract class ServerLevelBlockChangeMixin {

    @Inject(method = "updatePOIOnBlockStateChange", at = @At("HEAD"))
    private void numen$feedTargetIndex(class_2338 pos, class_2680 oldState, class_2680 newState, CallbackInfo ci) {
        TargetIndex.onBlockChange((class_3218) (Object) this, pos, oldState, newState);
    }
}
