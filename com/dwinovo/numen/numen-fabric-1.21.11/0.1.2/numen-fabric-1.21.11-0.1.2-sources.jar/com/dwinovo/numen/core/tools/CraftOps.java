package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.agent.tool.ToolArgs;
import com.dwinovo.numen.core.PlayerInv;
import com.dwinovo.numen.core.act.Interaction;
import com.dwinovo.numen.core.scan.BlockScanner;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.task.TaskResult;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1869;
import net.minecraft.class_2304;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3908;
import net.minecraft.class_3955;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.minecraft.class_8566;
import net.minecraft.class_8786;

/**
 * The {@code craft} tool: the whole craft flow in one call — pick a recipe whose
 * materials the inventory can feed, lay the ingredients into a REAL crafting grid
 * via menu clicks, and shift-take the result. Everything runs through the vanilla
 * container path ({@code menu.clicked} on a live {@code CraftingMenu} /
 * {@code InventoryMenu}), so recipe-unlock, stats, ingredient remainders (bucket
 * back from milk) and container-observing mods all see a normal player crafting —
 * items never appear out of thin air.
 *
 * <p>Grid choice: an already-open grid that fits &gt; the body's own 2x2 &gt; a
 * crafting table within reach (right-clicked open, closed after). No table in
 * reach is a refusal with the nearest table's coordinates (or "place one") — going
 * there is the planner's move, not this tool's.
 */
public final class CraftOps {

    /** Eye-to-block-center reach for using a crafting table without walking. */
    private static final double REACH = 4.5;
    /** "Where IS one" hint scan when no table is in reach (horizontal / vertical). */
    private static final int HINT_H = 16, HINT_V = 6;
    /** Rounds of fill-grid + shift-take; each round crafts up to a full stack per cell. */
    private static final int MAX_ROUNDS = 16;

    /** A crafting recipe candidate with its (input-independent) output count. */
    private record Cand(class_3955 recipe, int outCount) {}

    /** One grid cell to fill: row-major position in the target grid + what goes there. */
    private record Placement(int gridPos, class_1856 ing) {}

    /** The clickable geometry of an open crafting surface. */
    private record Grid(int w, int h, int[] cells, int result) {}

    public String craft(String item_id, Integer count, NumenPlayer self) {
        class_1792 target = ToolArgs.parseItem(item_id);
        int want = count == null ? 1 : Math.clamp(count, 1, 256);
        if (!(self.method_51469() instanceof class_3218 level)) {
            return TaskResult.fail("crafting needs a server level.").toJson();
        }
        String name = class_7923.field_41178.method_10221(target).method_12832();

        List<Cand> candidates = candidatesFor(level, target);
        if (candidates.isEmpty()) {
            return TaskResult.fail("no crafting recipe makes " + name + " — check lookup_recipe: it may "
                    + "be smelted, stonecut, smithed, mined or traded instead.").toJson();
        }

        // Reclaim anything stranded in an already-open grid before counting materials.
        Grid pre = findGrid(self.field_7512);
        if (pre != null) {
            sweepGrid(self.field_7512, self, pre);
        }

        // Materials gate: keep recipes the inventory can feed at least once; remember the
        // closest miss for the refusal message.
        Map<class_1792, Integer> pool = poolOf(self.field_7512, self);
        List<Cand> satisfiable = new ArrayList<>();
        List<String> bestMissing = null;
        for (Cand c : candidates) {
            List<class_1856> ings = ingredientsOf(c.recipe());
            if (feasibleBatch(ings, pool, 1) == 1) {
                satisfiable.add(c);
            } else {
                List<String> missing = missingFor(ings, pool);
                if (bestMissing == null || missing.size() < bestMissing.size()) {
                    bestMissing = missing;
                }
            }
        }
        if (satisfiable.isEmpty()) {
            return TaskResult.fail("not enough materials for " + name + " — missing: "
                    + String.join(", ", bestMissing)
                    + ". Collect or craft those first, then craft again.").toJson();
        }

        // Pick the crafting surface: the open grid if a satisfiable recipe fits it, else the
        // body's own 2x2, else a crafting table within reach.
        class_1703 menu = null;
        Grid grid = null;
        Cand chosen = null;
        boolean openedTable = false;
        String station = null;

        Grid cur = findGrid(self.field_7512);
        if (cur != null) {
            for (Cand c : satisfiable) {
                if (fits(c.recipe(), cur.w(), cur.h())) {
                    menu = self.field_7512;
                    grid = cur;
                    chosen = c;
                    station = (menu == self.field_7498)
                            ? "Used your own 2x2 grid." : "Used the already-open grid.";
                    break;
                }
            }
        }
        if (chosen == null) {
            for (Cand c : satisfiable) {
                if (fits(c.recipe(), 2, 2)) {
                    chosen = c;
                    break;
                }
            }
            if (chosen != null) {
                if (self.field_7512 != self.field_7498) {
                    self.method_7346();   // a gridless GUI (chest, furnace) was open — put it away
                }
                menu = self.field_7498;
                grid = findGrid(menu);
                station = "Used your own 2x2 grid.";
            }
        }
        if (chosen == null) {
            for (Cand c : satisfiable) {
                if (fits(c.recipe(), 3, 3)) {
                    chosen = c;
                    break;
                }
            }
            if (chosen == null) {
                return TaskResult.fail(name + "'s recipe needs a grid larger than 3x3 (modded station) — "
                        + "interact_at that station and use inspect_gui + transfer instead.").toJson();
            }
            class_3955 recipe = chosen.recipe();
            class_2338 table = BlockScanner.nearestBlock(level, self.method_24515(),
                    self.method_33571(), (int) Math.ceil(REACH), 3, REACH,
                    (pos, state) -> state.method_26204() instanceof class_2304);
            if (table == null) {
                // 类型认不出 ≠ 没有:有模组在放置时把工作台原地换成自家方块实体实现,
                // 注册名、方块类、标签全变了,只有行为没变——所以第二遍问行为。
                table = BlockScanner.nearestBlock(level, self.method_24515(),
                        self.method_33571(), (int) Math.ceil(REACH), 3, REACH,
                        (pos, state) -> opensFittingGrid(level, pos, state, self, recipe));
            }
            if (table == null) {
                class_2338 hintPos = BlockScanner.nearestBlock(level, self.method_24515(),
                        self.method_33571(), HINT_H, HINT_V, Double.MAX_VALUE,
                        (pos, state) -> state.method_26204() instanceof class_2304);
                return TaskResult.fail(name + " is a 3x3 recipe — it needs a crafting table within reach "
                        + "(~4 blocks). " + (hintPos != null
                                ? "Nearest one is at " + hintPos.method_10263() + "," + hintPos.method_10264() + ","
                                        + hintPos.method_10260() + " — goto it, then craft again."
                                : "None within " + HINT_H + " blocks — craft a crafting_table (4 planks, "
                                        + "fits your own 2x2) and build it (op `set`), then craft "
                                        + "again.")).toJson();
            }
            // 开台走 act 的按键原语:看向、右键、挥手都是身体动作,不归工具层手搓。
            // 预解析命中(不走射线)保持既有语义——门禁是"够得着",不是"看得见"。
            Interaction.useBlock(self,
                    new class_3965(class_243.method_24953(table), class_2350.field_11036, table, false),
                    class_1268.field_5808).tick();
            Grid opened = findGrid(self.field_7512);
            if (self.field_7512 == self.field_7498 || opened == null
                    || !fits(chosen.recipe(), opened.w(), opened.h())) {
                return TaskResult.fail("right-clicked the crafting table at " + table.method_10263() + ","
                        + table.method_10264() + "," + table.method_10260()
                        + " but no crafting menu opened (blocked, or another mod overrides it).").toJson();
            }
            menu = self.field_7512;
            grid = opened;
            openedTable = true;
            station = "Used the crafting table at " + table.method_10263() + "," + table.method_10264() + ","
                    + table.method_10260() + ".";
        }

        try {
            return doCraft(menu, grid, chosen, target, want, name, station, self);
        } finally {
            sweepGrid(menu, self, grid);
            if (openedTable) {
                self.method_7346();
            }
        }
    }

    // ---- the fill / take loop ----

    private static String doCraft(class_1703 menu, Grid grid, Cand chosen, class_1792 target,
                                  int want, String name, String station, NumenPlayer self) {
        if (!settleCarried(menu, self)) {
            return TaskResult.fail("the cursor is holding items and no inventory slot is free to put "
                    + "them down — free a slot first (drop_items).").toJson();
        }
        Map<class_1792, Integer> before = poolOf(menu, self);
        List<class_1856> ings = ingredientsOf(chosen.recipe());
        int output = Math.max(1, chosen.outCount());
        int crafted = 0;
        String stopped = null;

        for (int round = 0; round < MAX_ROUNDS && crafted < want; round++) {
            int craftsLeft = Math.ceilDiv(want - crafted, output);
            int batch = feasibleBatch(ings, poolOf(menu, self), Math.min(craftsLeft, 64));
            if (batch <= 0) {
                stopped = "ran out of materials";
                break;
            }
            // Lay out this batch: per cell, the matching inventory item with the deepest supply.
            Map<class_1792, Integer> sim = new HashMap<>(poolOf(menu, self));
            boolean laidOut = true;
            for (Placement pl : placements(chosen.recipe(), grid.w())) {
                class_1792 pick = pickItem(pl.ing(), sim);
                int cellIdx = pick == null ? -1 : grid.cells()[pl.gridPos()];
                if (cellIdx < 0 || placeIntoCell(menu, self, cellIdx, pick, pl.ing(), batch) < batch) {
                    laidOut = false;
                    break;
                }
                sim.merge(pick, -batch, Integer::sum);
            }
            if (!laidOut) {
                sweepGrid(menu, self, grid);
                stopped = "couldn't lay out the grid (materials changed mid-craft?)";
                break;
            }
            if (menu.field_7761.get(grid.result()).method_7677().method_7960()) {
                sweepGrid(menu, self, grid);
                stopped = "the laid-out grid doesn't form this recipe (unexpected — mod interference?)";
                break;
            }
            int have0 = PlayerInv.count(self.method_31548(), target);
            menu.method_7593(grid.result(), 0, class_1713.field_7794, self);   // vanilla mass-craft + onTake
            self.method_6104(class_1268.field_5808);
            sweepGrid(menu, self, grid);
            int gained = PlayerInv.count(self.method_31548(), target) - have0;
            if (gained <= 0) {
                stopped = "inventory is full — the result doesn't fit";
                break;
            }
            crafted += gained;
        }

        if (crafted <= 0) {
            return TaskResult.fail("crafted nothing — "
                    + (stopped == null ? "unknown reason" : stopped) + ".").toJson();
        }

        // Report material flow as inventory deltas (covers remainders like buckets coming back).
        Map<class_1792, Integer> after = poolOf(menu, self);
        List<String> used = new ArrayList<>();
        List<String> back = new ArrayList<>();
        for (class_1792 item : new TreeSet<>(union(before, after))) {
            int delta = after.getOrDefault(item, 0) - before.getOrDefault(item, 0);
            String path = class_7923.field_41178.method_10221(item).method_12832();
            if (delta < 0) {
                used.add((-delta) + "x " + path);
            } else if (delta > 0 && item != target) {
                back.add(delta + "x " + path);
            }
        }

        int carrying = PlayerInv.count(self.method_31548(), target);
        StringBuilder msg = new StringBuilder("crafted " + crafted + "x " + name);
        if (crafted < want) {
            msg.append(" (wanted ").append(want).append(" — stopped: ").append(stopped).append(")");
        }
        if (!used.isEmpty()) {
            msg.append(" — used ").append(String.join(", ", used));
        }
        if (!back.isEmpty()) {
            msg.append("; got back ").append(String.join(", ", back));
        }
        msg.append(". ").append(station).append(" Now carrying ").append(carrying).append("x ")
                .append(name).append(".");
        return TaskResult.ok(msg.toString(), Map.of("crafted", crafted, "carrying", carrying)).toJson();
    }

    private static TreeSet<class_1792> union(Map<class_1792, Integer> a, Map<class_1792, Integer> b) {
        TreeSet<class_1792> keys = new TreeSet<>((x, y) -> class_7923.field_41178.method_10221(x).method_12833(
                class_7923.field_41178.method_10221(y)));
        keys.addAll(a.keySet());
        keys.addAll(b.keySet());
        return keys;
    }

    // ---- recipe lookup / feasibility ----

    private static List<Cand> candidatesFor(class_3218 level, class_1792 target) {
        List<Cand> out = new ArrayList<>();
        // 1.21.2+ 服务端没有按类型取表的公开口(recipeMap 不公开),全量遍历、只认
        // 合成配方——执行层本来就只会往标准合成格里摆料,机器配方在这里被跳过。
        for (class_8786<?> holder : level.method_64577().method_8126()) {
            if (!(holder.comp_1933() instanceof class_3955 cr)) {
                continue;
            }
            try {
                // 产出依赖输入的配方(烟花、镶零件的装备)静态匹配答不了——模组
                // 自己标的 isSpecial 就是这句话,原版合成书同样不列它们。
                if (cr.method_8118()) {
                    continue;
                }
                class_1799 result = RecipeProbe.resultOf(cr, level.method_30349());
                if (result.method_7960() || result.method_7909() != target
                        || !RecipeProbe.usableIngredients(cr)) {
                    continue;
                }
                if (ingredientsOf(cr).isEmpty()) {
                    continue;   // 没有实际输入的配方摆不进格子
                }
                out.add(new Cand(cr, result.method_7947()));
            } catch (RuntimeException broken) {
                // 坏一条丢一条,记下 id 方便去上游反馈;绝不让它杀掉整个调用
                com.dwinovo.numen.core.Constants.LOG.debug(
                        "[numen-craft] 配方 {} 坏了,跳过: {}", holder.comp_1932(), broken.toString());
            }
        }
        return out;
    }

    /** The recipe's non-empty ingredients — the per-craft shopping list. */
    private static List<class_1856> ingredientsOf(class_3955 recipe) {
        // 1.21.2+ 静态清单在 PlacementInfo(网格空位不进清单);过滤仅防坏配方
        return recipe.method_61671().method_64675().stream().filter(i -> !i.method_65799()).toList();
    }

    private static boolean fits(class_3955 recipe, int w, int h) {
        if (recipe instanceof class_1869 s) {
            return s.method_8150() <= w && s.method_8158() <= h;
        }
        return ingredientsOf(recipe).size() <= w * h;
    }

    /** Where each ingredient goes in a grid of width {@code gridW} (shaped anchors top-left). */
    private static List<Placement> placements(class_3955 recipe, int gridW) {
        List<Placement> out = new ArrayList<>();
        if (recipe instanceof class_1869 s) {
            int w = s.method_8150(), h = s.method_8158();
            var cells = s.method_61693();   // 1.21.2+: List<Optional<Ingredient>>,空格 = empty
            for (int r = 0; r < h; r++) {
                for (int c = 0; c < w; c++) {
                    class_1856 ing = cells.get(r * w + c).orElse(null);
                    if (ing != null && !ing.method_65799()) {
                        out.add(new Placement(r * gridW + c, ing));
                    }
                }
            }
        } else {
            int pos = 0;
            for (class_1856 ing : recipe.method_61671().method_64675()) {
                if (!ing.method_65799()) {
                    out.add(new Placement(pos++, ing));
                }
            }
        }
        return out;
    }

    /** The matching item with the deepest supply in {@code pool}, or null. */
    private static class_1792 pickItem(class_1856 ing, Map<class_1792, Integer> pool) {
        class_1792 best = null;
        int bestN = 0;
        for (var h : ing.method_8105().toList()) {   // 1.21.2+: Stream<Holder<Item>>
            class_1792 item = h.comp_349();
            int n = pool.getOrDefault(item, 0);
            if (n > bestN) {
                best = item;
                bestN = n;
            }
        }
        return best;
    }

    /**
     * The largest per-cell stack size {@code <= wantBatch} the pool can feed for one grid
     * layout (each cell drawing greedily, shared items competing). 0 = can't craft once.
     */
    private static int feasibleBatch(List<class_1856> ings, Map<class_1792, Integer> pool0, int wantBatch) {
        int n = Math.max(0, wantBatch);
        while (n > 0) {
            Map<class_1792, Integer> pool = new HashMap<>(pool0);
            int cap = n;
            boolean ok = true;
            for (class_1856 ing : ings) {
                class_1792 pick = pickItem(ing, pool);
                int have = pick == null ? 0 : pool.getOrDefault(pick, 0);
                int usable = pick == null ? 0 : Math.min(have, new class_1799(pick).method_7914());
                if (usable < n) {
                    cap = usable;
                    ok = false;
                    break;
                }
                pool.merge(pick, -n, Integer::sum);
            }
            if (ok) {
                return n;
            }
            n = cap;
        }
        return 0;
    }

    /** "3x iron_ingot (have 1)" lines for every ingredient the pool can't cover once. */
    private static List<String> missingFor(List<class_1856> ings, Map<class_1792, Integer> pool) {
        Map<String, int[]> tally = new LinkedHashMap<>();       // desc -> [need]
        Map<String, class_1856> rep = new LinkedHashMap<>();
        for (class_1856 ing : ings) {
            String desc = QueryExtraOps.describeIngredient(ing);
            tally.computeIfAbsent(desc, k -> new int[1])[0]++;
            rep.putIfAbsent(desc, ing);
        }
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, int[]> e : tally.entrySet()) {
            int need = e.getValue()[0];
            int have = 0;
            for (var h : rep.get(e.getKey()).method_8105().toList()) {   // 1.21.2+: Stream<Holder<Item>>
                have += pool.getOrDefault(h.comp_349(), 0);
            }
            if (have < need) {
                out.add(need + "x " + e.getKey() + " (have " + have + ")");
            }
        }
        return out;
    }

    // ---- menu plumbing ----

    /**
     * 这一格右键能不能开出装得下这张配方的合成格——第二遍找台的判据只有这一条,
     * 问的是行为不是类型。把它的菜单按标准生命周期造出来问一句格子多大,问完立刻
     * 走 {@code removed} 收掉:构造时有副作用的(箱子把盖子计数加一)也就当场退掉,
     * 世界里什么都没发生。菜单不按套路造的(构造即抛),当它不是工作台。
     */
    private static boolean opensFittingGrid(class_3218 level, class_2338 pos, class_2680 state,
                                            NumenPlayer self, class_3955 recipe) {
        class_3908 provider = state.method_26196(level, pos);
        if (provider == null) {
            return false;
        }
        try {
            class_1703 menu = provider.createMenu(0, self.method_31548(), self);
            if (menu == null) {
                return false;
            }
            try {
                Grid grid = findGrid(menu);
                return grid != null && fits(recipe, grid.w(), grid.h());
            } finally {
                menu.method_7595(self);
            }
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Detect a crafting surface generically: CraftingContainer-backed slots + the ResultSlot. */
    private static Grid findGrid(class_1703 menu) {
        if (menu == null) {
            return null;
        }
        int w = 0, h = 0, result = -1;
        int[] cells = null;
        for (class_1735 slot : menu.field_7761) {
            if (slot instanceof class_1734) {
                result = slot.field_7874;
                continue;
            }
            if (slot.field_7871 instanceof class_8566 cc) {
                if (cells == null) {
                    w = cc.method_17398();
                    h = cc.method_17397();
                    cells = new int[w * h];
                    Arrays.fill(cells, -1);
                }
                int pos = slot.method_34266();
                if (pos >= 0 && pos < cells.length) {
                    cells[pos] = slot.field_7874;
                }
            }
        }
        return (cells == null || result < 0) ? null : new Grid(w, h, cells, result);
    }

    /**
     * The body's spendable materials as seen through {@code menu}: player-side slots only,
     * and only main inventory + hotbar (container slots 0–35) — armor and offhand stay on.
     */
    private static Map<class_1792, Integer> poolOf(class_1703 menu, NumenPlayer self) {
        Map<class_1792, Integer> pool = new HashMap<>();
        if (menu == null) {
            return pool;
        }
        for (class_1735 slot : menu.field_7761) {
            if (slot.field_7871 != self.method_31548() || slot.method_34266() >= 36) {
                continue;
            }
            class_1799 s = slot.method_7677();
            if (!s.method_7960()) {
                pool.merge(s.method_7909(), s.method_7947(), Integer::sum);
            }
        }
        return pool;
    }

    /** Put {@code n} of {@code item} into one grid cell via clicks; returns how many landed. */
    private static int placeIntoCell(class_1703 menu, NumenPlayer self, int cellIdx,
                                     class_1792 item, class_1856 ing, int n) {
        int placed = 0;
        int guard = 0;
        while (placed < n && guard++ < 40) {
            int src = -1;
            for (class_1735 slot : menu.field_7761) {
                if (slot.field_7871 != self.method_31548() || slot.method_34266() >= 36) {
                    continue;
                }
                class_1799 s = slot.method_7677();
                if (!s.method_7960() && s.method_31574(item) && ing.method_8093(s)) {
                    src = slot.field_7874;
                    break;
                }
            }
            if (src < 0) {
                break;
            }
            int before = placed;
            MenuOps.dripInto(menu, self, src, cellIdx, n - placed);
            placed = menu.field_7761.get(cellIdx).method_7677().method_7947();
            if (placed <= before) {
                break;   // 这一轮没放进任何东西(抓空/拒收),别空转
            }
        }
        return placed;
    }

    /** Shift every non-empty grid cell back into the inventory. */
    private static void sweepGrid(class_1703 menu, NumenPlayer self, Grid grid) {
        if (menu == null || grid == null) {
            return;
        }
        for (int idx : grid.cells()) {
            if (idx >= 0 && idx < menu.field_7761.size() && !menu.field_7761.get(idx).method_7677().method_7960()) {
                menu.method_7593(idx, 0, class_1713.field_7794, self);
            }
        }
    }

    /** Park a carried stack into a free main-inventory slot; false if none accepts it. */
    private static boolean settleCarried(class_1703 menu, NumenPlayer self) {
        if (menu.method_34255().method_7960()) {
            return true;
        }
        for (class_1735 slot : menu.field_7761) {
            if (slot.field_7871 != self.method_31548() || slot.method_34266() >= 36) {
                continue;
            }
            if (slot.method_7677().method_7960()) {
                menu.method_7593(slot.field_7874, 0, class_1713.field_7790, self);
                return menu.method_34255().method_7960();
            }
        }
        return false;
    }

}
