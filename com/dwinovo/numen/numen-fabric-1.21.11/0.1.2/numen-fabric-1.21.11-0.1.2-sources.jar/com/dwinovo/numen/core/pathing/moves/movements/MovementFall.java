package com.dwinovo.numen.core.pathing.moves.movements;
import com.dwinovo.numen.core.pathing.moves.AimGeometry;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2399;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3621;
import com.dwinovo.numen.core.pathing.moves.CalculationContext;
import com.dwinovo.numen.core.pathing.moves.TerrainPermit;
import com.dwinovo.numen.core.pathing.moves.ChunkLoadedTest;
import com.dwinovo.numen.core.pathing.moves.Input;
import com.dwinovo.numen.core.pathing.moves.Movement;
import com.dwinovo.numen.core.pathing.moves.MovementHelper;
import com.dwinovo.numen.core.pathing.moves.MovementState;
import com.dwinovo.numen.core.pathing.moves.MovementStatus;
import com.dwinovo.numen.core.pathing.moves.MutableMoveResult;
import com.dwinovo.numen.core.pathing.settings.NavSettings;

import static com.dwinovo.numen.core.pathing.moves.ActionCosts.COST_INF;

/** 坠落 ≥2 格:走出边缘垂直下落到落点,超过安全高度时空中放水桶接底。 */
public class MovementFall extends Movement {

    public MovementFall(class_3222 player, class_2338 src, class_2338 dest) {
        super(player, src, dest, buildPositionsToBreak(src, dest));
    }

    /** 成本复用下降原语的坠落分档;落点不符则本实例不适用。 */
    @Override
    public double calculateCost(CalculationContext context, MutableMoveResult result) {
        MovementDescend.cost(context, src.method_10263(), src.method_10264(), src.method_10260(),
                dest.method_10263(), dest.method_10260(), result);
        if (result.y != dest.method_10264()) {
            return COST_INF; // 该位置属于下降而非坠落
        }
        return result.cost;
    }

    /** src 加上落点上方整列(下落全程身体都会经过)。 */
    @Override
    protected Set<class_2338> calculateValidPositions() {
        Set<class_2338> set = new HashSet<>();
        set.add(src);
        for (int y = src.method_10264() - dest.method_10264(); y >= 0; y--) {
            set.add(dest.method_10086(y));
        }
        return set;
    }

    /** 重算坠落分档:本次坠落是否需要空中放水桶。 */
    private boolean willPlaceBucket() {
        // 只问要不要放水桶(hasWaterBucket),与地形许可无关;MLG 放水再收回,不改世界
        CalculationContext context = new CalculationContext(player, player.method_51469(),
                ChunkLoadedTest.ALWAYS, false, TerrainPermit.PRESERVE);
        MutableMoveResult result = new MutableMoveResult();
        return MovementDescend.dynamicFallCost(context, src.method_10263(), src.method_10264(), src.method_10260(),
                dest.method_10263(), dest.method_10260(), 0,
                context.get(dest.method_10263(), src.method_10264() - 2, dest.method_10260()), result);
    }

    @Override
    public MovementState updateState(MovementState state) {
        super.updateState(state);
        if (state.getStatus() != MovementStatus.RUNNING) {
            return state;
        }

        class_1937 level = player.method_51469();
        class_2338 feet = feet(player);
        class_243 eye = player.method_33571();
        class_243 destCenter = AimGeometry.blockCenter(dest);
        float toDestYaw = AimGeometry.yawTo(eye, destCenter);
        boolean forcedRotation = false;
        class_2680 destState = level.method_8320(dest);
        boolean isWater = destState.method_26227().method_15772() instanceof class_3621;
        if (!isWater && willPlaceBucket() && !feet.equals(dest)) {
            int bucketSlot = hotbarSlotWith(class_1802.field_8705);
            if (bucketSlot == -1 || level.method_27983() == class_1937.field_25180) {
                return state.setStatus(MovementStatus.UNREACHABLE);
            }
            if (player.method_23318() - dest.method_10264() < NavSettings.get().blockReachDistance
                    && !player.method_24828()) {
                // 够得着落点了:切水桶、竖直向下瞄,命中落点即放水
                player.method_31548().method_61496(bucketSlot);
                state.setTarget(new MovementState.MovementTarget(toDestYaw, 90.0f, true));
                forcedRotation = true;
                if (MovementPlacement.isLookingAt(player, dest)
                        || MovementPlacement.isLookingAt(player, dest.method_10074())) {
                    state.setInput(Input.CLICK_RIGHT, true);
                }
            }
        }
        if (!forcedRotation) {
            state.setTarget(new MovementState.MovementTarget(toDestYaw,
                    AimGeometry.pitchTo(eye, destCenter), false));
        }
        if (feet.equals(dest) && (player.method_23318() - feet.method_10264() < 0.094 || isWater)) { // 睡莲容差
            if (isWater) {
                // 落进自己放的水:收水再走
                int emptySlot = hotbarSlotWith(class_1802.field_8550);
                if (emptySlot != -1) {
                    player.method_31548().method_61496(emptySlot);
                    if (player.method_18798().field_1351 >= 0) {
                        return state.setInput(Input.CLICK_RIGHT, true);
                    }
                    return state; // 还在下沉,等浮上来再收
                } else {
                    if (player.method_18798().field_1351 >= 0) {
                        return state.setStatus(MovementStatus.SUCCESS);
                    }
                    // 下沉中不提前返回:水面下可能有暗流,继续对中
                }
            } else {
                return state.setStatus(MovementStatus.SUCCESS);
            }
        }
        // 空中对中:预测下 tick 位置偏出 0.1 就往中心挤,竖速大时按潜行刹车
        if (Math.abs(player.method_23317() + player.method_18798().field_1352 - destCenter.field_1352) > 0.1
                || Math.abs(player.method_23321() + player.method_18798().field_1350 - destCenter.field_1350) > 0.1) {
            if (!player.method_24828() && Math.abs(player.method_18798().field_1351) > 0.4) {
                state.setInput(Input.SNEAK, true);
            }
            state.setInput(Input.MOVE_FORWARD, true);
        }
        // 梯子回避:下方有梯子时把瞄点往梯子朝向偏,免得挂上去
        class_2350 avoidDir = avoid();
        class_2382 avoid = avoidDir == null ? null : avoidDir.method_62675();
        if (avoid == null) {
            avoid = src.method_10059(dest);
        } else {
            double dist = Math.abs(avoid.method_10263() * (destCenter.field_1352 - avoid.method_10263() / 2.0 - player.method_23317()))
                    + Math.abs(avoid.method_10260() * (destCenter.field_1350 - avoid.method_10260() / 2.0 - player.method_23321()));
            if (dist < 0.6) {
                state.setInput(Input.MOVE_FORWARD, true);
            } else if (!player.method_24828()) {
                state.setInput(Input.SNEAK, false);
            }
        }
        if (!forcedRotation) {
            class_243 destCenterOffset = new class_243(destCenter.field_1352 + 0.125 * avoid.method_10263(),
                    destCenter.field_1351, destCenter.field_1350 + 0.125 * avoid.method_10260());
            state.setTarget(new MovementState.MovementTarget(
                    AimGeometry.yawTo(eye, destCenterOffset),
                    AimGeometry.pitchTo(eye, destCenterOffset), false));
        }
        return state;
    }

    /** 脚下 15 格内的第一段梯子的朝向(回避向量)。 */
    private class_2350 avoid() {
        for (int i = 0; i < 15; i++) {
            class_2680 state = player.method_51469().method_8320(feet(player).method_10087(i));
            if (state.method_26204() == class_2246.field_9983) {
                return state.method_11654(class_2399.field_11253);
            }
        }
        return null;
    }

    /** 还没走出边缘(或还在准备期)才可取消;空中动量收不回来。 */
    @Override
    protected boolean safeToCancel(MovementState state) {
        return feet(player).equals(src) || state.getStatus() != MovementStatus.RUNNING;
    }

    /** 快捷栏里找(物品与组件都相同的)指定物品槽位,找不到返回 -1。 */
    private int hotbarSlotWith(class_1792 item) {
        int slot = player.method_31548().method_7395(new net.minecraft.class_1799(item));
        return net.minecraft.class_1661.method_7380(slot) ? slot : -1;
    }

    /** 从 src.above() 到 dest 的整列(高 diffY+2)。 */
    private static class_2338[] buildPositionsToBreak(class_2338 src, class_2338 dest) {
        int diffY = Math.abs(src.method_10264() - dest.method_10264());
        class_2338[] toBreak = new class_2338[diffY + 2];
        for (int i = 0; i < toBreak.length; i++) {
            toBreak[i] = new class_2338(dest.method_10263(), src.method_10264() + 1 - i, dest.method_10260());
        }
        return toBreak;
    }

    /** 只有顶端四格需要挖时才走通用挖掘;更深处(可能是水)忽略。 */
    @Override
    protected boolean prepared(MovementState state) {
        if (state.getStatus() == MovementStatus.WAITING) {
            return true;
        }
        for (int i = 0; i < 4 && i < positionsToBreak.length; i++) {
            if (!MovementHelper.canWalkThrough(player.method_51469(), positionsToBreak[i])) {
                return super.prepared(state);
            }
        }
        return true;
    }
}
