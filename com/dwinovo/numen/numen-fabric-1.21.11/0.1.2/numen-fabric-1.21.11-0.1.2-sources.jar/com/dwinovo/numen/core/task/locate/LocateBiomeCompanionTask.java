package com.dwinovo.numen.core.task.locate;
import com.dwinovo.numen.core.task.IdSuggest;
import com.dwinovo.numen.core.task.CompassUtil;
import com.dwinovo.numen.core.scan.SearchBudget;
import com.dwinovo.numen.core.scan.RingSpiral;
import com.dwinovo.numen.core.FailureType;

import com.dwinovo.numen.task.TaskState;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.core.task.base.AbstractCompanionTask;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.class_1959;
import net.minecraft.class_1966;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_5742;
import net.minecraft.class_6544;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

/**
 * Goal for {@code locate_biome}: find the nearest instance of a biome (by id)
 * or biome family (by {@code #tag}) in the entity's CURRENT dimension —
 * vanilla {@code /locate biome} semantics, time-sliced across ticks.
 *
 * <h2>The Nature's Compass model</h2>
 * Biomes need no chunks at all: {@link class_1966#method_38109} answers from
 * climate noise alone, so unlike the structure locator there is no expensive
 * fallback — just bounded sampling. Mirrors Nature's Compass (MattCzyr):
 * <ul>
 *   <li>sample on a {@value #SAMPLE_STEP_BLOCKS}-block grid, walked as an
 *       expanding square ring spiral (their worker walks the same square,
 *       turn by turn; a ring is the same set of points);</li>
 *   <li>probe SEVERAL Y levels per column ({@code Mth.outFromOrigin}, 64-block
 *       steps from the entity's own Y) — Nether and cave biomes are 3D, a
 *       single-Y scan misses warped forests under/above you;</li>
 *   <li>per-tick work caps via the GLOBAL {@link SearchBudget}
 *       shared with structure searches (NC uses a tick worker; same idea).</li>
 * </ul>
 * Coverage: {@value #SEARCH_RADIUS_RINGS} rings × {@value #SAMPLE_STEP_BLOCKS}
 * blocks = 6400 blocks, exactly vanilla /locate biome's radius; NC's default
 * reach is 10k with the same 64-block grid. Worst-case full miss ≈ 40k samples
 * ≈ 160 budgeted ticks ≈ 8s, far under the task deadline.
 */
public final class LocateBiomeCompanionTask extends AbstractCompanionTask<LocateBiomeTaskRecord> {

    /** Sample grid pitch — NC's default (16 × biome size 4). Vanilla /locate uses 32. */
    private static final int SAMPLE_STEP_BLOCKS = 64;
    /** Rings of samples; 100 × 64 = 6400 blocks, vanilla /locate biome's radius. */
    private static final int SEARCH_RADIUS_RINGS = 100;
    /** Vertical probe pitch within a sample column (NC uses the same 64). */
    private static final int Y_STEP_BLOCKS = 64;

    private Predicate<class_6880<class_1959>> match;
    private class_1966 biomeSource;
    private class_6544.class_6552 sampler;
    private int[] yBlocks;          // probe heights, ordered outward from entity Y
    private int centerX, centerZ;   // block coords of the search origin
    private int ring, perimIdx;
    private boolean exhausted;
    private class_2338 best;
    private String failReason = "not on a server level";

    public LocateBiomeCompanionTask(NumenPlayer player, LocateBiomeTaskRecord record) {
        super(player, record);
    }

    @Override
    protected void onStart() {
        match = null;
        best = null;
        ring = 0;
        perimIdx = 0;
        exhausted = false;

        if (!(player.method_51469() instanceof class_3218 sl)) {
            fail("not on a server level", FailureType.UNKNOWN);
            return;
        }
        match = resolveBiomePredicate(sl, r.biome.trim());
        if (match == null) {
            fail(failReason, FailureType.UNKNOWN);   // failReason set by resolveBiomePredicate
            return;
        }
        biomeSource = sl.method_14178().method_12129().method_12098();
        sampler = sl.method_14178().method_41248().method_42371();
        yBlocks = class_3532.method_42117(player.method_31478(),
                sl.method_31607() + 1, sl.method_31600(), Y_STEP_BLOCKS).toArray();
        centerX = player.method_31477();
        centerZ = player.method_31479();
    }

    /** @return a holder predicate, or null on bad input (failReason set). */
    private Predicate<class_6880<class_1959>> resolveBiomePredicate(class_3218 sl, String arg) {
        var registry = sl.method_30349().method_30530(class_7924.field_41236);
        if (arg.startsWith("#")) {
            class_2960 tagId = class_2960.method_12829(arg.substring(1));
            if (tagId == null) {
                failReason = "invalid biome tag: " + arg;
                return null;
            }
            class_6862<class_1959> tag = class_6862.method_40092(class_7924.field_41236, tagId);
            if (registry.method_46733(tag).isEmpty()) {
                failReason = isStructureTag(sl, tagId)
                        ? arg + " is a STRUCTURE tag, not a biome tag — call "
                                + "locate_structure(structure=\"" + arg + "\") instead"
                        : "unknown biome tag: " + arg + " — try a biome id like "
                                + "minecraft:warped_forest, or tags like #minecraft:is_forest";
                return null;
            }
            return holder -> holder.method_40220(tag);
        }
        class_2960 id = class_2960.method_12829(arg);
        if (id == null || registry.method_46746(class_5321.method_29179(class_7924.field_41236, id)).isEmpty()) {
            if (id != null && isStructureId(sl, id)) {
                failReason = arg + " is a STRUCTURE, not a biome — call "
                        + "locate_structure(structure=\"" + arg + "\") instead";
                return null;
            }
            String suggestion = IdSuggest.closest(
                    registry.method_42017().map(ref -> ref.method_40237().method_29177()), arg);
            failReason = "unknown biome: " + arg
                    + (suggestion != null
                            ? " — did you mean " + suggestion + "?"
                            : " — use a biome id like minecraft:warped_forest / "
                                    + "minecraft:desert, or a tag like #minecraft:is_forest; "
                                    + "load_skill(world_atlas) lists every id");
            return null;
        }
        class_5321<class_1959> key = class_5321.method_29179(class_7924.field_41236, id);
        return holder -> holder.method_40225(key);
    }

    private static boolean isStructureId(class_3218 sl, class_2960 id) {
        return sl.method_30349().method_30530(class_7924.field_41246)
                .method_46746(class_5321.method_29179(class_7924.field_41246, id)).isPresent();
    }

    private static boolean isStructureTag(class_3218 sl, class_2960 tagId) {
        return sl.method_30349().method_30530(class_7924.field_41246)
                .method_46733(class_6862.method_40092(class_7924.field_41246, tagId)).isPresent();
    }

    @Override
    protected TaskState onTick() {
        if (!(player.method_51469() instanceof class_3218 sl)) {
            fail("not on a server level", FailureType.UNKNOWN);
            return TaskState.FAILED;
        }
        SearchBudget.refresh(sl.method_8503());
        while (true) {
            if (exhausted) {
                return TaskState.SUCCESS;   // best == null → "not found"
            }
            if (!SearchBudget.tryBiomeSample()) {
                return TaskState.RUNNING;    // pool drained — resume next tick
            }
            class_2338 hit = sampleNext();
            if (hit != null) {
                best = hit;                  // ring order ⇒ first hit ≈ nearest
                return TaskState.SUCCESS;
            }
        }
    }

    /** Probe the next spiral column (all Y levels); non-null = matching pos. */
    private class_2338 sampleNext() {
        // Ring perimeter walk, same shape as the structure locator's spiral.
        while (perimIdx >= RingSpiral.perimeter(ring)) {
            ring++;
            perimIdx = 0;
            if (ring > SEARCH_RADIUS_RINGS) {
                exhausted = true;
                return null;
            }
        }
        int[] d = RingSpiral.offset(ring, perimIdx++);
        int x = centerX + d[0] * SAMPLE_STEP_BLOCKS;
        int z = centerZ + d[1] * SAMPLE_STEP_BLOCKS;
        int qx = class_5742.method_33100(x);
        int qz = class_5742.method_33100(z);
        for (int y : yBlocks) {
            class_6880<class_1959> biome = biomeSource.method_38109(qx, class_5742.method_33100(y), qz, sampler);
            if (match.test(biome)) {
                return new class_2338(x, y, z);
            }
        }
        return null;
    }

    /** Search tasks paint no path overlay — nothing to release. */
    @Override
    protected void cleanup() {}

    @Override
    protected Map<String, Object> resultData() {
        Map<String, Object> data = new HashMap<>();
        data.put("biome", r.biome);
        if (best != null) {
            class_2338 me = player.method_24515();
            int dx = best.method_10263() - me.method_10263();
            int dz = best.method_10260() - me.method_10260();
            int dist = (int) Math.sqrt((double) dx * dx + (double) dz * dz);
            data.put("found", true);
            data.put("x", best.method_10263());
            data.put("y", best.method_10264());
            data.put("z", best.method_10260());
            data.put("direction", CompassUtil.compass(dx, dz));
            data.put("horizontal_distance", dist);
        } else {
            data.put("found", false);
        }
        return data;
    }

    @Override
    protected String successMessage() {
        if (best != null) {
            class_2338 me = player.method_24515();
            int dx = best.method_10263() - me.method_10263();
            int dz = best.method_10260() - me.method_10260();
            int dist = (int) Math.sqrt((double) dx * dx + (double) dz * dz);
            String dir = CompassUtil.compass(dx, dz);
            return "nearest " + r.biome + " around " + best.method_10263() + ","
                    + best.method_10264() + "," + best.method_10260() + " (" + dir + ", ~" + dist
                    + " blocks; accurate to ~" + SAMPLE_STEP_BLOCKS + "). goto the "
                    + "x/z (pick a sensible y for the terrain), then confirm with "
                    + "scan_blocks or scan_nearby_entities.";
        }
        String dim = player.method_51469().method_27983().method_29177().method_12832();
        int searched = Math.min(ring, SEARCH_RADIUS_RINGS) * SAMPLE_STEP_BLOCKS;
        return "no " + r.biome + " within ~" + searched
                + " blocks IN THIS DIMENSION (" + dim + ") — check the biome's "
                + "home dimension (warped_forest/soul_sand_valley: nether; most "
                + "others: overworld) or travel a few thousand blocks and retry";
    }

    @Override
    protected String timeoutMessage() {
        int searched = Math.min(ring, SEARCH_RADIUS_RINGS) * SAMPLE_STEP_BLOCKS;
        return "biome search deadline hit after ~"
                + searched + " blocks with no " + r.biome
                + " — retrying immediately is fine, or travel first";
    }

    @Override
    protected String cancelledMessage() {
        return "locate_biome interrupted";
    }
}
