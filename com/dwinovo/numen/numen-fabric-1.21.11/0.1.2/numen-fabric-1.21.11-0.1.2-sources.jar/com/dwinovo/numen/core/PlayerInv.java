package com.dwinovo.numen.core;

import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

/**
 * Small adapter giving the companion task layer the {@code SimpleContainer}-style
 * inventory operations it grew up on (count / remove-by-type / add-with-leftover)
 * over the player's native {@link class_1661}. The Mob used a 27-slot
 * SimpleContainer; the player body uses its full Inventory (hotbar + main +
 * armor + offhand), all reachable via {@link class_1661#method_5439()} /
 * {@link class_1661#method_5438(int)}.
 */
public final class PlayerInv {

    private PlayerInv() {}

    /**
     * 建造能动用的格数:快捷栏 + 主背包,<b>不含盔甲栏与副手</b>。
     *
     * <p>建造那一族(报价、逐格闸门、实扣)必须共用这一个数,而不是各写各的循环。这条
     * 口径分岔过两次,症状一模一样:一整叠木板放在副手,数 41 格的那一方说"料够了",
     * 数 36 格的那一方每格都判缺料——玩家看着手里那叠木板,而我们两张嘴说两样话。
     *
     * <p>为什么是 36 而不是 41:盔甲是穿在身上的,副手是她另一只手里握着的东西(演出要
     * 用),都不是"备料"。把它们算进可用材料,等于说她会拆自己的胸甲去砌墙。
     */
    public static final int BUILDABLE_SLOTS = 36;

    /** Total count of {@code item} across the whole inventory (armor + offhand included). */
    public static int count(class_1661 inv, class_1792 item) {
        int n = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960() && s.method_31574(item)) n += s.method_7947();
        }
        return n;
    }

    /**
     * 背着的数量:只数 36 个主格(含快捷栏),穿在身上和副手握着的不算。
     * "它离开了背包"这类判断要用这一个——{@link #count} 含盔甲槽,头盔从手里挪到头上数量不变。
     */
    public static int carriedCount(class_1661 inv, class_1792 item) {
        int n = 0;
        for (int i = 0; i < Math.min(BUILDABLE_SLOTS, inv.method_67533().size()); i++) {
            class_1799 s = inv.method_67533().get(i);
            if (!s.method_7960() && s.method_31574(item)) n += s.method_7947();
        }
        return n;
    }

    /** 建造口径的存量:只数 {@link #BUILDABLE_SLOTS} 格。报价与实扣共用这一个。 */
    public static int buildableCount(class_1661 inv, class_1792 item) {
        int limit = Math.min(BUILDABLE_SLOTS, inv.method_67533().size());
        int n = 0;
        for (int i = 0; i < limit; i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960() && s.method_31574(item)) n += s.method_7947();
        }
        return n;
    }

    /** First slot holding {@code item}, or -1. */
    public static int findSlot(class_1661 inv, class_1792 item) {
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960() && s.method_31574(item)) return i;
        }
        return -1;
    }


    /**
     * Add {@code stack} to the inventory; returns whatever didn't fit (empty if
     * all fit). Mirrors {@code SimpleContainer.addItem}'s leftover contract over
     * {@link class_1661#method_7394(class_1799)} (which mutates the stack down by what fit).
     */
    public static class_1799 add(class_1661 inv, class_1799 stack) {
        inv.method_7394(stack);
        return stack;   // Inventory.add consumed what fit; remainder stays here
    }
}
