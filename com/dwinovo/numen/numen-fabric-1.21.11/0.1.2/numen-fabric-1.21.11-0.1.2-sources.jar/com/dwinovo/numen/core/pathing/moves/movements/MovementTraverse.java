package com.dwinovo.numen.core.pathing.moves.movements;
import com.dwinovo.numen.core.pathing.moves.AimGeometry;

import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2399;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2577;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_3222;
import com.dwinovo.numen.core.pathing.moves.CalculationContext;
import com.dwinovo.numen.core.pathing.moves.Input;
import com.dwinovo.numen.core.pathing.moves.Movement;
import com.dwinovo.numen.core.pathing.moves.MovementHelper;
import com.dwinovo.numen.core.pathing.moves.MovementState;
import com.dwinovo.numen.core.pathing.moves.MovementStatus;
import com.dwinovo.numen.core.pathing.moves.MutableMoveResult;
import com.dwinovo.numen.core.pathing.settings.NavSettings;

import static com.dwinovo.numen.core.pathing.moves.ActionCosts.COST_INF;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.SNEAK_ONE_BLOCK_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.SPRINT_MULTIPLIER;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.WALK_ONE_BLOCK_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.WALK_ONE_OVER_SOUL_SAND_COST;

/** 平移一格:走到水平相邻的同高度格,必要时挖穿两格身位或在落脚点下搭桥。 */
public class MovementTraverse extends Movement {

    /** 桥块是否一直都在(false 表示本次执行需要现搭)。 */
    private boolean wasTheBridgeBlockAlwaysThere = true;

    public MovementTraverse(class_3222 player, class_2338 src, class_2338 dest) {
        super(player, src, dest, new class_2338[]{dest.method_10084(), dest}, dest.method_10074());
    }

    @Override
    public void reset() {
        super.reset();
        wasTheBridgeBlockAlwaysThere = true;
    }

    /**
     * 成本。走路分支:落脚点可站(或霜行者可冻),水中用水速、
     * 灵魂沙两端各计半罚、水面行走加罚,身位两格通透且非水可疾跑;
     * 需要挖时站在梯/藤上挖速 ×5。搭桥分支:落脚点下可替换才可放,
     * 侧贴面(排除来向)可贴按普通走速计,只能背贴时按潜行速
     * ×(潜行/平走) 计,灵魂沙/非双层台阶/水上出发不可背贴。
     */
    public static double cost(CalculationContext context, int x, int y, int z, int destX, int destZ) {
        class_2680 pb0 = context.get(destX, y + 1, destZ);
        class_2680 pb1 = context.get(destX, y, destZ);
        class_2680 destOn = context.get(destX, y - 1, destZ);
        class_2680 srcDown = context.get(x, y - 1, z);
        class_2248 srcDownBlock = srcDown.method_26204();
        boolean standingOnABlock = MovementHelper.mustBeSolidToWalkOn(context, x, y - 1, z, srcDown);
        boolean frostWalker = standingOnABlock && !context.assumeWalkOnWater
                && MovementHelper.canUseFrostWalker(context, destOn);
        if (frostWalker || MovementHelper.canWalkOn(context, destX, y - 1, destZ, destOn)) {
            // 走路分支:桥本来就在
            double WC = WALK_ONE_BLOCK_COST;
            boolean water = false;
            if (MovementHelper.isWater(pb0) || MovementHelper.isWater(pb1)) {
                WC = context.waterWalkSpeed;
                water = true;
            } else {
                if (destOn.method_26204() == class_2246.field_10114) {
                    WC += (WALK_ONE_OVER_SOUL_SAND_COST - WALK_ONE_BLOCK_COST) / 2;
                } else if (frostWalker) {
                    // 霜行者冻出的冰面走起来没有水面罚金
                } else if (destOn.method_26204() == class_2246.field_10382) {
                    WC += context.walkOnWaterOnePenalty;
                }
                if (srcDownBlock == class_2246.field_10114) {
                    WC += (WALK_ONE_OVER_SOUL_SAND_COST - WALK_ONE_BLOCK_COST) / 2;
                }
            }
            double hardness1 = MovementHelper.getMiningDurationTicks(context, destX, y, destZ, pb1, false);
            if (hardness1 >= COST_INF) {
                return COST_INF;
            }
            // 只有上格计入落沙链:挖穿上格才会引沙下坠
            double hardness2 = MovementHelper.getMiningDurationTicks(context, destX, y + 1, destZ, pb0, true);
            if (hardness1 == 0 && hardness2 == 0) {
                if (!water && context.canSprint) {
                    // 身位通透且不在水里,可以疾跑(灵魂沙上也能疾跑,不必排除)
                    WC *= SPRINT_MULTIPLIER;
                }
                return WC;
            }
            if (srcDownBlock == class_2246.field_9983 || srcDownBlock == class_2246.field_10597) {
                // 挂在梯/藤上挖极慢
                hardness1 *= 5;
                hardness2 *= 5;
            }
            return WC + hardness1 + hardness2;
        } else {
            // 搭桥分支:需要在落脚点下放一块
            if (srcDownBlock == class_2246.field_9983 || srcDownBlock == class_2246.field_10597) {
                return COST_INF;
            }
            if (!MovementHelper.isReplaceable(destX, y - 1, destZ, destOn, context.loadedTest)) {
                return COST_INF;
            }
            boolean throughWater = MovementHelper.isWater(pb0) || MovementHelper.isWater(pb1);
            if (MovementHelper.isWater(destOn) && throughWater) {
                // 在水里且要往水里垫:这套水上行走语义不允许
                return COST_INF;
            }
            double placeCost = context.costOfPlacingAt(destX, y - 1, destZ, destOn);
            if (placeCost >= COST_INF) {
                return COST_INF;
            }
            double hardness1 = MovementHelper.getMiningDurationTicks(context, destX, y, destZ, pb1, false);
            if (hardness1 >= COST_INF) {
                return COST_INF;
            }
            double hardness2 = MovementHelper.getMiningDurationTicks(context, destX, y + 1, destZ, pb0, true);
            double WC = throughWater ? context.waterWalkSpeed : WALK_ONE_BLOCK_COST;
            for (int i = 0; i < 5; i++) {
                int againstX = destX + MovementPlacement.HORIZONTALS_AND_DOWN[i].method_10148();
                int againstY = y - 1 + MovementPlacement.HORIZONTALS_AND_DOWN[i].method_10164();
                int againstZ = destZ + MovementPlacement.HORIZONTALS_AND_DOWN[i].method_10165();
                if (againstX == x && againstZ == z) {
                    // 来向那面是背贴,单独按潜行处理
                    continue;
                }
                if (MovementHelper.canPlaceAgainst(context, againstX, againstY, againstZ)) {
                    // 有侧贴面,不必潜行
                    return WC + placeCost + hardness1 + hardness2;
                }
            }
            // 只能背贴(潜行悬出边缘,回身贴脚下那块的侧面放)
            if (srcDownBlock == class_2246.field_10114
                    || (srcDownBlock instanceof class_2482 && srcDown.method_11654(class_2482.field_11501) != class_2771.field_12682)) {
                return COST_INF; // 灵魂沙 / 非双层台阶顶面矮一截,背贴瞄不到贴面
            }
            if (!standingOnABlock) {
                return COST_INF; // 站在水上没法潜行背贴
            }
            class_2248 blockSrc = context.getBlock(x, y, z);
            if ((blockSrc == class_2246.field_10588 || blockSrc instanceof class_2577)
                    && !srcDown.method_26227().method_15769()) {
                return COST_INF; // 睡莲/地毯能站不能贴
            }
            WC = WC * (SNEAK_ONE_BLOCK_COST / WALK_ONE_BLOCK_COST); // 全程潜行
            return WC + placeCost + hardness1 + hardness2;
        }
    }

    @Override
    public double calculateCost(CalculationContext context, MutableMoveResult result) {
        return cost(context, src.method_10263(), src.method_10264(), src.method_10260(), dest.method_10263(), dest.method_10260());
    }

    @Override
    protected Set<class_2338> calculateValidPositions() {
        return Set.of(src, dest);
    }

    @Override
    public MovementState updateState(MovementState state) {
        super.updateState(state);
        class_1937 level = player.method_51469();
        class_2680 pb0 = level.method_8320(positionsToBreak[0]);
        class_2680 pb1 = level.method_8320(positionsToBreak[1]);
        if (state.getStatus() != MovementStatus.RUNNING) {
            // 准备期(挖前方方块)可以边挖边走,贴近后再停下专心挖
            if (!NavSettings.get().walkWhileBreaking) {
                return state;
            }
            if (state.getStatus() != MovementStatus.PREPPING) {
                return state;
            }
            if (MovementHelper.avoidWalkingInto(pb0) || MovementHelper.avoidWalkingInto(pb1)) {
                return state;
            }
            double dist = Math.max(Math.abs(player.method_23317() - (dest.method_10263() + 0.5)),
                    Math.abs(player.method_23321() - (dest.method_10260() + 0.5)));
            if (dist < 0.83) {
                return state; // 已经贴上了
            }
            if (!state.getTarget().hasRotation()) {
                // 偶发:落沙实体迟到,挖掘目标还没建立
                return state;
            }
            // yaw 对准终点中心,pitch 沿用挖掘目标;两格都是整方块/空气时用固定俯角
            float yawToDest = AimGeometry.yawTo(player.method_33571(), AimGeometry.blockCenter(dest));
            float pitchToBreak = state.getTarget().getPitch();
            if (MovementHelper.isBlockNormalCube(pb0)
                    || (pb0.method_26204() instanceof class_2189
                            && (MovementHelper.isBlockNormalCube(pb1) || pb1.method_26204() instanceof class_2189))) {
                pitchToBreak = 26;
            }
            return state.setTarget(new MovementState.MovementTarget(yawToDest, pitchToBreak, true))
                    .setInput(Input.MOVE_FORWARD, true)
                    .setInput(Input.SPRINT, true);
        }

        // 准备期可能按过潜行,先松开
        state.setInput(Input.SNEAK, false);

        class_2248 fd = level.method_8320(src.method_10074()).method_26204();
        boolean ladder = fd == class_2246.field_9983 || fd == class_2246.field_10597;

        // 木门:挡路且能开 → 看门中心右键
        if (pb0.method_26204() instanceof class_2323 || pb1.method_26204() instanceof class_2323) {
            boolean notPassable = (pb0.method_26204() instanceof class_2323
                            && !MovementHelper.isDoorPassable(level, src, dest))
                    || (pb1.method_26204() instanceof class_2323
                            && !MovementHelper.isDoorPassable(level, dest, src));
            boolean canOpen = !(pb0.method_26204() == class_2246.field_9973 || pb1.method_26204() == class_2246.field_9973);
            if (notPassable && canOpen) {
                class_243 center = AimGeometry.blockCenter(positionsToBreak[0]);
                return state.setTarget(new MovementState.MovementTarget(
                                AimGeometry.yawTo(player.method_33571(), center),
                                AimGeometry.pitchTo(player.method_33571(), center), true))
                        .setInput(Input.CLICK_RIGHT, true);
            }
        }

        // 栅栏门:找出挡路的那扇,射线可视时才看向它右键;完全不可视
        // 则不点击,落到后续行走逻辑继续推进
        if (pb0.method_26204() instanceof class_2349 || pb1.method_26204() instanceof class_2349) {
            class_2338 blocked = !MovementHelper.isGatePassable(level, positionsToBreak[0], src.method_10084())
                    ? positionsToBreak[0]
                    : !MovementHelper.isGatePassable(level, positionsToBreak[1], src)
                            ? positionsToBreak[1]
                            : null;
            if (blocked != null) {
                class_243 aim = AimGeometry.reachableAimPoint(player, blocked);
                if (aim != null) {
                    return state.setTarget(new MovementState.MovementTarget(
                                    AimGeometry.yawTo(player.method_33571(), aim),
                                    AimGeometry.pitchTo(player.method_33571(), aim), true))
                            .setInput(Input.CLICK_RIGHT, true);
                }
            }
        }

        boolean isTheBridgeBlockThere = MovementHelper.canWalkOn(level, positionToPlace)
                || ladder
                || MovementPlacement.canUseFrostWalker(player, level.method_8320(positionToPlace));
        class_2338 feet = feet(player);
        if (feet.method_10264() != dest.method_10264() && !ladder) {
            // 高度不对:低了跳一下,高了等下落
            if (feet.method_10264() < dest.method_10264()) {
                return state.setInput(Input.JUMP, true);
            }
            return state;
        }

        if (isTheBridgeBlockThere) {
            if (feet.equals(dest)) {
                return state.setStatus(MovementStatus.SUCCESS);
            }
            class_2338 dir = getDirection();
            if (NavSettings.get().overshootTraverse
                    && (feet.equals(dest.method_10081(dir)) || feet.equals(dest.method_10081(dir).method_10081(dir)))) {
                // 冲过头一两格也算成功,不必回身减速
                return state.setStatus(MovementStatus.SUCCESS);
            }
            class_2248 low = level.method_8320(src).method_26204();
            class_2248 high = level.method_8320(src.method_10084()).method_26204();
            if (player.method_23318() > src.method_10264() + 0.1 && !player.method_24828()
                    && (low == class_2246.field_10597 || low == class_2246.field_9983
                            || high == class_2246.field_10597 || high == class_2246.field_9983)) {
                // 挂在梯/藤上离地,按前进会变成往上爬,等落地
                return state;
            }
            class_2338 into = dest.method_10059(src).method_10081(dest);
            class_2680 intoBelow = level.method_8320(into);
            class_2680 intoAbove = level.method_8320(into.method_10084());
            if (wasTheBridgeBlockAlwaysThere
                    && (!MovementHelper.isLiquid(level.method_8320(feet)) || NavSettings.get().sprintInWater)
                    && (!MovementHelper.avoidWalkingInto(intoBelow) || MovementHelper.isWater(intoBelow))
                    && !MovementHelper.avoidWalkingInto(intoAbove)) {
                state.setInput(Input.SPRINT, true);
            }

            class_2680 destDown = level.method_8320(dest.method_10074());
            class_2338 against = positionsToBreak[0];
            if (feet.method_10264() != dest.method_10264() && ladder
                    && (destDown.method_26204() == class_2246.field_10597 || destDown.method_26204() == class_2246.field_9983)) {
                // 往下一段梯/藤走:朝攀爬贴面方向走
                against = destDown.method_26204() == class_2246.field_10597
                        ? MovementPillar.getAgainst(level, dest.method_10074())
                        : dest.method_10093(destDown.method_11654(class_2399.field_11253).method_10153());
                if (against == null) {
                    return state.setStatus(MovementStatus.UNREACHABLE);
                }
            }
            AimGeometry.moveTowards(player, state, against);
            return state;
        } else {
            // 搭桥执行:桥块不在(或被挖掉了),现场放
            wasTheBridgeBlockAlwaysThere = false;
            class_2248 standingOn = level.method_8320(feet.method_10074()).method_26204();
            if (standingOn == class_2246.field_10114 || standingOn instanceof class_2482) {
                // 顶面矮一截的方块上潜行容易滑出去,离得近就倒着走稳住
                double dist = Math.max(Math.abs(dest.method_10263() + 0.5 - player.method_23317()),
                        Math.abs(dest.method_10260() + 0.5 - player.method_23321()));
                if (dist < 0.85) { // 0.5 + 0.3 + 容差
                    AimGeometry.moveTowards(player, state, dest);
                    return state.setInput(Input.MOVE_FORWARD, false)
                            .setInput(Input.MOVE_BACK, true);
                }
            }
            double dist1 = Math.max(Math.abs(player.method_23317() - (dest.method_10263() + 0.5)),
                    Math.abs(player.method_23321() - (dest.method_10260() + 0.5)));
            MovementPlacement.PlaceResult p = MovementPlacement.attemptToPlaceABlock(
                    state, player, dest.method_10074(), false, true);
            if ((p == MovementPlacement.PlaceResult.READY_TO_PLACE || dist1 < 0.6)
                    && !NavSettings.get().assumeSafeWalk) {
                state.setInput(Input.SNEAK, true);
            }
            switch (p) {
                case READY_TO_PLACE: {
                    // 潜行确认后下一 tick 才右键(先蹲住再放,防滑落)
                    if (player.method_18276() || NavSettings.get().assumeSafeWalk) {
                        state.setInput(Input.CLICK_RIGHT, true);
                    }
                    return state;
                }
                case ATTEMPTING: {
                    if (dist1 > 0.83) {
                        // 还没贴上去,放置目标又在正前方时才敢继续前进
                        float yaw = AimGeometry.yawTo(player.method_33571(),
                                AimGeometry.blockCenter(dest));
                        if (Math.abs(state.getTarget().getYaw() - yaw) < 0.1) {
                            return state.setInput(Input.MOVE_FORWARD, true);
                        }
                    } else if (MovementPlacement.isFacing(player, state.getTarget())) {
                        // 对准了还放不上,说明有东西挡着,打掉
                        return state.setInput(Input.CLICK_LEFT, true);
                    }
                    return state;
                }
                default:
                    break;
            }
            if (feet.equals(dest)) {
                // 已潜行悬在目标格上空:回身贴 src 脚下那块的侧面放(背贴)
                double faceX = (dest.method_10263() + src.method_10263() + 1.0) * 0.5;
                double faceY = (dest.method_10264() + src.method_10264() - 1.0) * 0.5;
                double faceZ = (dest.method_10260() + src.method_10260() + 1.0) * 0.5;
                class_243 face = new class_243(faceX, faceY, faceZ);
                class_2338 goalLook = src.method_10074(); // 刚离开的脚下块,就贴它
                float facePitch = AimGeometry.pitchTo(player.method_33571(), face);
                double dist2 = Math.max(Math.abs(player.method_23317() - faceX),
                        Math.abs(player.method_23321() - faceZ));
                if (dist2 < 0.29) {
                    // 贴面太近瞄不到,反向 yaw 倒退拉开距离
                    float yaw = AimGeometry.yawTo(AimGeometry.blockCenter(dest),
                            player.method_33571());
                    state.setTarget(new MovementState.MovementTarget(yaw, facePitch, true));
                    state.setInput(Input.MOVE_BACK, true);
                } else {
                    state.setTarget(new MovementState.MovementTarget(
                            AimGeometry.yawTo(player.method_33571(), face), facePitch, true));
                }
                if (MovementPlacement.isLookingAt(player, goalLook)) {
                    return state.setInput(Input.CLICK_RIGHT, true);
                }
                if (MovementPlacement.isFacing(player, state.getTarget())) {
                    // 对准了还不行,有杂物挡视线,打掉
                    state.setInput(Input.CLICK_LEFT, true);
                }
                return state;
            }
            AimGeometry.moveTowards(player, state, positionsToBreak[0]);
            return state;
        }
    }

    /** 正在潜行悬空放置时不可中断,其余时刻可。 */
    @Override
    protected boolean safeToCancel(MovementState state) {
        return state.getStatus() != MovementStatus.RUNNING
                || MovementHelper.canWalkOn(player.method_51469(), dest.method_10074());
    }

    /** 站在梯/藤上挖掘时按住潜行防滑落。 */
    @Override
    protected boolean prepared(MovementState state) {
        class_2338 feet = feet(player);
        if (feet.equals(src) || feet.equals(src.method_10074())) {
            class_2248 block = player.method_51469().method_8320(src.method_10074()).method_26204();
            if (block == class_2246.field_9983 || block == class_2246.field_10597) {
                state.setInput(Input.SNEAK, true);
            }
        }
        return super.prepared(state);
    }
}
