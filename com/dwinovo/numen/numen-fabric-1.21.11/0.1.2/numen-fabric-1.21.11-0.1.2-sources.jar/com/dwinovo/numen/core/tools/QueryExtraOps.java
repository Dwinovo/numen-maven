package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.agent.tool.ToolArgs;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.platform.Services;
import com.dwinovo.numen.task.TaskResult;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1869;
import net.minecraft.class_1874;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_3975;
import net.minecraft.class_7923;
import net.minecraft.class_8059;
import net.minecraft.class_8786;
import net.minecraft.class_9697;

/**
 * Query tool implementations — the business half of {@code LookupRecipeTool},
 * {@code ScanNearbyEntitiesTool} and {@code InspectBlockStorageTool}.
 */
public final class QueryExtraOps {

    // ---- scan_nearby_entities ----

    private static final int MAX_RESULTS = 20;
    private static final double MIN_RADIUS = 1.0;
    private static final double MAX_RADIUS = 64.0;

    public String scanNearbyEntities(
double radius,
String type_filter,
            NumenPlayer self) {
        radius = Math.clamp(radius, MIN_RADIUS, MAX_RADIUS);
        String filter = readEnum("type_filter", type_filter,
                List.of("hostile", "passive", "player", "all"));

        class_238 box = self.method_5829().method_1014(radius);
        List<class_1297> raw = self.method_51469().method_8335(self, box);

        List<ScoredEntity> matched = new ArrayList<>(raw.size());
        for (class_1297 e : raw) {
            String cat = categorise(e);
            if (!matches(filter, cat)) continue;
            matched.add(new ScoredEntity(e, cat, self.method_5739(e)));
        }
        matched.sort(Comparator.comparingDouble(s -> s.distance));

        JsonArray entities = new JsonArray();
        int limit = Math.min(matched.size(), MAX_RESULTS);
        for (int i = 0; i < limit; i++) {
            ScoredEntity s = matched.get(i);
            JsonObject o = new JsonObject();
            o.addProperty("id", s.entity.method_5628());
            o.addProperty("type", s.entity.method_5864().method_5882());
            o.addProperty("category", s.category);
            JsonObject pos = new JsonObject();
            pos.addProperty("x", s.entity.method_23317());
            pos.addProperty("y", s.entity.method_23318());
            pos.addProperty("z", s.entity.method_23321());
            o.add("position", pos);
            o.addProperty("distance", s.distance);
            if (s.entity instanceof class_1309 le) {
                o.addProperty("hp", le.method_6032());
                o.addProperty("max_hp", le.method_6063());
            }
            entities.add(o);
        }

        JsonObject root = new JsonObject();
        root.add("entities", entities);
        root.addProperty("total_found", matched.size());
        root.addProperty("truncated", matched.size() > MAX_RESULTS);
        root.addProperty("radius_searched", radius);
        root.addProperty("filter", filter);
        return root.toString();
    }

    private static String categorise(class_1297 e) {
        if (e instanceof class_1657) return "player";
        if (e instanceof class_1588) return "hostile";
        return "passive";
    }

    private static boolean matches(String filter, String category) {
        if ("all".equals(filter)) return true;
        return filter.equals(category);
    }

    private record ScoredEntity(class_1297 entity, String category, double distance) {}

    private static String readEnum(String key, String value, List<String> allowed) {
        if (value == null) {
            throw new IllegalArgumentException("missing required argument: " + key);
        }
        String v = value;
        if (!allowed.contains(v)) {
            throw new IllegalArgumentException(
                    "argument '" + key + "' must be one of " + allowed + ", got: " + v);
        }
        return v;
    }

    // ---- lookup_recipe ----

    /** Cap recipes per lookup — enough variants to choose from without a token bomb. */
    private static final int MAX_RECIPES = 4;

    public String lookupRecipe(
String item_id,
            NumenPlayer self) {
        class_1792 target = ToolArgs.parseItem(item_id);
        if (!(self.method_51469() instanceof class_3218 level)) {
            return TaskResult.fail("recipe lookup needs a server level.").toJson();
        }
        String name = class_7923.field_41178.method_10221(target).method_12832();

        List<String> recipes = new ArrayList<>();
        for (class_8786<?> holder : level.method_64577().method_8126()) {
            if (recipes.size() >= MAX_RECIPES) {
                break;
            }
            // 每条配方自成一格:整合包里一条坏配方(产出为 null、输入表为 null)
            // 只丢它自己,绝不让它杀掉整个查询。见 RecipeProbe。
            try {
                class_1860<?> r = holder.comp_1933();
                if (r instanceof class_3955 cr) {
                    // 产出依赖输入的配方(烟花、镶零件的装备)静态描述答不了;
                    // 1.21.2+ 静态清单在 PlacementInfo,不可摆放即特殊配方。
                    if (cr.method_8118() || cr.method_61671().method_61687()
                            || cr.method_61671().method_64675().isEmpty()) {
                        continue;
                    }
                    class_1799 result = RecipeProbe.resultOf(cr, level.method_30349());
                    if (result.method_7960() || result.method_7909() != target) {
                        continue;
                    }
                    recipes.add("[crafting] " + format(cr, result));
                } else if (r instanceof class_1874 cook) {
                    class_1799 result = RecipeProbe.resultOf(cook, level.method_30349());
                    if (result.method_7960() || result.method_7909() != target) {
                        continue;
                    }
                    recipes.add(formatCooking(cook, result));
                } else if (r instanceof class_3975 sc) {
                    class_1799 result = RecipeProbe.resultOf(sc, level.method_30349());
                    if (result.method_7960() || result.method_7909() != target) {
                        continue;
                    }
                    recipes.add("[stonecutter] " + describeIngredient(sc.method_64720())
                            + " -> makes " + result.method_7947());
                } else if (r instanceof class_8059 sm) {
                    // 锻造不走展示产出,保留空输入 assemble 的既有语义:变换配方
                    // (下界合金升级)照样给出产物,纹饰配方产出(空的)基底、自然排除。
                    class_1799 result = RecipeProbe.probe(() -> sm.method_8116(new class_9697(
                            class_1799.field_8037, class_1799.field_8037, class_1799.field_8037), level.method_30349()));
                    if (result.method_7960() || result.method_7909() != target) {
                        continue;
                    }
                    recipes.add(formatSmithing(sm, result));
                }
            } catch (RuntimeException broken) {
                com.dwinovo.numen.core.Constants.LOG.debug(
                        "[numen-recipe] 配方 {} 坏了,跳过: {}", holder.comp_1932(), broken.toString());
            }
        }

        if (recipes.isEmpty()) {
            return TaskResult.ok("no recipe for " + name + " — it's obtained another way (mine it, or "
                    + "trade), not crafted or smelted.").toJson();
        }
        return TaskResult.ok("recipe(s) for " + name + ":\n\n" + String.join("\n\n", recipes) + "\n\n"
                + "To make it —\n"
                + "• [crafting]: call craft {item_id, count} — it lays out the grid and takes the "
                + "result for you (a 3x3 recipe needs a crafting table within reach; 2x2 works "
                + "anywhere).\n"
                + "• [smelting|blasting|smoking]: interact_at the furnace, then transfer the input and "
                + "the fuel with NO `to` — the menu routes each to its slot. Wait, then transfer the "
                + "output back out.\n"
                + "• [stonecutter]: interact_at it, transfer the input (no `to` routes it in), take the "
                + "output. [smithing]: interact_at it, inspect_gui, then transfer template + base + "
                + "addition each into its own slot (give `to`).").toJson();
    }

    private static String format(class_3955 recipe, class_1799 result) {
        int count = result.method_7947();
        if (recipe instanceof class_1869 shaped) {
            int w = shaped.method_8150();
            int h = shaped.method_8158();
            var cells = shaped.method_61693();   // 1.21.2+: List<Optional<Ingredient>>,空格 = empty
            StringBuilder sb = new StringBuilder("shaped " + w + "x" + h + ", makes " + count + ":");
            for (int r = 0; r < h; r++) {
                sb.append("\n  ");
                for (int c = 0; c < w; c++) {
                    class_1856 ing = cells.get(r * w + c).orElse(null);
                    sb.append(ing == null || ing.method_65799() ? "." : describeIngredient(ing));
                    if (c < w - 1) {
                        sb.append(" | ");
                    }
                }
            }
            return sb.toString();
        }
        // Shapeless: order doesn't matter, place anywhere.
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (class_1856 ing : recipe.method_61671().method_64675()) {
            if (ing.method_65799()) continue;
            counts.merge(describeIngredient(ing), 1, Integer::sum);
        }
        String list = counts.entrySet().stream()
                .map(e -> e.getValue() + "x " + e.getKey())
                .collect(Collectors.joining(", "));
        return "shapeless, makes " + count + ": " + list + " (place anywhere in the grid)";
    }

    /** A cooking recipe (one input → one output) labelled by its station. */
    private static String formatCooking(class_1874 recipe, class_1799 result) {
        class_3956<?> type = recipe.method_17716();
        String station = type == class_3956.field_17547 ? "blasting (blast furnace)"
                : type == class_3956.field_17548 ? "smoking (smoker)"
                : type == class_3956.field_17549 ? "campfire"
                : "smelting (furnace)";
        return "[" + station + "] " + describeIngredient(recipe.method_64720()) + " -> makes "
                + result.method_7947() + " (" + recipe.method_8167() + " ticks)";
    }

    /** A smithing recipe (smithing table). Station + result only — the trailing "To make it" section
     *  already walks the three input slots, so per-recipe input enumeration adds nothing. */
    private static String formatSmithing(class_8059 recipe, class_1799 result) {
        return "[smithing] (smithing table: template + base + addition) -> makes " + result.method_7947();
    }

    /** Name an ingredient: a single item directly, a shared-suffix tag as "planks (any)", else a few
     *  members — so a category ingredient doesn't mislead the model into one specific item.
     *  Package-visible: the craft tool names its material shortfalls with the same vocabulary. */
    static String describeIngredient(class_1856 ing) {
        List<String> paths = ing.method_8105()   // 1.21.2+: Stream<Holder<Item>>
                .map(h -> class_7923.field_41178.method_10221(h.comp_349()).method_12832())
                .distinct()
                .toList();
        if (paths.isEmpty()) {
            return "?";
        }
        if (paths.size() == 1) {
            return paths.get(0);
        }
        String suffix = commonSuffixToken(paths);
        if (suffix != null) {
            return suffix + "(any)";
        }
        return "any[" + paths.stream().limit(3).collect(Collectors.joining("/"))
                + (paths.size() > 3 ? "/…" : "") + "]";
    }

    private static String commonSuffixToken(List<String> paths) {
        String token = null;
        for (String p : paths) {
            int u = p.lastIndexOf('_');
            String t = u < 0 ? p : p.substring(u + 1);
            if (token == null) {
                token = t;
            } else if (!token.equals(t)) {
                return null;
            }
        }
        return token;
    }

    // ---- inspect_block_storage ----

    public String inspectBlockStorage(int x,
int y,
int z,
                                      NumenPlayer self) {
        class_2338 pos = new class_2338(x, y, z);
        class_2680 state = self.method_51469().method_8320(pos);
        String coord = x + "," + y + "," + z;
        if (state.method_26215()) {
            return TaskResult.fail("block at " + coord + " is air — nothing to read.").toJson();
        }
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        String caps = Services.CAPS.describe(self.method_51469(), pos);
        if (caps == null || caps.isBlank()) {
            return TaskResult.ok(id + " at " + coord + " exposes no item/fluid/energy storage "
                    + "(not a machine/tank/battery, or it keeps its state elsewhere). "
                    + "If it has a GUI, right-click it then use inspect_gui.").toJson();
        }
        return TaskResult.ok(id + " at " + coord + ":\n" + caps).toJson();
    }
}
