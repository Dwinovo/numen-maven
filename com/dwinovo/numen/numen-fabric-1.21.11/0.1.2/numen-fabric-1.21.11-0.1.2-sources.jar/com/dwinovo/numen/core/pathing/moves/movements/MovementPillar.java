package com.dwinovo.numen.core.pathing.moves.movements;
import com.dwinovo.numen.core.pathing.moves.AimGeometry;

import java.util.Set;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2349;
import net.minecraft.class_2399;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2577;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_3222;
import com.dwinovo.numen.core.pathing.moves.CalculationContext;
import com.dwinovo.numen.core.pathing.moves.Input;
import com.dwinovo.numen.core.pathing.moves.Movement;
import com.dwinovo.numen.core.pathing.moves.MovementHelper;
import com.dwinovo.numen.core.pathing.moves.MovementState;
import com.dwinovo.numen.core.pathing.moves.MovementStatus;
import com.dwinovo.numen.core.pathing.moves.MutableMoveResult;

import static com.dwinovo.numen.core.pathing.moves.ActionCosts.COST_INF;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.JUMP_ONE_BLOCK_COST;
import static com.dwinovo.numen.core.pathing.moves.ActionCosts.LADDER_UP_ONE_COST;

/** 垫柱上一格:原地起跳在脚下放方块(或沿梯子/藤蔓/水柱直接上一格)。 */
public class MovementPillar extends Movement {

    public MovementPillar(class_3222 player, class_2338 src, class_2338 dest) {
        super(player, src, dest, new class_2338[]{src.method_10086(2)}, src);
    }

    /**
     * 成本。四形态:梯/藤直接爬(头顶要挖时挖速 ×5);已在水柱中
     * 上游按爬梯价;其余为垫柱——跳跃 + 放置罚金 + 跳跃罚金 + 头顶
     * 挖掘,悬空垫柱轻罚 +0.1。梯上不能垫、下半砖上不能垫、水上
     * (按水面行走语义)不能垫、睡莲/地毯浮在流体上不能垫、头顶是
     * 栅栏门不可行,头顶落沙柱只有整根都是落沙时才敢挖。
     */
    public static double cost(CalculationContext context, int x, int y, int z) {
        class_2680 fromState = context.get(x, y, z);
        class_2248 from = fromState.method_26204();
        boolean ladder = from == class_2246.field_9983 || from == class_2246.field_10597;
        class_2680 fromDown = context.get(x, y - 1, z);
        if (!ladder) {
            if (fromDown.method_26204() == class_2246.field_9983 || fromDown.method_26204() == class_2246.field_10597) {
                return COST_INF; // 站在梯/藤顶上垫不了柱
            }
            if (fromDown.method_26204() instanceof class_2482
                    && fromDown.method_11654(class_2482.field_11501) == class_2771.field_12681) {
                return COST_INF; // 下半砖上跳不满一格
            }
        }
        if (from == class_2246.field_10597 && !hasAgainst(context, x, y, z)) {
            return COST_INF; // 四邻无实心方块的藤蔓爬不了
        }
        class_2680 toBreak = context.get(x, y + 2, z);
        class_2248 toBreakBlock = toBreak.method_26204();
        if (toBreakBlock instanceof class_2349) {
            return COST_INF; // 栅栏门顶头,跳不过去也挖不干净
        }
        class_2680 srcUp = null;
        if (MovementHelper.isWater(toBreak) && MovementHelper.isWater(fromState)) {
            srcUp = context.get(x, y + 1, z);
            if (MovementHelper.isWater(srcUp)) {
                return LADDER_UP_ONE_COST; // 已在水柱中,允许继续上游
            }
        }
        double placeCost = 0;
        if (!ladder) {
            // 要在出发格原位放一块垫脚
            placeCost = context.costOfPlacingAt(x, y, z, fromState);
            if (placeCost >= COST_INF) {
                return COST_INF;
            }
            if (fromDown.method_26204() instanceof class_2189) {
                placeCost += 0.1; // 悬空垫柱轻罚(1/200 秒)
            }
        }
        if ((MovementHelper.isLiquid(fromState)
                        && !MovementHelper.canPlaceAgainst(context, x, y - 1, z, fromDown))
                || (MovementHelper.isLiquid(fromDown) && context.assumeWalkOnWater)) {
            // 泡在水里贴不到下面、或按水面行走语义站在水上,都垫不了
            return COST_INF;
        }
        if ((from == class_2246.field_10588 || from instanceof class_2577)
                && !fromDown.method_26227().method_15769()) {
            return COST_INF; // 想上去得先拆自己站的睡莲/地毯
        }
        double hardness = MovementHelper.getMiningDurationTicks(context, x, y + 2, z, toBreak, true);
        if (hardness >= COST_INF) {
            return COST_INF;
        }
        if (hardness != 0) {
            if (toBreakBlock == class_2246.field_9983 || toBreakBlock == class_2246.field_10597) {
                hardness = 0; // 头顶是梯/藤:直接爬,不挖
            } else {
                class_2680 check = context.get(x, y + 3, z);
                if (check.method_26204() instanceof class_2346) {
                    // 头顶再上一格是落沙:除非整根(含身位上格)都是落沙
                    // 早已被清理的情形,否则挖了会塌下来闷住
                    if (srcUp == null) {
                        srcUp = context.get(x, y + 1, z);
                    }
                    if (!(toBreakBlock instanceof class_2346)
                            || !(srcUp.method_26204() instanceof class_2346)) {
                        return COST_INF;
                    }
                }
            }
        }
        if (ladder) {
            return LADDER_UP_ONE_COST + hardness * 5; // 挂梯上挖极慢
        } else {
            return JUMP_ONE_BLOCK_COST + placeCost + context.jumpPenalty + hardness;
        }
    }

    /** 四个水平邻格有无实心方块(藤蔓攀爬依据)。 */
    public static boolean hasAgainst(CalculationContext context, int x, int y, int z) {
        return MovementHelper.isBlockNormalCube(context.get(x + 1, y, z))
                || MovementHelper.isBlockNormalCube(context.get(x - 1, y, z))
                || MovementHelper.isBlockNormalCube(context.get(x, y, z + 1))
                || MovementHelper.isBlockNormalCube(context.get(x, y, z - 1));
    }

    /** 藤蔓格四邻里第一个实心方块(攀爬贴面),没有则 null。 */
    public static class_2338 getAgainst(class_1922 level, class_2338 vine) {
        if (MovementHelper.isBlockNormalCube(level.method_8320(vine.method_10095()))) {
            return vine.method_10095();
        }
        if (MovementHelper.isBlockNormalCube(level.method_8320(vine.method_10072()))) {
            return vine.method_10072();
        }
        if (MovementHelper.isBlockNormalCube(level.method_8320(vine.method_10078()))) {
            return vine.method_10078();
        }
        if (MovementHelper.isBlockNormalCube(level.method_8320(vine.method_10067()))) {
            return vine.method_10067();
        }
        return null;
    }

    @Override
    public double calculateCost(CalculationContext context, MutableMoveResult result) {
        return cost(context, src.method_10263(), src.method_10264(), src.method_10260());
    }

    @Override
    protected Set<class_2338> calculateValidPositions() {
        return Set.of(src, dest);
    }

    @Override
    public MovementState updateState(MovementState state) {
        super.updateState(state);
        if (state.getStatus() != MovementStatus.RUNNING) {
            return state;
        }

        if (feet(player).method_10264() < src.method_10264()) {
            return state.setStatus(MovementStatus.UNREACHABLE);
        }

        class_1937 level = player.method_51469();
        class_243 eye = player.method_33571();
        class_2680 fromDown = level.method_8320(src);
        if (MovementHelper.isWater(fromDown)
                && MovementHelper.isWater(level.method_8320(dest))) {
            // 水柱:看向上方目标中心保持居中上浮(上浮强跳由基类通用规则按)
            class_243 destCenter = AimGeometry.blockCenter(dest);
            state.setTarget(new MovementState.MovementTarget(
                    AimGeometry.yawTo(eye, destCenter),
                    AimGeometry.pitchTo(eye, destCenter), false));
            if (Math.abs(player.method_23317() - destCenter.field_1352) > 0.2
                    || Math.abs(player.method_23321() - destCenter.field_1350) > 0.2) {
                state.setInput(Input.MOVE_FORWARD, true);
            }
            if (feet(player).equals(dest)) {
                return state.setStatus(MovementStatus.SUCCESS);
            }
            return state;
        }
        boolean ladder = fromDown.method_26204() == class_2246.field_9983 || fromDown.method_26204() == class_2246.field_10597;
        boolean vine = fromDown.method_26204() == class_2246.field_10597;
        class_243 placeCenter = AimGeometry.blockCenter(positionToPlace);
        float placePitch = AimGeometry.pitchTo(eye, placeCenter);
        if (!ladder) {
            // 只压 pitch 看向脚下放置点,yaw 保持current(垫柱不需要转身)
            state.setTarget(new MovementState.MovementTarget(player.method_36454(), placePitch, true));
        }

        boolean blockIsThere = MovementHelper.canWalkOn(level, src) || ladder;
        if (ladder) {
            class_2338 against = vine
                    ? getAgainst(level, src)
                    : src.method_10093(fromDown.method_11654(class_2399.field_11253).method_10153());
            if (against == null) {
                return state.setStatus(MovementStatus.UNREACHABLE); // 藤蔓四邻无贴面爬不了
            }
            if (feet(player).equals(against.method_10084())
                    || feet(player).equals(dest)) {
                return state.setStatus(MovementStatus.SUCCESS);
            }
            if (MovementHelper.isBottomSlab(level.method_8320(src.method_10074()))) {
                state.setInput(Input.JUMP, true); // 从下半砖上够梯子得先跳
            }
            AimGeometry.moveTowards(player, state, against);
            if (player.field_6012 % 10 == 0) {
                // 爬梯分支得留声:没有它,卡在这里时外面只看到"垫柱毫无动静"。
                com.dwinovo.numen.core.Constants.LOG.debug(
                        "[numen-pillar] 爬梯 src={} 贴面={} 身位={} y={} 竖速={} 攀附={}",
                        src.method_23854(), against.method_23854(),
                        feet(player).method_23854(), String.format("%.2f", player.method_23318()),
                        String.format("%.3f", player.method_18798().field_1351),
                        player.method_6101());
            }
            return state;
        } else {
            // 垫柱:先把耗材拿到手
            if (!MovementPlacement.selectForLocation(player, src, true)) {
                return state.setStatus(MovementStatus.UNREACHABLE);
            }

            double diffX = player.method_23317() - (dest.method_10263() + 0.5);
            double diffZ = player.method_23321() - (dest.method_10260() + 0.5);
            double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
            double flatMotion = Math.sqrt(player.method_18798().field_1352 * player.method_18798().field_1352
                    + player.method_18798().field_1350 * player.method_18798().field_1350);

            // 潜行只在它真正管用的两个时刻按下:落砖那一刻(高过目标,蹲住别踩空)
            // 和已经站到柱心上等起跳时。走位阶段绝不蹲——潜行把移速砍到三成,
            // 视角又是逐帧步进的,蹲着找柱心会变成绕着柱心打转:半径恒定在 0.24
            // 不收敛,于是 dist 永远大于 0.17,跳跃分支永远轮不到,而"还没跳起来"
            // 又永远成立,三者首尾相接自锁死。潜行是为放置服务的,不是为走路。
            // 蹲姿要在放置窗口打开之前就位:蹲是"请求"了要下一刻才真正生效(姿态
            // 在 aiStep 里更新),而窗口本身只有跳跃顶点附近几刻。若等"已高过目标"
            // 才请求下蹲,生效时人往往已经越过或跌出窗口,三条件永远凑不齐——命中
            // 全靠运气。上升途中接近目标高度就先蹲好,窗口一开即可落砖。
            boolean risingIntoWindow = player.method_18798().field_1351 > 0.0
                    && player.method_23318() > dest.method_10264() - 0.5;
            state.setInput(Input.SNEAK,
                    player.method_23318() > dest.method_10264()
                            || risingIntoWindow
                            || (dist <= 0.17 && player.method_23318() < src.method_10264() + 0.2));

            if (dist > 0.17) { // 需小于潜行边缘保护的 0.2,留余量
                // 偏出中心(可能被卡):完整看向放置点走回去
                state.setInput(Input.MOVE_FORWARD, true);
                state.setTarget(new MovementState.MovementTarget(
                        AimGeometry.yawTo(eye, placeCenter), placePitch, true));
            } else if (flatMotion < 0.05) {
                // 横速稳了才跳;到高度就松跳
                state.setInput(Input.JUMP, player.method_23318() < dest.method_10264());
            }

            if (!blockIsThere) {
                class_2680 frState = level.method_8320(src);
                if (!(frState.method_26204() instanceof class_2189 || frState.method_45474())) {
                    // 出发格有不可替换的杂物:射线可视时才改看向它;跳着挖
                    // 慢五倍,停跳,按左键打掉
                    class_243 aim = AimGeometry.reachableAimPoint(player, src);
                    if (aim != null) {
                        state.setTarget(new MovementState.MovementTarget(
                                AimGeometry.yawTo(eye, aim),
                                AimGeometry.pitchTo(eye, aim), true));
                    }
                    state.setInput(Input.JUMP, false);
                    state.setInput(Input.CLICK_LEFT, true);
                } else {
                    boolean crouched = player.method_18276();
                    boolean looking = MovementPlacement.isLookingAt(player, src.method_10074())
                            || MovementPlacement.isLookingAt(player, src);
                    boolean highEnough = player.method_23318() > dest.method_10264() + 0.1;
                    if (crouched && looking && highEnough) {
                        // 已蹲稳、看准、跳够高度:放块
                        state.setInput(Input.CLICK_RIGHT, true);
                        com.dwinovo.numen.core.Constants.LOG.info(
                                "[numen-pillar] 放置尝试 src={} y={} sneak={} dist={}",
                                src.method_23854(),
                                String.format("%.2f", player.method_23318()), player.method_5715(),
                                String.format("%.2f", dist));
                    } else if (player.field_6012 % 10 == 0) {
                        // 插桩:跳搭三条件逐值(500ms 限频)——之前这里全哑,只能猜
                        com.dwinovo.numen.core.Constants.LOG.info(
                                "[numen-pillar] 未就绪 src={} 蹲={} 看准={} 高度够={} y={} dy={} dist={} "
                                        + "横速={} 在地={} 请求跳={} 竖速={} 手持={}",
                                src.method_23854(), crouched, looking, highEnough,
                                String.format("%.2f", player.method_23318()),
                                String.format("%.2f", player.method_23318() - dest.method_10264()),
                                String.format("%.2f", dist),
                                String.format("%.3f", flatMotion), player.method_24828(),
                                state.getInputStates().getOrDefault(Input.JUMP, false),
                                String.format("%.3f", player.method_18798().field_1351),
                                player.method_6047().method_7909());
                    }
                }
            }
        }

        if (feet(player).equals(dest) && blockIsThere) {
            com.dwinovo.numen.core.Constants.LOG.info(
                    "[numen-pillar] 垫柱成功 src={} feet={}", src.method_23854(),
                    feet(player).method_23854());
            return state.setStatus(MovementStatus.SUCCESS);
        }
        return state;
    }

    /** 站梯/藤上挖掘时按住潜行;头顶目标格上方是水则不做准备挖掘。 */
    @Override
    protected boolean prepared(MovementState state) {
        class_2338 feet = feet(player);
        if (feet.equals(src) || feet.equals(src.method_10074())) {
            class_2248 block = player.method_51469().method_8320(src.method_10074()).method_26204();
            if (block == class_2246.field_9983 || block == class_2246.field_10597) {
                state.setInput(Input.SNEAK, true);
            }
        }
        if (MovementHelper.isWater(player.method_51469().method_8320(dest.method_10084()))) {
            return true;
        }
        return super.prepared(state);
    }
}

