package com.dwinovo.numen.mixin.inject;

import com.dwinovo.numen.scan.BlockSearch;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Feed every successful server-side block state change into the block search's shared index
 * ({@link BlockSearch#onBlockChange}).
 *
 * <p>{@code ServerLevel.onBlockStateChange} is the exact hook vanilla's own POI index consumes:
 * it fires for every change routed through {@code Level.setBlock} (players, pistons, explosions,
 * commands, growth, fluids) and for worldgen writes via {@code WorldGenRegion.setBlock}. The
 * handler is O(1) for irrelevant blocks and a single volatile read when no search or task has any
 * target registered, so this costs effectively nothing while no companion is looking for blocks.
 */
@Mixin(class_3218.class)
public abstract class ServerLevelBlockChangeMixin {

    @Inject(method = "onBlockStateChange", at = @At("HEAD"))
    private void numen$feedTargetIndex(class_2338 pos, class_2680 oldState, class_2680 newState, CallbackInfo ci) {
        BlockSearch.onBlockChange((class_3218) (Object) this, pos, oldState, newState);
    }
}
