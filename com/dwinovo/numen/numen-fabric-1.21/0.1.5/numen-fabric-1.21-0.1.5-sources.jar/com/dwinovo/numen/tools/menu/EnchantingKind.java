package com.dwinovo.numen.tools.menu;

import com.dwinovo.numen.PlayerInv;
import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.sdk.Call;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1718;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

/**
 * 附魔台:三个选项各自的等级要求与原版露出的那一个提示;选一项就是按钮 0 到 2(选项编号减一)。等级、青金石够不够、物品能不能附魔,原版在
 * {@code clickMenuButton} 里判,不够什么也不做;读回来这一格里的东西没变就是没附上,把要的和有的说出来。
 */
final class EnchantingKind implements MenuKind.Chooses<class_1718> {

    @Override
    public Class<class_1718> menu() {
        return class_1718.class;
    }

    @Override
    public String name() {
        return "an enchanting table";
    }

    @Override
    public Screen read(class_1718 menu, NumenPlayer her) {
        var ids = her.method_37908().method_30349().method_30530(class_7924.field_41265).method_40295();
        List<Screen.EnchantOption> options = new ArrayList<>();
        for (int i = 0; i < menu.field_7808.length; i++) {
            class_6880<class_1887> clue = menu.field_7812[i] < 0 ? null : ids.method_10200(menu.field_7812[i]);
            Optional<Screen.EnchantHint> hint = clue == null ? Optional.empty()
                    : Optional.of(new Screen.EnchantHint(clue.method_40230().map(key -> key.method_29177().toString()).orElse("?"),
                            menu.field_7810[i]));
            options.add(new Screen.EnchantOption(i + 1, menu.field_7808[i], menu.field_7808[i] > 0, hint));
        }
        return new Screen.Enchanting(options, menu.method_7638(), her.field_7520);
    }

    @Override
    public String choose(class_1718 menu, NumenPlayer her, Pick first, Pick second) {
        if (second != null) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "an enchanting table takes one option: 1, 2 or 3",
                    Call.of("numen.gui.choose", 1));
        }
        int n = first.numberIn("option", menu.field_7808.length);
        String before = Receipt.stack(menu.method_7611(0).method_7677());
        her.packets().menuButton(n - 1);
        if (Receipt.stack(menu.method_7611(0).method_7677()).equals(before)) {
            throw refused(menu, her, n);
        }
        return "pressed enchanting option " + n;
    }

    /** 没附上:读到的事实——这一项要什么、她和台子里有什么。 */
    private static ApiError refused(class_1718 menu, NumenPlayer her, int n) {
        class_1799 item = menu.method_7611(0).method_7677();
        if (item.method_7960()) {
            return new ApiError(ErrorKind.FAILED, "nothing was enchanted: the table's item slot is empty — put the item "
                    + "in first (numen.gui.put)", Call.of("numen.gui.view"));
        }
        int cost = menu.field_7808[n - 1];
        if (cost <= 0) {
            return new ApiError(ErrorKind.FAILED, "nothing was enchanted: the table offers nothing at option " + n
                    + " for " + Receipt.stack(item) + " — numen.gui.view shows which options are offered",
                    Call.of("numen.gui.view"));
        }
        int lapis = menu.method_7638();
        String hint = lapis < n && PlayerInv.carriedCount(her.method_31548(), class_1802.field_8759) > 0
                ? Call.of("numen.gui.put", "minecraft:lapis_lazuli") : null;
        return new ApiError(ErrorKind.FAILED, "nothing was enchanted: option " + n + " needs " + Math.max(cost, n)
                + " experience levels and " + n + " lapis lazuli; you have " + her.field_7520 + " levels and the table "
                + "holds " + lapis + " lapis lazuli", hint);
    }
}
