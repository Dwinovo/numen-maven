package com.dwinovo.numen.tools.inventory;

import com.dwinovo.numen.api.NumenApi;
import com.dwinovo.numen.api.knowledge.InfoPage;
import com.dwinovo.numen.api.knowledge.ItemFacts;
import com.dwinovo.numen.api.knowledge.KnowledgeKind;
import com.dwinovo.numen.api.knowledge.RecipePage;
import com.dwinovo.numen.api.sdk.Doc;
import com.dwinovo.numen.api.sdk.Fn;
import com.dwinovo.numen.api.sdk.ServerCall;
import com.dwinovo.numen.tools.RecipeBook;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

/**
 * 配方与物品知识的第一个来源:游戏自己的数据,服务端就有,不依赖任何模组。配方读自配方表(任何模组的配方类型都在里面,见
 * {@link RecipeBook}),事实读自物品注册表与默认组件。三个动词各登记一个来源;它们是隐藏的函数,模型只看见动词
 * ({@code numen.inv.recipes}、{@code uses}、{@code info}),不看见来源。
 */
public final class VanillaKnowledge {

    /** 原版读不到、因此不会给的字段:配方表只有类型、输入与产物。 */
    private static final List<String> NOT_PROVIDED = List.of("chance", "time", "heat", "energy", "fluids",
            "which machine does it");

    private VanillaKnowledge() {}

    static void install(NumenApi numen) {
        numen.knowledgeSource(KnowledgeKind.RECIPES, "every recipe type in the game's recipe list, crafting, cooking, "
                + "stonecutting and smithing in full", NOT_PROVIDED, Recipes.class);
        numen.knowledgeSource(KnowledgeKind.USES, "every recipe type in the game's recipe list that takes the item as an "
                + "input", NOT_PROVIDED, Uses.class);
        numen.knowledgeSource(KnowledgeKind.INFO, "the game's own facts about the item: stack size, durability, food, "
                + "the block it places, its tags", List.of("descriptions"), Info.class);
    }

    /** 查哪一样。 */
    public record Query(@Doc("The item.") class_1792 item) {}

    /** {@code recipes} 的来源。 */
    public static final class Recipes {
        private Recipes() {}

        @Fn("The recipes that make an item, from the game's recipe list.")
        public static RecipePage read(ServerCall call, Query args) {
            return RecipeBook.recipesFor(args.item(), call.her());
        }
    }

    /** {@code uses} 的来源。 */
    public static final class Uses {
        private Uses() {}

        @Fn("The recipes that take an item as an input, from the game's recipe list.")
        public static RecipePage read(ServerCall call, Query args) {
            return RecipeBook.usesOf(args.item(), call.her());
        }
    }

    /** {@code info} 的来源。 */
    public static final class Info {
        private Info() {}

        @Fn("The game's own facts about an item.")
        public static InfoPage read(ServerCall call, Query args) {
            return new InfoPage(Optional.of(facts(args.item())), List.of());
        }
    }

    /** 读一样物品的事实。 */
    public static ItemFacts facts(class_1792 item) {
        class_1799 stack = item.method_7854();
        class_4174 food = stack.method_57824(class_9334.field_50075);
        return new ItemFacts(class_7923.field_41178.method_10221(item).toString(), stack.method_7914(),
                stack.method_7963() ? Optional.of(stack.method_7936()) : Optional.empty(),
                food == null ? Optional.empty()
                        : Optional.of(new ItemFacts.Food(food.comp_2491(), Math.round(food.comp_2492() * 100) / 100.0,
                                food.comp_2493())),
                item instanceof class_1747 block
                        ? Optional.of(class_7923.field_41175.method_10221(block.method_7711()).toString()) : Optional.empty(),
                class_7923.field_41178.method_47983(item).method_40228().map(t -> t.comp_327().toString()).sorted().toList());
    }
}
