package com.dwinovo.numen.pathing.search;

import java.util.Optional;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_3532;
import com.dwinovo.numen.pathing.plan.Stance;
import com.dwinovo.numen.pathing.world.BodyStats;
import com.dwinovo.numen.pathing.world.Footing;

/**
 * 搜索从哪个节点出发。身体的位置是连续的,节点是它脚所在的那一格(第 0 层 {@link Footing#cellOf});身体站在方块边沿、
 * 中心已经悬空时,那一格待不住,就从身体脚底压着的相邻几列里、同一个节点高度上待得住的那一列出发,取离身体中心最近的。
 * 这是"假起点"的唯一规则。
 */
public final class Origin {

    private Origin() {}

    /** 身体脚底中心在 {@code (x, feetY, z)} 时搜索的起点;身体脚底压着的每一列都待不住时为空。身体没在飞。 */
    public static Optional<class_2338> of(class_1922 level, BodyStats body, double x, double feetY, double z) {
        return of(level, body, x, feetY, z, false);
    }

    /**
     * 同上;飞着({@code flying})的身体在空中也待得住:脚所在的那一格世界里待不住、放得下身体,它就是起点({@link Stance#afloat})。
     * 飞着的身体不是站在边沿,不找旁边的列。
     */
    public static Optional<class_2338> of(class_1922 level, BodyStats body, double x, double feetY, double z, boolean flying) {
        int y = Footing.cellOf(feetY);
        class_2338 own = class_2338.method_49637(x, y, z);
        if (Stance.at(level, body, own, flying) != null) {
            return Optional.of(own);
        }
        double half = body.width() / 2;
        class_2338 best = null;
        double bestDistance = Double.POSITIVE_INFINITY;
        for (int cx = class_3532.method_15357(x - half); cx <= class_3532.method_15357(x + half); cx++) {
            for (int cz = class_3532.method_15357(z - half); cz <= class_3532.method_15357(z + half); cz++) {
                class_2338 node = new class_2338(cx, y, cz);
                if (node.equals(own) || Stance.at(level, body, node) == null) {
                    continue;
                }
                double dx = cx + 0.5 - x;
                double dz = cz + 0.5 - z;
                double distance = dx * dx + dz * dz;
                if (distance < bestDistance) {
                    best = node;
                    bestDistance = distance;
                }
            }
        }
        return Optional.ofNullable(best);
    }

    /**
     * 飞着的身体要走路:先垂直降下去({@code Alight}),降下去会落在的那一格是只走的搜索的起点——脚下往下第一个站得住的格;下面没有地面为空。
     */
    public static Optional<class_2338> alighting(class_1922 level, BodyStats body, double x, double feetY, double z) {
        for (int y = Footing.cellOf(feetY); y >= level.method_31607(); y--) {
            class_2338 cell = class_2338.method_49637(x, y, z);
            Stance stance = Stance.at(level, body, cell);
            if (stance != null && stance.grounded()) {
                return Optional.of(cell);
            }
        }
        return Optional.empty();
    }
}
