package com.dwinovo.numen.tools;

import com.dwinovo.numen.api.entity.BodyAction;
import com.dwinovo.numen.api.entity.Hotbar;
import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.sdk.Call;
import com.dwinovo.numen.api.sdk.Doc;
import com.dwinovo.numen.api.sdk.Pending;
import com.dwinovo.numen.nav.NavText;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_7923;
import net.minecraft.class_9262;
import net.minecraft.class_9301;
import net.minecraft.class_9302;
import net.minecraft.class_9334;

/**
 * 书:读书与笔、成书的标题作者各页({@code numen.inv.read}、讲台上那本),和往书与笔里写字、署名({@code numen.inv.write})。
 * 写是替她发 {@code EditBook}(见 {@code ClientPackets}),原版只认快捷栏或副手里的书与笔,校验和落地是原版做的,发完读回来。
 */
public final class Books {

    private Books() {}

    /** 一本书的字。 */
    @Doc("A book and quill or a written book, read.")
    public record Book(@Doc("minecraft:writable_book or minecraft:written_book.") String item,
                       @Doc("Its title; only a written book has one.") Optional<String> title,
                       @Doc("Who signed it; only a written book has an author.") Optional<String> author,
                       @Doc("The text of each page, in order.") List<String> pages,
                       @Doc("Signed: it can no longer be edited.") boolean signed) {}

    /** 一叠东西若是书与笔或成书,读出它的字;不是书是空。 */
    public static Optional<Book> read(class_1799 stack) {
        String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        if (stack.method_31574(class_1802.field_8674)) {
            class_9301 content = stack.method_57825(class_9334.field_49653, class_9301.field_49369);
            return Optional.of(new Book(id, Optional.empty(), Optional.empty(),
                    content.comp_2422().stream().map(class_9262::comp_2369).toList(), false));
        }
        if (stack.method_31574(class_1802.field_8360)) {
            class_9302 content = stack.method_57825(class_9334.field_49606, class_9302.field_49829);
            return Optional.of(new Book(id, Optional.of(content.comp_2419().comp_2369()), Optional.of(content.comp_2420()),
                    content.comp_2422().stream().map(page -> page.comp_2369().getString()).toList(), true));
        }
        return Optional.empty();
    }

    /** 背包(含副手)里这一种书,每一本读一遍,先见先列。 */
    public static List<Book> carried(NumenPlayer her, net.minecraft.class_1792 item) {
        if (item != class_1802.field_8674 && item != class_1802.field_8360) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "only a book and quill or a written book can be read",
                    Call.of("numen.inv.read", "minecraft:written_book"));
        }
        class_1661 inventory = her.method_31548();
        java.util.ArrayList<Book> out = new java.util.ArrayList<>();
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (inventory.method_5438(i).method_31574(item)) {
                read(inventory.method_5438(i)).ifPresent(out::add);
            }
        }
        return out;
    }

    /**
     * 往快捷栏或副手里的书与笔写上这些页;{@code title} 有值就署名成成书。书不在那两处就先拿到手上(和 {@code numen.gear.hold} 同一个拿法,
     * 拿了什么如实报告)。页数、每页和标题的长度取原版客户端能发的上限;原版排队写完之后读回来,写进去的和要的不一样就是没成。
     *
     * @param title 署名的书名;不署名为 null
     */
    public static Pending<Book> write(NumenPlayer her, List<String> pages, String title) {
        if (pages.size() > class_9301.field_51411
                || pages.stream().anyMatch(page -> page.length() > class_9301.field_49370)) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "a book holds at most " + class_9301.field_51411
                    + " pages of " + class_9301.field_49370 + " characters", null);
        }
        if (title != null && (title.isBlank() || title.length() > class_9302.field_49378)) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "a title is 1 to " + class_9302.field_49378
                    + " characters", null);
        }
        Hotbar.Grip grip = her.hotbar().grip(class_1802.field_8674);
        if (!grip.ready()) {
            throw new ApiError(ErrorKind.NOT_FOUND, "you carry no book and quill", Call.of("numen.inv.make",
                    "minecraft:writable_book"));
        }
        int slot = grip.hand() == net.minecraft.class_1268.field_5808 ? her.method_31548().field_7545
                : class_1661.field_30639;
        Pending<Book> out = Pending.create();
        her.packets().editBook(slot, pages, Optional.ofNullable(title));
        her.packets().afterHandled(() -> {
            Optional<Book> now = read(her.method_31548().method_5438(slot));
            boolean written = now.isPresent() && now.get().pages().equals(pages)
                    && now.get().signed() == (title != null)
                    && (title == null || now.get().title().equals(Optional.of(title)));
            if (!written) {
                out.fail(new ApiError(ErrorKind.FAILED, "the book was not written as asked: the slot now holds "
                        + (now.isPresent() ? now.get() : her.method_31548().method_5438(slot)),
                        Call.of("numen.inv.read", "minecraft:writable_book")));
                return;
            }
            BodyAction moved = grip.action();
            out.report((moved == null ? "" : NavText.actions(List.of(moved)) + "; ") + "wrote " + pages.size()
                    + " pages" + (title == null ? " into the book and quill" : " and signed it \"" + title + "\"")
                    + " in hotbar slot " + slot + ".");
            out.complete(now.get());
        });
        return out;
    }
}
