package com.dwinovo.numen.pathing.plan;

import java.util.List;
import net.minecraft.class_2338;
import com.dwinovo.numen.pathing.world.BodyStats;
import com.dwinovo.numen.pathing.world.CellFlags;
import com.dwinovo.numen.pathing.world.Footing;
import com.dwinovo.numen.pathing.world.Semantics;
import com.dwinovo.numen.pathing.world.Kinematics;

/**
 * 垫柱:原地起跳,在脚刚离开的那一格放一块,落在它上面,升一个节点。
 *
 * <p>前提:起步时站在地上,脚所在那一格不泡在液体里(水里跳不起来);那一格放得进一块垫路料(要改地形、要有料,放的那一刻
 * 身体已经跳离了它);放下后脚落在新方块上的高度不超过起跳能升的高度;头顶挡着的挖开、门就开关。在梯子、藤蔓上往上是
 * {@link Climb},不是垫柱。
 */
final class Pillar implements Move {

    private static final List<Heading> HEADINGS = List.of(Heading.UP);

    @Override
    public MoveKind kind() {
        return MoveKind.PILLAR;
    }

    @Override
    public List<Heading> headings() {
        return HEADINGS;
    }


    @Override
    public Premise premise(CostModel model, WorldView view, class_2338 from, Stance stance, Heading heading) {
        if (!stance.grounded() || Strides.feetInFluid(view, from)) {
            return Premise.fail(from, Reason.WRONG_STANCE);
        }
        BodyStats body = model.body().stats();
        Draft draft = new Draft(model, view);
        class_2338 to = from.method_10084();
        double f0 = stance.feetY();
        double peak = f0 + Kinematics.jumpHeight(body, Semantics.jumpFactor(view, from.method_10263(), f0, from.method_10260()));
        // 头顶先腾出来:身体要在垫好的那一块上放得下
        if (!draft.clear(Strides.at(draft, body, to, to.method_10264()), true, from.method_10263(), f0, from.method_10260(), true)) {
            return draft.failure();
        }
        // 放的那一刻身体已经跳到落点的脚高
        if (!draft.place(from, from.method_10263(), to.method_10264(), from.method_10260())) {
            return draft.failure();
        }
        double f1 = Footing.height(draft, body, to.method_10263(), to.method_10264(), to.method_10260());
        if (Double.isNaN(f1)) {
            return Premise.fail(to, Reason.NO_FOOTING);
        }
        if (f1 > peak + Footing.EPSILON) {
            return Premise.fail(to, Reason.TOO_HIGH);
        }
        Stance landing = Stance.at(draft, body, to);
        if (landing == null) {
            return Premise.fail(to, Reason.NO_CLEARANCE);
        }
        Contact contact = new Contact(body, from, f0).column(from.method_10263(), from.method_10260(), f0, f1);
        class_2338 support = landing.support(to.method_10263(), to.method_10260());
        if (!contact.admit(draft, model, support, false)) {
            return draft.failure();
        }
        return new Premise.Holds(new Maneuver(MoveKind.PILLAR, heading, from, stance, to, landing, true, false, false, false,
                Strides.submerged(draft, body, from, stance, to, landing), 1, 0, 0, 0, draft.edits(), contact.cells(), contact.exposure(), support,
                Strides.reversible(draft, body, from, stance, to, landing)));
    }

    /**
     * 垫柱要站着、脚所在的格不泡在流体里;还要放一块:这一趟一块也放不了就不成立。头顶挡着的格精确判断会先去挖(挖之前要瞄,
     * 瞄的射线读四周的格),所以放不了的只在四周读全了的节点上断定;其余答"可能",代价至少是起跳上一格、起跳的罚分与放一块。
     */
    @Override
    public int quick(Quick q, Heading heading) {
        if (!q.stance().grounded() || (q.own() & CellFlags.FLUID) != 0) {
            return Quick.REJECT;
        }
        if (!q.mayPlace() && q.loadedAround(0, 0)) {
            return Quick.REJECT;
        }
        return q.likely(0, 1, 0, q.stepJump() + q.jumpPenalty() + q.placeFloor());
    }

    @Override
    public double cost(CostModel model, Maneuver m) {
        return Strides.jump(model, 1) + model.spec().jumpPenalty() + model.overhead(m);
    }

    @Override
    public double ticks(CostModel model, Maneuver m) {
        return Strides.jump(model, 1) + model.workTicks(m);
    }
}
