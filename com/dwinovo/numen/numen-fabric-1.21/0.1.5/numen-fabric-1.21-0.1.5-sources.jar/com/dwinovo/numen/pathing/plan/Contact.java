package com.dwinovo.numen.pathing.plan;

import java.util.Arrays;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import com.dwinovo.numen.pathing.spec.PositionCosts.Use;
import com.dwinovo.numen.pathing.spec.RouteSpec;
import com.dwinovo.numen.pathing.world.BodyStats;
import com.dwinovo.numen.pathing.world.Clearance;
import com.dwinovo.numen.pathing.world.Footing;
import com.dwinovo.numen.pathing.world.Semantics;
import com.dwinovo.numen.pathing.world.Semantics.Kind;

/**
 * 身体这一步碰到的格,以及它们能不能碰:每种走法把身体经过的列与脚高范围报进来,这里数出新进入的格(起步时已经占着的
 * 不算),再统一按路线规格查——排除的语义种类、按位置的"穿过"与"站上"禁令、按种类的"不站"禁令,以及从高处落上去会
 * 踩坏的格。走法各自只管几何,碰到什么一律在这里判,只此一处。
 *
 * <p>身体碰到的是它的碰撞盒占到的格,外加脚踩的那一格(岩浆块踩上去就烫)。细雪托得住的身体站在细雪上不会陷进去,
 * 细雪对它不算危险。进入的格与脚下那一格水平方向上紧挨着的伤身的格(岩浆、火、仙人掌……)也在这里数出来,挨着它们走要加价
 * ({@link CostModel#overhead}),路线因此离它们远一点。
 *
 * <p>一步碰到的格只有十来个,记在一个按需加长的数组里、逐个比对去重;种类一律按位掩码判({@link Semantics#mask}),
 * 前提函数每一步都要问它,不建集合。
 */
final class Contact {

    /** 碰了伤身的种类:挨着它走,身子歪一点就碰上。 */
    private static final int HARMFUL = Semantics.bit(Kind.LAVA) | Semantics.bit(Kind.HAZARD);
    /** 水平方向紧挨着的四格(北东南西),{x, z} 偏移。 */
    private static final int[][] SIDES = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};

    private final BodyStats body;
    private final int fromX;
    private final int fromZ;
    private final int fromLow;
    private final int fromHigh;
    /** 新进入的格,按进入的先后。 */
    private final Cells cells = new Cells();
    /** 斜走擦过的拐角列脚下的格({@link #over});没斜走过为 null。 */
    private Cells beneath;
    private int exposure;

    /** 身体起步时脚在 {@code (from 那一列, fromFeet)}:它那时占着的格不算新进入的。 */
    Contact(BodyStats body, class_2338 from, double fromFeet) {
        this.body = body;
        this.fromX = from.method_10263();
        this.fromZ = from.method_10260();
        this.fromLow = Footing.cellOf(fromFeet);
        this.fromHigh = Clearance.topCell(body, fromFeet);
    }

    /** 身体在 {@code (x, z)} 这一列经过,脚在 {@code lowFeet} 到 {@code highFeet} 之间。 */
    Contact column(int x, int z, double lowFeet, double highFeet) {
        int low = Footing.cellOf(Math.min(lowFeet, highFeet));
        int high = Clearance.topCell(body, Math.max(lowFeet, highFeet));
        for (int y = low; y <= high; y++) {
            if (x == fromX && z == fromZ && y >= fromLow && y <= fromHigh) {
                continue;
            }
            cells.add(class_2338.method_10064(x, y, z));
        }
        return this;
    }

    /**
     * 斜走擦过 {@code (x, z)} 这一列的拐角:身体的脚底压在它上面,脚在 {@code feet} 高时托着脚的那一格也算踩到了。直着走只踩起步与落点那两列
     * (落点脚下的由 {@link #admit} 的 {@code support} 管),不会擦到别的列。
     */
    Contact over(int x, int z, double feet) {
        beneath = Cells.add(beneath, class_2338.method_10064(x, Footing.cellOf(feet) - 1, z));
        return this;
    }

    long[] cells() {
        return Arrays.copyOf(cells.items, cells.size);
    }

    /** 这一步新进入的格与脚下那一格水平方向上紧挨着几格伤身的({@link #admit} 时数出来)。 */
    int exposure() {
        return exposure;
    }

    /** 这一格碰了伤身:岩浆、危险方块;托得住身体的细雪不算。只看这一格的方块状态,读一次。 */
    private boolean harmful(Draft draft, class_2338 pos) {
        class_2680 state = draft.method_8320(pos);
        return (Semantics.stateMask(state) & HARMFUL) != 0 && !(body.walksOnPowderSnow() && state.method_27852(class_2246.field_27879));
    }

    /**
     * 这些格与脚踩的 {@code support} 这条路线碰不碰得:不行就在草稿上记下哪一格、为什么。
     *
     * @param support    落定后脚踩的那一格;不是站着为 null
     * @param fromHeight 是从高处落上去的(落差超过半格):耕地、海龟蛋会被踩坏
     */
    boolean admit(Draft draft, CostModel model, class_2338 support, boolean fromHeight) {
        RouteSpec spec = model.spec();
        class_2338.class_2339 pos = new class_2338.class_2339();
        // 挨着的伤身格多半一个都没有:碰上了才建表
        Cells near = null;
        for (int i = 0; i < cells.size; i++) {
            long cell = cells.items[i];
            pos.method_16363(cell);
            if (model.excludes(Semantics.mask(draft, pos))) {
                return draft.fail(pos, Reason.EXCLUDED);
            }
            if (model.forbids(Use.PASS, cell)) {
                return draft.fail(pos, Reason.FORBIDDEN);
            }
            for (int[] side : SIDES) {
                long beside = class_2338.method_10096(cell, side[0], 0, side[1]);
                if (!cells.contains(beside) && harmful(draft, pos.method_16363(beside))) {
                    near = Cells.add(near, beside);
                }
            }
        }
        for (int i = 0; beneath != null && i < beneath.size; i++) {
            pos.method_16363(beneath.items[i]);
            if (model.excludes(Semantics.mask(draft, pos))) {
                return draft.fail(pos, Reason.EXCLUDED);
            }
        }
        if (support != null) {
            // 脚下那一格旁边的也算:站在岩浆坑边上,脚底一滑就下去了
            long under = support.method_10063();
            for (int[] side : SIDES) {
                long beside = class_2338.method_10096(under, side[0], 0, side[1]);
                if (harmful(draft, pos.method_16363(beside))) {
                    near = Cells.add(near, beside);
                }
            }
        }
        exposure = near == null ? 0 : near.size;
        if (support == null) {
            return true;
        }
        class_2680 state = draft.method_8320(support);
        int kinds = Semantics.mask(draft, support);
        if (body.walksOnPowderSnow() && state.method_27852(class_2246.field_27879)) {
            kinds &= ~Semantics.bit(Kind.HAZARD);
        }
        if (model.excludes(kinds)) {
            return draft.fail(support, Reason.EXCLUDED);
        }
        if (fromHeight && (kinds & Semantics.bit(Kind.FRAGILE)) != 0) {
            return draft.fail(support, Reason.TRAMPLES);
        }
        if (model.forbids(Use.STAND, support.method_10063()) || spec.bans().standingOn().contains(state.method_26204())) {
            return draft.fail(support, Reason.FORBIDDEN);
        }
        return true;
    }

    /** 一步里数出来的格,{@link class_2338#method_10063} 编码,不重复:只有十来个,逐个比对比建哈希表快。 */
    private static final class Cells {
        private long[] items = new long[4];
        private int size;

        boolean contains(long cell) {
            for (int i = 0; i < size; i++) {
                if (items[i] == cell) {
                    return true;
                }
            }
            return false;
        }

        void add(long cell) {
            if (contains(cell)) {
                return;
            }
            if (size == items.length) {
                items = Arrays.copyOf(items, size * 2);
            }
            items[size++] = cell;
        }

        /** 加进 {@code into};它还没建就先建一个。 */
        static Cells add(Cells into, long cell) {
            Cells out = into == null ? new Cells() : into;
            out.add(cell);
            return out;
        }
    }
}
