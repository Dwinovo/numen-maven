package com.dwinovo.numen.tools.shape;

import com.dwinovo.numen.build.BuildStates;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_2769;

/**
 * 方块状态跟着一个 3×3 线性变换转(转向、翻转):全仓"方块状态怎么转"只有这一处。
 *
 * <p>分工:水平面里的 90° 倍数转动与水平镜像一律走原版的 {@code BlockState.rotate} 与 {@code mirror}——每种方块(模组的也是)自己知道
 * 铁轨、门、楼梯内外角、合成器朝向怎么转。原版不覆盖的(竖直翻转、绕 X 与 Z 转、不是 90° 倍数的转动)照 WorldEdit
 * {@code BlockTransformExtent} 的规则:方向属性取变换后最接近的方向,{@code axis}、{@code rotation}、东南西北四面、铁轨的 {@code shape}、
 * 合成器的 {@code orientation} 同理,{@code half}/{@code type} 随竖直翻转上下互换,楼梯 {@code shape} 与箱子 {@code type} 随水平翻转左右互换。
 * 变换后落不进这个方块的取值范围的(横向的 {@code axis} 转到竖直),这个属性保持原样。
 */
final class BlockTurns {

    private BlockTurns() {}

    /**
     * 每一种写法转一遍:没变的原样交回(模型写的是什么就是什么);变了的照它的写法改——方块名、写了的属性及其先后、NBT 原文都留着,
     * 只把属性的值换成转后的,没写的属性转后变了值的补在后面。
     */
    static List<String> turn(List<String> written, double[][] matrix) {
        Map<String, String> done = new HashMap<>();
        List<String> out = new ArrayList<>(written.size());
        for (String w : written) {
            out.add(done.computeIfAbsent(w, one -> turnOne(one, matrix)));
        }
        return out;
    }

    private static String turnOne(String written, double[][] m) {
        class_2680 before = BuildStates.parse(written, true).comp_622();
        class_2680 after = turn(before, m);
        return after == before ? written : restated(written.trim(), before, after);
    }

    private static String restated(String text, class_2680 before, class_2680 after) {
        int open = text.indexOf('[');
        int brace = text.indexOf('{');
        boolean states = open >= 0 && (brace < 0 || open < brace);
        int close = states ? text.indexOf(']', open) : -1;
        String head = states ? text.substring(0, open) : brace >= 0 ? text.substring(0, brace) : text;
        String tail = states ? text.substring(close + 1) : brace >= 0 ? text.substring(brace) : "";
        List<String> parts = new ArrayList<>();
        List<String> written = new ArrayList<>();
        if (states) {
            for (String pair : text.substring(open + 1, close).split(",")) {
                String key = pair.split("=", 2)[0].trim();
                class_2769<?> p = after.method_26204().method_9595().method_11663(key);
                written.add(key);
                parts.add(key + "=" + name(p, after.method_11654(p)));
            }
        }
        List<class_2769<?>> others = new ArrayList<>(after.method_28501());
        others.sort((a, b) -> a.method_11899().compareTo(b.method_11899()));
        for (class_2769<?> p : others) {
            if (!written.contains(p.method_11899()) && !name(p, before.method_11654(p)).equals(name(p, after.method_11654(p)))) {
                parts.add(p.method_11899() + "=" + name(p, after.method_11654(p)));
            }
        }
        return head.trim() + (parts.isEmpty() ? "" : "[" + String.join(",", parts) + "]") + tail;
    }

    static class_2680 turn(class_2680 state, double[][] m) {
        Optional<class_2680> vanilla = horizontal(state, m);
        return vanilla.orElseGet(() -> nearestTurn(state, m));
    }

    // ---- 原版能做的:水平面里的四分之一转与镜像 ----

    /** 变换只动水平面、且是 90° 的倍数(可带水平镜像):交给原版;不是就空。 */
    private static Optional<class_2680> horizontal(class_2680 state, double[][] m) {
        if (m[1][1] != 1 || m[0][1] != 0 || m[1][0] != 0 || m[1][2] != 0 || m[2][1] != 0) {
            return Optional.empty();
        }
        // 先镜像(不镜像、前后、左右)再转:变换 = 转 · 镜像,取不用转的那一种(不转最省)
        class_2415[] mirrors = {class_2415.field_11302, class_2415.field_11300, class_2415.field_11301};
        class_2470 best = null;
        class_2415 bestMirror = null;
        for (class_2415 mirror : mirrors) {
            class_2470 rotation = rotationOf(m[0][0] * (mirror == class_2415.field_11301 ? -1 : 1), m[0][2] * (mirror == class_2415.field_11300 ? -1 : 1),
                    m[2][0] * (mirror == class_2415.field_11301 ? -1 : 1), m[2][2] * (mirror == class_2415.field_11300 ? -1 : 1));
            if (rotation != null && (best == null || (best != class_2470.field_11467 && rotation == class_2470.field_11467))) {
                best = rotation;
                bestMirror = mirror;
            }
        }
        if (best == null) {
            return Optional.empty();
        }
        return Optional.of(state.method_26185(bestMirror).method_26186(best));
    }

    /** 2×2 阵 (a b; c d) 作用在 (x, z) 上:是哪个顺时针转动(从上看)。东 (1,0) 转到南 (0,1) 是顺时针 90°。不是四分之一转是 null。 */
    private static class_2470 rotationOf(double a, double b, double c, double d) {
        if (a == 1 && b == 0 && c == 0 && d == 1) {
            return class_2470.field_11467;
        }
        if (a == 0 && b == -1 && c == 1 && d == 0) {
            return class_2470.field_11463;
        }
        if (a == -1 && b == 0 && c == 0 && d == -1) {
            return class_2470.field_11464;
        }
        if (a == 0 && b == 1 && c == -1 && d == 0) {
            return class_2470.field_11465;
        }
        return null;
    }

    // ---- 原版不覆盖的:WorldEdit 的规则 ----

    private static final List<class_2350> CARDINAL = List.of(class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039);
    private static final List<class_2350> UPRIGHT_AND_CARDINAL = List.of(class_2350.field_11043, class_2350.field_11034, class_2350.field_11035,
            class_2350.field_11039, class_2350.field_11036, class_2350.field_11033);
    private static final List<String> STRAIGHT_RAILS = List.of("north_south", "east_west", "ascending_east", "ascending_west",
            "ascending_north", "ascending_south");

    /**
     * 原版管不到的变换:按原状态的属性次序一个个改(后面的读前面改过的),每个属性只认它的类型或名字;最后把东南西北四面搬到转后的面上。
     * 设的值这个方块不接受的,那个属性不变。
     */
    private static class_2680 nearestTurn(class_2680 original, double[][] m) {
        boolean sideFlip = m[0][0] * m[2][2] - m[0][2] * m[2][0] < 0;
        boolean upFlip = m[1][1] < 0;
        class_2680 turned = original;
        for (class_2769<?> p : original.method_28501()) {
            String value = name(p, turned.method_11654(p));
            if (p instanceof class_2753 facing) {
                class_2350 to = closest(m, turned.method_11654(facing), List.copyOf(facing.method_11898()), true);
                if (to != null) {
                    turned = with(turned, p, to.method_15434());
                }
            } else if (p.method_11899().equals("axis")) {
                class_2350 along = switch (value) {
                    case "x" -> class_2350.field_11034;
                    case "y" -> class_2350.field_11036;
                    case "z" -> class_2350.field_11043;
                    default -> null;
                };
                class_2350 to = along == null ? null : closest(m, along, UPRIGHT_AND_CARDINAL, true);
                if (to != null) {
                    turned = with(turned, p, to.method_10166().method_10174());
                }
            } else if (p.method_11899().equals("type")) {
                String type = sideFlip ? swapped(value, "left", "right") : value;
                turned = with(turned, p, upFlip ? swapped(type, "bottom", "top") : type);
            } else if (p.method_11899().equals("half")) {
                if (upFlip) {
                    turned = with(turned, p, swapped(value, "bottom", "top"));
                }
            } else if (p.method_11899().equals("shape")) {
                String shape = sideFlip ? swapped(swapped(value, "outer_left", "outer_right"), "inner_left", "inner_right") : value;
                turned = with(turned, p, shape);
                if (isRailShape(p)) {
                    turned = with(turned, p, railShape(p, name(p, turned.method_11654(p)), m, upFlip));
                }
            } else if (p.method_11899().equals("orientation")) {
                turned = with(turned, p, crafterOrientation(value, m));
            } else if (p.method_11899().equals("rotation") && p instanceof class_2758 steps && steps.method_11898().size() == 16) {
                turned = turned.method_11657(steps, turnedRotation(turned.method_11654(steps), m));
            }
        }
        return sides(original, turned, m);
    }

    /**
     * 东南西北四面(围栏、墙、玻璃板、红石线、藤蔓…):原状态里开着的面(布尔真,或枚举不是 none),先全部清掉,再统一搬到变换后最接近的那一面;
     * 两面落到同一面时按北东南西靠后的为准。没开着的、或转不出方向的面保持 turned 里的值。
     */
    private static class_2680 sides(class_2680 original, class_2680 turned, double[][] m) {
        Map<class_2769<?>, String> moved = new HashMap<>();
        class_2680 out = turned;
        for (class_2350 side : CARDINAL) {
            class_2769<?> from = original.method_26204().method_9595().method_11663(side.method_15434());
            if (from == null) {
                continue;
            }
            boolean flag = from.method_11902() == Boolean.class;
            String value = name(from, original.method_11654(from));
            if (value.equals(flag ? "false" : "none")) {
                continue;
            }
            class_2350 to = closest(m, side, CARDINAL, false);
            if (to == null) {
                continue;
            }
            out = with(out, from, flag ? "false" : "none");
            class_2769<?> target = original.method_26204().method_9595().method_11663(to.method_15434());
            if (target != null) {
                moved.put(target, value);
            }
        }
        for (Map.Entry<class_2769<?>, String> e : moved.entrySet()) {
            out = with(out, e.getKey(), e.getValue());
        }
        return out;
    }

    /** 铁轨的 shape:取值里有全部六种直轨的那种。 */
    private static boolean isRailShape(class_2769<?> p) {
        List<String> values = new ArrayList<>();
        for (Comparable<?> v : p.method_11898()) {
            values.add(name(p, v));
        }
        return values.containsAll(STRAIGHT_RAILS);
    }

    /**
     * 铁轨形状 {@code a_b}:竖直翻转先把上坡的方向反过来;两段里是方向的各自在水平四向里取最近的,{@code a_b} 不是这种铁轨的取值就试
     * {@code b_a},都不是就留竖直翻转后的值。
     */
    private static String railShape(class_2769<?> p, String shape, double[][] m, boolean verticalFlip) {
        String flipped = verticalFlip
                ? swapped(swapped(shape, "ascending_east", "ascending_west"), "ascending_north", "ascending_south") : shape;
        int cut = flipped.indexOf('_');
        if (cut < 0) {
            return flipped;
        }
        String a = horizontalTurn(flipped.substring(0, cut), m);
        String b = horizontalTurn(flipped.substring(cut + 1), m);
        if (p.method_11900(a + "_" + b).isPresent()) {
            return a + "_" + b;
        }
        if (p.method_11900(b + "_" + a).isPresent()) {
            return b + "_" + a;
        }
        return flipped;
    }

    /** 方向名在水平四向里转到最近的那个;不是方向名(如 ascending)或转不出方向的原样。 */
    private static String horizontalTurn(String part, double[][] m) {
        class_2350 d = class_2350.method_10168(part);
        if (d == null) {
            return part;
        }
        class_2350 to = closest(m, d, CARDINAL, false);
        return to == null ? part : to.method_15434();
    }

    /** 合成器的 orientation:{@code 朝向_上方}(朝向可以是上下,上方只在水平方向里选,朝下换成朝上)。 */
    private static String crafterOrientation(String orientation, double[][] m) {
        int cut = orientation.indexOf('_');
        if (cut < 0) {
            return orientation;
        }
        class_2350 front = class_2350.method_10168(orientation.substring(0, cut));
        class_2350 top = class_2350.method_10168(orientation.substring(cut + 1));
        if (front == null || top == null) {
            return orientation;
        }
        class_2350 newFront = closest(m, front, UPRIGHT_AND_CARDINAL, true);
        class_2350 newTop = closest(m, top, UPRIGHT_AND_CARDINAL, true);
        if (newFront == null || newTop == null) {
            return orientation;
        }
        if (newTop == class_2350.field_11033) {
            newTop = class_2350.field_11036;
        }
        return newFront.method_15434() + "_" + newTop.method_15434();
    }

    /** 告示牌、旗帜、头颅的 0..15 档:十六个水平方向里取变换后最接近的;0 是南,每档 22.5°,4 是西。 */
    private static int turnedRotation(int index, double[][] m) {
        double angle = Math.toRadians(index * 22.5);
        double[] v = apply(m, -Math.sin(angle), 0, Math.cos(angle));
        if (Math.hypot(v[0], v[2]) < 1e-9) {
            return index;
        }
        long steps = Math.round(Math.toDegrees(Math.atan2(-v[0], v[2])) / 22.5);
        return (int) Math.floorMod(steps, 16L);
    }

    /**
     * 一个方向变换后,候选里最接近的那个(点积最大,并列取后面的,同 WorldEdit);{@code withY} 为否时竖直分量不算。变换把它转成了零向量是 null。
     */
    private static class_2350 closest(double[][] m, class_2350 d, List<class_2350> candidates, boolean withY) {
        double[] v = apply(m, d.method_10148(), d.method_10164(), d.method_10165());
        if (!withY) {
            v[1] = 0;
        }
        double length = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (length < 1e-9) {
            return null;
        }
        class_2350 best = null;
        double bestDot = Double.NEGATIVE_INFINITY;
        for (class_2350 c : candidates) {
            double dot = (v[0] * c.method_10148() + v[1] * c.method_10164() + v[2] * c.method_10165()) / length;
            if (dot >= bestDot) {
                best = c;
                bestDot = dot;
            }
        }
        return best;
    }

    private static double[] apply(double[][] m, double x, double y, double z) {
        return new double[]{m[0][0] * x + m[0][1] * y + m[0][2] * z, m[1][0] * x + m[1][1] * y + m[1][2] * z,
                m[2][0] * x + m[2][1] * y + m[2][2] * z};
    }

    private static String swapped(String value, String a, String b) {
        return value.equals(a) ? b : value.equals(b) ? a : value;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static String name(class_2769<?> p, Comparable<?> value) {
        return ((class_2769) p).method_11901(value);
    }

    /** 把这个属性设成名字为 value 的取值;这个方块没有这个取值就保持原样。 */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static class_2680 with(class_2680 state, class_2769<?> p, String value) {
        Optional<?> v = p.method_11900(value.toLowerCase(Locale.ROOT));
        return v.isPresent() ? state.method_11657((class_2769) p, (Comparable) v.get()) : state;
    }
}
