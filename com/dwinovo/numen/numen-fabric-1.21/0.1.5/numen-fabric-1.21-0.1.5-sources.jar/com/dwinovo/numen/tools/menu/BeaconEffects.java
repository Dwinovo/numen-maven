package com.dwinovo.numen.tools.menu;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_2580;
import net.minecraft.class_6880;

/**
 * 信标按金字塔层数能选哪些效果,和原版客户端 {@code BeaconScreen} 里哪些按钮点得了是同一张表({@code BeaconBlockEntity.BEACON_EFFECTS}):
 * 前三组是主效果,第 {@code i} 组要 {@code i + 1} 层以上;最后一组(再生)是副效果,要 4 层,副效果也可以是和主效果一样的那一个。
 * 原版服务端收 {@code SetBeacon} 时不查层数,所以谁都能发出点不了的按钮对应的包;这里只让她发真客户端点得了的。
 */
final class BeaconEffects {

    /** 副效果要的层数。 */
    static final int SECONDARY_LEVELS = 4;

    private BeaconEffects() {}

    /** 这个层数下能选的主效果,按原版的先后。 */
    static List<class_6880<class_1291>> primaries(int levels) {
        List<class_6880<class_1291>> out = new ArrayList<>();
        for (int tier = 0; tier < Math.min(levels, class_2580.field_11801.size() - 1); tier++) {
            out.addAll(class_2580.field_11801.get(tier));
        }
        return out;
    }

    /** 这个层数下除了"和主效果一样"之外能选的副效果。 */
    static List<class_6880<class_1291>> secondaries(int levels) {
        return levels >= SECONDARY_LEVELS ? class_2580.field_11801.get(class_2580.field_11801.size() - 1)
                : List.of();
    }

    /** 效果的名字:注册表里的路径,{@code haste}。 */
    static String name(class_6880<class_1291> effect) {
        return effect.method_40230().map(key -> key.method_29177().method_12832()).orElse("?");
    }

    static List<String> names(List<class_6880<class_1291>> effects) {
        return effects.stream().map(BeaconEffects::name).toList();
    }
}
