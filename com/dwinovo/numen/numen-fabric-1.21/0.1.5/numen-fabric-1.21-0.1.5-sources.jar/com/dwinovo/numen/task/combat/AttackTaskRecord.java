package com.dwinovo.numen.task.combat;

import com.dwinovo.numen.api.task.Activity;
import com.dwinovo.numen.api.task.TaskRecord;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * {@code fight attack} 的进度账本:请求的实体 id、每个 id 的终态(打倒/丢失/够不着)与出手次数。
 *
 * <p>近战与远程曾是两个工具、两份账本,差别只在措辞("defeated/hits" 对 "destroyed/shots"),
 * 为此有三个抽象的词汇钩子。现在只有一个工具,措辞也就只有一套,钩子跟着消失。
 */
public final class AttackTaskRecord extends TaskRecord<Fought> {

    public final List<Integer> entityIds;

    /**
     * 不点名,打退附近所有敌对生物。
     *
     * <p>按 id 授权在会分裂的怪面前根本行不通:打一只大史莱姆,它裂成四只<b>全新 id</b> 的
     * 小史莱姆,原来那份清单当场作废,任务判"目标丢失"收工,而她还站在史莱姆堆里。
     */
    public final boolean indiscriminate;

    private final Set<Integer> defeated = new LinkedHashSet<>();
    private final Set<Integer> lost = new LinkedHashSet<>();
    private final Set<Integer> unreachable = new LinkedHashSet<>();
    /** 权限层不让打的:id → 理由。宠物、有名字的、村民,主人没点头就不动手。 */
    private final Map<Integer, String> refused = new LinkedHashMap<>();
    private final Map<Integer, Integer> strikesByEntity = new LinkedHashMap<>();
    private int strikes;

    /**
     * @param name       这件活叫什么:命令派的是那次调用的任务名,本能开的仗是本能的 id
     * @param toolCallId 派它的那次调用;本能开的仗是本能自己起的号
     */
    public AttackTaskRecord(String name, String toolCallId, long deadlineGameTime,
                            List<Integer> entityIds, boolean indiscriminate) {
        super(name, toolCallId, deadlineGameTime);
        this.entityIds = List.copyOf(entityIds);
        this.indiscriminate = indiscriminate;
    }

    public Set<Integer> defeated() { return Set.copyOf(defeated); }
    public Set<Integer> lost() { return Set.copyOf(lost); }
    public Set<Integer> unreachable() { return Set.copyOf(unreachable); }
    public Map<Integer, String> refused() { return Map.copyOf(refused); }
    public int strikes() { return strikes; }

    public void defeated(int id) { defeated.add(id); }
    public void lost(int id) { lost.add(id); }
    public void unreachable(int id) { unreachable.add(id); }
    public void refused(int id, String why) { refused.put(id, why); }

    /** 出手一次(挥击或射出一箭)。 */
    public void strike(int id) {
        strikes++;
        strikesByEntity.merge(id, 1, Integer::sum);
    }

    public int strikes(int id) { return strikesByEntity.getOrDefault(id, 0); }

    public String status(int id) {
        if (defeated.contains(id)) return "defeated";
        if (lost.contains(id)) return "lost";
        if (unreachable.contains(id)) return "unreachable";
        if (refused.containsKey(id)) return "refused: " + refused.get(id);
        return "pending";
    }

    public boolean terminal(int id) {
        return defeated.contains(id) || lost.contains(id) || unreachable.contains(id)
                || refused.containsKey(id);
    }

    /**
     * 一行人话 —— 这是<b>给模型看的</b>:{@code <current_task>} 与 task status 印的是它,主人看的是 {@link #activity()}。
     * 工具 id 不写进来,需要它的地方(运行时状态的 tool 属性、派发回执)本来就有。
     */
    @Override
    public String describe() {
        return indiscriminate
                ? "清场 已放倒 " + defeated.size()
                : "战斗 " + defeated.size() + "/" + entityIds.size();
    }

    /** 给主人看的一句(头顶气泡、档案页),客户端按当前语言翻;{@link #describe()} 是给模型的。 */
    @Override
    public Activity activity() {
        return indiscriminate
                ? Activity.of("numen.activity.attack_clear", defeated.size())
                : Activity.of("numen.activity.attack", defeated.size(), entityIds.size());
    }
}
