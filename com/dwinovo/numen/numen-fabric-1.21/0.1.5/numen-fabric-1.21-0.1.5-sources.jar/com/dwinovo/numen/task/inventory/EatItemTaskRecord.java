package com.dwinovo.numen.task.inventory;

import com.dwinovo.numen.api.task.Activity;
import com.dwinovo.numen.api.sdk.ServerCall;
import com.dwinovo.numen.api.task.TaskRecord;
import net.minecraft.class_1792;

/**
 * Typed task descriptor for {@code inv eat}: consume a food / drink from the
 * companion's inventory. {@link EatCompanionTask} eats it natively (the player
 * body's own held-use path), so hunger + saturation + consume effects apply
 * exactly as they do for a real player when the chew completes.
 */
public final class EatItemTaskRecord extends TaskRecord<EatCompanionTask.Ate> {

    /** Generous — covers any food's eat duration (most ~1.6s) plus buffer. */
    private static final long TIMEOUT_TICKS = 15 * 20;

    /** The food item to eat (one is consumed on completion). */
    public final class_1792 item;
    /** Human-readable label for messages / debug overlay (e.g. "golden_apple"). */
    public final String label;

    public EatItemTaskRecord(ServerCall source, class_1792 item, String label) {
        super(source, source.her().method_37908().method_8510() + TIMEOUT_TICKS);
        this.item = item;
        this.label = label;
    }

    @Override
    public String describe() {
        return getToolName() + " " + label;
    }

    /** 给主人看的一句(头顶气泡、档案页),客户端按当前语言翻;{@link #describe()} 是给模型的。 */
    @Override
    public Activity activity() {
        return Activity.of("numen.activity.eat", label);
    }
}
