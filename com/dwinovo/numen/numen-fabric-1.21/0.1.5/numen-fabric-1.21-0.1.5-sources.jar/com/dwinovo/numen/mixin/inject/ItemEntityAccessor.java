package com.dwinovo.numen.mixin.inject;

import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Read-only access to vanilla's private pickup-delay countdown and its "never" marker. */
@Mixin(class_1542.class)
public interface ItemEntityAccessor {

    @Accessor("pickupDelay")
    int numen$getPickupDelay();

    @Accessor("INFINITE_PICKUP_DELAY")
    static int numen$infinitePickupDelay() {
        throw new AssertionError();
    }
}
