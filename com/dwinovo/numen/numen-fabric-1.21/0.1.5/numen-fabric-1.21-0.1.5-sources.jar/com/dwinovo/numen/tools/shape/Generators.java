package com.dwinovo.numen.tools.shape;

import com.dwinovo.numen.api.sdk.BlockAt;
import com.dwinovo.numen.api.sdk.Call;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_2794;
import net.minecraft.class_2944;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_2979;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_3449;
import net.minecraft.class_4076;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_6796;
import net.minecraft.class_7924;

/**
 * 让原版(和模组)的生成器跑在 {@link RecordedLevel} 上,交回"要写什么":地物({@code //feature})、结构({@code //structure})、树林({@code //forest})
 * 靠注册表里的生成器本身;花草({@code //flora})与南瓜田({@code //pumpkins})是 WorldEdit 自己的算法。落点判据与 WorldEdit 一致:每列从选区最高处往下找
 * 第一块非空气的方块当地面,按密度掷骰子。真实世界一格不动。
 */
final class Generators {

    private Generators() {}

    /** 树林默认的树。 */
    static final String DEFAULT_TREE = "minecraft:oak_checked";
    /** WorldEdit 自己的两种树:随机挑一种,和它那棵简陋的松树。 */
    static final String RANDOM_TREE = "worldedit:random";
    static final String PINE_TREE = "worldedit:pine";
    /** 每个落点最多试几次(同 WorldEdit:原版的树常因为空间不够长不出来)。 */
    private static final int TREE_TRIES = 10;

    /** 生成的结果:要写的方块,和 Cells 装不下的东西。 */
    record Grown(List<BlockAt> blocks, List<RecordedLevel.Lost> lost) {

        static Grown of(RecordedLevel level) {
            return new Grown(level.blocks(), level.lost());
        }
    }

    // ---- 注册表 ----

    private static class_2960 id(String text, String what, String hint) {
        class_2960 id = class_2960.method_12829(text.trim().toLowerCase(java.util.Locale.ROOT));
        if (id == null) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, what + " \"" + text + "\" is not a valid id", hint(hint));
        }
        return id;
    }

    private static String hint(String function) {
        return Call.help(function);
    }

    /** 注册表里是树的放置地物:底下的地物是树、珊瑚树(模组注册的树也在里面)。 */
    static List<String> treeIds(class_3218 level) {
        class_2378<class_6796> placed = level.method_30349().method_30530(class_7924.field_41245);
        List<String> out = new ArrayList<>();
        for (var entry : placed.method_29722()) {
            var feature = entry.getValue().comp_334().comp_349().comp_332();
            if (feature instanceof class_2944 || feature instanceof class_2979) {
                out.add(entry.getKey().method_29177().toString());
            }
        }
        out.sort(null);
        return out;
    }

    private static class_6796 tree(class_3218 level, String text) {
        class_2960 id = id(text, "tree", "numen.shape.forest");
        class_6796 placed = level.method_30349().method_30530(class_7924.field_41245).method_10223(id);
        if (placed == null || !treeIds(level).contains(id.toString())) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "\"" + text + "\" is no tree of this game; trees are " + treeIds(level)
                    + " (and " + PINE_TREE + ", " + RANDOM_TREE + ")", hint("numen.shape.forest"));
        }
        return placed;
    }

    // ---- 地物、结构 ----

    private static ApiError failed(String what, Throwable cause) {
        return new ApiError(ErrorKind.FAILED, what + " could not be run on a recorded level: " + cause, null);
    }

    /** {@code //feature}:一个原版配置地物种在 at。 */
    static Grown feature(LoadedBlocks w, class_2338 at, String text) {
        class_3218 level = w.level();
        class_2960 id = id(text, "feature", "numen.shape.feature");
        class_2975<?, ?> feature = level.method_30349().method_30530(class_7924.field_41239).method_10223(id);
        if (feature == null) {
            throw new ApiError(ErrorKind.NOT_FOUND, "no feature \"" + text + "\" in this game", hint("numen.shape.feature"));
        }
        RecordedLevel recorded = new RecordedLevel(w);
        class_2794 generator = level.method_14178().method_12129();
        boolean placed;
        try {
            placed = recorded.attempt(() -> feature.method_12862(recorded.level(), generator, recorded.random(), at));
        } catch (ClassCastException | UnsupportedOperationException e) {
            throw failed("the feature " + id, e);
        }
        if (!placed) {
            throw new ApiError(ErrorKind.FAILED, "the feature " + id + " found no place to grow at " + at.method_23854()
                    + " (the game's own placement rules said no)", null);
        }
        return Grown.of(recorded);
    }

    /** {@code //structure}:一个原版结构在 at 所在区块生成(高度由区块生成器定,同 WorldEdit)。 */
    static Grown structure(LoadedBlocks w, class_2338 at, String text) {
        class_3218 level = w.level();
        class_2960 id = id(text, "structure", "numen.shape.structure");
        class_2378<class_3195> registry = level.method_30349().method_30530(class_7924.field_41246);
        class_3195 structure = registry.method_10223(id);
        if (structure == null) {
            throw new ApiError(ErrorKind.NOT_FOUND, "no structure \"" + text + "\" in this game",
                    hint("numen.shape.structure"));
        }
        RecordedLevel recorded = new RecordedLevel(w);
        class_2794 generator = level.method_14178().method_12129();
        class_5281 view = recorded.level();
        class_1923 chunkPos = new class_1923(at);
        boolean placed;
        try {
            placed = recorded.attempt(() -> {
                class_3449 start = structure.method_41614(
                        level.method_30349(), generator, generator.method_12098(), level.method_14178().method_41248(),
                        level.method_14183(), level.method_8412(), chunkPos, 0, view, biome -> true);
                if (!start.method_16657()) {
                    return false;
                }
                class_3341 box = start.method_14969();
                class_1923 min = new class_1923(class_4076.method_18675(box.method_35415()), class_4076.method_18675(box.method_35417()));
                class_1923 max = new class_1923(class_4076.method_18675(box.method_35418()), class_4076.method_18675(box.method_35420()));
                class_1923.method_19281(min, max).forEach(each -> start.method_14974(view, level.method_27056(), generator,
                        recorded.random(), new class_3341(each.method_8326(), level.method_31607(), each.method_8328(),
                                each.method_8327(), level.method_31600(), each.method_8329()), each));
                return true;
            });
        } catch (ClassCastException | UnsupportedOperationException e) {
            throw failed("the structure " + id, e);
        }
        if (!placed) {
            throw new ApiError(ErrorKind.FAILED, "the structure " + id + " has no valid layout at chunk " + chunkPos.field_9181 + ", "
                    + chunkPos.field_9180 + " (the game's own generator said no)", null);
        }
        return Grown.of(recorded);
    }

    // ---- 按列落点:forest、flora、pumpkins ----

    /** 每一列要不要落点:先掷骰子,再从 maxY 往下找第一块非空气的方块当地面;顶上一格就不是空气的列在地下,跳过。 */
    interface Ground {

        void apply(RecordedLevel level, class_2338 ground);
    }

    private static void eachColumn(RecordedLevel level, List<class_2338> columns, int minY, int maxY, double density, Ground ground) {
        LoadedBlocks w = level.real();
        int top = Math.min(maxY, w.maxY());
        int bottom = Math.max(minY, w.minY());
        for (class_2338 column : columns) {
            if (level.random().method_43058() > density) {
                continue;
            }
            if (top + 1 <= w.maxY() && !level.at(new class_2338(column.method_10263(), top + 1, column.method_10260())).method_26215()) {
                continue;
            }
            for (int y = top; y >= bottom; y--) {
                class_2338 pos = new class_2338(column.method_10263(), y, column.method_10260());
                if (!level.at(pos).method_26215()) {
                    ground.apply(level, pos);
                    break;
                }
            }
        }
    }

    /** {@code //forest}:每列按 density(0 到 1)落一棵树。 */
    static Grown forest(LoadedBlocks w, List<class_2338> columns, int minY, int maxY, String treeText, double density) {
        RecordedLevel recorded = new RecordedLevel(w);
        TerrainReads.requireAround(w, columns, 0);
        Ground ground;
        if (treeText.equals(PINE_TREE)) {
            ground = (rec, pos) -> rec.attempt(() -> pine(rec, pos.method_10084()));
        } else {
            class_3218 level = w.level();
            class_2794 generator = level.method_14178().method_12129();
            boolean any = treeText.equals(RANDOM_TREE);
            List<String> trees = any ? treeIds(level) : List.of();
            class_6796 fixed = any ? null : tree(level, treeText);
            ground = (rec, pos) -> {
                class_6796 placed = fixed != null ? fixed : tree(level, trees.get(rec.random().method_43048(trees.size())));
                class_2338 above = pos.method_10084();
                for (int i = 0; i < TREE_TRIES; i++) {
                    try {
                        if (rec.attempt(() -> placed.method_39644(rec.level(), generator, rec.random(), above))) {
                            return;
                        }
                    } catch (ClassCastException | UnsupportedOperationException e) {
                        throw failed("the tree " + treeText, e);
                    }
                }
            };
        }
        eachColumn(recorded, columns, minY, maxY, density, ground);
        return Grown.of(recorded);
    }

    /** WorldEdit 的"松树":一小截树干,往上一层层的橡木叶子;只在空气里放。 */
    private static boolean pine(RecordedLevel level, class_2338 base) {
        class_5819 random = level.random();
        class_2680 log = class_2246.field_10431.method_9564();
        class_2680 leaves = class_2246.field_10503.method_9564();
        int trunk = 3 + random.method_43048(2);
        int crown = 8 + random.method_43048(5);
        for (int i = 0; i < trunk; i++) {
            if (!ifAir(level, base.method_10086(i), log)) {
                return false;
            }
        }
        class_2338 top = base.method_10086(trunk);
        for (int i = 0; i < crown; i++) {
            class_2338 center = top.method_10086(i);
            ifAir(level, center, log);
            boolean edge = i == 0 || i == crown - 1;
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    int ring = Math.max(Math.abs(dx), Math.abs(dz));
                    if (ring == 1) {
                        byChance(level, center.method_10069(dx, 0, dz), leaves, edge ? 0.6 : 1);
                    } else if (ring == 2 && !edge) {
                        // 外圈四角各试两次,角上的叶子更常有
                        int tries = Math.abs(dx) == 2 && Math.abs(dz) == 2 ? 2 : 1;
                        for (int t = 0; t < tries; t++) {
                            byChance(level, center.method_10069(dx, 0, dz), leaves, 0.6);
                        }
                    }
                }
            }
        }
        ifAir(level, top.method_10086(crown), leaves);
        return true;
    }

    private static boolean ifAir(RecordedLevel level, class_2338 pos, class_2680 state) {
        if (!level.at(pos).method_26215()) {
            return false;
        }
        level.set(pos, state);
        return true;
    }

    /** 掷一次 [0,1) 的数,不超过 chance 就往这格放(仍只放进空气)。 */
    private static void byChance(RecordedLevel level, class_2338 pos, class_2680 state, double chance) {
        if (level.random().method_43058() <= chance) {
            ifAir(level, pos, state);
        }
    }

    /** {@code //flora}:草地上长草与小花,沙子上长枯灌木与仙人掌(其余的地面不长);一列一格,落在地面上一格。 */
    static List<BlockAt> flora(LoadedBlocks w, List<class_2338> columns, int minY, int maxY, double density) {
        RecordedLevel recorded = new RecordedLevel(w);
        TerrainReads.requireAround(w, columns, 0);
        eachColumn(recorded, columns, minY, maxY, density, (rec, pos) -> {
            class_2680 ground = rec.at(pos);
            if (ground.method_27852(class_2246.field_10219)) {
                rec.set(pos.method_10084(), weighted(rec.random(), new class_2248[]{class_2246.field_10479, class_2246.field_10449, class_2246.field_10182},
                        new int[]{300, 5, 5}));
            } else if (ground.method_27852(class_2246.field_10102)) {
                rec.set(pos.method_10084(), weighted(rec.random(), new class_2248[]{class_2246.field_10428, class_2246.field_10029, class_2246.field_10124},
                        new int[]{30, 20, 300}));
            }
        });
        return recorded.blocks();
    }

    private static class_2680 weighted(class_5819 random, class_2248[] blocks, int[] weights) {
        int total = 0;
        for (int weight : weights) {
            total += weight;
        }
        int pick = random.method_43048(total);
        for (int i = 0; i < blocks.length; i++) {
            pick -= weights[i];
            if (pick < 0) {
                return blocks[i].method_9564();
            }
        }
        return blocks[blocks.length - 1].method_9564();
    }

    /** {@code //pumpkins}:草地上零星的"南瓜田":一圈叶子藤蔓、橡木和南瓜,在 at 周围 apothem 格、高低 -5 到 +10 层里,密度 2%。 */
    static List<BlockAt> pumpkins(LoadedBlocks w, class_2338 at, int apothem) {
        List<class_2338> columns = new ArrayList<>();
        for (int x = at.method_10263() - apothem; x <= at.method_10263() + apothem; x++) {
            for (int z = at.method_10260() - apothem; z <= at.method_10260() + apothem; z++) {
                columns.add(new class_2338(x, at.method_10264(), z));
            }
        }
        TerrainReads.requireAround(w, columns, 0);
        RecordedLevel recorded = new RecordedLevel(w);
        class_2680 leaf = class_2246.field_10503.method_9564().method_11657(class_2397.field_11200, true);
        eachColumn(recorded, columns, at.method_10264() - 5, at.method_10264() + 10, 0.02, (rec, ground) -> {
            class_2338 patch = rec.at(ground).method_26215() ? ground : ground.method_10084();
            if (!rec.at(patch.method_10074()).method_27852(class_2246.field_10219)) {
                return;
            }
            rec.set(patch, leaf);
            vine(rec, patch, patch.method_10072(), leaf);
            vine(rec, patch, patch.method_10095(), leaf);
            vine(rec, patch, patch.method_10078(), leaf);
            vine(rec, patch, patch.method_10067(), leaf);
        });
        return recorded.blocks();
    }

    /** 南瓜藤的一段:t 选下表的一行,依次是再长一段藤的起点、可能有的橡木(高低随 h)、南瓜,偏移相对这段藤落定的那一格。 */
    private static final int[][][] VINE_TURNS = {
            {{1, 0, 0}, {1, 0, -1}, {0, 0, -1}},
            {{0, 0, 1}, {1, 0, 0}, {1, 0, 1}},
            {{0, 0, -1}, {-1, 0, 0}, {-1, 0, 1}},
            {{-1, 0, 0}, {-1, 0, -1}, {-1, 0, -1}},
    };

    /** 从 start 长一段藤,离 base 超过 4 格或 start 不空就不长;先长完下一段,再放这一段的橡木和南瓜。 */
    private static void vine(RecordedLevel level, class_2338 base, class_2338 start, class_2680 leaf) {
        if (start.method_10262(base) > 16 || !level.at(start).method_26215()) {
            return;
        }
        // 悬空的藤往下落,最多两格
        class_2338 at = start;
        for (int i = 0; i < 2 && level.at(at.method_10074()).method_26215(); i++) {
            at = at.method_10074();
        }
        ifAir(level, at, leaf);
        class_5819 random = level.random();
        int[][] turn = VINE_TURNS[random.method_43048(4)];
        int h = random.method_43048(3) - 1;
        if (random.method_43056()) {
            vine(level, base, at.method_10069(turn[0][0], turn[0][1], turn[0][2]), leaf);
        }
        if (random.method_43056()) {
            ifAir(level, at.method_10069(turn[1][0], h, turn[1][2]), class_2246.field_10431.method_9564());
        }
        ifAir(level, at.method_10069(turn[2][0], turn[2][1], turn[2][2]), class_2246.field_46282.method_9564());
    }

}
