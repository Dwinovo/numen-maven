package com.dwinovo.numen.act;

import com.dwinovo.numen.api.entity.BodyDelta;
import com.dwinovo.numen.api.entity.NumenPlayer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_7923;

/**
 * 一次按键前后的世界事实差异。按键被"消费"不等于"发生了什么"——船可以吃掉点击,
 * 却因为生成位置和身体重叠被原版静默拒绝,世界纹丝不动。这里不判成败,只把看得见的变化如实报出:
 * 她身上的(背包与经验、血量、骑乘,见 {@link BodyDelta})、瞄着的那一格、按的那只实体身上穿的拿的、身边新冒出来的实体。
 * 判断交给读回执的人——什么算"成"只有意图知道,而意图在模型那边。
 */
public final class PressReceipt {

    /** 新实体的观察半径:够罩住触及距离(4.5)内放出的船/掷物,不把远处的路人算进来。 */
    private static final double ENTITY_RADIUS = 6.0;

    private final BodyDelta body;
    private final class_2338 aim;
    private final class_2680 aimBefore;
    private final Set<Integer> entityIdsBefore;
    /** 按的那只实体与按之前它身上穿的拿的(盔甲架摆装备取装备就在这里变);没有目标实体为 null。 */
    private final class_1297 target;
    private final List<class_1799> worn;

    private PressReceipt(NumenPlayer player, class_2338 aim, class_1297 target) {
        this.body = BodyDelta.open(player);
        this.aim = aim;
        this.aimBefore = aim == null ? null : player.method_37908().method_8320(aim);
        this.entityIdsBefore = nearbyIds(player);
        this.target = target;
        this.worn = equipment(target);
    }

    /** 按键之前拍快照;{@code aim} 可空(朝空气挥没有目标格)。 */
    public static PressReceipt before(NumenPlayer player, class_2338 aim) {
        return new PressReceipt(player, aim, null);
    }

    /** 按一只实体之前拍快照:连同它身上穿的拿的。 */
    public static PressReceipt before(NumenPlayer player, class_2338 aim, class_1297 target) {
        return new PressReceipt(player, aim, target);
    }

    /**
     * 按键之后对账:每一条是一件真发生的事,空表 = 观察的几个面都没动静。
     * 语言面向工具回执(英文),坐标点名,方便模型下一步引用。
     */
    public List<String> diff(NumenPlayer player) {
        List<String> facts = new ArrayList<>();
        facts.addAll(body.changes(player));
        if (aim != null) {
            class_2680 now = player.method_37908().method_8320(aim);
            if (now != aimBefore) {
                facts.add("block at " + aim.method_10263() + "," + aim.method_10264() + "," + aim.method_10260()
                        + ": " + blockName(aimBefore) + " -> " + blockName(now));
            }
        }
        List<class_1799> now = equipment(target);
        for (int i = 0; i < now.size(); i++) {
            if (!class_1799.method_7973(worn.get(i), now.get(i))) {
                facts.add(com.dwinovo.numen.api.sdk.EntityLabel.shown(target) + " " + class_1304.values()[i].method_5923()
                        + ": " + name(worn.get(i)) + " -> " + name(now.get(i)));
            }
        }
        for (class_1297 e : nearby(player)) {
            if (!entityIdsBefore.contains(e.method_5628())) {
                facts.add("appeared: " + com.dwinovo.numen.api.sdk.EntityLabel.shown(e));
            }
        }
        return facts;
    }

    private static List<class_1799> equipment(class_1297 target) {
        List<class_1799> out = new ArrayList<>();
        if (target instanceof class_1309 living) {
            for (class_1304 slot : class_1304.values()) {
                out.add(living.method_6118(slot).method_7972());
            }
        }
        return out;
    }

    private static String name(class_1799 stack) {
        return stack.method_7960() ? "nothing" : class_7923.field_41178.method_10221(stack.method_7909()).toString();
    }

    private static String blockName(class_2680 state) {
        return class_7923.field_41175.method_10221(state.method_26204()).method_12832();
    }

    private static Set<Integer> nearbyIds(NumenPlayer player) {
        Set<Integer> ids = new HashSet<>();
        for (class_1297 e : nearby(player)) {
            ids.add(e.method_5628());
        }
        return ids;
    }

    private static List<class_1297> nearby(NumenPlayer player) {
        return player.method_37908().method_8335(player,
                player.method_5829().method_1014(ENTITY_RADIUS));
    }
}
