package com.dwinovo.numen.pathing.drive;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import com.dwinovo.numen.pathing.drive.Blockage.Hitch;
import com.dwinovo.numen.pathing.plan.Breath;
import com.dwinovo.numen.pathing.plan.CostModel;
import com.dwinovo.numen.pathing.plan.Edit;
import com.dwinovo.numen.pathing.plan.Maneuver;
import com.dwinovo.numen.pathing.plan.Moves;
import com.dwinovo.numen.pathing.plan.Reason;

/**
 * 执行路线上的一步。开始之前已由往前核({@link Lookahead})在活世界上复核过它的前提,照那一次复核交出的 {@link Maneuver}
 * 与成本模型去做(世界若已替它挖开了一格,那一格就不必再挖)。执行中由 {@link Watchdog} 看它有没有超期。
 *
 * <h2>憋气</h2>
 * 这一步憋着气时,开始前与执行中的每一刻都按身体此刻的真实氧气把这一段水下剩下的部分重算一遍({@link #breathless}),判据与
 * 规划时同一个({@link Breath#after}、{@link Breath#lasts}):游不到换气的地方就停下,报 {@link Reason#OUT_OF_BREATH}。每一刻都算,
 * 是因为一步在水下被挡住拖长时,期限({@link Watchdog})按这一步的估价给,比氧气宽得多——憋不住的那一刻就得停下,把身体交给
 * 宿主的换气本能,不等期限。
 */
final class Step {

    private final Rig rig;
    /** 路线上紧接在这一步前面的一步;路线的头一步没有。步态要看身体是不是沿着一条直线走进来的。 */
    private final Maneuver previous;
    /** 这一步:往前核在活世界上复核交出的样子。 */
    private final Maneuver planned;
    /** 往前核为这一步组的成本模型。 */
    private final CostModel model;
    /** 路线上这一步后面的几步:步态要看得到连着的冲劲接不接得住。 */
    private final List<Maneuver> ahead;
    /** 这一步之后同一段水下接着的几步(都憋着气),按先后;这一步不在水下或后面换得了气为空。 */
    private final List<Maneuver> diving;
    private final Watchdog watchdog;
    private Control control;
    /** 这一步与同一段水下接着的几步,按先后;这一步开始时定下,不憋气为空。 */
    private List<Maneuver> dive = List.of();
    /** {@link #dive} 里每一步要几刻,开始时按那一刻的成本模型算好。 */
    private double[] diveTicks = new double[0];
    /** 计划内的坠落开始时身体的血量;不是这样的一步为 NaN。落地时拿它对账。 */
    private float healthBefore = Float.NaN;
    /** 计划内的坠落预计掉几点血。 */
    private int expectedDamage;

    Step(Rig rig, Maneuver previous, Maneuver planned, CostModel model, List<Maneuver> ahead, List<Maneuver> diving,
         Watchdog watchdog) {
        this.rig = rig;
        this.previous = previous;
        this.planned = planned;
        this.model = model;
        this.ahead = List.copyOf(ahead);
        this.diving = List.copyOf(diving);
        this.watchdog = watchdog;
    }

    Maneuver planned() {
        return planned;
    }

    /** 控制器此刻正在做的那件改动;还没动手、或动手的那件已经做完为 null。 */
    Edit working() {
        Edit edit = control == null ? null : control.work.current();
        return edit != null && !control.work.done(edit) ? edit : null;
    }

    /** 这一步此刻是计划内的坠落。 */
    boolean falls() {
        return control != null && control.falls();
    }

    /** 这一步还有收尾的事没做完,身体落在落点上也先不算走完。 */
    boolean holds() {
        return control != null && control.holds();
    }

    Beat tick() {
        if (control == null) {
            dive(model, planned);
            Maneuver drowns = breathless(model.body().breath(), 0);
            if (drowns != null) {
                return outOfBreath(drowns, 0);
            }
            List<Maneuver> window = new ArrayList<>(ahead.size() + 1);
            window.add(planned);
            window.addAll(ahead);
            control = Control.of(rig, planned, Gait.stride(rig.world(), model, previous, window));
            double expected = Moves.of(planned.kind()).ticks(model, planned);
            watchdog.begin(expected, rig.entity.method_19538());
            begun(planned, expected);
        } else {
            Maneuver drowns = breathless(rig.snapshot().breath(), watchdog.stepTicks());
            if (drowns != null) {
                return outOfBreath(drowns, watchdog.stepTicks());
            }
        }
        Beat beat = control.tick();
        watchdog.observe(rig.entity.method_19538(), beat instanceof Beat.Going going && going.worked());
        if (beat instanceof Beat.Going && watchdog.overran()) {
            PathLog.info("{} 卡住 {} 做了 {} 刻,超过期限 {} 刻;落点 {} 是 {} {}", rig.who, PathLog.step(planned),
                    watchdog.stepTicks(), PathLog.num(watchdog.allowance()), PathLog.pos(planned.to()),
                    PathLog.block(rig.world().method_8320(planned.to())), PathLog.body(rig.entity));
            return new Beat.Blocked(blocked(planned.to(), Hitch.STUCK));
        }
        return beat;
    }

    /**
     * 一步开始:DEBUG 记走法、估价与期限;落差过一格、会掉血或要倒水接住的坠落是计划内的坠落,记 INFO——落差、落在什么上、
     * 预计掉几点血、接不接水,落地时({@link #finish})再对一次账。
     */
    private void begun(Maneuver m, double expected) {
        if (PathLog.debugging()) {
            PathLog.debug("{} 步 {} 估 {} 刻 期限 {} 刻 改动 {}", rig.who, PathLog.step(m), PathLog.num(expected),
                    PathLog.num(watchdog.allowance()), m.edits().size());
        }
        boolean catches = !m.edits().isEmpty() && m.edits().get(m.edits().size() - 1) instanceof Edit.Catch;
        if (!control.falls() || !(m.drop() > 1 || m.fallDamage() > 0 || catches)) {
            return;
        }
        healthBefore = rig.entity.method_6032();
        expectedDamage = m.fallDamage();
        PathLog.info("{} 计划坠落 {} 落差 {} 落在 {}{} 预计掉 {} 点血 血 {}", rig.who, PathLog.step(m), PathLog.num(m.drop()),
                m.support() != null ? PathLog.block(rig.world().method_8320(m.support())) : m.landing().kind(),
                catches ? " 上倒的水里" : "", m.fallDamage(), PathLog.num(healthBefore));
    }

    /** 这一步走完,身体落在 {@code node}:计划内的坠落记一行落地——实际掉了几点血。 */
    void finish(class_2338 node) {
        if (Float.isNaN(healthBefore)) {
            return;
        }
        PathLog.info("{} 落地 {} 掉了 {} 点血(预计 {}) {}", rig.who, PathLog.pos(node),
                PathLog.num(healthBefore - rig.entity.method_6032()), expectedDamage, PathLog.body(rig.entity));
    }

    /** 这一步憋着气时,定下这一段水下剩下的几步(这一步与同一段接着的几步)与各要几刻。 */
    private void dive(CostModel model, Maneuver fresh) {
        if (!fresh.submerged()) {
            return;
        }
        List<Maneuver> ahead = new ArrayList<>(diving.size() + 1);
        ahead.add(fresh);
        ahead.addAll(diving);
        dive = List.copyOf(ahead);
        diveTicks = new double[dive.size()];
        for (int i = 0; i < dive.size(); i++) {
            diveTicks[i] = Moves.of(dive.get(i).kind()).ticks(model, dive.get(i));
        }
    }

    /**
     * 此刻的氧气({@code breath})撑不撑得到这一段水下走完:先走完这一步还没用掉的刻数(估价减去已经做了的 {@code elapsed} 刻,
     * 拖过了估价就是零),再依次走过同一段接着的几步;在哪一步走完憋不住,交出那一步,都憋得住(或这一步不憋气)为 null。
     */
    private Maneuver breathless(Breath breath, int elapsed) {
        Breath.Air air = breath.now();
        for (int i = 0; i < dive.size(); i++) {
            double ticks = i == 0 ? Math.max(0, diveTicks[0] - elapsed) : diveTicks[i];
            air = breath.after(air, true, ticks);
            if (!breath.lasts(air)) {
                return dive.get(i);
            }
        }
        return null;
    }

    /**
     * 此刻还在计划内的一段水下:这一步还没开始(开始前按真实氧气判),或已经开始而此刻的氧气撑得到这一段走完。宿主的换气本能
     * 每刻问的就是它({@link Driver#plannedDive}),与 {@link #tick} 每刻判的是同一条。
     */
    boolean holdsBreath() {
        return control == null || breathless(rig.snapshot().breath(), watchdog.stepTicks()) == null;
    }

    /** 憋不住了:记一行,这一步以 {@link Reason#OUT_OF_BREATH} 走不下去。 */
    private Beat outOfBreath(Maneuver drowns, int elapsed) {
        PathLog.info("{} 憋不住气 {} 做了 {} 刻,起这一段水下到 {},此刻的氧气撑不到 {}", rig.who, PathLog.step(planned),
                elapsed, PathLog.pos(drowns.to()), PathLog.body(rig.entity));
        return new Beat.Blocked(new Blockage(drowns.to(), rig.world().method_8320(drowns.to()), planned.kind(),
                Reason.OUT_OF_BREATH, null));
    }

    private Blockage blocked(class_2338 cell, Hitch hitch) {
        return new Blockage(cell, rig.world().method_8320(cell), planned.kind(), null, hitch);
    }
}
