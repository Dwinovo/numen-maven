package com.dwinovo.numen.pathing.plan;

import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2756;
import net.minecraft.class_2784;
import net.minecraft.class_3610;
import net.minecraft.class_4076;
import com.dwinovo.numen.pathing.world.Recall;
import com.dwinovo.numen.pathing.world.Semantics;

/**
 * 做了一些改动之后的世界:把改动叠在一个只读视图上,自己也是只读视图。一件改动让世界变成什么样只写在这里——挖掉的格
 * 只剩它原来含着的液体,放下的格是那种方块的默认状态,开关过的门连同另一半一起翻转。
 *
 * <p>规划一步时,草稿在它上面叠这一步设想的改动;搜索展开一个节点时,在快照上叠"走到这个节点的那一步"做过的改动,
 * 下一步的前提看到的就是身体此刻真正面对的世界。叠在另一份改动之上时,直接读它底下的视图、改过的格共用那份的表:
 * 前提函数每一步要读几百格,读一格只经几层、每层一次哈希查找。改动表一层一层叠(持久的):底下被叠过的一层冻住不再变,
 * 要改的视图在它上面另起一层只记自己的改动——一个节点展开的几十次前提判断,绝大多数一格也不改,改的也只有那么几格,
 * 都不必抄整张表。
 */
public class EditedView implements WorldView, Recall.Source {

    private final WorldView base;
    /** 改过的格,最上面一层;一件改动都没有时为 null(规划一步时大多数草稿一件也不改)。 */
    private Changes changed;

    EditedView(WorldView base) {
        if (base instanceof EditedView under) {
            this.base = under.base;
            this.changed = under.changed;
            if (changed != null) {
                changed.freeze();
            }
        } else {
            this.base = base;
        }
    }

    /** {@code base} 做完 {@code edits} 之后的样子;没有改动就是 {@code base} 本身。 */
    public static WorldView after(WorldView base, List<Edit> edits) {
        return edits.isEmpty() ? base : over(base, edits);
    }

    /** 同 {@link #after},总交出一份叠着改动的视图(改动可以是空的):要问"哪些格改过"({@link #changed(int, int, int, int)})的用它。 */
    public static EditedView over(WorldView base, List<Edit> edits) {
        EditedView view = new EditedView(base);
        view.changed = new Changes(view.changed, edits.size());
        view.apply(edits);
        return view;
    }

    private void apply(List<Edit> edits) {
        for (Edit edit : edits) {
            switch (edit) {
                case Edit.Dig dig -> dig(dig.pos());
                case Edit.Place place -> place(place.pos(), place.block());
                case Edit.Door door -> toggle(door.pos(), door.state());
                // 倒下的水在这一步里就收回了
                case Edit.Catch caught -> {
                }
            }
        }
    }

    /**
     * 反复换改动用的一份叠加视图:搜索每展开一个节点、每精确判一步都要把"走到那里的最近几步改动"叠在快照上,用这一份重新装填
     * ({@link #load}),不为每次新建一份视图与改动表。装填一次,上一次交出的视图和叠在它上面起草的草稿就作废了,
     * 调用方只在一次展开或判断里用,不留着。
     */
    public static final class Reusable extends EditedView {

        /** @param base 快照一类的底层视图,不能再是叠加视图:改动表是这一份自己的,装填时整张清掉 */
        public Reusable(WorldView base) {
            super(base);
            if (super.changed != null) {
                throw new IllegalArgumentException("底下不能再是叠加视图:" + base);
            }
        }

        /** {@code base} 做完 {@code edits} 之后的样子;没有改动就是 {@code base} 本身。 */
        public WorldView load(List<Edit> edits) {
            if (edits.isEmpty()) {
                return super.base;
            }
            if (super.changed == null) {
                super.changed = new Changes(null, edits.size());
            } else {
                super.changed.reset(edits.size());
            }
            super.apply(edits);
            return this;
        }
    }

    // ==================== 改动 ====================

    /** 挖掉:只剩这一格原来含着的液体。 */
    void dig(class_2338 pos) {
        set(pos, method_8320(pos).method_26227().method_15759());
    }

    /** 放下一块 {@code block}。 */
    void place(class_2338 pos, class_2248 block) {
        set(pos, block.method_9564());
    }

    /** 倒一桶水:这一格成了水源。 */
    void pour(class_2338 pos) {
        set(pos, class_2246.field_10382.method_9564());
    }

    /**
     * 开关一扇门:开关之前它是 {@code before},开关之后是它翻过来的样子;门的另一半照原版跟着同一开合。按开关之前的样子翻,
     * 不按这份视图此刻读到的翻:同一步的改动叠两遍(活世界里那一步已经做了,接着搜时又叠一遍)结果一样。
     */
    void toggle(class_2338 pos, class_2680 before) {
        class_2680 after = Semantics.toggled(before);
        set(pos, after);
        if (before.method_26204() instanceof class_2323) {
            class_2338 other = before.method_11654(class_2323.field_10946) == class_2756.field_12607 ? pos.method_10084() : pos.method_10074();
            class_2680 half = method_8320(other);
            if (half.method_27852(before.method_26204())) {
                set(other, half.method_11657(class_2323.field_10945, after.method_11654(class_2323.field_10945)));
            }
        }
    }

    final void set(class_2338 pos, class_2680 state) {
        if (changed == null || changed.frozen()) {
            changed = new Changes(changed, 2);
        }
        changed.put(pos.method_10063(), state);
    }

    /** 记事本是底下那份视图的:记的是没叠改动的快照,叠了改动的格子由 {@link #changed(int, int, int, int)} 告诉结论哪些不能用。 */
    @Override
    public Recall recall() {
        return base instanceof Recall.Source source ? source.recall() : null;
    }

    @Override
    public boolean changed(int x, int yMin, int yMax, int z) {
        return changed != null && changed.within(x, yMin, yMax, z);
    }

    /** 改过的每一格改成了什么,按格各报一次。 */
    public void forEachChanged(java.util.function.BiConsumer<class_2338, class_2680> visitor) {
        if (changed != null) {
            changed.forEach(visitor);
        }
    }

    /** 这一格改过。 */
    boolean changed(class_2338 pos) {
        return changed != null && changed.get(pos.method_10063()) != null;
    }

    // ==================== 视图 ====================

    @Override
    public class_2680 method_8320(class_2338 pos) {
        if (changed == null) {
            return base.method_8320(pos);
        }
        class_2680 state = changed.get(pos.method_10063());
        return state != null ? state : base.method_8320(pos);
    }

    /** 这一段里改过哪一格,就不敢说整段是空气;没改过的照底下的视图答。 */
    @Override
    public boolean airSection(int x, int y, int z) {
        if (changed != null) {
            long section = class_4076.method_18685(class_4076.method_18675(x), class_4076.method_18675(y),
                    class_4076.method_18675(z));
            if (changed.within(section)) {
                return false;
            }
        }
        return base.airSection(x, y, z);
    }

    @Override
    public class_3610 method_8316(class_2338 pos) {
        return method_8320(pos).method_26227();
    }

    @Override
    public class_2586 method_8321(class_2338 pos) {
        return changed(pos) ? null : base.method_8321(pos);
    }

    @Override
    public int method_31605() {
        return base.method_31605();
    }

    @Override
    public int method_31607() {
        return base.method_31607();
    }

    @Override
    public class_2784 border() {
        return base.border();
    }

    @Override
    public boolean ultraWarm() {
        return base.ultraWarm();
    }

    /**
     * 改过的格与改成了什么,一层。开放寻址的哈希表(槽里的方块状态为 null 是空槽):读一格要先问它,读得比改得多几个数量级,
     * 一个节点叠着最近几步的十几件改动,线性找一遍太贵。{@link #parent} 是底下那一层:被别的视图叠过的层冻住({@link #freeze}),
     * 不再写;要改的视图在它上面另起一层。
     */
    private static final class Changes {

        private static final long GOLDEN = 0x9E3779B97F4A7C15L;

        private final Changes parent;
        private boolean frozen;
        private long[] cells;
        private class_2680[] states;
        private int size;

        /** @param expected 预计要记几格;不够会长大 */
        Changes(Changes parent, int expected) {
            this.parent = parent;
            int capacity = 4;
            while (capacity < 2 * expected) {
                capacity <<= 1;
            }
            this.cells = new long[capacity];
            this.states = new class_2680[capacity];
        }

        void freeze() {
            frozen = true;
        }

        /** 清空重来(底下没有别的层):要记 {@code expected} 格,够大就沿用现成的数组。 */
        void reset(int expected) {
            int capacity = 4;
            while (capacity < 2 * expected) {
                capacity <<= 1;
            }
            if (capacity > cells.length) {
                cells = new long[capacity];
                states = new class_2680[capacity];
            } else {
                Arrays.fill(states, null);
            }
            size = 0;
            frozen = false;
        }

        boolean frozen() {
            return frozen;
        }

        private static int slot(long cell, int mask) {
            return (int) ((cell * GOLDEN) >>> 32) & mask;
        }

        /** 改过的每一格改成了什么(同一格只报最上面一层的)。 */
        void forEach(java.util.function.BiConsumer<class_2338, class_2680> visitor) {
            for (Changes layer = this; layer != null; layer = layer.parent) {
                for (int i = 0; i < layer.cells.length; i++) {
                    if (layer.states[i] != null && get(layer.cells[i]) == layer.states[i]) {
                        visitor.accept(class_2338.method_10092(layer.cells[i]), layer.states[i]);
                    }
                }
            }
        }

        /** 这一格改成了什么,自己这层没有就问底下;没改过为 null。 */
        class_2680 get(long cell) {
            for (Changes layer = this; layer != null; layer = layer.parent) {
                if (layer.size == 0) {
                    continue;
                }
                int mask = layer.cells.length - 1;
                for (int i = slot(cell, mask); layer.states[i] != null; i = (i + 1) & mask) {
                    if (layer.cells[i] == cell) {
                        return layer.states[i];
                    }
                }
            }
            return null;
        }

        void put(long cell, class_2680 state) {
            int mask = cells.length - 1;
            int i = slot(cell, mask);
            while (states[i] != null) {
                if (cells[i] == cell) {
                    states[i] = state;
                    return;
                }
                i = (i + 1) & mask;
            }
            if (2 * (size + 1) > cells.length) {
                grow();
                put(cell, state);
                return;
            }
            cells[i] = cell;
            states[i] = state;
            size++;
        }

        private void grow() {
            long[] oldCells = cells;
            class_2680[] oldStates = states;
            cells = new long[oldCells.length * 2];
            states = new class_2680[oldCells.length * 2];
            size = 0;
            for (int i = 0; i < oldCells.length; i++) {
                if (oldStates[i] != null) {
                    put(oldCells[i], oldStates[i]);
                }
            }
        }

        /** 改过的格里有没有在 {@code (x, z)} 这一列 {@code yMin} 到 {@code yMax} 之间的。 */
        boolean within(int x, int yMin, int yMax, int z) {
            for (Changes layer = this; layer != null; layer = layer.parent) {
                for (int i = 0; i < layer.cells.length; i++) {
                    if (layer.states[i] == null) {
                        continue;
                    }
                    long cell = layer.cells[i];
                    int y = class_2338.method_10071(cell);
                    if (y >= yMin && y <= yMax && class_2338.method_10061(cell) == x && class_2338.method_10083(cell) == z) {
                        return true;
                    }
                }
            }
            return false;
        }

        /** 改过的格里有没有落在区段 {@code section}({@link class_4076#method_18694} 编码)里的。 */
        boolean within(long section) {
            for (Changes layer = this; layer != null; layer = layer.parent) {
                for (int i = 0; i < layer.cells.length; i++) {
                    if (layer.states[i] != null && class_4076.method_18691(layer.cells[i]) == section) {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
