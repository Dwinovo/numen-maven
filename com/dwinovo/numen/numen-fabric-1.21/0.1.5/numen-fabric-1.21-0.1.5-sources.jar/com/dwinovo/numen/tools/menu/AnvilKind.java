package com.dwinovo.numen.tools.menu;

import com.dwinovo.numen.api.entity.NumenPlayer;
import com.dwinovo.numen.api.sdk.Call;
import com.dwinovo.numen.script.ApiError;
import com.dwinovo.numen.script.ErrorKind;
import com.dwinovo.numen.tools.inventory.InvApi.Stack;
import java.util.Optional;
import net.minecraft.class_1706;
import net.minecraft.class_1799;

/**
 * 铁砧:这次要花的经验和结果格(名字);改名是 {@code RenameItem}。名字多长、输入格有没有东西,原版在 {@code setItemName} 里管,不合就什么也
 * 不做;读回来结果格上的名字不是要的就是没成。取结果(扣经验)是 {@code numen.gui.take} 或 {@code numen.gui.quick}(结果格那一格)。
 */
final class AnvilKind implements MenuKind.Renames<class_1706> {

    @Override
    public Class<class_1706> menu() {
        return class_1706.class;
    }

    @Override
    public String name() {
        return "an anvil";
    }

    @Override
    public Screen read(class_1706 menu, NumenPlayer her) {
        class_1799 result = menu.method_7611(class_1706.field_41900).method_7677();
        return new Screen.Anvil(menu.method_17369(),
                result.method_7960() ? Optional.empty()
                        : Optional.of(Stack.of(result, result.method_7947())),
                result.method_7960() ? Optional.empty() : Optional.of(result.method_7964().getString()));
    }

    @Override
    public String rename(class_1706 menu, NumenPlayer her, String name) {
        if (name.isBlank() || name.length() > class_1706.field_30751) {
            throw new ApiError(ErrorKind.BAD_ARGUMENT, "a name is 1 to " + class_1706.field_30751 + " characters",
                    Call.of("numen.gui.rename", "Name"));
        }
        her.packets().renameItem(name);
        class_1799 result = menu.method_7611(class_1706.field_41900).method_7677();
        if (result.method_7960() || !result.method_7964().getString().equals(name)) {
            throw new ApiError(ErrorKind.FAILED, menu.method_7611(class_1706.field_41898).method_7677().method_7960()
                    ? "nothing to rename: the anvil's input slot is empty — put the item in first (numen.gui.put)"
                    : "no result named \"" + name + "\" appeared (it may already have that name)",
                    Call.of("numen.gui.view"));
        }
        return "renamed the result to \"" + name + "\"; taking it (window slot " + class_1706.field_41900 + ") costs "
                + menu.method_17369() + " levels";
    }
}
