package com.dwinovo.numen.core.task.locate;
import com.dwinovo.numen.core.task.IdSuggest;
import com.dwinovo.numen.core.task.CompassUtil;
import com.dwinovo.numen.core.scan.SearchBudget;
import com.dwinovo.numen.core.scan.RingSpiral;
import com.dwinovo.numen.core.FailureType;

import com.dwinovo.numen.task.TaskState;

import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.core.task.base.AbstractCompanionTask;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.Climate;

import java.util.function.Predicate;

/**
 * Goal for {@code locate biome}: find the nearest instance of a biome (by id)
 * or biome family (by {@code #tag}) in the entity's CURRENT dimension —
 * vanilla {@code /locate biome} semantics, time-sliced across ticks.
 *
 * <h2>The Nature's Compass model</h2>
 * Biomes need no chunks at all: {@link BiomeSource#getNoiseBiome} answers from
 * climate noise alone, so unlike the structure locator there is no expensive
 * fallback — just bounded sampling. Mirrors Nature's Compass (MattCzyr):
 * <ul>
 *   <li>sample on a {@value #SAMPLE_STEP_BLOCKS}-block grid, walked as an
 *       expanding square ring spiral (their worker walks the same square,
 *       turn by turn; a ring is the same set of points);</li>
 *   <li>probe SEVERAL Y levels per column ({@code Mth.outFromOrigin}, 64-block
 *       steps from the entity's own Y) — Nether and cave biomes are 3D, a
 *       single-Y scan misses warped forests under/above you;</li>
 *   <li>per-tick work caps via the GLOBAL {@link SearchBudget}
 *       shared with structure searches (NC uses a tick worker; same idea).</li>
 * </ul>
 * Coverage: {@value #SEARCH_RADIUS_RINGS} rings × {@value #SAMPLE_STEP_BLOCKS}
 * blocks = 6400 blocks, exactly vanilla /locate biome's radius; NC's default
 * reach is 10k with the same 64-block grid. Worst-case full miss ≈ 40k samples
 * ≈ 160 budgeted ticks ≈ 8s.
 *
 * <p>收工看环数,不看时间:身体从头到尾站着等这次搜索({@link #awaitSearch}),任务期限不走,
 * 机器慢只是答案晚几刻,不会变成"搜到一半超时"。
 */
public final class LocateBiomeCompanionTask extends AbstractCompanionTask<LocateBiomeTaskRecord> {

    /** Sample grid pitch — NC's default (16 × biome size 4). Vanilla /locate uses 32. */
    private static final int SAMPLE_STEP_BLOCKS = 64;
    /** Rings of samples; 100 × 64 = 6400 blocks, vanilla /locate biome's radius. */
    private static final int SEARCH_RADIUS_RINGS = 100;
    /** Vertical probe pitch within a sample column (NC uses the same 64). */
    private static final int Y_STEP_BLOCKS = 64;

    private Predicate<Holder<Biome>> match;
    private BiomeSource biomeSource;
    private Climate.Sampler sampler;
    private int[] yBlocks;          // probe heights, ordered outward from entity Y
    private int centerX, centerZ;   // block coords of the search origin
    private int ring, perimIdx;
    private boolean exhausted;
    private BlockPos best;
    private String failReason = "not on a server level";

    public LocateBiomeCompanionTask(NumenPlayer player, LocateBiomeTaskRecord record) {
        super(player, record);
    }

    @Override
    protected void onStart() {
        match = null;
        best = null;
        ring = 0;
        perimIdx = 0;
        exhausted = false;

        if (!(player.level() instanceof ServerLevel sl)) {
            fail("not on a server level", FailureType.UNKNOWN);
            return;
        }
        match = resolveBiomePredicate(sl, r.biome.trim());
        if (match == null) {
            fail(failReason, FailureType.UNKNOWN);   // failReason set by resolveBiomePredicate
            return;
        }
        biomeSource = sl.getChunkSource().getGenerator().getBiomeSource();
        sampler = sl.getChunkSource().randomState().sampler();
        yBlocks = Mth.outFromOrigin(player.getBlockY(),
                sl.getMinBuildHeight() + 1, sl.getMaxBuildHeight(), Y_STEP_BLOCKS).toArray();
        centerX = player.getBlockX();
        centerZ = player.getBlockZ();
    }

    /** @return a holder predicate, or null on bad input (failReason set). */
    private Predicate<Holder<Biome>> resolveBiomePredicate(ServerLevel sl, String arg) {
        var registry = sl.registryAccess().lookupOrThrow(Registries.BIOME);
        if (arg.startsWith("#")) {
            ResourceLocation tagId = ResourceLocation.tryParse(arg.substring(1));
            if (tagId == null) {
                failReason = "invalid biome tag: " + arg;
                return null;
            }
            TagKey<Biome> tag = TagKey.create(Registries.BIOME, tagId);
            if (registry.get(tag).isEmpty()) {
                failReason = isStructureTag(sl, tagId)
                        ? arg + " is a STRUCTURE tag, not a biome tag — use "
                                + "locate structure " + arg + " instead"
                        : "unknown biome tag: " + arg + " — try a biome id like "
                                + "minecraft:warped_forest, or tags like #minecraft:is_forest";
                return null;
            }
            return holder -> holder.is(tag);
        }
        ResourceLocation id = ResourceLocation.tryParse(arg);
        if (id == null || registry.get(ResourceKey.create(Registries.BIOME, id)).isEmpty()) {
            if (id != null && isStructureId(sl, id)) {
                failReason = arg + " is a STRUCTURE, not a biome — use "
                        + "locate structure " + arg + " instead";
                return null;
            }
            String suggestion = IdSuggest.closest(
                    registry.listElements().map(ref -> ref.key().location()), arg);
            failReason = "unknown biome: " + arg
                    + (suggestion != null
                            ? " — did you mean " + suggestion + "?"
                            : " — use a biome id like minecraft:warped_forest / "
                                    + "minecraft:desert, or a tag like #minecraft:is_forest; "
                                    + "the world_atlas skill lists every id");
            return null;
        }
        ResourceKey<Biome> key = ResourceKey.create(Registries.BIOME, id);
        return holder -> holder.is(key);
    }

    private static boolean isStructureId(ServerLevel sl, ResourceLocation id) {
        return sl.registryAccess().lookupOrThrow(Registries.STRUCTURE)
                .get(ResourceKey.create(Registries.STRUCTURE, id)).isPresent();
    }

    private static boolean isStructureTag(ServerLevel sl, ResourceLocation tagId) {
        return sl.registryAccess().lookupOrThrow(Registries.STRUCTURE)
                .get(TagKey.create(Registries.STRUCTURE, tagId)).isPresent();
    }

    @Override
    protected TaskState onTick() {
        if (!(player.level() instanceof ServerLevel sl)) {
            fail("not on a server level", FailureType.UNKNOWN);
            return TaskState.FAILED;
        }
        try (SearchBudget.Slice slice = SearchBudget.slice(sl.getServer())) {
            while (true) {
                if (exhausted) {
                    return TaskState.SUCCESS;   // best == null → "not found"
                }
                if (!SearchBudget.tryBiomeSample()) {
                    awaitSearch();
                    return TaskState.RUNNING;    // pool drained — resume next tick
                }
                BlockPos hit = sampleNext();
                if (hit != null) {
                    best = hit;                  // ring order ⇒ first hit ≈ nearest
                    return TaskState.SUCCESS;
                }
            }
        }
    }

    /** Probe the next spiral column (all Y levels); non-null = matching pos. */
    private BlockPos sampleNext() {
        // Ring perimeter walk, same shape as the structure locator's spiral.
        while (perimIdx >= RingSpiral.perimeter(ring)) {
            ring++;
            perimIdx = 0;
            if (ring > SEARCH_RADIUS_RINGS) {
                exhausted = true;
                return null;
            }
        }
        int[] d = RingSpiral.offset(ring, perimIdx++);
        int x = centerX + d[0] * SAMPLE_STEP_BLOCKS;
        int z = centerZ + d[1] * SAMPLE_STEP_BLOCKS;
        int qx = QuartPos.fromBlock(x);
        int qz = QuartPos.fromBlock(z);
        for (int y : yBlocks) {
            Holder<Biome> biome = biomeSource.getNoiseBiome(qx, QuartPos.fromBlock(y), qz, sampler);
            if (match.test(biome)) {
                return new BlockPos(x, y, z);
            }
        }
        return null;
    }

    /** Search tasks paint no path overlay — nothing to release. */
    @Override
    protected void cleanup() {}

    @Override
    protected Located value() {
        String dim = player.level().dimension().location().toString();
        return best != null ? Located.at(best, player.blockPosition(), dim)
                : Located.none(Math.min(ring, SEARCH_RADIUS_RINGS) * SAMPLE_STEP_BLOCKS, dim);
    }

    @Override
    protected String successMessage() {
        if (best != null) {
            BlockPos me = player.blockPosition();
            int dx = best.getX() - me.getX();
            int dz = best.getZ() - me.getZ();
            int dist = (int) Math.sqrt((double) dx * dx + (double) dz * dz);
            String dir = CompassUtil.compass(dx, dz);
            return "nearest " + r.biome + " around " + best.getX() + ","
                    + best.getY() + "," + best.getZ() + " (" + dir + ", ~" + dist
                    + " blocks; accurate to ~" + SAMPLE_STEP_BLOCKS + "). " + com.dwinovo.numen.core.nav.NavText.gotoCall(
                    new com.dwinovo.numen.sdk.Place(best.getX(), null, best.getZ()), "") + " goes there (it finds the height on its own), then confirm with "
                    + "`numen.scan.blocks` or `numen.scan.entities`.";
        }
        String dim = player.level().dimension().location().getPath();
        int searched = Math.min(ring, SEARCH_RADIUS_RINGS) * SAMPLE_STEP_BLOCKS;
        return "no " + r.biome + " within ~" + searched
                + " blocks IN THIS DIMENSION (" + dim + ") — check the biome's "
                + "home dimension (warped_forest/soul_sand_valley: nether; most "
                + "others: overworld) or travel a few thousand blocks and retry";
    }

    @Override
    protected String cancelledMessage() {
        return r.getToolName() + " interrupted";
    }
}
