package com.dwinovo.numen.core.pathing.moves;

import com.dwinovo.numen.core.pathing.settings.ScaffoldMaterials;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_3222;
import com.dwinovo.numen.core.pathing.settings.NavSettings;
import com.dwinovo.numen.core.pathing.util.BlockHelper;

import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.longs.LongSets;

import static com.dwinovo.numen.core.pathing.moves.ActionCosts.COST_INF;

/**
 * 一次成本计算/搜索的世界视图与能力快照。构造时把设置、背包、附魔
 * 状态全部取样为 final 字段:同一次搜索里每条边用同一把尺,不会
 * 因中途改设置得到自相矛盾的路径。
 *
 * <p>世界读取走注入的 {@link class_1922} 视图 + {@link ChunkLoadedTest}
 * 谓词;三个语义开关:{@code permit}(这次移动能不能改地形,见
 * {@link TerrainPermit})、{@code sacred}(自身目标格,不可挖不可埋,
 * 不可穿透)、{@code deniedPlace}(执行层证明放不上的格)。
 */
public class CalculationContext {

    private static final class_1799 STACK_BUCKET_WATER = new class_1799(class_1802.field_8705);

    /** 视图是否可在 worker 线程安全读取(冻结快照 true,活世界 false)。 */
    public final boolean safeForThreadedUse;
    /**
     * 仅供主线程侧使用(执行期状态机、装配移动时存进 Movement 备用)。
     * 线程审计结论:成本计算路径(cost/apply/装配)不得解引用它读活
     * 状态——背包/附魔/饥饿/药水已在构造时折进本类与 {@link ToolSet}
     * 的 final 字段,世界边界由搜索器自行在构造时取样。
     */
    public final class_3222 player;
    public final class_1922 view;
    public final ChunkLoadedTest loadedTest;
    public final ToolSet toolSet;
    /** 背包里是否有可垫路耗材(泥土/圆石/下界岩/石头)。 */
    public final boolean hasThrowaway;
    /** 快捷栏有水桶且不在下界。 */
    public final boolean hasWaterBucket;
    public final boolean canSprint;
    /** 放置一格的成本;经 {@link #costOfPlacingAt} 取用,勿直接读。 */
    protected final double placeBlockCost;
    public final boolean allowBreak;
    public final List<class_2248> allowBreakAnyway;
    public final boolean allowParkour;
    public final boolean allowParkourPlace;
    public final boolean allowJumpAtBuildLimit;
    public final boolean allowParkourAscend;
    public final boolean assumeWalkOnWater;
    /** 恒 false,占位保留(落岩浆永不可接受)。 */
    public final boolean allowFallIntoLava;
    /** 装备的霜行者附魔等级,0 为无。 */
    public final int frostWalker;
    public final boolean allowDiagonalDescend;
    public final boolean allowDiagonalAscend;
    public final boolean allowDownward;
    /** 坠落类移动的最小坠落高度。 */
    public int minFallHeight;
    public int maxFallHeightNoWater;
    public final int maxFallHeightBucket;
    public final double fallDamageCostPerPoint;
    /** 水中行走单格成本(水下速附魔按系数折向平走速度)。 */
    public final double waterWalkSpeed;
    public final double breakBlockAdditionalCost;
    public double backtrackCostFavoringCoefficient;
    public double jumpPenalty;
    public final double walkOnWaterOnePenalty;
    public final boolean allowPlaceInFluidsSource;
    public final boolean allowPlaceInFluidsFlow;

    /** 这次移动对地形的许可;{@link #allowBreak}/{@link #hasThrowaway} 已把它折进去。 */
    public final TerrainPermit permit;
    /** 不可挖不可埋的自身目标格(BlockPos.asLong 键),不可穿透。 */
    public final LongSet sacred;
    /** 执行层证明无支撑放不上的格:放置成本直接 INF。 */
    public final LongSet deniedPlace;

    /** 世界可建高度下界(含)与上界(不含)。 */
    public final int worldBottom;
    public final int worldHeight;

    /**
     * 世界边界快照(构造时在主线程取样)。avoidBreaking 用它的
     * {@code canPlaceAt(x,z)} 拒绝在边界外挖方块。
     */
    public final class_2784 worldBorder;

    /** 便捷构造:无目标格/禁放格开关,只带许可。 */
    public CalculationContext(class_3222 player, class_1922 view, ChunkLoadedTest loadedTest,
                              boolean safeForThreadedUse, TerrainPermit permit) {
        this(player, view, loadedTest, safeForThreadedUse,
                LongSets.emptySet(), LongSets.emptySet(), permit);
    }

    public CalculationContext(class_3222 player, class_1922 view, ChunkLoadedTest loadedTest,
                              boolean safeForThreadedUse,
                              LongSet sacred, LongSet deniedPlace, TerrainPermit permit) {
        NavSettings settings = NavSettings.get();
        this.safeForThreadedUse = safeForThreadedUse;
        this.player = player;
        this.view = view;
        this.loadedTest = loadedTest;
        this.permit = permit;
        this.sacred = sacred;
        this.deniedPlace = deniedPlace;
        this.toolSet = new ToolSet(player);
        // 免耗材画像(创造)恒有耗材:执行层选料时会自动补一组(伸手进创造
        // 物品栏的代码版),规划器因此敢想所有需要垫方块的路线——不然空手
        // 创造同伴会挖坑出不来(离目标 2 格报 NO-PATH)。
        // 许可与总开关同折:PRESERVE 下没有耗材这回事,放置成本处处 INF
        this.hasThrowaway = permit.mayAlter() && settings.allowPlace
                && (hasGenericThrowaway(player, settings)
                        || com.dwinovo.numen.core.WorkProfile.of(player).freeMaterials());
        this.hasWaterBucket = settings.allowWaterBucketFall
                && hotbarHasWaterBucket(player)
                && player.method_37908().method_27983() != class_1937.field_25180;
        // 无饥饿画像(创造)不受饱食度门限——否则 food≤6 时被切创造会永久锁死疾跑
        this.canSprint = settings.allowSprint
                && (!com.dwinovo.numen.core.WorkProfile.of(player).hasHunger()
                        || player.method_7344().method_7586() > 6);
        this.placeBlockCost = settings.blockPlacementPenalty;
        this.allowBreak = permit.mayAlter() && settings.allowBreak;
        this.allowBreakAnyway = List.copyOf(settings.allowBreakAnyway());
        this.allowParkour = settings.allowParkour;
        this.allowParkourPlace = settings.allowParkourPlace;
        this.allowJumpAtBuildLimit = settings.allowJumpAtBuildLimit;
        this.allowParkourAscend = settings.allowParkourAscend;
        this.assumeWalkOnWater = settings.assumeWalkOnWater;
        this.allowFallIntoLava = false;
        this.frostWalker = equipmentEnchantLevel(player);
        this.allowDiagonalDescend = settings.allowDiagonalDescend;
        this.allowDiagonalAscend = settings.allowDiagonalAscend;
        this.allowDownward = settings.allowDownward;
        this.minFallHeight = 3;
        // 落差上限不写死:摔不死的高度都可以是路,只是疼。原版摔伤 = 高度-3(半心/格),
        // 按当前血量留 3 颗心(6 点)保命余量反推可承受高度;设置值兜底为下限。
        int survivableFall = 3 + Math.max(0, (int) ((player.method_6032() - 6.0f) / 1.0f));
        this.maxFallHeightNoWater = Math.min(12,
                Math.max(settings.maxFallHeightNoWater, survivableFall));
        this.maxFallHeightBucket = settings.maxFallHeightBucket;
        this.fallDamageCostPerPoint = settings.fallDamageCostPerPoint;
        this.waterWalkSpeed = computeWaterWalkSpeed(player);
        this.breakBlockAdditionalCost = settings.blockBreakAdditionalPenalty;
        this.backtrackCostFavoringCoefficient = settings.backtrackCostFavoringCoefficient;
        this.jumpPenalty = settings.jumpPenalty;
        this.walkOnWaterOnePenalty = settings.walkOnWaterOnePenalty;
        this.allowPlaceInFluidsSource = settings.allowPlaceInFluidsSource;
        this.allowPlaceInFluidsFlow = settings.allowPlaceInFluidsFlow;
        this.worldBottom = view.method_31607();
        this.worldHeight = view.method_31600();
        class_2784 border = null;
        if (player != null) {
            try {
                border = player.method_37908() != null ? player.method_37908().method_8621() : null;
            } catch (NullPointerException ignored) {
                // 测试壳玩家无 level 字段:无世界边界,按"不限制"处理
            }
        }
        this.worldBorder = border;
    }

    /**
     * 是否持有可垫路耗材。查快捷栏(0-8)与副手;仅当
     * {@code allowInventory} 开启才查背包深处(9-35)。
     */
    private static boolean hasGenericThrowaway(class_3222 player, NavSettings settings) {
        List<net.minecraft.class_1792> acceptable = ScaffoldMaterials.of(player);
        var inv = player.method_31548();
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && acceptable.contains(stack.method_7909())) {
                return true;
            }
        }
        class_1799 offhand = player.method_6118(class_1304.field_6171);
        if (!offhand.method_7960() && acceptable.contains(offhand.method_7909())) {
            // 副手耗材要真能用出来,主手须能切到"右键无消费"的槽
            // (空手或带 TOOL 组件的挖掘工具),否则右键走主手放不出副手方块
            for (int i = 0; i < 9; i++) {
                class_1799 stack = inv.method_5438(i);
                if (stack.method_7960() || stack.method_7909() instanceof net.minecraft.class_1831
                        || stack.method_7909() instanceof net.minecraft.class_1820) {
                    return true;
                }
            }
        }
        if (settings.allowInventory) {
            for (int i = 9; i < 36; i++) {
                class_1799 stack = inv.method_5438(i);
                if (!stack.method_7960() && acceptable.contains(stack.method_7909())) {
                    return true;
                }
            }
        }
        return false;
    }

    /** 快捷栏里是否有(物品与组件都相同的)水桶。 */
    private static boolean hotbarHasWaterBucket(class_3222 player) {
        return net.minecraft.class_1661.method_7380(
                player.method_31548().method_7395(STACK_BUCKET_WATER));
    }

    /** 装备槽遍历顺序中最后一件带霜行者附魔的等级。 */
    private static int equipmentEnchantLevel(class_3222 player) {
        int level = 0;
        for (class_1304 slot : class_1304.values()) {
            // 1.20.4:直接查附魔等级,无 Holder/组件。
            int lvl = class_1890.method_8225(
                    class_1893.field_9122, player.method_6118(slot));
            if (lvl > 0) {
                level = lvl;
            }
        }
        return level;
    }

    /** 按装备的水下移动效率附魔,把水中步速在水速与平走速之间插值。 */
    private static double computeWaterWalkSpeed(class_3222 player) {
        // 1.20.4:水下移动效率即深海探索者附魔,乘数 = level/3(1.21 的
        // WATER_MOVEMENT_EFFICIENCY 属性效果同曲线),无附魔保持 1.0 与原逻辑一致。
        int depthStrider = class_1890.method_8232(player);
        float waterSpeedMultiplier = depthStrider > 0
                ? Math.min(1.0f, depthStrider / 3.0f) : 1.0f;
        return ActionCosts.WALK_ONE_IN_WATER_COST * (1 - waterSpeedMultiplier)
                + ActionCosts.WALK_ONE_BLOCK_COST * waterSpeedMultiplier;
    }

    // ==================== 世界读取 ====================

    /** 单线程游标,省去每次读取的 BlockPos 分配(域回调只在一个线程跑)。 */
    private final class_2338.class_2339 cursor = new class_2338.class_2339();

    public class_2680 get(int x, int y, int z) {
        return view.method_8320(cursor.method_10103(x, y, z));
    }

    public class_2680 get(class_2338 pos) {
        return view.method_8320(pos);
    }

    public class_2248 getBlock(int x, int y, int z) {
        return get(x, y, z).method_26204();
    }

    public boolean isLoaded(int x, int z) {
        return loadedTest.isLoaded(x, z);
    }

    // ==================== 成本函数 ====================

    /**
     * 在 (x,y,z) 放一个方块的成本。无耗材、sacred/denied 命中、
     * 贴着世界边界(边界格无法右键贴放)、流体规则不许 → INF;
     * 否则放置罚金。
     */
    public double costOfPlacingAt(int x, int y, int z, class_2680 current) {
        if (!hasThrowaway) { // 构造时已含许可与 allowPlace 判定
            return COST_INF;
        }
        long key = class_2338.method_10064(x, y, z);
        if (sacred.contains(key) || deniedPlace.contains(key)) {
            return COST_INF;
        }
        if (!MovementHelper.placeableWithinBorder(worldBorder, x, z)) {
            return COST_INF;
        }
        if (!allowPlaceInFluidsSource && current.method_26227().method_15771()) {
            return COST_INF;
        }
        if (!allowPlaceInFluidsFlow && !current.method_26227().method_15769()
                && !current.method_26227().method_15771()) {
            return COST_INF;
        }
        return placeBlockCost;
    }

    /** 挖掘保护判定的专用游标(与 {@link #cursor} 分开,免得互相踩)。 */
    private final class_2338.class_2339 protectionCursor = new class_2338.class_2339();

    /**
     * 挖 (x,y,z) 的成本乘数。两层禁令,从严到宽:
     * <ol>
     *   <li>sacred(自身目标格)永远 INF,任何开关都不可穿透;</li>
     *   <li>do_not_break 标签成员(默认设施类:床/门/活板门/栅栏门,
     *       数据包可追加)直接 INF,任何开关都不可解除;</li>
     *   <li>许可为 PRESERVE、或总开关 {@code allowBreak} 关闭,且不在例外清单 → INF。</li>
     * </ol>
     * 功能方块(工作台/熔炉/箱子等)的 ×10 软惩罚由 {@link ToolSet}
     * 的 {@code avoidanceMultiplier}(NavSettings.blocksToAvoidBreaking)
     * 在 {@code getStrVsBlock} 里实现,此处不参与。
     */
    public double breakCostMultiplierAt(int x, int y, int z, class_2680 current) {
        if (sacred.contains(class_2338.method_10064(x, y, z))) {
            return COST_INF;
        }
        if (BlockHelper.shouldAvoidBreaking(view, protectionCursor.method_10103(x, y, z))) {
            return COST_INF;
        }
        if (!allowBreak && !allowBreakAnyway.contains(current.method_26204())) {
            return COST_INF;
        }
        return 1;
    }

    /** 坠落中放水桶的成本(与放置罚金同价)。 */
    public double placeBucketCost() {
        return placeBlockCost;
    }
}
