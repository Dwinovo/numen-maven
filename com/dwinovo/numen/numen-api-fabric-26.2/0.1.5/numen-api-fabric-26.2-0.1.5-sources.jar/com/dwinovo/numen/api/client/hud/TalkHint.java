package com.dwinovo.numen.api.client.hud;

import net.minecraft.client.resources.language.I18n;
import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.client.NumenKeys;
import com.dwinovo.numen.api.client.chat.CompanionChatScreen;
import com.dwinovo.numen.api.client.screen.UiTheme;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.AbstractClientPlayer;

/**
 * 快捷对话提醒:准星指着自己的同伴时,准星下方浮一行「按 [键] 与 名字
 * 对话」。键名跟着 Controls 里的实际绑定走,改键提示自动变;设置的
 * THEME 区可整体关掉。纯 HUD 文本,不占用世界渲染。
 */
public final class TalkHint {

    private TalkHint() {}

    /** 短暂的教学/反馈行(如转盘关盘后的「按 [键] 对话」),盖过常规提示。 */
    private static String flashText;
    private static long flashUntilMs;

    public static void flash(String text, long lifeMs) {
        flashText = text;
        flashUntilMs = System.currentTimeMillis() + lifeMs;
    }

    public static void render(GuiGraphicsExtractor g) {
        // 崩溃护栏:HUD 层逐帧执行,异常绝不外抛
        com.dwinovo.numen.api.client.ui.SafeUi.run("talk-hint", () -> renderInner(g));
    }

    private static void renderInner(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui.screen() != null || mc.gui.hud.isHidden()) {
            return;
        }
        // 快捷语音的实时状态(录音中/没听清等提示)优先于按键提示
        String voiceLine = com.dwinovo.numen.api.client.chat.QuickVoice.hudLine();
        if (voiceLine != null) {
            draw(g, mc, voiceLine, 0xFFFFC862);
            return;
        }
        if (flashText != null && System.currentTimeMillis() < flashUntilMs) {
            draw(g, mc, flashText, 0xFFFFE9B0);
            return;
        }
        if (!com.dwinovo.numen.api.client.data.ClientPrefs.talkHint()) {
            return;
        }
        AbstractClientPlayer body = CompanionChatScreen.crosshairCompanion();
        if (body == null) {
            return;
        }
        String name = com.dwinovo.numen.api.client.agent.NumenRoster.instance().name(body.getUUID());
        if (name == null || name.isBlank()) {
            name = body.getScoreboardName();
        }
        String talk = NumenKeys.TALK_COMPANION.getTranslatedKeyMessage().getString();
        String voice = NumenKeys.QUICK_VOICE.getTranslatedKeyMessage().getString();
        draw(g, mc, I18n.get(Keys.TALK_HINT, talk, name, voice), 0xFFFFFFFF);
    }

    private static void draw(GuiGraphicsExtractor g, Minecraft mc, String text, int color) {
        Font font = mc.font;
        int x = (g.guiWidth() - font.width(text)) / 2;
        int y = g.guiHeight() / 2 + 16;   // 准星正下方一点,不挡视线焦点
        g.text(font, text, x, y, color, true);
    }
}
