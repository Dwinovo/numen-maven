package com.dwinovo.numen.api.client.chat;

import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.language.I18n;
import com.dwinovo.numen.api.data.ModLanguageData.Keys;
import com.dwinovo.numen.api.agent.conversation.Conversation;
import com.dwinovo.numen.api.Delivery;
import com.dwinovo.numen.api.NumenGateway;
import com.dwinovo.numen.api.client.agent.RemoteCompanions;
import com.dwinovo.numen.api.client.agent.Conversations;
import com.dwinovo.numen.api.client.agent.RemoteCompanion;
import com.dwinovo.numen.api.client.agent.NumenRoster;
import com.dwinovo.numen.api.client.consent.ConsentCards;
import com.dwinovo.numen.api.client.consent.ConsentMessage;
import com.dwinovo.numen.api.client.screen.Nb;
import com.dwinovo.numen.api.client.screen.UiTheme;
import com.dwinovo.numen.api.client.screen.chat.ChatInputBar;
import com.dwinovo.numen.api.client.screen.settings.HostThemeColors;
import com.dwinovo.numen.api.client.skin.ConversationFaces;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.EntityHitResult;

import java.util.EnumSet;
import java.util.UUID;

/**
 * 快捷对话:按对话键(默认 Y,入口在 {@code NumenKeys})对「当前交互
 * 对象」弹出这一条极简输入行——就一行,回车说出去立刻关屏,回复会浮
 * 在它头顶的气泡里。收件人是一个会话,由 {@code SelectedCompanion} 解析:准星指着
 * 谁就是跟她一个人说,否则是转盘选中的那个(可能是多人会话)。屏只是输入法,不是对话窗口;
 * 历史与长文在 G 面板。准星提示见 {@code TalkHint}。
 *
 * <p>输入行与 G 面板是<b>同一条</b>({@link ChatInputBar}):斜杠补全弹层、
 * {@code /skills} 这类面板、回车先补后发,两处一模一样,不另写一套。不带麦克风键
 * ——快捷语音有自己的按住说话键。命令跑完的回话走准星提示层闪一下,屏照关。
 *
 * <p>与 {@code @名字} 路由是同一条管线({@link NumenGateway#emit}),
 * 对应两种社交距离:@ 是远程喊话,这里是走到跟前说话。
 *
 * <p>样子照 Telegram 的输入区:窗口底色的一条、浮起的细描边;左端是说给谁——会话头像(群是群头像)加名字,
 * 一道分隔线隔开输入框。开屏时整条自下浮起 {@link #OPEN_MS},不硬切。
 *
 * <p>有征询挂着时按对话键先答征询(对象是最早在等的那位,见 {@code NumenKeys}):她问的那条(问话 + 内联按钮,
 * 见 {@link ConsentMessage})浮在输入卡上面,点按钮、"说一句再拒绝"后打字回车都和 G 面板一样;答完
 * 还有别的同伴在等就换到她,都答完且输入框是空的就关屏——和说完一句一样。
 */
public class CompanionChatScreen extends Screen {

    private static final int INPUT_W = 300;
    /** 与 G 面板输入行同高。 */
    private static final int INPUT_H = 18;
    /** 名字牌里的会话头像:输入行里上下各留 2。 */
    private static final int FACE = INPUT_H - 4;
    /** 开屏浮起:Telegram 的快动效时长,浮起的高度。 */
    private static final long OPEN_MS = 150;
    private static final int OPEN_RISE = 8;

    private final Conversation conv;
    private final String companionName;
    private ChatInputBar inputBar;
    private final long openedAtMs = net.minecraft.util.Util.getMillis();
    /** 这一帧征询那排按钮画在哪(点的时候照它认);没画是 0 宽。 */
    private int keysX, keysY, keysW;

    public CompanionChatScreen(Conversation conv) {
        super(Component.translatable(Keys.CHAT_SCREEN_TITLE));
        this.conv = conv;
        this.companionName = conv.displayName(NumenRoster.instance()::name);
    }

    /**
     * 准星此刻指着的「自己的」同伴,不在指着返回 null。花名册只含本人的
     * 同伴,身份校验是白送的;别人的同伴不响应(它的大脑不在你机器上)。
     */
    public static AbstractClientPlayer crosshairCompanion() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.isSpectator()) return null;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return null;
        if (!(hit.getEntity() instanceof AbstractClientPlayer body)) return null;
        for (NumenRoster.Entry entry : NumenRoster.instance().entries()) {
            if (entry.uuid().equals(body.getUUID())) {
                return body;
            }
        }
        return null;
    }

    /** 就他俩那只的大脑(补全、征询);会话没有单一的主时 null。 */
    private RemoteCompanion loop() {
        UUID her = Conversations.instance().soloOf(conv);
        return her == null ? null : RemoteCompanions.getOrCreate(her);
    }

    /** 名字牌(说给谁:头像 + 名字)的宽度:它和输入行同排,占掉输入卡最左边这一截。 */
    private int tagW() {
        return FACE + 4 + this.font.width(companionName) + 4;
    }

    @Override
    protected void init() {
        // 输入框的真控件挂到本屏上:只注册事件、不进 renderables,画面归 NumenUI。
        // 屏幕作用域——关屏时在 removed() 卸掉。
        com.dwinovo.numen.api.client.ui.mc.McTextInput.mountVia(this::addWidget, this::setFocused);
        String kept = inputBar != null ? inputBar.text() : "";
        int x = (this.width - INPUT_W) / 2;
        int y = this.height - 44;
        inputBar = new ChatInputBar(new BarHost(), EnumSet.of(ChatInputBar.Key.SEND, ChatInputBar.Key.STOP));
        int lead = tagW() + 6;
        inputBar.build(x, y, INPUT_W, INPUT_H, lead);
        if (!kept.isEmpty()) inputBar.setText(kept);
    }

    /** 输入行的宿主:说话走 Gateway 然后关屏;命令的回话闪在准星提示层,屏也关。 */
    private final class BarHost implements ChatInputBar.Host {
        @Override public void onSend(String text) {
            if (Conversations.instance().say(conv, text).reached()) {
                ChatLines.owner(companionName, text, false);
            } else {
                com.dwinovo.numen.api.client.hud.TalkHint.flash(I18n.get(Keys.CHAT_NOT_RECEIVED, companionName), 3000);
            }
            onClose();
        }

        @Override public void onAbort() { Conversations.instance().abort(conv); }   // 停止停全体

        @Override public boolean canAbort() { return Conversations.instance().canAbort(conv); }

        @Override public String hint() {
            return I18n.get(Keys.CHAT_INPUT_HINT);
        }

        @Override public RemoteCompanion loop() { return CompanionChatScreen.this.loop(); }

        @Override public Conversation conversation() { return conv; }

        @Override public void onConsentSettled() {
            var next = com.dwinovo.numen.api.client.consent.ConsentCards.first();
            if (next != null) {
                minecraft.gui.setScreen(new CompanionChatScreen(Conversations.instance().of(next.companion())));
            } else if (inputBar.text().isEmpty()) {
                onClose();
            }
        }

        /** 只注册事件,不进 renderables——画面归 NumenUI。见 {@code McTextInput}。 */
        @Override public void onCommandReply(String reply) {
            if (reply == null || reply.isBlank()) {
                return;   // 不吭声的命令,或面板已在输入行原位打开——屏留着
            }
            // 行数越多给的时间越长——一屏技能清单三秒看不完
            long life = 4000L + reply.split("\n").length * 600L;
            com.dwinovo.numen.api.client.hud.TalkHint.flash(reply, life);
            onClose();
        }
    }

    /**
     * 此刻占着屏幕的那一块:输入卡连同它上面挂着的征询,{@code {左, 顶, 右}}。消息通知卡落在它旁边就得让开,
     * 不能压住输入行。
     */
    public int[] occupied() {
        int x = (this.width - INPUT_W) / 2;
        int cardTop = this.height - 44 - 6 - (inputBar.height() - INPUT_H);
        int top = cardTop;
        ConsentCards.Card card = ConsentCards.pending(Conversations.instance().soloOf(conv));
        if (card != null) top = consentTop(card, cardTop);
        return new int[]{x - 8, top, x + INPUT_W + 8};
    }

    /** 征询那张卡的顶边:贴着输入卡上沿往上摞。 */
    private int consentTop(ConsentCards.Card card, int cardTop) {
        int innerW = INPUT_W + 16 - 8;
        int h = 4 + ConsentMessage.listHeight(card) + ConsentMessage.GAP + ConsentMessage.keyboardHeight(this.font, innerW) + 4;
        return cardTop - 4 - h;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTicks) {
        // 刻意留空:super.extractRenderState 默认会画菜单模糊+压暗遮罩,面对面说话
        // 不该把世界糊掉——她就站在你面前
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTicks) {
        UiTheme th = UiTheme.current();
        int x = (this.width - INPUT_W) / 2;
        int y = this.height - 44;
        long now = net.minecraft.util.Util.getMillis();

        // 开屏浮起:只挪画面,点击区不跟着挪——150ms 里差几个像素,点不偏
        float rise = 1f - com.dwinovo.numen.api.client.ui.Anim.easeOutCubic((now - openedAtMs) / (float) OPEN_MS);
        g.pose().pushMatrix();
        g.pose().translate(0, Math.round(OPEN_RISE * rise));
        var surface = new com.dwinovo.numen.api.client.ui.mc.McDrawSurface(g, this.font);
        // 输入卡:Telegram 输入区是窗口底色,浮在世界上用浮起的描边;输入行(含弹层/面板)画在它上面。
        // 输入行往上长(多行、引用栏、"说一句再拒绝"的提示栏)时卡片跟着长,底边不动
        int grown = inputBar.height() - INPUT_H;
        com.dwinovo.numen.api.client.ui.NumenStyle.box(surface, x - 8, y - 6 - grown, INPUT_W + 16, INPUT_H + 10 + grown,
                th.band(), th.aiBorder());
        // 名字牌:与输入行同排、占卡片最左一截,标明这句话说给谁。不放输入框上方——
        // 斜杠补全弹层和 /skills 面板都贴着输入框往上长,上面那块地是它们的
        ConversationFaces.draw(g, conv, x, y + (INPUT_H - FACE) / 2, FACE);
        Nb.text(g, this.font, companionName, x + FACE + 4, y + (INPUT_H - this.font.lineHeight) / 2 + 1,
                th.onBand());
        int div = x + tagW() + 2;
        g.fill(div, y + 1, div + 1, y + INPUT_H - 1, th.surfaceBorder());
        renderConsent(g, surface, th, x - 8, y - 6 - grown, mouseX, mouseY);
        inputBar.render(g, mouseX, mouseY, now, HostThemeColors.current());
        g.pose().popMatrix();

        String tip = inputBar.tooltipAt(mouseX, mouseY);
        if (tip != null) {
            g.setTooltipForNextFrame(this.font, Component.literal(tip), mouseX, mouseY);
        }
        super.extractRenderState(g, mouseX, mouseY, partialTicks);
    }

    /**
     * 她挂着的征询浮在输入卡上面:同一套框,里面是清单与内联按钮;顶边一道缩短的线是剩下的时间(撤不回时是警示色)。
     */
    private void renderConsent(GuiGraphicsExtractor g, com.dwinovo.numen.api.client.ui.mc.McDrawSurface surface, UiTheme th,
                               int cardX, int cardTop, int mouseX, int mouseY) {
        ConsentCards.Card card = ConsentCards.pending(Conversations.instance().soloOf(conv));
        keysW = 0;
        if (card == null) return;
        int w = INPUT_W + 16;
        int listH = ConsentMessage.listHeight(card);
        int innerW = w - 8;
        int h = 4 + listH + ConsentMessage.GAP + ConsentMessage.keyboardHeight(this.font, innerW) + 4;
        int top = consentTop(card, cardTop);
        com.dwinovo.numen.api.client.ui.NumenStyle.box(surface, cardX, top, w, h, th.band(), th.aiBorder());
        g.fill(cardX + 1, top + 1, cardX + 1 + Math.round((w - 2) * ConsentMessage.timeLeft(card)), top + 2,
                ConsentMessage.tone(card));
        ConsentMessage.drawList(g, this.font, card, cardX + 4, top + 4, innerW);
        keysX = cardX + 4;
        keysY = top + 4 + listH + ConsentMessage.GAP;
        keysW = innerW;
        ConsentMessage.drawKeyboard(g, this.font, card, keysX, keysY, keysW, mouseX, mouseY);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int keyCode = com.dwinovo.numen.api.client.ui.KeyCodes.canonical(event.key());   // 小键盘回车并成回车
        // 输入行先拿:弹层的上下/Tab/回车、面板的整个键盘、回车发送。它不要的(比如
        // 没开面板时的 Esc)才落到屏幕——Esc 关屏
        if (inputBar != null && inputBar.keyPressed(keyCode, event.modifiers())) {
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (inputBar != null && inputBar.charTyped((char) event.codepoint())) {
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x();
        double mouseY = event.y();
        ConsentCards.Card card = ConsentCards.pending(Conversations.instance().soloOf(conv));
        if (card != null && keysW > 0
                && ConsentMessage.click(this.font, card, keysX, keysY, keysW, mouseX, mouseY)) {
            return true;
        }
        boolean handled = inputBar != null && inputBar.mouseClicked(mouseX, mouseY, event.button())
                || super.mouseClicked(event, doubleClick);
        // 这一屏只是一行输入:点到哪儿输入框都不失焦。失了焦字打不进、回车也没反应,只剩发送键还能点
        if (inputBar != null) inputBar.setFocused(true);
        return handled;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        // 写满五行的输入框在框里翻
        if (inputBar != null && scrollY != 0 && inputBar.mouseScrolled(mouseX, mouseY, scrollY)) {
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void tick() {
        if (inputBar != null) {
            inputBar.tick();
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        com.dwinovo.numen.api.client.ui.mc.McTextInput.mountVia(null, null);
        super.removed();
    }
}
