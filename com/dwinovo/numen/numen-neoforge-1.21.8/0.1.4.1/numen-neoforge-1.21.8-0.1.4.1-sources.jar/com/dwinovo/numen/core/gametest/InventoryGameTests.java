package com.dwinovo.numen.core.gametest;

import com.dwinovo.numen.core.Constants;
import com.dwinovo.numen.entity.CompanionFactory;
import com.dwinovo.numen.entity.NumenPlayer;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import com.dwinovo.numen.gametest.NumenBeforeBatch;
import com.dwinovo.numen.gametest.NumenTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Difficulty;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import com.dwinovo.numen.gametest.NumenGameTestHolder;

import static com.dwinovo.numen.core.gametest.GameTestKit.*;

/**
 * 穿戴与背包:{@code numen.gear.wear} / {@code numen.gear.hold} / {@code numen.gear.remove}、{@code numen.inv.drop} 带出的物品组件、
 * {@code numen.inv.craft} 与模块 {@code numen.inv.make/store/fetch/smelt}、{@code numen.inv.items/count}、{@code numen.time.wait}、
 * {@code numen.inv.eat}、换皮回收。
 */
@NumenGameTestHolder(Constants.MOD_ID)
public class InventoryGameTests {

    /** 背包批次前置:和平难度 + 正午。 */
    @NumenBeforeBatch(batch = "numen_inventory")
    public static void prepareInventoryBatch(ServerLevel level) {
        settleWorld(level, Difficulty.PEACEFUL, NOON);
    }

    /** 进食批次前置:普通难度(和平难度下饥饿值自己会回满,测不出吃下去补了多少)+ 正午。 */
    @NumenBeforeBatch(batch = "numen_food")
    public static void prepareFoodBatch(ServerLevel level) {
        settleWorld(level, Difficulty.NORMAL, NOON);
    }

    /**
     * 穿盔甲的回执要说真话:不给 --slot 的 numen.gear.wear 自动选位,头盔确实到了头上,
     * 回执必须说 "in head"。曾经用含盔甲槽的总数比对来确认"离开了背包",头盔从手里挪到
     * 头上数量不变,于是判没穿上、兜底报 "holding … in main hand"——穿对了话说错了。
     */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void equip_armor_reply_names_the_slot(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        NumenPlayer companion = spawnAt(helper, "gametest_dresser", new BlockPos(4, 2, 4), false);
        companion.getInventory().add(new ItemStack(Items.DIAMOND_HELMET));
        ToolRun wear = lua(companion, "numen.gear.wear(\"minecraft:diamond_helmet\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD)
                    .is(Items.DIAMOND_HELMET), "the helmet is not on her head");
            String said = wear.done() ? wear.outcome() : null;
            assertTrue(helper, said != null && said.contains("in head"),
                    "the reply must say where it went, got: " + said);
            CompanionFactory.despawn(level.getServer(), companion);
        });
    }

    /**
     * 丢出去的是原物:附魔镐 numen.inv.drop 之后,地上的掉落物必须还带着那条附魔。
     * 曾经按数量销毁再按种类重造,附魔/耐久/改名全部蒸发——主人递来的神器一进一出成白板。
     */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void dropped_items_keep_their_components(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        NumenPlayer companion = spawnAt(helper, "gametest_courier", new BlockPos(4, 2, 4), false);
        ItemStack pick = new ItemStack(Items.DIAMOND_PICKAXE);
        var efficiency = level.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                .getOrThrow(net.minecraft.world.item.enchantment.Enchantments.EFFICIENCY);
        pick.enchant(efficiency, 3);
        companion.getInventory().add(pick);
        // 这条测的是丢出去的是不是原物;丢东西要不要问主人另有用例,这里让主人选"全放行"
        com.dwinovo.numen.permission.Permission.setMode(companion, com.dwinovo.numen.permission.Mode.BYPASS);
        lua(companion, "numen.inv.drop(\"minecraft:diamond_pickaxe\", {count = 1})");

        succeedWhen(helper, () -> {
            var drops = level.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                    companion.getBoundingBox().inflate(8));
            assertTrue(helper, !drops.isEmpty(), "nothing was dropped");
            ItemStack landed = drops.get(0).getItem();
            assertTrue(helper, landed.is(Items.DIAMOND_PICKAXE), "wrong item dropped: " + landed);
            var enchants = net.minecraft.world.item.enchantment.EnchantmentHelper.getEnchantmentsForCrafting(landed);
            assertTrue(helper, enchants.getLevel(efficiency) == 3,
                    "the enchantment did not survive the toss: " + enchants);
            CompanionFactory.despawn(level.getServer(), companion);
        });
    }

    /**
     * 换肤走的是"改注册表 + 原地回收":休眠存盘、按注册表重建之后,GameProfile 挂上
     * textures,而 UUID 与背包(经 .dat)原样回来——换的是皮,不是人。
     * ChangeSkinPayload 对活体执行的正是这一串。
     */
    @NumenTest(template = "floor16", timeoutTicks = 400, batch = "numen_inventory")
    public static void reskin_recycle_keeps_identity_and_items(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        var server = level.getServer();
        BlockPos spawn = helper.absolutePos(new BlockPos(4, 2, 4));
        NumenPlayer first = com.dwinovo.numen.entity.Companions.summon(server, UUID.randomUUID(),
                "gametest_reskin", level,
                new Vec3(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5));
        UUID uuid = first.getUUID();
        first.getInventory().add(new ItemStack(Items.DIAMOND));
        var reg = com.dwinovo.numen.entity.CompanionRegistry.get(server);
        reg.put(uuid, reg.find(uuid).withSkin("ZmFrZQ==", ""));
        com.dwinovo.numen.entity.Companions.dormant(server, first);
        com.dwinovo.numen.entity.Companions.respawn(server, uuid);

        succeedWhen(helper, () -> {
            NumenPlayer live = NumenPlayer.findByUuid(server, uuid);
            assertTrue(helper, live != null, "the body did not come back");
            assertTrue(helper, live.getGameProfile().getProperties().containsKey("textures"),
                    "the new skin is not on the rebuilt profile");
            assertTrue(helper, live.getInventory().hasAnyMatching(s -> s.is(Items.DIAMOND)),
                    "her inventory did not survive the recycle");
            com.dwinovo.numen.entity.Companions.dismiss(server, live);
        });
    }

    // ---- craft ----

    /** 手上的 2×2 就够:两根橡木原木合出 8 块木板,原木用光,回执说合了多少。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void craft_planks_from_logs_in_hand(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_joiner", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.OAK_LOG, 2));
        ToolRun craft = lua(companion, "numen.inv.craft(\"minecraft:oak_planks\", {count = 8})");

        succeedWhen(helper, () -> {
            assertTrue(helper, craft.done(), "inv craft has not replied");
            assertTrue(helper, craft.succeeded() && Long.valueOf(8).equals(craft.field("crafted")),
                    "inv craft did not report 8 planks: " + craft.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.OAK_PLANKS) == 8
                            && companion.getInventory().countItem(Items.OAK_LOG) == 0,
                    "the inventory does not hold 8 planks and no logs");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /**
     * 3×3 的配方在她自己的 2×2 里合不了:numen.inv.craft 只用开着的格,回执叫她先开一张工作台(或交给 numen.inv.make),
     * 材料一样不动。远处那张工作台它不去找——找台、走过去是 numen.inv.make 的事(见下一条)。
     */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void craft_3x3_in_her_own_grid_says_to_open_a_table(GameTestHelper helper) {
        BlockPos table = helper.absolutePos(new BlockPos(13, 2, 13));
        helper.getLevel().setBlockAndUpdate(table, Blocks.CRAFTING_TABLE.defaultBlockState());
        NumenPlayer companion = spawnAt(helper, "gametest_seeker", new BlockPos(2, 2, 2), false);
        companion.getInventory().add(new ItemStack(Items.OAK_PLANKS, 8));
        ToolRun craft = lua(companion, "numen.inv.craft(\"minecraft:chest\", {count = 1})");

        succeedWhen(helper, () -> {
            assertTrue(helper, craft.done(), "inv craft has not replied");
            assertTrue(helper, !craft.succeeded() && craft.outcome().contains("needs a 3x3 grid; the open one is 2x2")
                            && craft.outcome().contains("numen.use.block a crafting table"),
                    "the reply does not say to open a crafting table: " + craft.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.OAK_PLANKS) == 8,
                    "the planks were touched although nothing could be crafted");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** numen.inv.make 自己找台:够得着的地方没有,它走到 16 格内最近的那张,打开、合出一口箱子,木板用光,界面合上。 */
    @NumenTest(template = "floor16", timeoutTicks = 100000, batch = "numen_inventory")
    public static void make_walks_to_the_nearest_table(GameTestHelper helper) {
        BlockPos table = helper.absolutePos(new BlockPos(13, 2, 13));
        helper.getLevel().setBlockAndUpdate(table, Blocks.CRAFTING_TABLE.defaultBlockState());
        NumenPlayer companion = spawnAt(helper, "gametest_seeker_walks", new BlockPos(2, 2, 2), false);
        companion.getInventory().add(new ItemStack(Items.OAK_PLANKS, 8));
        ToolRun make = lua(companion, "return numen.inv.make(\"minecraft:chest\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, make.done(), "inv make has not finished");
            assertTrue(helper, make.ranToTheEnd(), "make failed: " + make.receipt());
            assertTrue(helper, companion.getInventory().countItem(Items.CHEST) == 1
                            && companion.getInventory().countItem(Items.OAK_PLANKS) == 0,
                    "the inventory does not hold the chest with the planks spent");
            assertTrue(helper, companion.position().distanceTo(Vec3.atCenterOf(table)) < 6,
                    "she did not walk to the table");
            assertTrue(helper, companion.containerMenu == companion.inventoryMenu, "the crafting table was left open");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 附近没有工作台,包里有一张:numen.inv.make 把它放在身边一格,打开、合出一口箱子,界面合上,那张台留在原地。 */
    @NumenTest(template = "floor16", timeoutTicks = 100000, batch = "numen_inventory")
    public static void make_puts_down_the_table_she_carries(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_tablebearer", new BlockPos(7, 2, 7), false);
        companion.getInventory().add(new ItemStack(Items.OAK_PLANKS, 8));
        companion.getInventory().add(new ItemStack(Items.CRAFTING_TABLE));
        ToolRun make = lua(companion, "return numen.inv.make(\"minecraft:chest\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, make.done(), "inv make has not finished");
            assertTrue(helper, make.ranToTheEnd(), "make failed: " + make.receipt());
            assertTrue(helper, companion.getInventory().countItem(Items.CHEST) == 1
                            && companion.getInventory().countItem(Items.CRAFTING_TABLE) == 0,
                    "the chest was not made at the table she carried");
            boolean placed = false;
            for (BlockPos p : BlockPos.betweenClosed(helper.absolutePos(new BlockPos(5, 2, 5)),
                    helper.absolutePos(new BlockPos(9, 2, 9)))) {
                placed |= helper.getLevel().getBlockState(p).is(Blocks.CRAFTING_TABLE);
            }
            assertTrue(helper, placed, "no crafting table stands beside her");
            assertTrue(helper, companion.containerMenu == companion.inventoryMenu, "the crafting table was left open");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 工作台就在手边:numen.inv.make 右键打开、摆好、取出一口箱子,木板用光,界面合上。 */
    @NumenTest(template = "floor16", timeoutTicks = 100000, batch = "numen_inventory")
    public static void craft_3x3_at_a_table_within_reach(GameTestHelper helper) {
        helper.getLevel().setBlockAndUpdate(helper.absolutePos(new BlockPos(5, 2, 3)),
                Blocks.CRAFTING_TABLE.defaultBlockState());
        NumenPlayer companion = spawnAt(helper, "gametest_carpenter", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.OAK_PLANKS, 8));
        ToolRun craft = lua(companion, "return numen.inv.make(\"minecraft:chest\", 1)");

        succeedWhen(helper, () -> {
            assertTrue(helper, craft.done(), "inv make has not finished");
            assertTrue(helper, craft.ranToTheEnd(), "craft at the table failed: " + craft.receipt());
            assertTrue(helper, companion.getInventory().countItem(Items.CHEST) == 1
                            && companion.getInventory().countItem(Items.OAK_PLANKS) == 0,
                    "the inventory does not hold the chest with the planks spent");
            assertTrue(helper, companion.containerMenu == companion.inventoryMenu,
                    "the crafting table was left open");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 材料不够:回执写明缺什么,手里的一块不动。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void craft_short_of_materials_names_the_shortfall(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_skimper", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.OAK_PLANKS, 3));
        ToolRun craft = lua(companion, "numen.inv.craft(\"minecraft:chest\", {count = 1})");

        succeedWhen(helper, () -> {
            assertTrue(helper, craft.done(), "inv craft has not replied");
            assertTrue(helper, !craft.succeeded() && craft.outcome().contains("not enough materials")
                            && craft.outcome().contains("missing"),
                    "the reply does not name the shortfall: " + craft.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.OAK_PLANKS) == 3,
                    "the planks were touched although nothing could be crafted");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    // ---- eat ----

    /** 饿了吃面包:吃完才生效,饥饿值涨上去、面包少一个,回执报现在的饥饿值。 */
    @NumenTest(template = "floor16", timeoutTicks = 2000, batch = "numen_food")
    public static void eat_restores_hunger(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_eater", new BlockPos(3, 2, 3), false);
        companion.getFoodData().setFoodLevel(10);
        companion.getInventory().add(new ItemStack(Items.BREAD, 2));
        ToolRun eat = lua(companion, "numen.inv.eat(\"minecraft:bread\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, eat.done(), "inv eat has not finished");
            assertTrue(helper, eat.succeeded() && eat.outcome().startsWith("ate bread"),
                    "inv eat did not report the meal: " + eat.outcome());
            assertTrue(helper, companion.getFoodData().getFoodLevel() >= 15
                            && companion.getInventory().countItem(Items.BREAD) == 1,
                    "hunger is " + companion.getFoodData().getFoodLevel() + " with "
                            + companion.getInventory().countItem(Items.BREAD) + " bread left");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 吃饱了还要吃:原版不让,回执如实说吃不下,面包还在。 */
    @NumenTest(template = "floor16", timeoutTicks = 2000, batch = "numen_food")
    public static void eat_on_a_full_stomach_keeps_the_food(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_sated", new BlockPos(3, 2, 3), false);
        companion.getFoodData().setFoodLevel(20);
        companion.getInventory().add(new ItemStack(Items.BREAD, 2));
        ToolRun eat = lua(companion, "numen.inv.eat(\"minecraft:bread\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, eat.done(), "inv eat has not finished");
            assertTrue(helper, !eat.succeeded() && eat.outcome().contains("already full"),
                    "eating on a full stomach was not refused: " + eat.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.BREAD) == 2, "the bread was eaten");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 没有这个物品的合成配方:numen.inv.make 以 not_found 收场、叫她去查配方,背包不动。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void craft_something_without_a_recipe_says_so(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_dreamer", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.OAK_PLANKS, 8));
        ToolRun craft = lua(companion, "numen.inv.make(\"minecraft:bedrock\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, craft.done(), "inv make has not finished");
            assertTrue(helper, !craft.ranToTheEnd() && craft.receipt().contains("no crafting recipe makes")
                            && craft.receipt().contains("not_found"),
                    "the error does not say there is no recipe: " + craft.receipt());
            assertTrue(helper, companion.getInventory().countItem(Items.OAK_PLANKS) == 8, "the planks were touched");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 要穿的东西背包里没有:当场失败,说出缺的是什么。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void equip_something_not_carried_says_so(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_unarmed", new BlockPos(3, 2, 3), false);
        ToolRun equip = lua(companion, "numen.gear.wear(\"minecraft:iron_helmet\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear wear has not finished");
            assertTrue(helper, !equip.succeeded() && equip.outcome().contains("in inventory to equip"),
                    "the failure does not say the item is not carried: " + equip.outcome());
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    // ---- numen.gear.wear / numen.gear.remove:换下、卸甲、没地方放 ----

    /** 头上已经戴着铁头盔,再戴钻石头盔:钻石的上了头,铁的回到背包里,不掉在地上。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void equip_a_second_helmet_stows_the_first(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_milliner", new BlockPos(4, 2, 4), false);
        companion.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        companion.getInventory().add(new ItemStack(Items.DIAMOND_HELMET));
        ToolRun equip = lua(companion, "numen.gear.wear(\"minecraft:diamond_helmet\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear wear has not finished");
            assertTrue(helper, equip.succeeded() && equip.outcome().contains("in head"),
                    "the reply does not say the helmet went on her head: " + equip.outcome());
            assertTrue(helper, companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD)
                    .is(Items.DIAMOND_HELMET), "the diamond helmet is not on her head");
            assertTrue(helper, companion.getInventory().countItem(Items.IRON_HELMET) == 1,
                    "the iron helmet did not go back into her inventory");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 雕刻南瓜没有右键穿戴,但原版认它是头部装备:照样戴上头,回执说在头上。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void equip_a_carved_pumpkin_goes_on_the_head(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_scarecrow", new BlockPos(4, 2, 4), false);
        companion.getInventory().add(new ItemStack(Items.CARVED_PUMPKIN));
        ToolRun equip = lua(companion, "numen.gear.wear(\"minecraft:carved_pumpkin\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear wear has not finished");
            assertTrue(helper, equip.succeeded() && equip.outcome().contains("in head"),
                    "the reply does not say the pumpkin went on her head: " + equip.outcome());
            assertTrue(helper, companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD)
                    .is(Items.CARVED_PUMPKIN), "the pumpkin is not on her head");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 卸甲:头盔和靴子一起脱下来收进背包,两个槽都空了,回执点名脱了哪两件。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void unequip_armor_takes_every_piece_off(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_undresser", new BlockPos(4, 2, 4), false);
        companion.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        companion.setItemSlot(net.minecraft.world.entity.EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
        ToolRun unequip = lua(companion, "numen.gear.remove({slot = \"armor\"})");

        succeedWhen(helper, () -> {
            assertTrue(helper, unequip.done(), "gear remove has not finished");
            assertTrue(helper, unequip.succeeded() && unequip.outcome().startsWith("took off")
                            && unequip.outcome().contains("iron_helmet") && unequip.outcome().contains("iron_boots"),
                    "the reply does not name both pieces: " + unequip.outcome());
            assertTrue(helper, companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).isEmpty()
                            && companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.FEET).isEmpty(),
                    "some armor is still worn");
            assertTrue(helper, companion.getInventory().countItem(Items.IRON_HELMET) == 1
                            && companion.getInventory().countItem(Items.IRON_BOOTS) == 1,
                    "the armor did not go into her inventory");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 背包三十六格全满时卸头盔:没地方放就不脱,头盔还戴着,也不扔在地上;回执说背包满了。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void unequip_with_a_full_inventory_keeps_the_armor_on(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_overpacked", new BlockPos(4, 2, 4), false);
        for (int i = 0; i < 36; i++) {
            companion.getInventory().setItem(i, new ItemStack(Items.COBBLESTONE, 64));
        }
        companion.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        ToolRun unequip = lua(companion, "numen.gear.remove({slot = \"head\"})");

        succeedWhen(helper, () -> {
            assertTrue(helper, unequip.done(), "gear remove has not finished");
            assertTrue(helper, !unequip.succeeded() && unequip.outcome().contains("inventory is full"),
                    "the failure does not say the inventory is full: " + unequip.outcome());
            assertTrue(helper, companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD)
                    .is(Items.IRON_HELMET), "the helmet came off with nowhere to go");
            assertTrue(helper, helper.getLevel().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                            companion.getBoundingBox().inflate(4)).isEmpty(), "something was dropped on the ground");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 头上本来就空着还要卸:不算错,回执说没什么可脱。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void unequip_an_empty_slot_says_there_is_nothing(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_bareheaded", new BlockPos(4, 2, 4), false);
        ToolRun unequip = lua(companion, "numen.gear.remove({slot = \"head\"})");

        succeedWhen(helper, () -> {
            assertTrue(helper, unequip.done(), "gear remove has not finished");
            assertTrue(helper, unequip.succeeded() && unequip.outcome().startsWith("nothing to take off"),
                    "the reply does not say there was nothing to take off: " + unequip.outcome());
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 卸甲不说卸哪个槽:{@code --slot} 不写就是盔甲(四件甲),头盔卸进背包,手上的剑不动。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void unequip_without_a_slot_takes_off_the_armor(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_vague", new BlockPos(4, 2, 4), false);
        companion.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        companion.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
        ToolRun unequip = lua(companion, "numen.gear.remove()");

        succeedWhen(helper, () -> {
            assertTrue(helper, unequip.done(), "gear remove has not replied");
            assertTrue(helper, unequip.succeeded() && unequip.outcome().contains("took off iron_helmet (head)"),
                    "gear remove without a slot did not take the armor off: " + unequip.outcome());
            assertTrue(helper, companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).isEmpty()
                            && companion.getInventory().countItem(Items.IRON_HELMET) == 1,
                    "the helmet did not go into the backpack");
            assertTrue(helper, companion.getMainHandItem().is(Items.IRON_SWORD), "the sword in her hand came off");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** armor 只是卸下的别名(四件甲),穿戴没有这个目标:按参数错误退回,头盔还在背包里。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void wear_into_the_armor_alias_is_rejected(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_overdresser", new BlockPos(4, 2, 4), false);
        companion.getInventory().add(new ItemStack(Items.IRON_HELMET));
        ToolRun equip = lua(companion, "numen.gear.wear(\"minecraft:iron_helmet\", {slot = \"armor\"})");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear wear has not replied");
            assertTrue(helper, !equip.succeeded() && equip.outcome().contains("is only for numen.gear.remove"),
                    "the armor alias was not rejected for wearing: " + equip.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.IRON_HELMET) == 1
                            && companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).isEmpty(),
                    "the helmet moved anyway");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 穿戴不说穿什么:这一行写不通,当场失败并附上 numen.gear.wear 的用法,不派活。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void wear_without_an_item_is_rejected(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_emptyhanded", new BlockPos(4, 2, 4), false);
        ToolRun equip = lua(companion, "numen.gear.wear()");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done() && equip.task() == null, "gear wear has not replied, or dispatched work");
            assertTrue(helper, !equip.succeeded() && equip.outcome().contains("usage: numen.gear.wear(item, {slot=…})"),
                    "the rejection does not show the usage: " + equip.outcome());
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /**
     * 拿水桶不等于倒水:她低头对着地面,numen.gear.hold water_bucket 只把桶拿到主手,地上没有水、桶里的水还在。
     * 倒水是改世界的动作,只能经权限层裁决,装备这条路上不许有第二个入口。
     */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void equip_a_water_bucket_does_not_pour_it(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_waterbearer", new BlockPos(4, 2, 4), false);
        companion.setXRot(90f);
        companion.getInventory().add(new ItemStack(Items.WATER_BUCKET));
        ToolRun equip = lua(companion, "numen.gear.hold(\"minecraft:water_bucket\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear hold has not finished");
            assertTrue(helper, equip.succeeded() && equip.outcome().contains("main hand"),
                    "the reply does not say the bucket is in her main hand: " + equip.outcome());
            assertTrue(helper, companion.getMainHandItem().is(Items.WATER_BUCKET),
                    "the water bucket is not in her main hand: " + companion.getMainHandItem());
            BlockPos feet = companion.blockPosition();
            for (BlockPos p : BlockPos.betweenClosed(feet.offset(-3, -2, -3), feet.offset(3, 2, 3))) {
                assertTrue(helper, helper.getLevel().getFluidState(p).isEmpty(), "water was poured at " + p);
            }
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 拿雪球不等于扔雪球:numen.gear.hold snowball 之后四个雪球都还在,拿在主手,周围没有飞出去的雪球。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void equip_a_snowball_does_not_throw_it(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_snowkeeper", new BlockPos(4, 2, 4), false);
        companion.getInventory().add(new ItemStack(Items.SNOWBALL, 4));
        ToolRun equip = lua(companion, "numen.gear.hold(\"minecraft:snowball\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear hold has not finished");
            assertTrue(helper, equip.succeeded() && equip.outcome().contains("main hand"),
                    "the reply does not say the snowball is in her main hand: " + equip.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.SNOWBALL) == 4,
                    "a snowball left her inventory: " + companion.getInventory().countItem(Items.SNOWBALL));
            assertTrue(helper, helper.getLevel().getEntitiesOfClass(
                            net.minecraft.world.entity.projectile.Snowball.class,
                            companion.getBoundingBox().inflate(16)).isEmpty(), "a snowball was thrown");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 绑定诅咒的头盔脱不下来:卸下失败,说出原因,头盔还戴着、背包里没多出它。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void unequip_a_cursed_helmet_is_refused(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        NumenPlayer companion = spawnAt(helper, "gametest_cursed", new BlockPos(4, 2, 4), false);
        ItemStack helmet = new ItemStack(Items.IRON_HELMET);
        helmet.enchant(level.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                .getOrThrow(net.minecraft.world.item.enchantment.Enchantments.BINDING_CURSE), 1);
        companion.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, helmet);
        ToolRun unequip = lua(companion, "numen.gear.remove({slot = \"head\"})");

        succeedWhen(helper, () -> {
            assertTrue(helper, unequip.done(), "gear remove has not finished");
            assertTrue(helper, !unequip.succeeded() && unequip.outcome().contains("binding"),
                    "the failure does not name the curse of binding: " + unequip.outcome());
            assertTrue(helper, companion.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD)
                    .is(Items.IRON_HELMET), "the cursed helmet came off");
            assertTrue(helper, companion.getInventory().countItem(Items.IRON_HELMET) == 1,
                    "the cursed helmet was duplicated into her inventory");
            CompanionFactory.despawn(level.getServer(), companion);
        });
    }

    /** 盾不是穿戴物:numen.gear.hold 不点名哪只手时照原版进副手,回执说在副手。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void equip_a_shield_goes_to_the_offhand(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_shieldbearer", new BlockPos(4, 2, 4), false);
        companion.getInventory().add(new ItemStack(Items.SHIELD));
        ToolRun equip = lua(companion, "numen.gear.hold(\"minecraft:shield\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear hold has not finished");
            assertTrue(helper, equip.succeeded() && equip.outcome().contains("offhand"),
                    "the reply does not say the shield is in her off hand: " + equip.outcome());
            assertTrue(helper, companion.getOffhandItem().is(Items.SHIELD), "the shield is not in her off hand");
            assertTrue(helper, companion.getInventory().countItem(Items.SHIELD) == 1, "the shield was duplicated");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    // ---- eat:没有、不能吃、金苹果、叫停、创造 ----

    /** 背包里没有面包还要吃:当场失败,说缺的是面包。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_food")
    public static void eat_something_not_carried_says_so(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_hungry", new BlockPos(3, 2, 3), false);
        companion.getFoodData().setFoodLevel(10);
        ToolRun eat = lua(companion, "numen.inv.eat(\"minecraft:bread\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, eat.done(), "inv eat has not finished");
            assertTrue(helper, !eat.succeeded() && eat.outcome().contains("no bread in inventory"),
                    "the failure does not say there is no bread: " + eat.outcome());
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 要吃圆石:不是能吃能喝的东西,当场失败,圆石还在。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_food")
    public static void eat_something_inedible_says_so(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_gnawer", new BlockPos(3, 2, 3), false);
        companion.getFoodData().setFoodLevel(10);
        companion.getInventory().add(new ItemStack(Items.COBBLESTONE, 3));
        ToolRun eat = lua(companion, "numen.inv.eat(\"minecraft:cobblestone\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, eat.done(), "inv eat has not finished");
            assertTrue(helper, !eat.succeeded() && eat.outcome().contains("can't be eaten or drunk"),
                    "the failure does not say cobblestone is not food: " + eat.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.COBBLESTONE) == 3, "the cobblestone was used up");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 金苹果饱着也能吃(原版允许):吃掉了,身上有了伤害吸收,回执说吃了。 */
    @NumenTest(template = "floor16", timeoutTicks = 2000, batch = "numen_food")
    public static void eat_a_golden_apple_on_a_full_stomach(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_gourmet", new BlockPos(3, 2, 3), false);
        companion.getFoodData().setFoodLevel(20);
        companion.getInventory().add(new ItemStack(Items.GOLDEN_APPLE));
        ToolRun eat = lua(companion, "numen.inv.eat(\"minecraft:golden_apple\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, eat.done(), "inv eat has not finished");
            assertTrue(helper, eat.succeeded() && eat.outcome().startsWith("ate golden_apple"),
                    "the golden apple was not eaten on a full stomach: " + eat.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.GOLDEN_APPLE) == 0
                            && companion.hasEffect(net.minecraft.world.effect.MobEffects.ABSORPTION),
                    "the apple is still there or its effect is missing");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 嚼到一半主人按停止:按主人停止收场;面包一个没少,饥饿值没变,过了整段咀嚼时长也不再生效。 */
    @NumenTest(template = "floor16", timeoutTicks = 2000, batch = "numen_food")
    public static void owner_stop_mid_meal_keeps_the_food(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_interrupted", new BlockPos(3, 2, 3), false);
        companion.getFoodData().setFoodLevel(10);
        companion.getInventory().add(new ItemStack(Items.BREAD, 2));
        ToolRun eat = lua(companion, "numen.inv.eat(\"minecraft:bread\")");

        steps(helper)
                .thenIdle(10)
                .thenExecute(() -> com.dwinovo.numen.task.CompanionTickDispatcher.cancelFor(companion))
                .thenWaitUntil(() -> assertTrue(helper, eat.done() && eat.outcome().startsWith("the owner pressed Stop"),
                        "the meal did not end as stopped by the owner: " + eat.outcome()))
                .thenIdle(40)
                .thenWaitUntil(() -> assertTrue(helper, companion.getInventory().countItem(Items.BREAD) == 2
                                && companion.getFoodData().getFoodLevel() == 10,
                        "the stopped meal still took effect: " + companion.getInventory().countItem(Items.BREAD)
                                + " bread, hunger " + companion.getFoodData().getFoodLevel()))
                .thenExecute(() -> CompanionFactory.despawn(helper.getLevel().getServer(), companion))
                .thenSucceed();
    }

    /** 创造模式没有饥饿:不去吃,回执如实说用不着,面包留着。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_food")
    public static void eat_in_creative_says_there_is_no_hunger(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_immortal", new BlockPos(3, 2, 3), true);
        companion.getInventory().add(new ItemStack(Items.BREAD, 2));
        ToolRun eat = lua(companion, "numen.inv.eat(\"minecraft:bread\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, eat.done(), "inv eat has not finished");
            assertTrue(helper, !eat.succeeded() && eat.outcome().contains("creative mode has no hunger"),
                    "the reply does not say creative has no hunger: " + eat.outcome());
            assertTrue(helper, companion.getInventory().countItem(Items.BREAD) == 2, "the bread was eaten");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 箱子的配方认"任意木板":四块橡木加四块白桦木板,在手边的工作台合出一口箱子,两种木板都用光。 */
    @NumenTest(template = "floor16", timeoutTicks = 100000, batch = "numen_inventory")
    public static void craft_a_chest_from_mixed_planks(GameTestHelper helper) {
        helper.getLevel().setBlockAndUpdate(helper.absolutePos(new BlockPos(5, 2, 3)),
                Blocks.CRAFTING_TABLE.defaultBlockState());
        NumenPlayer companion = spawnAt(helper, "gametest_patchworker", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.OAK_PLANKS, 4));
        companion.getInventory().add(new ItemStack(Items.BIRCH_PLANKS, 4));
        ToolRun craft = lua(companion, "return numen.inv.make(\"minecraft:chest\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, craft.done(), "inv make has not finished");
            assertTrue(helper, craft.ranToTheEnd(), "craft from mixed planks failed: " + craft.receipt());
            assertTrue(helper, companion.getInventory().countItem(Items.CHEST) == 1
                            && companion.getInventory().countItem(Items.OAK_PLANKS) == 0
                            && companion.getInventory().countItem(Items.BIRCH_PLANKS) == 0,
                    "the chest was not made from both kinds of planks");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 背包里有什么、有几件:numen.inv.items 按种类合起来列出,numen.inv.count 数一种,没有的是 0。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void items_and_count_read_the_backpack(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_counter", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.COBBLESTONE, 64));
        companion.getInventory().add(new ItemStack(Items.COBBLESTONE, 6));
        companion.getInventory().add(new ItemStack(Items.TORCH, 3));
        ToolRun read = lua(companion, "local n = 0\nfor _, s in ipairs(numen.inv.items()) do\n"
                + "  if s.item == \"minecraft:cobblestone\" then n = s.count end\nend\n"
                + "return n .. \"/\" .. numen.inv.count(\"torch\") .. \"/\" .. numen.inv.count(\"minecraft:diamond\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, read.done(), "the program has not finished");
            assertTrue(helper, read.ranToTheEnd() && read.receipt().contains("70/3/0"),
                    "items and count do not read what she carries: " + read.receipt());
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 存进箱子再取出来:numen.inv.store 走过去放进 20 块圆石,numen.inv.fetch 取回 5 块;箱子里剩 15,界面合上。 */
    @NumenTest(template = "floor16", timeoutTicks = 100000, batch = "numen_inventory")
    public static void store_and_fetch_go_through_the_chest(GameTestHelper helper) {
        BlockPos chest = helper.absolutePos(new BlockPos(11, 2, 7));
        helper.getLevel().setBlockAndUpdate(chest, Blocks.CHEST.defaultBlockState());
        NumenPlayer companion = spawnAt(helper, "gametest_stocker", new BlockPos(3, 2, 7), false);
        companion.getInventory().add(new ItemStack(Items.COBBLESTONE, 20));
        ToolRun run = lua(companion, "local chest = " + xyz(chest) + "\nlocal put = numen.inv.store(chest, "
                + "\"cobblestone\")\nlocal took = numen.inv.fetch(chest, \"cobblestone\", 5)\nreturn put .. \"/\" .. took");

        succeedWhen(helper, () -> {
            assertTrue(helper, run.done(), "the program has not finished");
            assertTrue(helper, run.ranToTheEnd() && run.receipt().contains("20/5"),
                    "store and fetch did not move 20 and 5: " + run.receipt());
            var box = (net.minecraft.world.level.block.entity.ChestBlockEntity) helper.getLevel().getBlockEntity(chest);
            int inChest = 0;
            for (int i = 0; i < box.getContainerSize(); i++) {
                inChest += box.getItem(i).is(Items.COBBLESTONE) ? box.getItem(i).getCount() : 0;
            }
            assertTrue(helper, inChest == 15 && companion.getInventory().countItem(Items.COBBLESTONE) == 5,
                    "the chest holds " + inChest + ", she carries " + companion.getInventory().countItem(Items.COBBLESTONE));
            assertTrue(helper, companion.containerMenu == companion.inventoryMenu, "the chest was left open");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 烧两块粗铁:numen.inv.smelt 放进粗铁和一块煤,站着等烧完,取出两块铁锭,界面合上。 */
    @NumenTest(template = "floor16", timeoutTicks = 100000, batch = "numen_inventory")
    public static void smelt_loads_waits_and_takes_the_output(GameTestHelper helper) {
        BlockPos furnace = helper.absolutePos(new BlockPos(5, 2, 7));
        helper.getLevel().setBlockAndUpdate(furnace, Blocks.FURNACE.defaultBlockState());
        NumenPlayer companion = spawnAt(helper, "gametest_smelter", new BlockPos(3, 2, 7), false);
        companion.getInventory().add(new ItemStack(Items.RAW_IRON, 2));
        companion.getInventory().add(new ItemStack(Items.COAL, 4));
        ToolRun run = lua(companion, "return numen.inv.smelt(" + xyz(furnace) + ", \"raw_iron\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, run.done(), "smelt has not finished");
            assertTrue(helper, run.ranToTheEnd(), "smelt failed: " + run.receipt());
            assertTrue(helper, companion.getInventory().countItem(Items.IRON_INGOT) == 2
                            && companion.getInventory().countItem(Items.RAW_IRON) == 0
                            && companion.getInventory().countItem(Items.COAL) == 3,
                    "she does not hold the two ingots with one coal spent");
            assertTrue(helper, companion.containerMenu == companion.inventoryMenu, "the furnace was left open");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 等一会儿:numen.time.wait(1) 站着等够一秒(至少 20 刻)才回,回的是等了几秒。 */
    @NumenTest(template = "floor16", timeoutTicks = 400, batch = "numen_inventory")
    public static void time_wait_stands_for_the_time_given(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_patient", new BlockPos(3, 2, 3), false);
        long start = helper.getLevel().getGameTime();
        long[] ended = {-1};
        ToolRun wait = lua(companion, "return numen.time.wait(1)");
        helper.onEachTick(() -> {
            if (ended[0] < 0 && wait.done()) {
                ended[0] = helper.getLevel().getGameTime();
            }
        });

        succeedWhen(helper, () -> {
            assertTrue(helper, wait.done(), "time wait has not finished");
            assertTrue(helper, wait.ranToTheEnd() && wait.receipt().contains("1"), "wait failed: " + wait.receipt());
            assertTrue(helper, ended[0] - start >= 20, "she came back after " + (ended[0] - start) + " ticks");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 木棍不是穿的东西:numen.gear.wear 如实失败、叫她用 numen.gear.hold,主手不变、木棍还在包里。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void wear_a_stick_says_to_hold_it(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_stickler", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.STICK));
        companion.getInventory().setSelectedSlot(5);
        ToolRun equip = lua(companion, "numen.gear.wear(\"minecraft:stick\")");

        succeedWhen(helper, () -> {
            assertTrue(helper, equip.done(), "gear wear has not finished");
            assertTrue(helper, !equip.succeeded() && equip.outcome().contains("not something you wear")
                            && equip.outcome().contains("numen.gear.hold(\"minecraft:stick\")"),
                    "the failure does not send her to hold it: " + equip.outcome());
            assertTrue(helper, companion.getMainHandItem().isEmpty(), "her main hand changed");
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /** 拿到副手:numen.gear.hold 点名副手,火把到了副手,回执说在副手。 */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void hold_in_the_off_hand(GameTestHelper helper) {
        NumenPlayer companion = spawnAt(helper, "gametest_torchbearer", new BlockPos(3, 2, 3), false);
        companion.getInventory().add(new ItemStack(Items.TORCH, 8));
        ToolRun hold = lua(companion, "numen.gear.hold(\"minecraft:torch\", {hand = \"off\"})");

        succeedWhen(helper, () -> {
            assertTrue(helper, hold.done(), "gear hold has not finished");
            assertTrue(helper, hold.succeeded() && hold.outcome().contains("offhand")
                            && companion.getOffhandItem().is(Items.TORCH),
                    "the torch is not in her off hand: " + hold.outcome());
            CompanionFactory.despawn(helper.getLevel().getServer(), companion);
        });
    }

    /**
     * 背包满了说一次:36 格塞满石头,脚边一块泥土、一块沙子都放不下——一条 inventory_full,说的是留在地上的那一件;再等一秒也
     * 不多一条。腾出一格,她捡起其中一件把那格占上,另一件又放不下——再满一次,再来一条。没有派任何活。
     */
    @NumenTest(template = "floor16", timeoutTicks = 200, batch = "numen_inventory")
    public static void a_full_backpack_is_told_once_each_time_it_fills(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        NumenPlayer companion = spawnAt(helper, "gametest_packrat", new BlockPos(4, 2, 4), false);
        for (int slot = 0; slot < 36; slot++) {
            companion.getInventory().setItem(slot, new ItemStack(Items.STONE, 64));
        }
        Vec3 feet = companion.position();
        for (var item : java.util.List.of(Items.DIRT, Items.SAND)) {
            var drop = new net.minecraft.world.entity.item.ItemEntity(level, feet.x, feet.y, feet.z, new ItemStack(item));
            drop.setNoPickUpDelay();
            drop.setDeltaMovement(Vec3.ZERO);
            level.addFreshEntity(drop);
        }

        steps(helper)
                .thenWaitUntil(() -> assertTrue(helper, fullEvents(companion).size() == 1,
                        "not one inventory_full event: " + fullEvents(companion)))
                .thenIdle(20)
                .thenExecute(() -> {
                    java.util.List<String> told = fullEvents(companion);
                    assertTrue(helper, told.size() == 1 && told.get(0).contains("your backpack is full")
                                    && told.get(0).contains("stayed on the ground"),
                            "a full backpack was told more than once, or not as it is: " + told);
                    companion.getInventory().setItem(0, ItemStack.EMPTY);
                })
                .thenWaitUntil(() -> assertTrue(helper, fullEvents(companion).size() == 2,
                        "filling up again is not told again: " + fullEvents(companion)))
                .thenExecute(() -> {
                    ItemStack picked = companion.getInventory().getItem(0);
                    assertTrue(helper, picked.is(Items.DIRT) || picked.is(Items.SAND),
                            "the freed slot did not take what lay at her feet: " + picked);
                    CompanionFactory.despawn(level.getServer(), companion);
                })
                .thenSucceed();
    }

    /** 主人不在线,她的事件都在出箱里:其中 inventory_full 的原文。 */
    private static java.util.List<String> fullEvents(NumenPlayer companion) {
        return com.dwinovo.numen.entity.EventOutbox.get(companion.getServer()).peek(companion.getUUID()).entries()
                .stream()
                .filter(e -> com.dwinovo.numen.agent.inbox.EventTypes.INVENTORY_FULL.equals(e.type()))
                .map(com.dwinovo.numen.agent.inbox.EventQueue.Entry::text)
                .toList();
    }
}
