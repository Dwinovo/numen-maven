package com.dwinovo.numen.core.mixin;

import com.dwinovo.numen.core.act.Drops;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.class_1282;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 掉落物的两件事交给 {@link Drops}:同种的两堆并成一堆(并过去几件),挨打挨到没了(是什么打的)。原版与两个加载器都没有这两件事的
 * 事件;不跟并堆,并进别的一堆的会被当成不见了,不记伤害来源,就说不出是岩浆、火还是仙人掌毁的。
 */
@Mixin(class_1542.class)
public abstract class ItemEntityDropsMixin {

    @WrapMethod(method = "merge(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/world/item/ItemStack;"
            + "Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/world/item/ItemStack;)V")
    private static void numen$followMerge(class_1542 into, class_1799 intoStack, class_1542 from, class_1799 fromStack,
                                          Operation<Void> original) {
        int before = fromStack.method_7947();
        original.call(into, intoStack, from, fromStack);
        Drops.merged(into, from, before - fromStack.method_7947());
    }

    @Inject(method = "hurt", at = @At("RETURN"))
    private void numen$destroyed(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Drops.hurt((class_1542) (Object) this, source);
    }
}
