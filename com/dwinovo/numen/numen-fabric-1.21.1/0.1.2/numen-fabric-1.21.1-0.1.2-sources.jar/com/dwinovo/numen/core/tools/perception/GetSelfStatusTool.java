package com.dwinovo.numen.core.tools.perception;

import com.dwinovo.numen.agent.tool.Schema;
import com.dwinovo.numen.agent.tool.NumenTool;
import com.dwinovo.numen.entity.NumenPlayer;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * A query tool: runs on the body server-side and replies in place. No arguments
 * → an empty schema. The body of {@link #onServerCall} is just the perception
 * logic.
 */
public final class GetSelfStatusTool implements NumenTool {

    @Override
    public String name() {
        return "get_self_status";
    }

    /** 常驻:每轮都可能要看自己的状态。 */
    @Override
    public Residency residency() {
        return Residency.RESIDENT;
    }

    @Override
    public String description() {
        // The reflex overview rides THIS description (constitution §6): numen-api
        // exposes no system-prompt injection channel to core, but every request
        // re-reads tool descriptions, so the model sees the current roster each
        // turn. Dynamic on purpose — switched-off reflexes drop out of the text.
        String base = "Read your body's condition in one call: name, game mode, HP / max HP, "
                + "hunger / saturation, position, dimension, biome, the structures you are "
                + "standing in, what you are wearing, and movement state. ALWAYS call this before "
                + "combat or planning decisions. It does NOT list your backpack — what you carry "
                + "is already in front of you every turn; use inspect_gui when exact slots matter. "
                + "No arguments.";
        String overview = com.dwinovo.numen.task.reflex.ReflexRegistry.overview();
        return overview.isEmpty() ? base : base + "\n\n" + overview;
    }

    @Override
    public Map<String, Object> parameterSchema() {
        return Schema.none();
    }

    @Override
    public void onServerCall(String toolCallId, JsonObject args, NumenPlayer self, Consumer<String> reply) {
        JsonObject root = new JsonObject();
        root.addProperty("entity_id", self.method_5628());
        root.addProperty("name", self.method_5477().getString());
        root.addProperty("game_mode", self.field_13974.method_14257().method_8381());
        root.addProperty("hp", self.method_6032());
        root.addProperty("max_hp", self.method_6063());
        root.addProperty("hunger", self.method_7344().method_7586());
        root.addProperty("saturation", self.method_7344().method_7589());

        JsonObject pos = new JsonObject();
        pos.addProperty("x", self.method_23317());
        pos.addProperty("y", self.method_23318());
        pos.addProperty("z", self.method_23321());
        root.add("position", pos);

        root.addProperty("dimension", self.method_37908().method_27983().method_29177().toString());
        root.addProperty("biome", self.method_37908().method_23753(self.method_24515())
                .method_40230().map(k -> k.method_29177().toString()).orElse("unknown"));

        JsonArray structures = new JsonArray();
        if (self.method_37908() instanceof class_3218 sl) {
            class_2378<class_3195> reg = sl.method_30349().method_30530(class_7924.field_41246);
            for (class_3195 s : sl.method_27056().method_41037(self.method_24515()).keySet()) {
                class_2960 key = reg.method_10221(s);
                if (key != null) structures.add(key.toString());
            }
        }
        root.add("structures", structures);

        JsonObject equipment = new JsonObject();
        for (class_1304 slot : class_1304.values()) {
            class_1799 s = self.method_6118(slot);
            if (s.method_7960()) continue;
            JsonObject o = new JsonObject();
            o.addProperty("item", class_7923.field_41178.method_10221(s.method_7909()).toString());
            if (s.method_7947() > 1) o.addProperty("count", s.method_7947());
            equipment.add(slot.method_5923(), o);
        }
        root.add("equipment", equipment);

        // 背包不在这里。它是「状态」不是「事件」——工具结果会沉进对话历史,而历史里的
        // 状态永远不会过期:十轮之后她读到那份快照,上面写的还是十轮前的东西,而且和这一轮
        // 挂在请求里的实时背包对不上。全量背包只有一个来源(runtime_state 的 <inventory>),
        // 那一份永远是现在。要精确到槽位就调 inspect_gui。
        var inv = self.method_31548();
        JsonObject slots = new JsonObject();
        int used = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            if (!inv.method_5438(i).method_7960()) used++;
        }
        slots.addProperty("used", used);
        slots.addProperty("total", inv.method_5439());
        root.add("backpack_slots", slots);

        root.add("target", JsonNull.INSTANCE);
        root.addProperty("on_ground", self.method_24828());
        root.addProperty("in_water", self.method_5799());
        // Remaining breath — the one stat whose absence let a body drown while its
        // mind calmly planned an 870-block trip (frozen-ocean death, 2026-07-15).
        root.addProperty("air", self.method_5669() + "/" + self.method_5748() + " ticks");
        root.addProperty("in_lava", self.method_5771());

        reply.accept(root.toString());
    }
}
