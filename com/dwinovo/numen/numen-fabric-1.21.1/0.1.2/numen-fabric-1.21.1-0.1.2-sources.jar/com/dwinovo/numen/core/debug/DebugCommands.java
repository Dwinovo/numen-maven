package com.dwinovo.numen.core.debug;

import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2262;
import net.minecraft.class_2264;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import com.dwinovo.numen.core.tools.BlockActionOps;
import com.dwinovo.numen.core.tools.MovementOps;
import com.dwinovo.numen.entity.NumenPlayer;
import com.dwinovo.numen.network.payload.ClientUiActionPayload;
import com.dwinovo.numen.platform.Services;
import com.dwinovo.numen.task.CompanionTickDispatcher;
import com.dwinovo.numen.task.TaskDispatch;
import com.dwinovo.numen.task.TaskRecord;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

/**
 * 寻路调试命令树,并入 {@code /numen} 根:
 * <pre>
 *   /numen debug                          翻转调试模式(路径粒子渲染 + UI 文本不过滤直出)
 *   /numen profile                        翻转寻路性能探针([nav-profile] 主线程 tick 耗时按窗口汇总)
 *   /numen goto &lt;name&gt; &lt;y&gt;                该同伴走到目标高度
 *   /numen goto &lt;name&gt; &lt;x&gt; &lt;z&gt;            该同伴走到该水平位置(Y 自动落地表)
 *   /numen goto &lt;name&gt; &lt;x&gt; &lt;y&gt; &lt;z&gt;        该同伴走到精确格
 *   /numen mine &lt;name&gt; [count] &lt;block...&gt; 采集指定方块(空格分隔多个 id)
 *   /numen cancel &lt;name&gt;                  叫停该同伴当前任务
 * </pre>
 * 任务经与 LLM 工具相同的任务队列下发,占用/拒绝口径一致。
 */
public final class DebugCommands {

    private static final MovementOps MOVEMENT_TOOLS = new MovementOps();
    private static final BlockActionOps BLOCK_TOOLS = new BlockActionOps();
    /** mine 未给数量时的默认目标件数。 */
    private static final int DEFAULT_MINE_COUNT = 64;

    private DebugCommands() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("numen")
                .then(class_2170.method_9247("debug")
                        .executes(DebugCommands::toggleDebug))
                .then(class_2170.method_9247("profile")
                        .executes(DebugCommands::toggleProfile))
                .then(class_2170.method_9247("pad")
                        .executes(DebugCommands::togglePad))
                .then(class_2170.method_9247("goto")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                                .suggests(DebugCommands::suggestCompanions)
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(DebugCommands::gotoPos))
                                .then(class_2170.method_9244("column", class_2264.method_9701())
                                        .executes(DebugCommands::gotoColumn))
                                .then(class_2170.method_9244("level", IntegerArgumentType.integer())
                                        .executes(DebugCommands::gotoLevel))
                                .then(class_2170.method_9244("block", StringArgumentType.word())
                                        .suggests(DebugCommands::suggestBlocks)
                                        .executes(DebugCommands::gotoNearestBlock))))
                .then(class_2170.method_9247("mine")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                                .suggests(DebugCommands::suggestCompanions)
                                .then(class_2170.method_9244("blocks", StringArgumentType.greedyString())
                                        .suggests(DebugCommands::suggestBlocksGreedy)
                                        .executes(DebugCommands::mine))))
                .then(class_2170.method_9247("cancel")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                                .suggests(DebugCommands::suggestCompanions)
                                .executes(DebugCommands::cancel))));
    }

    // ==================== 补全 ====================

    /** 调用者名下同伴的名字。 */
    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions>
            suggestCompanions(CommandContext<class_2168> ctx,
                              com.mojang.brigadier.suggestion.SuggestionsBuilder builder) {
        class_3222 caller = ctx.getSource().method_44023();
        if (caller != null) {
            for (class_3222 p : caller.method_37908().method_8503().method_3760().method_14571()) {
                if (p instanceof NumenPlayer np && np.isOwnedByPlayer(caller.method_5667())) {
                    builder.suggest(p.method_5477().getString());
                }
            }
        }
        return builder.buildFuture();
    }

    /** 全部方块 id(单 token 参数用)。 */
    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions>
            suggestBlocks(CommandContext<class_2168> ctx,
                          com.mojang.brigadier.suggestion.SuggestionsBuilder builder) {
        return class_2172.method_9270(
                net.minecraft.class_7923.field_41175.method_10235(), builder);
    }

    /** 贪婪参数里补全最后一个 token(mine 的多方块清单用)。 */
    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions>
            suggestBlocksGreedy(CommandContext<class_2168> ctx,
                                com.mojang.brigadier.suggestion.SuggestionsBuilder builder) {
        var offset = builder.createOffset(builder.getInput().lastIndexOf(' ') + 1);
        return class_2172.method_9270(
                net.minecraft.class_7923.field_41175.method_10235(), offset);
    }

    // ==================== debug 开关 ====================

    private static int toggleDebug(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 caller = ctx.getSource().method_9207();
        boolean on = PathDebug.toggle(caller.method_5667());
        Services.NETWORK.sendToPlayer(caller, new ClientUiActionPayload(on
                ? ClientUiActionPayload.Action.DEBUG_TEXT_ON
                : ClientUiActionPayload.Action.DEBUG_TEXT_OFF));
        ctx.getSource().method_9226(() -> class_2561.method_43470(
                on ? "调试模式已开:路径粒子渲染 + UI 文本不过滤直出"
                   : "调试模式已关"), false);
        return 1;
    }

    /** 翻转寻路性能探针;开启后 NavProfiler 按 ~5 秒窗口把 [nav-profile] 汇总打到服务端日志。 */
    private static int toggleProfile(CommandContext<class_2168> ctx) {
        var settings = com.dwinovo.numen.core.pathing.settings.NavSettings.get();
        settings.profile = !settings.profile;
        boolean on = settings.profile;
        // Start each profiling session from a clean window/baseline (no skewed first line across toggles).
        com.dwinovo.numen.core.pathing.util.NavProfiler.reset();
        ctx.getSource().method_9226(() -> class_2561.method_43470(on
                ? "寻路性能探针已开:日志看 [nav-profile](主线程 tick 耗时按窗口汇总)"
                : "寻路性能探针已关"), false);
        return 1;
    }

    /** 翻转同伴区块加载 pad(诊断 A/B 用):关掉后同伴不再自持加载票据,只能在别人(玩家)
     *  保持加载的区块里活动;已有票据 40 tick 内自然过期。 */
    private static int togglePad(CommandContext<class_2168> ctx) {
        boolean on = !com.dwinovo.numen.entity.CompanionChunkLoader.enabled;
        com.dwinovo.numen.entity.CompanionChunkLoader.enabled = on;
        ctx.getSource().method_9226(() -> class_2561.method_43470(on
                ? "同伴加载 pad 已开(默认状态)"
                : "同伴加载 pad 已关:同伴仅在玩家加载的区块内活动(诊断用)"), false);
        return 1;
    }

    // ==================== goto ====================

    /** goto <名> <x> <y> <z>(BlockPos 参数,支持 ~ 相对与准星坐标补全)。 */
    private static int gotoPos(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        NumenPlayer companion = requireCompanion(ctx);
        if (companion == null) {
            return 0;
        }
        class_2338 pos = class_2262.method_48299(ctx, "pos");
        return dispatchMoveTo(ctx, companion,
                (double) pos.method_10263(), (double) pos.method_10264(), (double) pos.method_10260(), null);
    }

    /** goto <名> <x> <z>(列坐标,支持 ~;Y 自动落地表)。 */
    private static int gotoColumn(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        NumenPlayer companion = requireCompanion(ctx);
        if (companion == null) {
            return 0;
        }
        var col = class_2264.method_9702(ctx, "column");
        return dispatchMoveTo(ctx, companion, (double) col.comp_638(), null, (double) col.comp_639(), null);
    }

    /** goto <名> <y>(仅高度)。 */
    private static int gotoLevel(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        NumenPlayer companion = requireCompanion(ctx);
        if (companion == null) {
            return 0;
        }
        int y = IntegerArgumentType.getInteger(ctx, "level");
        return dispatchMoveTo(ctx, companion, null, (double) y, null, null);
    }

    /** goto <名> <方块id>(走到最近的一个旁边,带注册表补全)。 */
    private static int gotoNearestBlock(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        NumenPlayer companion = requireCompanion(ctx);
        if (companion == null) {
            return 0;
        }
        return dispatchMoveTo(ctx, companion, null, null, null,
                StringArgumentType.getString(ctx, "block"));
    }

    private static int dispatchMoveTo(CommandContext<class_2168> ctx, NumenPlayer companion,
                                      Double x, Double y, Double z, String block) {
        TaskRecord record;
        try {
            // 调试台是主人自己的手:开路许可给满,和模型那一侧的默认值无关
            record = (TaskRecord) MOVEMENT_TOOLS.moveTo(x, y, z, block, true,
                    TaskDispatch.ctx("debug-goto", companion));
        } catch (IllegalArgumentException e) {
            ctx.getSource().method_9213(class_2561.method_43470(e.getMessage()));
            return 0;
        }
        TaskDispatch.runSync(companion, record, reply ->
                ctx.getSource().method_9213(class_2561.method_43470(reply)));
        ctx.getSource().method_9226(() -> class_2561.method_43470(
                companion.method_5477().getString() + " ← " + record.describe()), false);
        return 1;
    }

    // ==================== mine / cancel ====================

    private static int mine(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        NumenPlayer companion = requireCompanion(ctx);
        if (companion == null) {
            return 0;
        }
        // 参数形态:[count] <block id...>——首 token 是数字则作数量
        List<String> tokens = Arrays.asList(
                StringArgumentType.getString(ctx, "blocks").trim().split("\\s+"));
        int count = DEFAULT_MINE_COUNT;
        List<String> blockIds = tokens;
        if (!tokens.isEmpty() && tokens.get(0).matches("\\d+")) {
            count = Integer.parseInt(tokens.get(0));
            blockIds = tokens.subList(1, tokens.size());
        }
        if (blockIds.isEmpty()) {
            ctx.getSource().method_9213(class_2561.method_43470("至少给一个方块 id"));
            return 0;
        }
        TaskRecord record;
        try {
            record = BLOCK_TOOLS.autoMine(blockIds, count,
                    TaskDispatch.ctx("debug-mine", companion));
        } catch (IllegalArgumentException e) {
            ctx.getSource().method_9213(class_2561.method_43470(e.getMessage()));
            return 0;
        }
        // 调试命令不走工具层,没有原始 args —— 传 null 就是"这件活不持久化",
        // 重启后不会被莫名其妙地接回来。
        TaskDispatch.setTask(companion, record, null, reply ->
                ctx.getSource().method_9226(() -> class_2561.method_43470(reply), false));
        return 1;
    }

    private static int cancel(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        NumenPlayer companion = requireCompanion(ctx);
        if (companion == null) {
            return 0;
        }
        CompanionTickDispatcher.stopActive(companion, "stopped by command");
        ctx.getSource().method_9226(() -> class_2561.method_43470(
                companion.method_5477().getString() + " 的当前任务已叫停"), false);
        return 1;
    }

    // ==================== 同伴定位 ====================

    /** 按名字找调用者拥有的同伴;找不到发失败提示并返回 null。 */
    private static NumenPlayer requireCompanion(CommandContext<class_2168> ctx)
            throws CommandSyntaxException {
        String name = StringArgumentType.getString(ctx, "name");
        class_3222 owner = ctx.getSource().method_9207();
        for (class_3222 p : owner.method_37908().method_8503().method_3760().method_14571()) {
            if (p instanceof NumenPlayer np && np.isOwnedByPlayer(owner.method_5667())
                    && np.method_5477().getString().equals(name)) {
                return np;
            }
        }
        ctx.getSource().method_9213(class_2561.method_43470("没有名为 '" + name + "' 的同伴"));
        return null;
    }
}
