package com.dwinovo.numen.core.task.interact;
import com.dwinovo.numen.core.task.MouseButton;

import com.dwinovo.numen.task.TaskRecord;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

/**
 * Typed descriptor for {@code interact_at} — the point-aimed half of the native
 * crosshair interaction (the BLOCK and AIR columns of vanilla's
 * {@code startAttack}/{@code startUseItem}; the ENTITY column is {@code interact_entity}).
 *
 * <p>Aim at a world point and press a mouse button; the native raytrace resolves whatever
 * is actually under the aim:
 * <ul>
 *   <li>{@link Button#LEFT} (attack): break the block hit (held until gone); air = nothing.</li>
 *   <li>{@link Button#RIGHT} (use): activate the block hit (lever / door / modded machine), or
 *       — when the aim is clear air — use the held item in that direction (throw an ender
 *       pearl, eat, draw a bow).</li>
 * </ul>
 * {@code aim} null = use the body's CURRENT facing (in-air use with no target, e.g. eating).
 * {@code holdTicks}: 0 = a single press; &gt;0 = hold that many ticks (modded crank / bow draw);
 * -1 = hold until the action self-completes or the task times out.
 */
public final class InteractAtTaskRecord extends TaskRecord {

    public static final String TOOL_NAME = "interact_at";

    public final MouseButton button;
    public final class_2338 aim;     // null → current facing (in-air use)
    public final int holdTicks;
    public final class_1792 item;        // null → use whatever is already in hand; else equip this first

    public InteractAtTaskRecord(String toolCallId, long deadlineGameTime,
                                MouseButton button, class_2338 aim, int holdTicks, class_1792 item) {
        super(TOOL_NAME, toolCallId, deadlineGameTime);
        this.button = button;
        this.aim = aim != null ? aim.method_10062() : null;
        this.holdTicks = holdTicks;
        this.item = item;
    }

    /**
     * Why {@code item} must not be used through the fake-player body, or {@code null} if it's fine.
     * The companion is a WORLD actuator: a consumable would feed the fake player (no heal, wasted),
     * and an ender pearl's landing teleports its OWNER — body-bound and undefined for a fake player.
     */
    public static String bodyBoundReason(class_1792 item) {
        if (item == null) {
            return null;
        }
        if (item.method_57347().method_57832(class_9334.field_50075)) {
            return class_7923.field_41178.method_10221(item).method_12832()
                    + " is a consumable — use eat (using it through the world body wouldn't heal you).";
        }
        if (item == class_1802.field_8634) {
            return "ender_pearl teleportation is body-bound and not supported — to travel use goto, "
                    + "to find a stronghold use locate_structure(\"minecraft:stronghold\").";
        }
        return null;
    }

    @Override
    public String describe() {
        return TOOL_NAME + " " + (button == MouseButton.LEFT ? "left" : "right")
                + (item != null ? " " + class_7923.field_41178.method_10221(item).method_12832() : "")
                + (aim != null ? " @" + aim.method_10263() + "," + aim.method_10264() + "," + aim.method_10260() : " (forward)")
                + (holdTicks != 0 ? " hold=" + holdTicks : "");
    }
}
