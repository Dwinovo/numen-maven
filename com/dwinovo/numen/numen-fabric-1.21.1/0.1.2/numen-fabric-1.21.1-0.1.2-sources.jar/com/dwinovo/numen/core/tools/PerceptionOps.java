package com.dwinovo.numen.core.tools;

import com.dwinovo.numen.entity.NumenPlayer;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_7923;

/**
 * Perception tool implementations — the business half of {@code InspectBlockTool},
 * {@code GetOwnerStatusTool} and {@code GetWorldInfoTool}, which own the LLM-facing
 * name / description / schema and delegate here.
 */
public final class PerceptionOps {

    /** Vanilla {@code block_interaction_range} for players is 4.5. */
    private static final double REACH_SQR = 4.5 * 4.5;

    @SuppressWarnings("deprecation")  // BlockBehaviour.isSolid() carries Mojang's
                                     // "deprecated for override" marker, not phased out.
    public String inspectBlock(int x,
int y,
int z,
                               NumenPlayer self) {
        class_2338 pos = new class_2338(x, y, z);
        class_2680 state = self.method_37908().method_8320(pos);

        JsonObject root = new JsonObject();
        root.addProperty("x", x);
        root.addProperty("y", y);
        root.addProperty("z", z);
        root.addProperty("block", class_7923.field_41175.method_10221(state.method_26204()).toString());
        // Block-state properties (e.g. end_portal_frame's has_eye/facing, so the
        // model can tell which of the 12 frames still need an ender_eye; stairs
        // facing; etc.). Omitted when the block has no properties.
        if (!state.method_28501().isEmpty()) {
            JsonObject props = new JsonObject();
            for (class_2769<?> p : state.method_28501()) {
                props.addProperty(p.method_11899(), propValue(state, p));
            }
            root.add("properties", props);
        }
        root.addProperty("is_air", state.method_26215());
        root.addProperty("is_solid", state.method_51367());
        root.addProperty("is_liquid", !state.method_26227().method_15769());

        float hardness = state.method_26214(self.method_37908(), pos);
        root.addProperty("hardness", hardness);
        root.addProperty("unbreakable", hardness < 0);

        boolean needsTool = state.method_29291();
        root.addProperty("needs_correct_tool", needsTool);
        class_1799 hand = self.method_6047();
        boolean handIsRightTool = hand.method_7951(state);
        root.addProperty("current_hand_correct_tool", handIsRightTool);

        if (!state.method_26215() && hardness >= 0) {
            float toolSpeed = hand.method_7924(state);
            if (toolSpeed <= 0.0F) toolSpeed = 1.0F;
            // Vanilla rule: a block that doesn't require the correct tool
            // always uses the fast divisor.
            boolean fast = !needsTool || handIsRightTool;
            float divisor = fast ? 30.0F : 100.0F;
            int ticks = hardness == 0.0F
                    ? 1
                    : Math.max(1, (int) Math.ceil(hardness * divisor / toolSpeed));
            root.addProperty("estimated_mining_ticks", ticks);
        }

        class_243 center = class_243.method_24953(pos);
        double distSqr = self.method_5707(center);
        root.addProperty("distance_to_me", Math.sqrt(distSqr));
        root.addProperty("in_reach", distSqr <= REACH_SQR);

        return root.toString();
    }

    /** Serialized value of one block-state property (e.g. "true", "north"). */
    private static <T extends Comparable<T>> String propValue(class_2680 state, class_2769<T> p) {
        return p.method_11901(state.method_11654(p));
    }

    public String getOwnerStatus(NumenPlayer self) {
        JsonObject root = new JsonObject();
        java.util.UUID ownerUuid = self.getOwnerUuid();
        if (ownerUuid == null) {
            root.addProperty("online", false);
            root.addProperty("message", "no owner (untamed)");
            return root.toString();
        }
        root.addProperty("owner_uuid", ownerUuid.toString());

        // Server-wide resolution: vanilla getOwner() is scoped to the PET's
        // level and would report a cross-dimension owner as "offline".
        class_1657 player = self.resolveOwnerPlayer();
        if (player == null) {
            root.addProperty("online", false);
            root.addProperty("message", "owner offline");
            return root.toString();
        }

        root.addProperty("online", true);
        root.addProperty("name", player.method_5477().getString());
        root.addProperty("hp", player.method_6032());
        root.addProperty("max_hp", player.method_6063());
        root.addProperty("hunger", player.method_7344().method_7586());
        root.addProperty("saturation", player.method_7344().method_7589());

        JsonObject pos = new JsonObject();
        pos.addProperty("x", player.method_23317());
        pos.addProperty("y", player.method_23318());
        pos.addProperty("z", player.method_23321());
        root.add("position", pos);

        boolean sameDimension = self.method_37908().method_27983().equals(player.method_37908().method_27983());
        root.addProperty("same_dimension", sameDimension);
        root.addProperty("owner_dimension", player.method_37908().method_27983().method_29177().toString());
        if (sameDimension) {
            root.addProperty("distance_to_me", self.method_5739(player));
        } else {
            root.addProperty("note", "owner is in a different dimension — their "
                    + "position is in THAT dimension's coordinates, not yours");
        }
        root.addProperty("main_hand", itemKey(player.method_6047()));
        root.addProperty("off_hand", itemKey(player.method_6079()));

        return root.toString();
    }

    private static String itemKey(class_1799 stack) {
        if (stack.method_7960()) return "minecraft:air";
        return class_7923.field_41178.method_10221(stack.method_7909()).toString();
    }

    public String getWorldInfo(NumenPlayer self) {
        var level = self.method_37908();

        JsonObject root = new JsonObject();
        root.addProperty("dimension", level.method_27983().method_29177().toString());
        root.addProperty("game_time", level.method_8401().method_188());
        root.addProperty("is_bright_outside", level.method_8530());
        root.addProperty("is_dark_outside", level.method_23886());

        String weather;
        if (level.method_8546()) weather = "thunder";
        else if (level.method_8419()) weather = "rain";
        else weather = "clear";
        root.addProperty("weather", weather);

        return root.toString();
    }
}
